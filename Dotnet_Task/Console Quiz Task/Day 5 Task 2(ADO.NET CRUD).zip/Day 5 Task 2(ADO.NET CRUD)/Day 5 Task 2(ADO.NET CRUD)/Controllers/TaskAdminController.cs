﻿// Controllers/TaskAdminController.cs
using Day_5_Task_2_ADO.NET_CRUD_.Models;
using Microsoft.AspNetCore.Mvc;
using static Day_5_Task_2_ADO.NET_CRUD_.Repositories.ITaskRepository;

public class TaskAdminController : Controller
{
    private readonly ITaskRepository _taskRepository;

    public TaskAdminController(ITaskRepository taskRepository)
    {
        _taskRepository = taskRepository;
    }

    // GET: /Admin/Tasks
    public IActionResult Index(string sortOrder, string statusFilter)
    {
        ViewData["TitleSortParam"] = string.IsNullOrEmpty(sortOrder) ? "title_desc" : "";
        ViewData["DateSortParam"] = sortOrder == "date" ? "date_desc" : "date";
        ViewData["StatusSortParam"] = sortOrder == "status" ? "status_desc" : "status";
        ViewData["CurrentStatusFilter"] = statusFilter;

        var tasks = _taskRepository.GetAllTasks();

        // Apply status filter
        if (!string.IsNullOrEmpty(statusFilter))
        {
            tasks = tasks.Where(t => t.Status == statusFilter);
        }

        // Apply sorting
        tasks = sortOrder switch
        {
            "title_desc" => tasks.OrderByDescending(t => t.Title),
            "date" => tasks.OrderBy(t => t.DueDate),
            "date_desc" => tasks.OrderByDescending(t => t.DueDate),
            "status" => tasks.OrderBy(t => t.Status),
            "status_desc" => tasks.OrderByDescending(t => t.Status),
            _ => tasks.OrderBy(t => t.Title),
        };

        return View(tasks);
    }

    // GET: /Admin/Tasks/Details/5
    public IActionResult Details(int id)
    {
        var task = _taskRepository.GetTaskById(id);
        if (task == null)
        {
            return NotFound();
        }

        return View(task);
    }

    // GET: /Admin/Tasks/Create
    public IActionResult Create()
    {
        ViewBag.Statuses = new List<string> { "Pending", "In Progress", "Completed" };
        return View();
    }

    // POST: /Admin/Tasks/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(TaskModel task)
    {
        if (ModelState.IsValid)
        {
            _taskRepository.AddTask(task);
            TempData["SuccessMessage"] = "Task created successfully!";
            return RedirectToAction(nameof(Index));
        }

        ViewBag.Statuses = new List<string> { "Pending", "In Progress", "Completed" };
        return View(task);
    }

    // GET: /Admin/Tasks/Edit/5
    public IActionResult Edit(int id)
    {
        var task = _taskRepository.GetTaskById(id);
        if (task == null)
        {
            return NotFound();
        }

        ViewBag.Statuses = new List<string> { "Pending", "In Progress", "Completed" };
        return View(task);
    }

    // POST: /Admin/Tasks/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(int id, TaskModel task)
    {
        if (id != task.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            _taskRepository.UpdateTask(task);
            TempData["SuccessMessage"] = "Task updated successfully!";
            return RedirectToAction(nameof(Index));
        }

        ViewBag.Statuses = new List<string> { "Pending", "In Progress", "Completed" };
        return View(task);
    }

    // GET: /Admin/Tasks/Delete/5
    public IActionResult Delete(int id)
    {
        var task = _taskRepository.GetTaskById(id);
        if (task == null)
        {
            return NotFound();
        }

        return View(task);
    }

    // POST: /Admin/Tasks/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteConfirmed(int id)
    {
        _taskRepository.DeleteTask(id);
        TempData["SuccessMessage"] = "Task deleted successfully!";
        return RedirectToAction(nameof(Index));
    }
}