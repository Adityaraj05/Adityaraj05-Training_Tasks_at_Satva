﻿using Day_5_Task_2_ADO.NET_CRUD_.Models;
using System.Data;
using System.Data.SqlClient;

namespace Day_5_Task_2_ADO.NET_CRUD_.Repositories
{
    public interface ITaskRepository
    {

        // Repositories/ITaskRepository.cs
        public interface ITaskRepository
        {
            IEnumerable<TaskModel> GetAllTasks();
            TaskModel GetTaskById(int id);
            int AddTask(TaskModel task);
            void UpdateTask(TaskModel task);
            void DeleteTask(int id);
        }

        // Repositories/TaskRepository.cs (Using SQL Commands)
        public class TaskRepository : ITaskRepository
        {
            private readonly string _connectionString;

            public TaskRepository(IConfiguration configuration)
            {
                _connectionString = configuration.GetConnectionString("DefaultConnection");
            }

            public IEnumerable<TaskModel> GetAllTasks()
            {
                List<TaskModel> tasks = new List<TaskModel>();

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("SELECT * FROM Tasks ORDER BY DueDate", connection);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            tasks.Add(new TaskModel
                            {
                                Id = (int)reader["Id"],
                                Title = reader["Title"].ToString(),
                                Description = reader["Description"]?.ToString(),
                                DueDate = reader["DueDate"] != DBNull.Value ? (DateTime?)reader["DueDate"] : null,
                                Status = reader["Status"].ToString()
                            });
                        }
                    }
                }

                return tasks;
            }

            public TaskModel GetTaskById(int id)
            {
                TaskModel task = null;

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("SELECT * FROM Tasks WHERE Id = @Id", connection);
                    command.Parameters.AddWithValue("@Id", id);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            task = new TaskModel
                            {
                                Id = (int)reader["Id"],
                                Title = reader["Title"].ToString(),
                                Description = reader["Description"]?.ToString(),
                                DueDate = reader["DueDate"] != DBNull.Value ? (DateTime?)reader["DueDate"] : null,
                                Status = reader["Status"].ToString()
                            };
                        }
                    }
                }

                return task;
            }

            public int AddTask(TaskModel task)
            {
                int newId = 0;

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand(
                        "INSERT INTO Tasks (Title, Description, DueDate, Status) VALUES (@Title, @Description, @DueDate, @Status); SELECT SCOPE_IDENTITY();",
                        connection
                    );

                    command.Parameters.AddWithValue("@Title", task.Title);
                    command.Parameters.AddWithValue("@Description", (object)task.Description ?? DBNull.Value);
                    command.Parameters.AddWithValue("@DueDate", (object)task.DueDate ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Status", task.Status);

                    connection.Open();
                    newId = Convert.ToInt32(command.ExecuteScalar());
                }

                return newId;
            }

            public void UpdateTask(TaskModel task)
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand(
                        "UPDATE Tasks SET Title = @Title, Description = @Description, DueDate = @DueDate, Status = @Status WHERE Id = @Id",
                        connection
                    );

                    command.Parameters.AddWithValue("@Id", task.Id);
                    command.Parameters.AddWithValue("@Title", task.Title);
                    command.Parameters.AddWithValue("@Description", (object)task.Description ?? DBNull.Value);
                    command.Parameters.AddWithValue("@DueDate", (object)task.DueDate ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Status", task.Status);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            public void DeleteTask(int id)
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("DELETE FROM Tasks WHERE Id = @Id", connection);
                    command.Parameters.AddWithValue("@Id", id);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        // Repositories/TaskStoredProcedureRepository.cs (Using Stored Procedures)
        public class TaskStoredProcedureRepository : ITaskRepository
        {
            private readonly string _connectionString;

            public TaskStoredProcedureRepository(IConfiguration configuration)
            {
                _connectionString = configuration.GetConnectionString("DefaultConnection");
            }

            public IEnumerable<TaskModel> GetAllTasks()
            {
                List<TaskModel> tasks = new List<TaskModel>();

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("spGetAllTasks", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            tasks.Add(new TaskModel
                            {
                                Id = (int)reader["Id"],
                                Title = reader["Title"].ToString(),
                                Description = reader["Description"]?.ToString(),
                                DueDate = reader["DueDate"] != DBNull.Value ? (DateTime?)reader["DueDate"] : null,
                                Status = reader["Status"].ToString()
                            });
                        }
                    }
                }

                return tasks;
            }

            public TaskModel GetTaskById(int id)
            {
                TaskModel task = null;

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("spGetTaskById", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", id);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            task = new TaskModel
                            {
                                Id = (int)reader["Id"],
                                Title = reader["Title"].ToString(),
                                Description = reader["Description"]?.ToString(),
                                DueDate = reader["DueDate"] != DBNull.Value ? (DateTime?)reader["DueDate"] : null,
                                Status = reader["Status"].ToString()
                            };
                        }
                    }
                }

                return task;
            }

            public int AddTask(TaskModel task)
            {
                int newId = 0;

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("spAddTask", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Title", task.Title);
                    command.Parameters.AddWithValue("@Description", (object)task.Description ?? DBNull.Value);
                    command.Parameters.AddWithValue("@DueDate", (object)task.DueDate ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Status", task.Status);

                    connection.Open();
                    newId = Convert.ToInt32(command.ExecuteScalar());
                }

                return newId;
            }

            public void UpdateTask(TaskModel task)
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("spUpdateTask", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Id", task.Id);
                    command.Parameters.AddWithValue("@Title", task.Title);
                    command.Parameters.AddWithValue("@Description", (object)task.Description ?? DBNull.Value);
                    command.Parameters.AddWithValue("@DueDate", (object)task.DueDate ?? DBNull.Value);
                    command.Parameters.AddWithValue("@Status", task.Status);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            public void DeleteTask(int id)
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("spDeleteTask", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", id);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
