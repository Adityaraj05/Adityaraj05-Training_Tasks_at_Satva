﻿namespace Task5._3.Models
{
    public class AppSettings
    {
        public string AppName { get; set; }
        public string Version { get; set; }
    }
}
