import React, { useEffect } from 'react';
import { Drawer, Form, Input, Button, FormInstance, Select } from 'antd';

interface CustomerData {
    id: string;
    displayName: string;
    companyName: string;
    phone: string;
    balance: number;
    email?: string;
    // Renamed to match backend field names
    billingLine1?: string;
    billingCity?: string;
    billingState?: string;
    billingPostalCode?: string;
    billingCountry?: string;
    companySource?: string;
    xeroContactId?: string;
    xeroTenantId?: string;
}

interface CustomerDrawerProps {
    visible: boolean;
    onClose: () => void;
    onSubmit: () => void;
    editingCustomer: CustomerData | null;
    form: FormInstance;
    submitting: boolean;
}

const CustomerDrawer: React.FC<CustomerDrawerProps> = ({
    visible,
    onClose,
    onSubmit,
    editingCustomer,
    form,
    submitting
}) => {
    // Set form values when editingCustomer changes
    useEffect(() => {
        if (editingCustomer && visible) {
            form.setFieldsValue({
                ...editingCustomer
            });
        } else if (!editingCustomer && visible) {
            form.resetFields();
        }
    }, [editingCustomer, form, visible]);

    return (
        <Drawer
            title={editingCustomer ? 'Edit Customer' : 'Add New Customer'}
            placement="right"
            width={500}
            onClose={onClose}
            open={visible}
            extra={
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Button onClick={onClose} style={{ marginRight: 8 }}>
                        Cancel
                    </Button>
                    <Button type="primary" onClick={onSubmit} loading={submitting}>
                        Save
                    </Button>
                </div>
            }
        >
            <Form
                form={form}
                layout="vertical"
                requiredMark={true}
            >
                {/* Preserving xeroContactId if it exists */}
                {editingCustomer?.xeroContactId && (
                    <Form.Item
                        name="xeroContactId"
                        hidden={true}
                    >
                        <Input type="hidden" />
                    </Form.Item>
                )}

                {/* Preserving xeroTenantId if it exists */}
                {editingCustomer?.xeroTenantId && (
                    <Form.Item
                        name="xeroTenantId"
                        hidden={true}
                    >
                        <Input type="hidden" />
                    </Form.Item>
                )}

                {/* Source field - disabled when editing */}
                <Form.Item
                    name="companySource"
                    label="Source"
                >
                    <Select disabled={!!editingCustomer}>
                        <Select.Option value="QuickBooks">QuickBooks</Select.Option>
                        <Select.Option value="Xero">Xero</Select.Option>
                    </Select>
                </Form.Item>

                <Form.Item
                    name="displayName"
                    label="Display Name"
                    rules={[{ required: true, message: 'Please enter the display name!' }]}
                >
                    <Input placeholder="Enter display name" />
                </Form.Item>

                <Form.Item
                    name="companyName"
                    label="Company Name"
                >
                    <Input placeholder="Enter company name" />
                </Form.Item>

                <Form.Item
                    name="email"
                    label="Email"
                    rules={[
                        { required: false, message: 'Please enter an email!' },
                        {
                            pattern: /^[a-zA-Z0-9](\.?[a-zA-Z0-9_-]+)*@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$/,
                            message: 'Please enter a valid email address!'
                        }
                    ]}
                >
                    <Input placeholder="Enter email" />
                </Form.Item>


                <Form.Item
                    name="phone"
                    label="Phone"
                >
                    <Input placeholder="Enter phone number" />
                </Form.Item>

                {/* Billing Address */}

                <Form.Item
                    name="billingLine1"
                    label="Billing Street"
                >
                    <Input placeholder="Enter street address" />
                </Form.Item>

                <Form.Item
                    name="billingCity"
                    label="City"
                >
                    <Input placeholder="Enter city" />
                </Form.Item>

                <Form.Item
                    name="billingState"
                    label="State/Province"
                >
                    <Input placeholder="Enter state or province" />
                </Form.Item>

                <Form.Item
                    name="billingPostalCode"
                    label="ZIP/Postal Code"
                >
                    <Input placeholder="Enter ZIP or postal code" />
                </Form.Item>

                <Form.Item
                    name="billingCountry"
                    label="Country"
                >
                    <Input placeholder="Enter country" />
                </Form.Item>
            </Form>
        </Drawer>
    );
};

export default CustomerDrawer;