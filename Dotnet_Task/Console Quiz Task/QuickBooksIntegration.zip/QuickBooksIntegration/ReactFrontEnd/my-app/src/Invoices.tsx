import React, { useState, useEffect } from "react";
import { Table, Button, Spin, Empty, message, Popconfirm, Modal } from "antd";
import {
  PlusOutlined,
  DownloadOutlined,
  LoadingOutlined,
  DeleteOutlined,
  EditOutlined,
} from "@ant-design/icons";
import SearchBar from "./SearchBar";
import InvoiceModal from "./InvoiceModal";
import axios from "axios";
import "./ChartOfAccount.css";

const antIcon = (
  <LoadingOutlined style={{ fontSize: 24, color: "#00A551" }} spin />
);

const Invoice = () => {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [mode, setMode] = useState("add");
  const [customerData, setCustomerData] = useState([]);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });

  useEffect(() => {
    fetchInvoices(1, pagination.pageSize);
  }, []);

  const fetchInvoices = async (page, pageSize) => {
    setLoading(true);
    try {
      const response = await fetch(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/invoice/fetch-from-db-paginated?page=${page}&pageSize=${pageSize}${
          searchTerm ? `&searchTerm=${encodeURIComponent(searchTerm)}` : ""
        }`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch invoices");
      }

      const data = await response.json();
      const invoiceItems = Array.isArray(data.items) ? data.items : [];
      const totalCount = data.totalCount || 0;
      console.log("Invoice items from backend:", invoiceItems);
      const mappedInvoices = invoiceItems.map((item) => ({
        ...item,
        key: item.id,
        id: item.id, 
      }));

      setInvoices(mappedInvoices);
      setPagination({
        ...pagination,
        current: page,
        total: totalCount,
      });
    } catch (error) {
      console.error("Error fetching invoices:", error);
      message.error("Failed to load invoices");
    } finally {
      setLoading(false);
    }
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
  };

  useEffect(() => {
    fetchInvoices(1, pagination.pageSize);
  }, [searchTerm]);

  const handleTableChange = (pagination) => {
    fetchInvoices(pagination.current, pagination.pageSize);
  };

  const handleDownload = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/invoice/fetch-from-quickbooks`,
        { method: "GET" }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.message || "Failed to download invoices from QuickBooks"
        );
      }

      message.success("Invoices downloaded successfully");
      fetchInvoices(1, pagination.pageSize);
    } catch (error) {
      console.error("Error downloading invoices:", error);
      message.error(error.message || "Failed to download invoices");
    } finally {
      setLoading(false);
    }
  };

  const handleButtonClick = async () => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/invoice/customer-dropdown`
      );
      const customers = response.data;

      if (customers.length === 0) {
        alert("No customers available.");
      } else {
        console.log(customers);
        setCustomerData(customers);
        setMode("add");
        setSelectedInvoice(null);
        setModalVisible(true);
      }
    } catch (error) {
      console.error("Error fetching customer data:", error);
      alert("Failed to fetch customers.");
    }
  };

  const handleEdit = async (record) => {
    try {
      console.log("Starting edit for record:", record);
  
      // Step 1: Fetch customer dropdown data
      const customerResponse = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/invoice/customer-dropdown`
      );
      const customers = customerResponse.data;
      setCustomerData(customers);
      console.log("Customer data fetched:", customers);
  
      // Step 2: Match customer display name
      const customerName = record.customer;
      const customerMatch = customers.find(
        (c) => c.displayName === customerName
      );
      const customerId = customerMatch
        ? customerMatch.quickBooksCustomerId
        : null;
      console.log("Matched customer ID:", customerId);
  
      // Step 3: Fetch full invoice data from backend
      const invoiceResponse = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/invoice/${record.id}`
      );
      const invoice = invoiceResponse.data;
      console.log("Invoice data from backend:", invoice);
  
      // Step 4: Transform line items to match form input model
      const transformedLines = invoice.lineItems.map((item, index) => ({
        key: index.toString(),
        ProductId: item.quickBooksItemId,
        ProductName: item.productName,
        Description: item.description,
        Quantity: item.qty,
        UnitPrice: item.rate,
        Amount: item.amount,
      }));
      console.log("Transformed line items:", transformedLines);
  
      // Step 5: Prepare invoice object for edit modal
      const invoiceForEdit = {
        quickBooksInvoiceId: invoice.quickBooksInvoiceId,
        customerId: invoice.quickBooksCustomerId, // already in backend now
        customerName: invoice.customerName,
        customerEmail: invoice.customerEmail,
        billingAddress: invoice.billingAddress,
        invoiceDate: invoice.invoiceDate,
        dueDate: invoice.dueDate,
        Line: transformedLines,
      };
  
      console.log("Invoice prepared for edit:", invoiceForEdit);
  
      // Step 6: Set state to open modal with prefilled data
      setSelectedInvoice(invoiceForEdit);
      setMode("edit");
      setModalVisible(true);
    } catch (error) {
      console.error("Error in handleEdit:", error);
      message.error("Failed to fetch data for editing.");
    }
  };
  
  const handleModalClose = () => {
    setModalVisible(false);
  };

  const handleInvoiceSave = async (invoiceData) => {
    try {
      console.log("handleInvoiceSave called with mode:", mode);
      console.log("Invoice data received:", invoiceData);
  
      let response;
  
      if (mode === "edit") {
        console.log("Final request payload for update:", invoiceData);
  
        response = await axios.put(
          `${import.meta.env.VITE_API_BASE_URL}/api/invoice/update-invoice`,
          invoiceData  
        );
        console.log("Update response:", response.data);
        message.success("Invoice updated successfully");
      } else {
        console.log("Request payload for create:", invoiceData);
  
        response = await axios.post(
          `${import.meta.env.VITE_API_BASE_URL}/api/invoice/create-invoice`,
          invoiceData  // Send the data directly without wrapping
        );
        console.log("Create response:", response.data);
        message.success("Invoice created successfully");
      }
  
      setModalVisible(false);
      fetchInvoices(pagination.current, pagination.pageSize);
    } catch (error) {
      console.error("Failed to save invoice:", error);
      console.error("Error details:", error.response?.data || error.message);
      message.error("Failed to save invoice. Please try again.");
    }
  };

  const handleDelete = async (id) => {
    try {

      const response = await axios.delete(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/invoice/delete-invoice/${id}`
      );

      console.log("Delete response:", response.data);
      message.success("Invoice deleted successfully");

      fetchInvoices(pagination.current, pagination.pageSize);
    } catch (error) {
      console.error("Failed to delete invoice:", error);
      console.error("Error details:", error.response?.data || error.message);
      message.error("Failed to delete invoice. Please try again.");
    }
  };
  const columns = [
    {
      title: "Invoice Date",
      dataIndex: "date",
      key: "date",
      render: (text) => new Date(text).toLocaleDateString(),
      sorter: (a, b) => new Date(a.date) - new Date(b.date),
    },
    {
      title: "Invoice #",
      dataIndex: "no",
      key: "no",
      sorter: (a, b) => a.no.localeCompare(b.no),
    },
    {
      title: "Customer",
      dataIndex: "customer",
      key: "customer",
      sorter: (a, b) => a.customer.localeCompare(b.customer),
    },
    {
      title: "Amount",
      dataIndex: "amount",
      key: "amount",
      render: (text) => `$${parseFloat(text).toFixed(2)}`,
      sorter: (a, b) => a.amount - b.amount,
      align: "right",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      filters: [
        { text: "Paid", value: "Paid" },
        { text: "Open", value: "Open" },
        { text: "Overdue", value: "Overdue" },
      ],
      onFilter: (value, record) => record.status?.includes(value),
    },
    {
      title: "Actions",
      key: "actions",
      render: (_: any, record: InvoiceData) => (
        <div className="action-buttons">
          <Button
            type="default"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            className="edit-button"
          >
            View
          </Button>
          <Popconfirm
            title="Are you sure you want to delete this Invoice?"
            onConfirm={() => handleDelete(record.id)}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="default"
              danger
              icon={<DeleteOutlined />}
              className="delete-button"
            >
              Delete
            </Button>
          </Popconfirm>
        </div>
      ),
    }    
  ];

  return (
    <div className="chart-accounts-container">
      <div className="chart-accounts-header">
        <div className="chart-accounts-title">Invoices</div>
        <div className="chart-accounts-actions">
          <SearchBar onSearch={handleSearchChange} searchTerm={searchTerm} />
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={handleButtonClick}
            className="action-button"
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Create Invoice
          </Button>
          <Button
            type="primary"
            onClick={handleDownload}
            icon={<DownloadOutlined />}
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Sync from QuickBooks
          </Button>
        </div>
      </div>

      <div className="scrollable-table-container">
        {/* Show loading indicator */}
        {loading ? (
          <div className="loading-container">
            <Spin indicator={antIcon} size="large" />
            <p style={{ color: "#00A551" }}>Loading Invoices...</p>
          </div>
        ) : invoices.length > 0 ? (
          // Show table if invoices are present
          <Table
            dataSource={invoices}
            columns={columns}
            rowKey={(record) => String(record.id)}
            pagination={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              showSizeChanger: true,
            }}
            onChange={handleTableChange}
            scroll={{ x: "max-content" }}
            bordered
            className="invoices-table"
          />
        ) : (
          // Show empty state if no invoices are found
          <div className="empty-data-container">
            <Empty
              description='No invoices available. Click "Sync from QuickBooks" to load invoices.'
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
          </div>
        )}
      </div>

      {/* Invoice Modal */}
      {modalVisible && (
        <InvoiceModal
          visible={modalVisible}
          onCancel={handleModalClose}
          onSave={handleInvoiceSave}
          invoice={selectedInvoice}
          mode={mode}
          customers={customerData}
        />
      )}
    </div>
  );
};

export default Invoice;
