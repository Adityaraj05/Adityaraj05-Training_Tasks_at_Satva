import React, { useState, useEffect } from 'react';
import { Layout, Menu, Button, message, Breadcrumb, Dropdown, Avatar, Badge } from 'antd';
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  UserOutlined,
  LogoutOutlined,
  DashboardOutlined,
  BankOutlined,
  SettingOutlined,
  DownOutlined,
  AppstoreOutlined,
  ShopOutlined,
  FileTextOutlined,
  ReconciliationOutlined,
  LinkOutlined
} from '@ant-design/icons';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import './HomeLayout.css';
import logo from './assets/logo.webp';
import { isTokenExpired, clearTokens, refreshToken } from './services/authService';
import { isXeroTokenExpired, initiateXeroAuth } from './services/xeroAuthService';

const { Header, Sider, Content, Footer } = Layout;

const Home: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [xeroConnected, setXeroConnected] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  // Check authentication when component mounts
  useEffect(() => {
    const checkAuthentication = async () => {
      // Check QuickBooks authentication
      const accessToken = localStorage.getItem('qb_access_token');
      const refreshTokenValue = localStorage.getItem('qb_refresh_token');
      
      // If no tokens exist, redirect to login
      if (!accessToken && !refreshTokenValue) {
        message.error('QuickBooks authentication required');
        navigate('/');
        return;
      }
      
      // If access token is expired, try to refresh
      if (isTokenExpired()) {
        const success = await refreshToken();
        if (!success) {
          message.error('Your QuickBooks session has expired. Please login again.');
          clearTokens();
          navigate('/');
        }
      }
      
      // Check Xero authentication
      const xeroAccessToken = localStorage.getItem('xero_access_token');
      const xeroTenantId = localStorage.getItem('xero_tenant_id');
      
      if (xeroAccessToken && xeroTenantId && !isXeroTokenExpired()) {
        setXeroConnected(true);
      }
    };
    
    checkAuthentication();
  }, [navigate]);
  
  // Extract the current page name from the URL path
  const getPageTitle = () => {
    const path = location.pathname;
  
    if (path.includes('chart-of-accounts')) return 'Chart of Accounts';
    if (path.includes('customer')) return 'Customers';
    if (path.includes('product')) return 'Products';
    if (path.includes('invoice')) return 'Invoices';
    if (path.includes('vendor')) return 'Vendors';
    if (path.includes('bill')) return 'Bills';
  
    return 'Dashboard';
  };

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  const handleLogout = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/auth/logout`, {
        method: 'DELETE',
      });
  
      if (response.ok) {
        message.success('Logged out successfully');
        clearTokens(); // Use the clearTokens function from authService
           // Also clear Xero tokens
      localStorage.removeItem('xero_access_token');
      localStorage.removeItem('xero_tenant_id');
      localStorage.removeItem('xero_refresh_token');
      localStorage.removeItem('xero_token_expiry');
      
      // Update the UI state
      setXeroConnected(false);
        navigate('/');
      } else {
        message.error('Logout failed');
      }
    } catch (error) {
      console.error('Error during logout:', error);
      message.error('Error during logout');
      
      // Even if server logout fails, clear local tokens
      clearTokens();
       localStorage.removeItem('xero_access_token');
    localStorage.removeItem('xero_tenant_id');
    localStorage.removeItem('xero_refresh_token');
    localStorage.removeItem('xero_token_expiry');
      navigate('/');
    }
  };
  
  const connectToXero = () => {
    initiateXeroAuth();
  };

  const userMenu = (
    <Menu>
      <Menu.Item key="profile" icon={<UserOutlined />}>
        Profile
      </Menu.Item>
      <Menu.Item key="settings" icon={<SettingOutlined />}>
        Settings
      </Menu.Item>
      <Menu.Divider />
      <Menu.Item key="logout" icon={<LogoutOutlined />} danger onClick={handleLogout}>
        Logout
      </Menu.Item>
    </Menu>
  );

  return (
    <Layout className="app-layout">
      <Sider 
        collapsible 
        collapsed={collapsed} 
        onCollapse={toggleCollapse}
        className="app-sider"
        width={240}
      >
        <div className="logo-container">
          <div 
            className="logo"
            style={{
              backgroundImage: `url(${logo})`,
            }}
          />
          {!collapsed && <span className="logo-text">QuickBooks</span>}
        </div>

        <Menu 
          theme="dark" 
          mode="inline" 
          defaultSelectedKeys={['chart-of-accounts']}
          className="side-menu"
        >
          <Menu.Item key="chart-of-accounts" icon={<BankOutlined />} onClick={() => navigate('/home/chart-of-accounts')}>
            Chart of Accounts
          </Menu.Item>
          <Menu.Item key="customer" icon={<DashboardOutlined />} onClick={() => navigate('/home/customer')}>
            Customers
          </Menu.Item>
          <Menu.Item key="product" icon={<AppstoreOutlined />} onClick={() => navigate('/home/product')}>
            Products
          </Menu.Item>
          <Menu.Item key="invoice" icon={<FileTextOutlined  />} onClick={() => navigate('/home/invoice')}>
            Invoice
          </Menu.Item>
          <Menu.Item key="vendor" icon={<ShopOutlined  />} onClick={() => navigate('/home/vendor')}>
            Vendor 
          </Menu.Item>
          <Menu.Item key="bill" icon={<ReconciliationOutlined  />} onClick={() => navigate('/home/bill')}>
            Bill 
          </Menu.Item>
        </Menu>
      </Sider>
      
      <Layout className="site-layout">
        <Header className="app-header">
          <div className="header-left">
            {collapsed ? (
              <MenuUnfoldOutlined className="trigger" onClick={toggleCollapse} />
            ) : (
              <MenuFoldOutlined className="trigger" onClick={toggleCollapse} />
            )}
            <Breadcrumb className="page-breadcrumb">
              <Breadcrumb.Item>Home</Breadcrumb.Item>
              <Breadcrumb.Item>{getPageTitle()}</Breadcrumb.Item>
            </Breadcrumb>
          </div>
          
          <div className="header-right">
            {!xeroConnected && (
              <Button 
                type="primary" 
                icon={<LinkOutlined />} 
                onClick={connectToXero} 
                style={{ marginRight: 16 }}
              >
                Connect to Xero
              </Button>
            )}
            {xeroConnected && (
              <Badge status="success" text="Xero Connected" style={{ marginRight: 16 }} />
            )}
            <Dropdown overlay={userMenu} trigger={['click']}>
              <Button type="text" className="user-dropdown-button">
                <Avatar size="small" icon={<UserOutlined />} className="user-avatar" />
                <span className="username">Admin</span>
                <DownOutlined />
              </Button>
            </Dropdown>
          </div>
        </Header>
        
        <Content className="app-content">
          <Outlet />
        </Content>
        
        <Footer className="app-footer">
          QuickBooks & Xero Integration ©{new Date().getFullYear()} Created with Ant Design
        </Footer>
      </Layout>
    </Layout>
  );
};

export default Home;