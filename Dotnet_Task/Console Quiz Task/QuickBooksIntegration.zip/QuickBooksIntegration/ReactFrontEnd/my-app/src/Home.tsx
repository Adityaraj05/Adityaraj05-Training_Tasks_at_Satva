import React, { useState } from 'react';
import { Layout, Menu, Button, message, Breadcrumb, Dropdown, Avatar } from 'antd';
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  UserOutlined,
  LogoutOutlined,
  BankOutlined,
  FileTextOutlined,
  SettingOutlined,
  DollarOutlined,
  UsergroupAddOutlined,
  DownOutlined,
  ProductOutlined,
} from '@ant-design/icons';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import './HomeLayout.css';
import logo from './assets/logo.png';


const { Header, Sider, Content, Footer } = Layout;

const Home: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const getPageTitle = () => {
    const path = location.pathname;
    if (path.includes('chart-of-accounts')) return 'Chart of Accounts';
    if (path.includes('customer')) return 'Customers';
    if (path.includes('products')) return 'Products';
    if (path.includes('invoices')) return 'Invoices';
    if (path.includes('vendors')) return 'Vendor';
    if (path.includes('bills')) return 'Bill';
    return 'Home';
  };

  const getSelectedKey = () => {
    if (location.pathname.includes('/home/invoices')) return 'invoices'; 
    if (location.pathname.includes('/home/vendors')) return 'vendors'; 
    if (location.pathname.includes('/home/products')) return 'products';
    if (location.pathname.includes('/home/chart-of-accounts')) return 'chart-of-accounts';
    if (location.pathname.includes('/home/bills')) return 'bills';
    
    return 'customer'; 
  };
  
  

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  const handleLogout = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/auth/logout`, {
        method: 'DELETE',
      });

      if (response.ok) {
        message.success('Logged out successfully');
        localStorage.removeItem('quickbooks_realmId');
        navigate('/');
      } else {
        message.error('Logout failed');
      }
    } catch (error) {
      console.error('Error during logout:', error);
      message.error('Error during logout');
    }
  };

  const userMenu = (
    <Menu>
      <Menu.Item key="profile" icon={<UserOutlined />}>
        Profile
      </Menu.Item>
      <Menu.Item key="settings" icon={<SettingOutlined />}>
        Settings
      </Menu.Item>
      <Menu.Divider />
      <Menu.Item key="logout" icon={<LogoutOutlined />} danger onClick={handleLogout}>
        Logout
      </Menu.Item>
    </Menu>
  );

  return (
    <Layout className="app-layout">
      <Sider
        theme='light'
        collapsible
        collapsed={collapsed}
        onCollapse={toggleCollapse}
        className="app-sider"
        width={240}
      >
        <div className="logo-container">
          {collapsed ? (
            <span className="logo-text">QB</span>
          ) : (
            <div
              className="logo"
              style={{
                backgroundImage: `url(${logo})`,
              }}
            />
          )}
        </div>


        <Menu
          mode="inline"
          defaultSelectedKeys={[getSelectedKey()]}
          className="side-menu"
        >
          <Menu.Item key="customer" icon={<UserOutlined  />} onClick={() => navigate('/home/customer')}>
            Customers
          </Menu.Item>
          <Menu.Item key="chart-of-accounts" icon={<BankOutlined />} onClick={() => navigate('/home/chart-of-accounts')}>
            Chart of Accounts
          </Menu.Item>
          <Menu.Item key="products" icon={<ProductOutlined />} onClick={() => navigate('/home/products')}>
            Products
          </Menu.Item>
          <Menu.Item key="invoices" icon={<FileTextOutlined  />} onClick={() => navigate('/home/invoices')}>
            Invoices
          </Menu.Item>
          <Menu.Item key="vendors" icon={<UsergroupAddOutlined   />} onClick={() => navigate('/home/vendors')}>
            Vendors
          </Menu.Item>
          <Menu.Item key="bills" icon={<DollarOutlined   />} onClick={() => navigate('/home/bills')}>
            Bills
          </Menu.Item>
        </Menu>
      </Sider>

      <Layout className="site-layout">
        <Header className="app-header">
          <div className="header-left">
            {collapsed ? (
              <MenuUnfoldOutlined className="trigger" onClick={toggleCollapse} />
            ) : (
              <MenuFoldOutlined className="trigger" onClick={toggleCollapse} />
            )}
            <Breadcrumb className="page-breadcrumb">
              <Breadcrumb.Item>Home</Breadcrumb.Item>
              <Breadcrumb.Item>{getPageTitle()}</Breadcrumb.Item>
            </Breadcrumb>
          </div>

          <div className="header-right">
            <Dropdown overlay={userMenu} trigger={['click']}>
              <Button type="text" className="user-dropdown-button">
                <Avatar size="small" icon={<UserOutlined />} className="user-avatar" />
                <span className="username">Admin</span>
                <DownOutlined />
              </Button>
            </Dropdown>
          </div>
        </Header>

        <Content className="app-content">
          <Outlet />
        </Content>
        <Footer className="app-footer">
          QuickBooks Integration ©{new Date().getFullYear()} Created with Ant Design
        </Footer>
      </Layout>
    </Layout>
  );
};

export default Home;