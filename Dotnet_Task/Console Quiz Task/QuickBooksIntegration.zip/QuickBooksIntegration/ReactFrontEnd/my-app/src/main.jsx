import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import App from './App';
import Callback from './Callback';
import XeroCallback from './XeroCallback';
import Home from './Home';
import ChartOfAccounts from './ChartOfAccounts';
import Customer from './Customer';
import Product from './Product';
import Invoice from './Invoice';
import Vendor from './Vendor';
import Bill from './Bill';


ReactDOM.createRoot(document.getElementById('root')).render(
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/callback" element={<Callback />} />
        <Route path="/xero-callback" element={<XeroCallback />} />
        <Route path="/home" element={<Home />}>
          <Route path="customer" element={<Customer />} />
          <Route path="chart-of-accounts" element={<ChartOfAccounts />} />
          <Route path="product" element={<Product />} />
          <Route path="invoice" element={<Invoice />} />
          <Route path="vendor" element={<Vendor />} />
          <Route path="bill" element={<Bill />} />
    
        </Route>     
      </Routes>
    </BrowserRouter>
);