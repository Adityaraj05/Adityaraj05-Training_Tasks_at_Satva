import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import App from './App';
import Callback from './Callback';
import Home from './Home';
import ChartOfAccounts from './ChartOfAccounts';
import Customer from './Customer';
import Product from './Products';
import Invoices from './Invoices';
import Vendor  from './Vendor'; 
import Bill from './Bill';
import './index.css';
import '@ant-design/v5-patch-for-react-19';

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/callback" element={<Callback />} />
      <Route path="/home" element={<Home />}>
        <Route index element={<Navigate to="/home/customer" replace />} />
        <Route path="chart-of-accounts" element={<ChartOfAccounts />} />
        <Route path="customer" element={<Customer />} />
        <Route path="products" element={<Product />} />
        <Route path='invoices' element = {<Invoices/>} />
        <Route path='vendors' element = {<Vendor/>} />
        <Route path='bills' element = {<Bill/>} />
      </Route>
    </Routes>
  </BrowserRouter>
);
