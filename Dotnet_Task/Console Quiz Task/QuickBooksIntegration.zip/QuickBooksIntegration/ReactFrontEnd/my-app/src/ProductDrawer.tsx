import React, { useState, useEffect } from 'react';
import {
  Drawer, Form, Input, Button, Select,
  DatePicker, InputNumber, message, Space,
  Switch, Divider, Spin, Checkbox, Radio
} from 'antd';
import dayjs from 'dayjs';

const { Option } = Select;
const { TextArea } = Input;

interface ProductDrawerProps {
  visible: boolean;
  onClose: () => void;
  onSubmit: (values: any, syncToExternalSystem: boolean) => Promise<void>;
  editingProduct: any | null;
  loading: boolean;
  sourceSystem: string;
  setSourceSystem: (system: string) => void;
  xeroEnabled: boolean;
  tenantId: string;
}

const ProductDrawer: React.FC<ProductDrawerProps> = ({
  visible,
  onClose,
  onSubmit,
  editingProduct,
  loading,
  sourceSystem,
  setSourceSystem,
  xeroEnabled,
  tenantId
}) => {
  const [form] = Form.useForm();
  const [productType, setProductType] = useState<string>('Inventory');
  const [isExternalProduct, setIsExternalProduct] = useState<boolean>(false);
  const [incomeAccounts, setIncomeAccounts] = useState<{ id: string; name: string; code: string }[]>([]);
  const [expenseAccounts, setExpenseAccounts] = useState<{ id: string; name: string; code: string }[]>([]);
  const [loadingAccounts, setLoadingAccounts] = useState(false);
  const [syncToExternalSystem, setSyncToExternalSystem] = useState<boolean>(true);
  const [isSold, setIsSold] = useState<boolean>(true);
  const [isPurchased, setIsPurchased] = useState<boolean>(true);
  const [isTrackedAsInventory, setIsTrackedAsInventory] = useState<boolean>(true);

  // Static asset accounts data
  const assetAccounts = [
    { id: 'asset1', name: 'Inventory Asset' },
    { id: 'asset2', name: 'Merchandise Inventory' },
    { id: 'asset3', name: 'Raw Materials Inventory' },
    { id: 'asset4', name: 'Work In Progress Inventory' }
  ];

  // Static Xero account codes for demo
  const xeroAccountCodes = {
    sales: [
      { code: '200', name: 'Sales' },
      { code: '201', name: 'Sales Discounts' },
      { code: '202', name: 'Sales Returns' }
    ],
    purchase: [
      { code: '300', name: 'Purchases' },
      { code: '310', name: 'Cost of Goods Sold' },
      { code: '320', name: 'Purchase Discounts' }
    ],
    inventory: [
      { code: '630', name: 'Inventory Asset' },
      { code: '631', name: 'Finished Goods' },
      { code: '632', name: 'Work in Progress' }
    ]
  };

  const taxTypes = [
    { value: 'INPUT', name: 'Input - GST/HST/PST/QST' },
    { value: 'OUTPUT', name: 'Output - GST/HST/PST/QST' },
  ];
  useEffect(() => {
    if (visible) {
      if (editingProduct) {
        // Set form values based on which system the product is from
        if (editingProduct.sourceSystem === 'Xero') {
          form.setFieldsValue({
            // Common fields
            name: editingProduct.name,
            description: editingProduct.description || '',
            
            // Xero-specific fields
            code: editingProduct.code || `ITEM-${Math.floor(Math.random() * 10000)}`,
            isSold: editingProduct.isSold !== false,
            isPurchased: editingProduct.isPurchased !== false,
            isTrackedAsInventory: editingProduct.isTrackedAsInventory !== false,
            salesUnitPrice: editingProduct.unitPrice || 0,
            purchaseUnitPrice: editingProduct.purchaseUnitPrice || 0,
            salesAccountCode: editingProduct.incomeAccountId || '200',
            purchaseAccountCode:'310',
            salesTaxType: editingProduct.salesTaxType || 'INPUT',
            purchaseTaxType: editingProduct.purchaseTaxType || 'OUTPUT',
            inventoryAssetAccountCode: editingProduct.assetAccountId || '630',
            
            // Also set QuickBooks fields to maintain compatibility
            Type: editingProduct.isTrackedAsInventory !== false ? 'Inventory' : 'Service',
            UnitPrice: editingProduct.unitPrice || 0,
            QuantityOnHand: editingProduct.quantityOnHand || 0,
            IncomeAccountId: editingProduct.incomeAccountId,
            ExpenseAccountId: editingProduct.expenseAccountId,
            AssetAccountId: editingProduct.assetAccountId,
            inventoryStartDate: editingProduct.inventoryStartDate
              ? dayjs(editingProduct.inventoryStartDate)
              : null,
          });
          
          // Set state variables for Xero
          setIsSold(editingProduct.isSold !== false);
          setIsPurchased(editingProduct.isPurchased !== false);
          setIsTrackedAsInventory(editingProduct.isTrackedAsInventory !== false);
          setProductType(editingProduct.isTrackedAsInventory !== false ? 'Inventory' : 'Service');
        } else {
          // QuickBooks product
          form.setFieldsValue({
            // Common fields
            Name: editingProduct.name,
            Description: editingProduct.description || '',
            
            // QuickBooks-specific fields
            Type: editingProduct.type || 'Inventory',
            UnitPrice: editingProduct.unitPrice || 0,
            QuantityOnHand: editingProduct.quantityOnHand || 0,
            IncomeAccountId: editingProduct.incomeAccountId,
            ExpenseAccountId: editingProduct.expenseAccountId,
            AssetAccountId: editingProduct.assetAccountId,
            Taxable: editingProduct.taxable !== false,
            inventoryStartDate: editingProduct.inventoryStartDate
              ? dayjs(editingProduct.inventoryStartDate)
              : null,
            
            // Also set some Xero fields for compatibility
            code: `ITEM-${Math.floor(Math.random() * 10000)}`,
            salesUnitPrice: editingProduct.unitPrice || 0,
            purchaseUnitPrice: editingProduct.unitPrice || 0,
            isSold: true,
            isPurchased: true,
            isTrackedAsInventory: editingProduct.type === 'Inventory'
          });
          
          setProductType(editingProduct.type || 'Inventory');
          setIsSold(true);
          setIsPurchased(true);
          setIsTrackedAsInventory(editingProduct.type === 'Inventory');
        }
        
        // Check if product exists in any external system
        const isExternal = !!editingProduct.quickBooksItemId || !!editingProduct.xeroItemId;
        setIsExternalProduct(isExternal);
        
        // If product is already in an external system, no need to sync
        setSyncToExternalSystem(!isExternal);
        
        // Set source system from the product
        if (editingProduct.sourceSystem) {
          setSourceSystem(editingProduct.sourceSystem);
        }
      } else {
        // New product
        form.resetFields();
        
        // Set default values based on selected source system
        if (sourceSystem === 'Xero') {
          form.setFieldsValue({
            code: `ITEM-${Math.floor(Math.random() * 10000)}`,
            isSold: true,
            isPurchased: true,
            isTrackedAsInventory: true,
            salesTaxType: 'INPUT',
            purchaseTaxType: 'OUTPUT',
            salesAccountCode: '200',
            purchaseAccountCode: '310',
            inventoryAssetAccountCode: '630',
            Type: 'Inventory'
          });
        } else {
          form.setFieldsValue({
            Type: 'Inventory',
            Active: true,
            Taxable: true
          });
        }
        
        setProductType('Inventory');
        setIsExternalProduct(false);
        setSyncToExternalSystem(true);
        setIsSold(true);
        setIsPurchased(true);
        setIsTrackedAsInventory(true);
      }

      // Fetch account data when drawer opens
      fetchAccounts();
    }
  }, [editingProduct, visible, sourceSystem, setSourceSystem]);
  const fetchAccounts = async () => {
    setLoadingAccounts(true);
    try {
      if (sourceSystem === 'QuickBooks') {
        // Fetch income accounts for QuickBooks
        const incomeResponse = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/api/Product/get-accounts?accountType=Income`
        );
        if (incomeResponse.ok) {
          let incomeData = await incomeResponse.json();
          
          // Check if the response is an array of objects with status/message/data structure
          if (Array.isArray(incomeData) && incomeData.length > 0 && incomeData[0].data) {
            // Extract and merge the data fields from each object in the array
            const extractedAccounts = incomeData.map(item => item.data);
            setIncomeAccounts(extractedAccounts);
          } else if (incomeData.data) {
            // Handle regular single response structure
            const accountsArray = Array.isArray(incomeData.data) 
              ? incomeData.data 
              : [incomeData.data];
            setIncomeAccounts(accountsArray);
          } else {
            console.error('Unexpected income accounts data format:', incomeData);
            message.error('Invalid income accounts data format');
          }
        } else {
          console.error('Failed to fetch income accounts:', incomeResponse.statusText);
          message.error('Failed to load income accounts');
        }
  
        // Fetch expense accounts for QuickBooks
        const expenseResponse = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/api/Product/get-accounts?accountType=Expense`
        );
        if (expenseResponse.ok) {
          let expenseData = await expenseResponse.json();
          
          // Check if the response is an array of objects with status/message/data structure
          if (Array.isArray(expenseData) && expenseData.length > 0 && expenseData[0].data) {
            // Extract and merge the data fields from each object in the array
            const extractedAccounts = expenseData.map(item => item.data);
            setExpenseAccounts(extractedAccounts);
          } else if (expenseData.data) {
            // Handle regular single response structure
            const accountsArray = Array.isArray(expenseData.data) 
              ? expenseData.data 
              : [expenseData.data];
            setExpenseAccounts(accountsArray);
          } else {
            console.error('Unexpected expense accounts data format:', expenseData);
            message.error('Invalid expense accounts data format');
          }
        } else {
          console.error('Failed to fetch expense accounts:', expenseResponse.statusText);
          message.error('Failed to load expense accounts');
        }
      } else if (sourceSystem === 'Xero' && xeroEnabled && tenantId) {
        // For Xero, use static account data directly
        console.log('Setting up Xero accounts using static data');
        setIncomeAccounts(xeroAccountCodes.sales.map(acc => ({ 
          id: acc.code, 
          name: acc.name, 
          code: acc.code 
        })));
      }
    } catch (error) {
      console.error('Error fetching accounts:', error);
      message.error(`Failed to load ${sourceSystem} accounts`);
    } finally {
      setLoadingAccounts(false);
    }
  };
  const handleTypeChange = (value: string) => {
    setProductType(value);
    setIsTrackedAsInventory(value === 'Inventory');
    
    // Reset inventory-specific fields when changing to Service
    if (value === 'Service') {
      form.setFieldsValue({
        QuantityOnHand: null,
        inventoryStartDate: null,
        AssetAccountId: null,
        ExpenseAccountId: null,
        isTrackedAsInventory: false,
        inventoryAssetAccountCode: null
      });
    } else {
      form.setFieldsValue({
        isTrackedAsInventory: true
      });
    }
  };

  const handleSourceSystemChange = (e: any) => {
    const newSourceSystem = e.target.value;
    setSourceSystem(newSourceSystem);
    
    // Reset accounts when changing source system
    setIncomeAccounts([]);
    setExpenseAccounts([]);
    
    // Set default values based on new source system
    if (newSourceSystem === 'Xero') {
      form.setFieldsValue({
        code: `ITEM-${Math.floor(Math.random() * 10000)}`,
        isSold: true,
        isPurchased: true,
        isTrackedAsInventory: productType === 'Inventory',
        salesTaxType: 'INPUT',
        purchaseTaxType: 'OUTPUT',
        salesAccountCode: '200',
        purchaseAccountCode: '310',
        inventoryAssetAccountCode: productType === 'Inventory' ? '630' : null
      });
      
      setIsSold(true);
      setIsPurchased(true);
      setIsTrackedAsInventory(productType === 'Inventory');
    }
    
    // Fetch accounts for the new source system
    fetchAccounts();
  };
  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      
      // Create appropriate data structure based on source system
      if (sourceSystem === 'Xero') {
        // Prepare Xero payload
        const xeroData = {
          id: editingProduct?.id || 0,
          name: values.name,
          description: values.description || '',
          code: values.code,
          isSold: values.isSold,
          isPurchased: values.isPurchased,
          isTrackedAsInventory: values.isTrackedAsInventory,
          salesUnitPrice: values.salesUnitPrice,
          purchaseUnitPrice: values.isPurchased && values.isTrackedAsInventory ? values.purchaseUnitPrice : null,
          salesAccountCode: values.isSold ? values.salesAccountCode || '200' : null,
          purchaseAccountCode: values.isPurchased ? values.purchaseAccountCode || '310' : null,
          salesTaxType: values.isSold ? values.salesTaxType || 'INPUT' : null,
          purchaseTaxType: values.isPurchased ? values.purchaseTaxType || 'OUTPUT' : null,
          inventoryAssetAccountCode: values.isTrackedAsInventory ? values.inventoryAssetAccountCode || '630' : null,
          
          // Additional fields needed for the API
          unitPrice: values.salesUnitPrice,
          type: values.isTrackedAsInventory ? 'Inventory' : 'Service',
          xeroItemId: editingProduct?.xeroItemId || "",
          quickBooksItemId: editingProduct?.quickBooksItemId || "",
          syncToken: editingProduct?.syncToken || "0",
          sourceSystem: 'Xero',
          
          // Map account names
          incomeAccountId: values.isSold ? values.salesAccountCode : null,
          incomeAccountName: values.isSold ? getAccountNameByCode(values.salesAccountCode, incomeAccounts) : null,
          expenseAccountId: values.isPurchased ? values.purchaseAccountCode : null,
          expenseAccountName: values.isPurchased ? getAccountNameByCode(values.purchaseAccountCode, expenseAccounts) : null,
          assetAccountId: values.isTrackedAsInventory ? values.inventoryAssetAccountCode : null,
          assetAccountName: values.isTrackedAsInventory ? getAssetAccountNameByCode(values.inventoryAssetAccountCode) : null,
          
          // Inventory fields
          quantityOnHand: values.isTrackedAsInventory ? values.QuantityOnHand || 0 : null,
          inventoryStartDate: values.isTrackedAsInventory && values.inventoryStartDate ? 
            values.inventoryStartDate.toISOString() : null
        };
        
        await onSubmit(xeroData, syncToExternalSystem);
      } else {
        // QuickBooks payload
        // Convert date to ISO string if present
        if (values.inventoryStartDate) {
          values.InventoryStartDate = values.inventoryStartDate.toISOString();
          delete values.inventoryStartDate;
        }
    
        // Get selected income account name if available
        let incomeAccountName = null;
        if (values.IncomeAccountId) {
          const selectedAccount = incomeAccounts.find((acc: any) => acc.id === values.IncomeAccountId);
          incomeAccountName = selectedAccount?.name || null;
        }
        
        // Get selected expense account name if available
        let expenseAccountName = null;
        if (values.ExpenseAccountId) {
          const selectedExpenseAccount = expenseAccounts.find((acc: any) => acc.id === values.ExpenseAccountId);
          expenseAccountName = selectedExpenseAccount?.name || null;
        }
        
        // Get selected asset account name if available
        let assetAccountName = null;
        if (values.AssetAccountId) {
          const selectedAssetAccount = assetAccounts.find((acc: any) => acc.id === values.AssetAccountId);
          assetAccountName = selectedAssetAccount?.name || null;
        }
    
        // Format the data specifically for QuickBooks API requirements
        const submitData = {
          // Core required fields
          id: editingProduct?.id || 0,
          Name: values.Name,
          Description: values.Description || "",
          Type: values.Type,
          UnitPrice: values.UnitPrice,
          IncomeAccountId: values.IncomeAccountId,
          Taxable: values.Taxable !== false,
          Active: values.Active !== false,
          
          // Additional required QuickBooks fields
          IncomeAccountRef: {
            value: values.IncomeAccountId,
            name: incomeAccountName || ""
          },
          
          // Inventory-specific fields
          TrackQtyOnHand: values.Type === 'Inventory',
          QtyOnHand: values.Type === 'Inventory' ? values.QuantityOnHand || 0 : null,
          InvStartDate: values.Type === 'Inventory' && values.InventoryStartDate ? values.InventoryStartDate : null,
          
          // Expense account for COGS if inventory type
          ExpenseAccountRef: values.Type === 'Inventory' ? {
            value: values.ExpenseAccountId,
            name: expenseAccountName || ""
          } : null,
          
          // Asset account for inventory
          AssetAccountRef: values.Type === 'Inventory' ? {
            value: values.AssetAccountId,
            name: assetAccountName || ""
          } : null,
          
          // Metadata fields for tracking
          quickBooksItemId: editingProduct?.quickBooksItemId || "",
          xeroItemId: editingProduct?.xeroItemId || "",
          syncToken: editingProduct?.syncToken || "0",
          sourceSystem: 'QuickBooks',
          
          // For UI consistency across systems
          name: values.Name,
          description: values.Description || "",
          unitPrice: values.UnitPrice,
          type: values.Type,
          incomeAccountName: incomeAccountName || "",
          expenseAccountName: expenseAccountName || "",
          assetAccountName: assetAccountName || "",
          quantityOnHand: values.Type === 'Inventory' ? values.QuantityOnHand : null
        };
    
        await onSubmit(submitData, syncToExternalSystem);
      }
      
      onClose();
    } catch (error) {
      console.error('Validation failed:', error);
      message.error('Product creation failed. Please check the form data and try again.');
    }
  };
  const getAccountNameByCode = (code: string, accounts: any[]) => {
    if (!code || !accounts || !accounts.length) return "";
    
    const account = accounts.find((acc: any) => acc.id === code || acc.code === code);
    return account ? account.name : "";
  };
  
  const getAssetAccountNameByCode = (code: string) => {
    if (!code) return "";
    
    const staticAccounts = xeroAccountCodes.inventory;
    const account = staticAccounts.find(acc => acc.code === code);
    return account ? account.name : "";
  };

  // Handle Xero-specific switch changes
  const handleIsSoldChange = (checked: boolean) => {
    setIsSold(checked);
    if (!checked) {
      form.setFieldsValue({
        salesUnitPrice: null,
        salesAccountCode: null,
        salesTaxType: null
      });
    } else {
      form.setFieldsValue({
        salesUnitPrice: form.getFieldValue('salesUnitPrice') || 0,
        salesAccountCode: '200',
        salesTaxType: 'INPUT'
      });
    }
  };
  
  const handleIsPurchasedChange = (checked: boolean) => {
    setIsPurchased(checked);
    if (!checked) {
      form.setFieldsValue({
        purchaseUnitPrice: null,
        purchaseAccountCode: null,
        purchaseTaxType: null
      });
    } else {
      form.setFieldsValue({
        purchaseUnitPrice: form.getFieldValue('purchaseUnitPrice') || 0,
        purchaseAccountCode: '310',
        purchaseTaxType: 'OUTPUT'
      });
    }
  };
  
  const handleIsTrackedAsInventoryChange = (checked: boolean) => {
    setIsTrackedAsInventory(checked);
    setProductType(checked ? 'Inventory' : 'Service');
    
    if (!checked) {
      form.setFieldsValue({
        Type: 'Service',
        QuantityOnHand: null,
        inventoryStartDate: null,
        inventoryAssetAccountCode: null,
        AssetAccountId: null
      });
    } else {
      form.setFieldsValue({
        Type: 'Inventory',
        QuantityOnHand: form.getFieldValue('QuantityOnHand') || 0,
        inventoryStartDate: form.getFieldValue('inventoryStartDate') || dayjs(),
        inventoryAssetAccountCode: '630',
        AssetAccountId: form.getFieldValue('AssetAccountId') || 'asset1'
      });
    }
  };

  return (
    <Drawer
      title={editingProduct ? 'Edit Product' : 'Add Product'}
      width={520}
      onClose={onClose}
      open={visible}
      bodyStyle={{ paddingBottom: 80 }}
      footer={
        <Space>
          <Button onClick={onClose}>Cancel</Button>
          <Button type="primary" loading={loading} onClick={handleSubmit}>
            {editingProduct ? 'Update' : 'Save'}
          </Button>
        </Space>
      }
    >
      {loadingAccounts ? (
        <div style={{ textAlign: 'center', padding: '30px 0' }}>
          <Spin tip={`Loading accounts from ${sourceSystem}...`} />
        </div>
      ) : (
        <Form
          form={form}
          layout="vertical"
          initialValues={{
            Type: 'Inventory',
            Active: true,
            Taxable: true,
            isSold: true,
            isPurchased: true,
            isTrackedAsInventory: true,
            salesTaxType: 'INPUT',
            purchaseTaxType: 'OUTPUT'
          }}
        >
          {!editingProduct && xeroEnabled && (
            <Form.Item
              name="sourceSystem"
              label="Source System"
            >
              <Radio.Group 
                onChange={handleSourceSystemChange} 
                value={sourceSystem}
              >
                <Radio.Button value="QuickBooks">QuickBooks</Radio.Button>
                <Radio.Button value="Xero">Xero</Radio.Button>
              </Radio.Group>
            </Form.Item>
          )}
          
          {/* Common Fields for both systems */}
          <Form.Item
            name={sourceSystem === 'Xero' ? 'name' : 'Name'}
            label="Product Name"
            rules={[{ required: true, message: 'Please enter the product name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            name={sourceSystem === 'Xero' ? 'description' : 'Description'}
            label="Description"
          >
            <TextArea rows={3} />
          </Form.Item>

          {/* System-specific fields */}
          {sourceSystem === 'Xero' ? (
            <>
              {/* Xero specific fields */}
              <Form.Item
                name="code"
                label="Product Code"
                tooltip="A unique code that identifies the product (SKU)"
                rules={[{ required: true, message: 'Please enter a product code' }]}
              >
                <Input />
              </Form.Item>
              
              <Divider>Product Options</Divider>
              
              <Form.Item 
                name="isSold" 
                label="This product is sold" 
                valuePropName="checked"
              >
                <Switch onChange={handleIsSoldChange} />
              </Form.Item>
              
              {isSold && (
                <>
                  <Form.Item
                    name="salesUnitPrice"
                    label="Sales Price"
                    rules={[{ required: isSold, message: 'Please enter a sales price' }]}
                  >
                    <InputNumber
                      style={{ width: '100%' }}
                      formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                      parser={(value) => value!.replace(/\$\s?|(,*)/g, '')}
                      min={0}
                    />
                  </Form.Item>
                  
                  <Form.Item
                    name="salesAccountCode"
                    label="Sales Account"
                    rules={[{ required: isSold, message: 'Please select a sales account' }]}
                  >
                    <Select placeholder="Select sales account">
                      {incomeAccounts.length > 0 ? (
                        incomeAccounts.map((account: any) => (
                          <Option key={account.id || account.code} value={account.id || account.code}>
                            {account.code ? `${account.code} - ${account.name}` : account.name}
                          </Option>
                        ))
                      ) : (
                        xeroAccountCodes.sales.map(account => (
                          <Option key={account.code} value={account.code}>
                            {account.code} - {account.name}
                          </Option>
                        ))
                      )}
                    </Select>
                  </Form.Item>
                  
                  <Form.Item
                    name="salesTaxType"
                    label="Sales Tax Type"
                    rules={[{ required: isSold, message: 'Please select a sales tax type' }]}
                  >
                    <Select placeholder="Select sales tax type">
                      {taxTypes.map(tax => (
                        <Option key={tax.value} value={tax.value}>
                          {tax.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </>
              )}
              
              <Form.Item 
                name="isPurchased" 
                label="This product is purchased" 
                valuePropName="checked"
              >
                <Switch onChange={handleIsPurchasedChange} />
              </Form.Item>
              
              {isPurchased && (
                <>
                  <Form.Item
                    name="purchaseUnitPrice"
                    label="Purchase Price"
                    rules={[{ required: isPurchased, message: 'Please enter a purchase price' }]}
                  >
                    <InputNumber
                      style={{ width: '100%' }}
                      formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                      parser={(value) => value!.replace(/\$\s?|(,*)/g, '')}
                      min={0}
                    />
                  </Form.Item>
                  
                  <Form.Item
                    name="purchaseAccountCode"
                    label="Purchase Account"
                    rules={[{ required: isPurchased, message: 'Please select a purchase account' }]}
                  >
                    <Select placeholder="Select purchase account">
                      {expenseAccounts.length > 0 ? (
                        expenseAccounts.map((account: any) => (
                          <Option key={account.id || account.code} value={account.id || account.code}>
                            {account.code ? `${account.code} - ${account.name}` : account.name}
                          </Option>
                        ))
                      ) : (
                        xeroAccountCodes.purchase.map(account => (
                          <Option key={account.code} value={account.code}>
                            {account.code} - {account.name}
                          </Option>
                        ))
                      )}
                    </Select>
                  </Form.Item>
                  
                  <Form.Item
                    name="purchaseTaxType"
                    label="Purchase Tax Type"
                    rules={[{ required: isPurchased, message: 'Please select a purchase tax type' }]}
                  >
                    <Select placeholder="Select purchase tax type">
                      {taxTypes.map(tax => (
                        <Option key={tax.value} value={tax.value}>
                          {tax.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </>
              )}
              
              <Form.Item 
                name="isTrackedAsInventory" 
                label="Track inventory for this product" 
                valuePropName="checked"
              >
                <Switch onChange={handleIsTrackedAsInventoryChange} />
              </Form.Item>
              
              {isTrackedAsInventory && (
                <>
                  <Divider>Inventory Settings</Divider>
                  <Form.Item
                    name="QuantityOnHand"
                    label="Initial Quantity on Hand"
                    rules={[{ required: isTrackedAsInventory, message: 'Please enter initial quantity' }]}
                  >
                    <InputNumber min={0} style={{ width: '100%' }} />
                  </Form.Item>
                  
                  <Form.Item
                    name="inventoryStartDate"
                    label="Inventory Start Date"
                    rules={[{ required: isTrackedAsInventory, message: 'Please select a start date' }]}
                  >
                    <DatePicker style={{ width: '100%' }} />
                  </Form.Item>
                  
                  <Form.Item
                    name="inventoryAssetAccountCode"
                    label="Inventory Asset Account"
                    rules={[{ required: isTrackedAsInventory, message: 'Please select an inventory asset account' }]}
                  >
                    <Select placeholder="Select inventory asset account">
                      {xeroAccountCodes.inventory.map(account => (
                        <Option key={account.code} value={account.code}>
                          {account.code} - {account.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </>
              )}
            </>
          ) : (
            <>
              {/* QuickBooks specific fields */}
              <Form.Item
                name="Type"
                label="Product Type"
                rules={[{ required: true, message: 'Please select a product type' }]}
              >
                <Select onChange={handleTypeChange}>
                  <Option value="Inventory">Inventory</Option>
                  <Option value="Service">Service</Option>
                  <Option value="NonInventory">Non-Inventory</Option>
                </Select>
              </Form.Item>
              
              <Form.Item
                name="UnitPrice"
                label="Unit Price"
                rules={[{ required: true, message: 'Please enter a unit price' }]}
              >
                <InputNumber
                  style={{ width: '100%' }}
                  formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={(value) => value!.replace(/\$\s?|(,*)/g, '')}
                  min={0}
                />
              </Form.Item>
              
              <Form.Item
                name="IncomeAccountId"
                label="Income Account"
                rules={[{ required: true, message: 'Please select an income account' }]}
              >
                <Select placeholder="Select income account">
                  {incomeAccounts.map((account: any) => (
                    <Option key={account.id} value={account.id}>
                      {account.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              
              {productType === 'Inventory' && (
                <>
                  <Form.Item
                    name="QuantityOnHand"
                    label="Initial Quantity on Hand"
                    rules={[{ required: true, message: 'Please enter initial quantity' }]}
                  >
                    <InputNumber min={0} style={{ width: '100%' }} />
                  </Form.Item>
                  
                  <Form.Item
                    name="inventoryStartDate"
                    label="Inventory Start Date"
                    rules={[{ required: true, message: 'Please select a start date' }]}
                  >
                    <DatePicker style={{ width: '100%' }} />
                  </Form.Item>
                  
                  <Form.Item
                    name="AssetAccountId"
                    label="Inventory Asset Account"
                    rules={[{ required: true, message: 'Please select an inventory asset account' }]}
                  >
                    <Select placeholder="Select inventory asset account">
                      {assetAccounts.map((account: any) => (
                        <Option key={account.id} value={account.id}>
                          {account.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  
                  <Form.Item
                    name="ExpenseAccountId"
                    label="Expense/COGS Account"
                    rules={[{ required: true, message: 'Please select an expense account' }]}
                  >
                    <Select placeholder="Select expense account">
                      {expenseAccounts.map((account: any) => (
                        <Option key={account.id} value={account.id}>
                          {account.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </>
              )}
              
              <Form.Item
                name="Taxable"
                label="Taxable"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
              
              <Form.Item
                name="Active"
                label="Active"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
            </>
          )}
          
          {/* Synchronization Options */}
          {!isExternalProduct && (
            <Form.Item
              name="syncTo"
              label={`Sync to ${sourceSystem}`}
              tooltip={`Create this product in ${sourceSystem}`}
            >
              <Checkbox 
                checked={syncToExternalSystem} 
                onChange={(e) => setSyncToExternalSystem(e.target.checked)}
              >
                Sync to {sourceSystem}
              </Checkbox>
            </Form.Item>
          )}
        </Form>
      )}
    </Drawer>
  );
};

export default ProductDrawer;