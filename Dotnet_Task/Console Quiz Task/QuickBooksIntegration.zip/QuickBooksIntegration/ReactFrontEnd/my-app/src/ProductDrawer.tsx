import React from 'react';
import { Drawer, Card, Typography, Row, Col } from 'antd';
import {
  AppstoreOutlined,
  ToolOutlined,
} from '@ant-design/icons';

const { Title, Text } = Typography;

interface Props {
  visible: boolean;
  onClose: () => void;
  onSelect: (type: 'inventory' | 'service') => void;
}

const ProductServiceDrawer: React.FC<Props> = ({ visible, onClose, onSelect }) => {
  return (
    <Drawer
      title="Product/Service information"
      placement="right"
      width={400}
      onClose={onClose}
      visible={visible}
    >
      <Row gutter={[16, 16]}>
        <Col span={24}>
          <Card
            hoverable
            onClick={() => onSelect('inventory')}
            bordered
          >
            <Row align="middle" gutter={16}>
              <Col>
                <AppstoreOutlined style={{ fontSize: 32, color: '#1890ff' }} />
              </Col>
              <Col>
                <Title level={5}>Inventory</Title>
                <Text type="secondary">
                  Products you buy and/or sell and that you track quantities of.
                </Text>
              </Col>
            </Row>
          </Card>
        </Col>

        <Col span={24}>
          <Card
            hoverable
            onClick={() => onSelect('service')}
            bordered
          >
            <Row align="middle" gutter={16}>
              <Col>
                <ToolOutlined style={{ fontSize: 32, color: '#1890ff' }} />
              </Col>
              <Col>
                <Title level={5}>Service</Title>
                <Text type="secondary">
                  Services you provide to customers, like landscaping or consulting.
                </Text>
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    </Drawer>
  );
};

export default ProductServiceDrawer;
