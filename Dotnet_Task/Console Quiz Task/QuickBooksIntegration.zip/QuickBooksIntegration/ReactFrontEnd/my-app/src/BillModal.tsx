import React, { useState } from "react";
import {
  Modal,
  Form,
  Input,
  DatePicker,
  Select,
  Button,
  Space,
  Collapse,
  Table,
  Divider,
  Upload,
  Typography
} from "antd";
import { PlusOutlined, DeleteOutlined, UploadOutlined } from "@ant-design/icons";
import dayjs from "dayjs";

const { Option } = Select;
const { TextArea } = Input;
const { Panel } = Collapse;
const { Text } = Typography;

// This function should be added within the Bill component
const BillModalForm = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [form] = Form.useForm();
  const [categoryItems, setCategoryItems] = useState([{ key: 1 }, { key: 2 }]);
  const [productItems, setProductItems] = useState([{ key: 1 }, { key: 2 }]);

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
  };

  const handleSave = () => {
    form.validateFields()
      .then(values => {
        console.log('Form values:', values);
        setIsModalVisible(false);
        form.resetFields();
      })
      .catch(info => {
        console.log('Validation failed:', info);
      });
  };

  const categoryColumns = [
    { title: "#", dataIndex: "key", key: "key", width: 50 },
    { title: "CATEGORY", dataIndex: "category", key: "category" },
    { title: "DESCRIPTION", dataIndex: "description", key: "description" },
    { title: "AMOUNT", dataIndex: "amount", key: "amount", width: 120 },
    { title: "BILLABLE", dataIndex: "billable", key: "billable", width: 100 },
    { title: "TAX", dataIndex: "tax", key: "tax", width: 80 },
    { title: "CUSTOMER", dataIndex: "customer", key: "customer", width: 120 },
    {
      title: "",
      key: "action",
      width: 50,
      render: (_, record) => (
        <Button 
          type="text" 
          icon={<DeleteOutlined />} 
          onClick={() => handleRemoveCategoryItem(record.key)}
        />
      ),
    },
  ];

  const productColumns = [
    { title: "#", dataIndex: "key", key: "key", width: 50 },
    { title: "PRODUCT/SERVICE", dataIndex: "product", key: "product" },
    { title: "DESCRIPTION", dataIndex: "description", key: "description" },
    { title: "QTY", dataIndex: "qty", key: "qty", width: 80 },
    { title: "RATE", dataIndex: "rate", key: "rate", width: 100 },
    { title: "AMOUNT", dataIndex: "amount", key: "amount", width: 120 },
    { title: "BILLABLE", dataIndex: "billable", key: "billable", width: 100 },
    { title: "TAX", dataIndex: "tax", key: "tax", width: 80 },
    { title: "CUSTOMER", dataIndex: "customer", key: "customer", width: 120 },
    {
      title: "",
      key: "action",
      width: 50,
      render: (_, record) => (
        <Button 
          type="text" 
          icon={<DeleteOutlined />} 
          onClick={() => handleRemoveProductItem(record.key)}
        />
      ),
    },
  ];

  const handleAddCategoryItem = () => {
    const newKey = categoryItems.length > 0 ? Math.max(...categoryItems.map(item => item.key)) + 1 : 1;
    setCategoryItems([...categoryItems, { key: newKey }]);
  };

  const handleRemoveCategoryItem = (key) => {
    setCategoryItems(categoryItems.filter(item => item.key !== key));
  };

  const handleAddProductItem = () => {
    const newKey = productItems.length > 0 ? Math.max(...productItems.map(item => item.key)) + 1 : 1;
    setProductItems([...productItems, { key: newKey }]);
  };

  const handleRemoveProductItem = (key) => {
    setProductItems(productItems.filter(item => item.key !== key));
  };

  const clearAllCategoryLines = () => {
    setCategoryItems([]);
  };

  const clearAllProductLines = () => {
    setProductItems([]);
  };

  return (
    <>
      {/* Add this button to your existing component to trigger the modal */}
      <Button 
        type="primary" 
        onClick={showModal}
        icon={<PlusOutlined />}
        style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
      >
        Create Bill
      </Button>

      <Modal
        title="Bill"
        open={isModalVisible}
        onCancel={handleCancel}
        width={1200}
        style={{ top: 20 }}
        footer={[
          <Button key="cancel" onClick={handleCancel}>
            Cancel
          </Button>,
          <Button key="print" onClick={() => console.log("Print")}>
            Print
          </Button>,
          <Button key="recurring" onClick={() => console.log("Make recurring")}>
            Make recurring
          </Button>,
          <Button key="save" type="primary" onClick={handleSave} style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}>
            Save
          </Button>,
          <Button
            key="saveSchedule"
            type="primary"
            onClick={() => console.log("Save and schedule")}
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Save and schedule payment
          </Button>,
        ]}
        closeIcon={<span style={{ fontSize: '24px' }}>×</span>}
      >
        <Form
          form={form}
          layout="vertical"
          initialValues={{ 
            billDate: dayjs(), 
            dueDate: dayjs()
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '24px' }}>
            <div style={{ flex: '1' }}>
              <Form.Item 
                label="Vendor" 
                name="vendor" 
                rules={[{ required: true, message: 'Please select a vendor' }]}
              >
                <Select 
                  placeholder="Choose a vendor"
                  showSearch
                  style={{ width: '100%' }}
                >
                  <Option value="vendor1">Vendor 1</Option>
                  <Option value="vendor2">Vendor 2</Option>
                </Select>
              </Form.Item>

              <Form.Item label="Mailing address" name="mailingAddress">
                <TextArea rows={4} />
              </Form.Item>
            </div>

            <div style={{ flex: '1', marginLeft: '24px' }}>
              <div style={{ textAlign: 'right', marginBottom: '20px' }}>
                <div style={{ fontSize: '12px', color: '#666' }}>BALANCE DUE</div>
                <div style={{ fontSize: '28px', fontWeight: 'bold' }}>$0.00</div>
              </div>

              <div style={{ display: 'flex', gap: '16px' }}>
                <Form.Item 
                  label="Terms" 
                  name="terms" 
                  style={{ flex: '1' }}
                >
                  <Select placeholder="Select terms">
                    <Option value="net15">Net 15</Option>
                    <Option value="net30">Net 30</Option>
                    <Option value="net60">Net 60</Option>
                  </Select>
                </Form.Item>

                <Form.Item 
                  label="Bill date" 
                  name="billDate" 
                  style={{ flex: '1' }}
                  rules={[{ required: true, message: 'Please select bill date' }]}
                >
                  <DatePicker style={{ width: '100%' }} format="MM/DD/YYYY" />
                </Form.Item>
              </div>

              <div style={{ display: 'flex', gap: '16px' }}>
                <Form.Item 
                  label="Due date" 
                  name="dueDate" 
                  style={{ flex: '1' }}
                  rules={[{ required: true, message: 'Please select due date' }]}
                >
                  <DatePicker style={{ width: '100%' }} format="MM/DD/YYYY" />
                </Form.Item>

                <Form.Item 
                  label="Bill no." 
                  name="billNumber" 
                  style={{ flex: '1' }}
                >
                  <Input placeholder="Enter bill number" />
                </Form.Item>
              </div>
            </div>
          </div>

          <Form.Item label="Tags" name="tags">
            <Input placeholder="Start typing to add a tag" />
          </Form.Item>
          
          <Collapse 
            defaultActiveKey={['category']} 
            style={{ marginBottom: '16px' }}
            expandIconPosition="end"
          >
            <Panel header="Category details" key="category">
              <Table 
                dataSource={categoryItems}
                columns={categoryColumns}
                pagination={false}
                size="small"
                bordered
                style={{ marginBottom: '16px' }}
              />
              <Space>
                <Button onClick={handleAddCategoryItem}>Add lines</Button>
                <Button onClick={clearAllCategoryLines}>Clear all lines</Button>
              </Space>
            </Panel>
          </Collapse>

          <Collapse 
            defaultActiveKey={['item']}
            expandIconPosition="end"
          >
            <Panel header="Item details" key="item">
              <Table 
                dataSource={productItems}
                columns={productColumns}
                pagination={false}
                size="small"
                bordered
                style={{ marginBottom: '16px' }}
              />
              <Space style={{ marginBottom: '16px' }}>
                <Button onClick={handleAddProductItem}>Add lines</Button>
                <Button onClick={clearAllProductLines}>Clear all lines</Button>
              </Space>
              
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '16px' }}>
                <div style={{ textAlign: 'right' }}>
                  <Text>Total</Text>
                  <div style={{ fontSize: '16px', fontWeight: 'bold' }}>$0.00</div>
                </div>
              </div>
            </Panel>
          </Collapse>

          <div style={{ display: 'flex', gap: '24px', marginTop: '24px' }}>
            <div style={{ flex: '1' }}>
              <Form.Item label="Memo" name="memo">
                <TextArea rows={4} />
              </Form.Item>
            </div>
            <div style={{ flex: '1' }}>
              <Form.Item label="Attachments">
                <Upload>
                  <Button icon={<UploadOutlined />}>Add attachment</Button>
                </Upload>
                <div style={{ marginTop: '8px', color: '#999', fontSize: '12px' }}>Max file size: 20 MB</div>
                <div style={{ marginTop: '8px' }}>
                  <a href="#">Show existing</a>
                </div>
                <div style={{ marginTop: '24px', textAlign: 'right' }}>
                  <a href="#">Privacy</a>
                </div>
              </Form.Item>
            </div>
          </div>

        </Form>
      </Modal>
    </>
  );
};
