import React, { useState, useEffect } from 'react';
import { 
  Drawer, 
  Form, 
  Input, 
  Button, 
  Select, 
  DatePicker, 
  InputNumber, 
  Space, 
  Divider, 
  message, 
  Spin,
  Table,
  Row,
  Col,
  Typography
} from 'antd';
import { PlusOutlined, DeleteOutlined, SaveOutlined, CloseOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';

const { Option } = Select;
const { TextArea } = Input;
const { Title } = Typography;

interface XeroBillDrawerProps {
  visible: boolean;
  onClose: (refresh?: boolean) => void;
  bill: any | null;
  tenantId: string;
}

interface XeroContact {
  id: number;
  xeroContactId: string;
  displayName: string;
  email?: string;
  billingLine1?: string;
  billingCity?: string;
  billingState?: string;
  billingPostalCode?: string;
  billingCountry?: string;
}

interface XeroItem {
  id: number;
  xeroItemId: string;
  code: string;
  name: string;
  description: string;
  xeroPurchaseUnitPrice: number;
  xeroPurchaseAccountCode: string | null;
  xeroPurchaseTaxType: string;
}

interface LineItem {
  key: number;
  itemCode: string;
  description: string;
  quantity: number;
  unitAmount: number;
  accountCode: string;
  taxType: string;
  amount: number;
}

const XeroBillDrawer: React.FC<XeroBillDrawerProps> = ({ 
  visible, 
  onClose, 
  bill, 
  tenantId 
}) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [contacts, setContacts] = useState<XeroContact[]>([]);
  const [items, setItems] = useState<XeroItem[]>([]);
  const [lineItems, setLineItems] = useState<LineItem[]>([]);
  const [currentItemKey, setCurrentItemKey] = useState<number>(0);
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [subtotal, setSubtotal] = useState<number>(0);
  const [tax, setTax] = useState<number>(0);
  const [loadingContacts, setLoadingContacts] = useState<boolean>(false);
  const [loadingItems, setLoadingItems] = useState<boolean>(false);

  // Fetch Xero data when drawer opens
  useEffect(() => {
    if (visible) {
      fetchXeroContacts();
      fetchXeroItems();
      
      // Initialize form with default values or existing bill data
      initializeForm();
    }
  }, [visible, bill]);

  const initializeForm = () => {
    if (bill) {
      // Set form values if editing an existing bill
      form.setFieldsValue({
        contactId: bill.contactId,
        date: bill.date ? dayjs(bill.date) : dayjs(),
        dueDate: bill.dueDate ? dayjs(bill.dueDate) : dayjs().add(30, 'days'),
        reference: bill.reference || '',
        notes: bill.notes || '',
        currency: bill.currencyCode || 'INR',
        lineAmountTypes: bill.lineAmountTypes || 'Exclusive',
      });
      
      // Initialize line items if editing an existing bill
      if (bill.lineItems && bill.lineItems.length > 0) {
        const initialLineItems = bill.lineItems.map((item: any, index: number) => ({
          key: index,
          itemCode: item.itemCode || '',
          description: item.description || '',
          quantity: item.quantity || 1,
          unitAmount: item.unitAmount || 0,
          accountCode: item.accountCode || '',
          taxType: item.taxType || 'NONE',
          amount: item.lineAmount || (item.quantity * item.unitAmount) || 0
        }));
        
        setLineItems(initialLineItems);
        setCurrentItemKey(initialLineItems.length);
        calculateTotals(initialLineItems);
      } else {
        // Initialize with one empty line item
        initializeEmptyLineItems();
      }
    } else {
      // Set default values for new bill
      form.setFieldsValue({
        date: dayjs(),
        dueDate: dayjs().add(30, 'days'),
        currency: 'INR',
        lineAmountTypes: 'Exclusive',
      });
      
      // Initialize with one empty line item
      initializeEmptyLineItems();
    }
  };

  const initializeEmptyLineItems = () => {
    const defaultLineItem = {
      key: 0,
      itemCode: '',
      description: '',
      quantity: 1,
      unitAmount: 0,
      accountCode: '',
      taxType: 'NONE',
      amount: 0
    };
    setLineItems([defaultLineItem]);
    setCurrentItemKey(1);
    calculateTotals([defaultLineItem]);
  };

  const fetchXeroContacts = async () => {
    if (!tenantId) {
      message.error('No Xero tenant ID available');
      return;
    }
    
    setLoadingContacts(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/XeroContacts?tenantId=${tenantId}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch Xero contacts');
      }
      
      const data = await response.json();
      

      if (data && data.data && Array.isArray(data.data)) {
        const formattedContacts = data.data.map((contact: any) => ({
          id: contact.id,
          xeroContactId: contact.xeroContactId,
          displayName: contact.displayName,
          email: contact.email,
          billingLine1: contact.billingLine1,
          billingCity: contact.billingCity,
          billingState: contact.billingState,
          billingPostalCode: contact.billingPostalCode,
          billingCountry: contact.billingCountry
        }));
        
        setContacts(formattedContacts);
      } else {
        console.error('Unexpected contacts data format:', data);
        message.error('Failed to parse contact data from API');
      }
    } catch (error) {
      console.error('Error fetching Xero contacts:', error);
      message.error('Failed to load contacts from Xero');
    } finally {
      setLoadingContacts(false);
    }
  };

  const formatAddress = (contact: XeroContact) => {
    if (!contact) return '';
    
    const parts = [
      contact.billingLine1,
      contact.billingCity,
      contact.billingState,
      contact.billingPostalCode,
      contact.billingCountry
    ].filter(Boolean);
    
    return parts.join(', ');
  };

  const fetchXeroItems = async () => {
    if (!tenantId) {
      message.error('No Xero tenant ID available');
      return;
    }
    
    setLoadingItems(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/products?tenantId=${tenantId}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch Xero items');
      }
      
      const data = await response.json();
      
      // Transform items to the format we need based on the products data in your message
      if (data && data.data && Array.isArray(data.data)) {
        const formattedItems = data.data.map((item: any) => ({
          id: item.id,
          xeroItemId: item.xeroItemId,
          code: item.code,
          name: item.name,
          description: item.description || item.purchaseDescription || '',
          xeroPurchaseUnitPrice: item.xeroPurchaseUnitPrice || 0,
          xeroPurchaseAccountCode: item.xeroPurchaseAccountCode || item.xeroCOGSAccountCode || '',
          xeroPurchaseTaxType: item.xeroPurchaseTaxType || 'NONE'
        }));
        
        setItems(formattedItems);
      } else {
        console.error('Unexpected items data format:', data);
        message.error('Failed to parse item data from API');
      }
    } catch (error) {
      console.error('Error fetching Xero items:', error);
      message.error('Failed to load items from Xero');
    } finally {
      setLoadingItems(false);
    }
  };

  const handleAddLineItem = () => {
    const newItem: LineItem = {
      key: currentItemKey,
      itemCode: '',
      description: '',
      quantity: 1,
      unitAmount: 0,
      accountCode: '',
      taxType: 'NONE',
      amount: 0
    };

    
    
    const updatedItems = [...lineItems, newItem];
    setLineItems(updatedItems);
    setCurrentItemKey(currentItemKey + 1);
    calculateTotals(updatedItems);
  };

  const handleRemoveLineItem = (key: number) => {
    if (lineItems.length > 1) {
      const updatedItems = lineItems.filter(item => item.key !== key);
      setLineItems(updatedItems);
      calculateTotals(updatedItems);
    } else {
      message.warning('You must have at least one line item');
    }
  };

  const updateLineItemField = (key: number, field: string, value: any) => {
    const updatedItems = lineItems.map(item => {
      if (item.key === key) {
        const updatedItem = { ...item, [field]: value };
        
        // If item code is changed, fetch details from items list
        if (field === 'itemCode') {
          const selectedItem = items.find(i => i.code === value);
          if (selectedItem) {
            updatedItem.description = selectedItem.description;
            updatedItem.unitAmount = selectedItem.xeroPurchaseUnitPrice || 0;
            updatedItem.accountCode = selectedItem.xeroPurchaseAccountCode || '';
            updatedItem.taxType = selectedItem.xeroPurchaseTaxType || 'NONE';
          }
        }
        
        // Update amount if quantity or unitAmount changes
        if (field === 'quantity' || field === 'unitAmount') {
          updatedItem.amount = updatedItem.quantity * updatedItem.unitAmount;
        }
        
        return updatedItem;
      }
      return item;
    });
    
    setLineItems(updatedItems);
    calculateTotals(updatedItems);
  };

  const calculateTotals = (items: LineItem[]) => {
    const itemSubtotal = items.reduce((sum, item) => sum + (item.amount || 0), 0);
    setSubtotal(itemSubtotal);
    
    // Calculate tax based on tax type
    let calculatedTax = 0;
    items.forEach(item => {
      // This is a simplified calculation - actual tax would depend on Xero's specific tax types
      if (item.taxType === 'INPUT') {
        calculatedTax += item.amount * 0.1; // Example: 10% tax
      } else if (item.taxType === 'OUTPUT') {
        calculatedTax += item.amount * 0.15; // Example: 15% tax
      }
    });
    
    setTax(calculatedTax);
    setTotalAmount(itemSubtotal + calculatedTax);
  };

  const handleItemChange = (key: number, selectedItemCode: string) => {
    const selectedItem = items.find(item => item.code === selectedItemCode);
    
    if (selectedItem) {
      // Get the current line item
      const currentLineItem = lineItems.find(item => item.key === key);
      const quantity = currentLineItem ? currentLineItem.quantity : 1;
      
      // Update all fields at once to ensure consistency
      const updatedItems = lineItems.map(item => {
        if (item.key === key) {
          const unitAmount = selectedItem.xeroPurchaseUnitPrice || 0;
          const amount = quantity * unitAmount;
          
          return {
            ...item,
            itemCode: selectedItemCode,
            description: selectedItem.description || '',
            unitAmount: unitAmount,
            accountCode: "630", 
            taxType: selectedItem.xeroPurchaseTaxType || 'NONE',
            amount: amount
          };
        }
        return item;
      });
      
      setLineItems(updatedItems);
      calculateTotals(updatedItems);
    }
  };

  const handleContactChange = (contactId: string) => {
    const selectedContact = contacts.find(c => c.xeroContactId === contactId);
    if (selectedContact) {
      // If contact has billing address info, automatically populate the form
      const formattedAddress = formatAddress(selectedContact);
      form.setFieldsValue({
        contactAddress: formattedAddress
      });
    }
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      setSubmitting(true);
      
      // Format the data according to Xero API requirements
      const billData = {
        Id: bill?.id || undefined,
        // Use Contact object instead of flat ContactId to match Xero API expectations
        Contact: {
          ContactID: values.contactId
        },
        Date: values.date.format('YYYY-MM-DD'),
        DueDate: values.dueDate.format('YYYY-MM-DD'),
        Reference: values.reference,
        CurrencyCode: values.currency,
        Status: 'AUTHORISED',
        LineAmountTypes: values.lineAmountTypes,
        Type: 'ACCPAY',
        LineItems: lineItems.map(item => ({
          Description: item.description,
          Quantity: item.quantity,
          UnitAmount: item.unitAmount,
          AccountCode: item.accountCode,
          ItemCode: item.itemCode,
          TaxType: item.taxType,
          LineAmount: item.amount
        }))
      };
      
      const url = bill?.id 
        ? `${import.meta.env.VITE_API_BASE_URL}/api/XeroBills/${bill.id}?tenantId=${tenantId}`
        : `${import.meta.env.VITE_API_BASE_URL}/api/XeroBills?tenantId=${tenantId}`;
      
      const method = bill?.id ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(billData)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to save bill');
      }
      
      message.success(`Bill ${bill?.id ? 'updated' : 'created'} successfully`);
      onClose(true); // Close and refresh list
    } catch (error) {
      console.error('Error saving Xero bill:', error);
      message.error(`Failed to ${bill?.id ? 'update' : 'create'} bill: ${error.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  // Table columns for line items
  const lineItemColumns = [
    {
      title: 'Item',
      dataIndex: 'itemCode',
      key: 'itemCode',
      width: '15%',
      render: (text: string, record: LineItem) => (
        <Select
          value={text || undefined}
          style={{ width: '100%' }}
          placeholder="Select item"
          showSearch
          loading={loadingItems}
          filterOption={(input, option) =>
            (option?.children as unknown as string).toLowerCase().indexOf(input.toLowerCase()) >= 0
          }
          onChange={(value) => handleItemChange(record.key, value)}
        >
          {items.map(item => (
            <Option key={item.xeroItemId} value={item.code}>{item.code} - {item.name}</Option>
          ))}
        </Select>
      ),
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
      width: '30%',
      render: (text: string, record: LineItem) => (
        <Input
          value={text}
          onChange={(e) => updateLineItemField(record.key, 'description', e.target.value)}
          placeholder="Enter description"
        />
      ),
    },
    {
      title: 'Qty',
      dataIndex: 'quantity',
      key: 'quantity',
      width: '10%',
      render: (value: number, record: LineItem) => (
        <InputNumber
          min={1}
          value={value}
          onChange={(value) => updateLineItemField(record.key, 'quantity', value)}
          style={{ width: '100%' }}
        />
      ),
    },
    {
      title: 'Unit Price',
      dataIndex: 'unitAmount',
      key: 'unitAmount',
      width: '15%',
      render: (value: number, record: LineItem) => (
        <InputNumber
          min={0}
          step={0.01}
          value={value}
          onChange={(value) => updateLineItemField(record.key, 'unitAmount', value)}
          style={{ width: '100%' }}
          formatter={(value) => `${value}`}
          parser={(value) => parseFloat(value || '0')}
        />
      ),
    },
    {
      title: 'Tax Type',
      dataIndex: 'taxType',
      key: 'taxType',
      width: '10%',
      render: (text: string, record: LineItem) => (
        <Select
          value={text || undefined}
          style={{ width: '100%' }}
          onChange={(value) => updateLineItemField(record.key, 'taxType', value)}
        >
          <Option value="NONE">None</Option>
          <Option value="INPUT">Tax on Purchases</Option>
          <Option value="OUTPUT">Tax on Sales</Option>
          <Option value="EXEMPTINPUT">Exempt Input</Option>
          <Option value="EXEMPTOUTPUT">Exempt Output</Option>
          <Option value="ZERORATED">Zero Rated</Option>
        </Select>
      ),
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      width: '12%',
      render: (amount: number) => (
        <span>{amount.toFixed(2)}</span>
      ),
    },
    {
      title: '',
      key: 'action',
      width: '5%',
      render: (_: any, record: LineItem) => (
        <Button
          type="text"
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveLineItem(record.key)}
          danger
        />
      ),
    },
  ];

  return (
    <Drawer
      title={bill ? "Edit Xero Bill" : "Create Xero Bill"}
      width="80%"
      placement="right"
      onClose={() => onClose(false)}
      open={visible}
      bodyStyle={{ paddingBottom: 80 }}
      extra={
        <Space>
          <Button onClick={() => onClose(false)} icon={<CloseOutlined />}>
            Cancel
          </Button>
          <Button
            type="primary"
            loading={submitting}
            onClick={handleSubmit}
            icon={<SaveOutlined />}
          >
            {bill ? 'Update Bill' : 'Create Bill'}
          </Button>
        </Space>
      }
    >
      <Spin spinning={loading || loadingContacts || loadingItems}>
        <Form
          form={form}
          layout="vertical"
        >
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="contactId"
                label="Vendor"
                rules={[{ required: true, message: 'Please select a vendor' }]}
              >
                <Select
                  placeholder="Select a vendor"
                  showSearch
                  loading={loadingContacts}
                  filterOption={(input, option) =>
                    (option?.children as unknown as string).toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onChange={handleContactChange}
                >
                  {contacts.map(contact => (
                    <Option key={contact.id} value={contact.xeroContactId}>
                      {contact.displayName}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                name="date"
                label="Date"
                rules={[{ required: true, message: 'Please select a date' }]}
              >
                <DatePicker 
                  style={{ width: '100%' }} 
                  format="DD MMM YYYY"
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                name="dueDate"
                label="Due Date"
                rules={[{ required: true, message: 'Please select a due date' }]}
              >
                <DatePicker 
                  style={{ width: '100%' }} 
                  format="DD MMM YYYY"
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="contactAddress"
                label="Vendor Address"
              >
                <TextArea rows={2} readOnly />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                name="reference"
                label="Reference"
              >
                <Input placeholder="Reference number" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item
                name="currency"
                label="Currency"
                rules={[{ required: true, message: 'Please select currency' }]}
              >
                <Select>
                  <Option value="INR">INR Indian Rupee</Option>
                  <Option value="USD">USD US Dollar</Option>
                  <Option value="GBP">GBP British Pound</Option>
                  <Option value="EUR">EUR Euro</Option>
                  <Option value="AUD">AUD Australian Dollar</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="lineAmountTypes"
                label="Amounts are"
                rules={[{ required: true, message: 'Please select tax handling' }]}
              >
                <Select>
                  <Option value="Exclusive">Tax Exclusive</Option>
                  <Option value="Inclusive">Tax Inclusive</Option>
                  <Option value="NoTax">No Tax</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Divider />

          <Table
            rowKey="key"
            columns={lineItemColumns}
            dataSource={lineItems}
            pagination={false}
            size="small"
            scroll={{ x: 'max-content' }}
          />

          <div style={{ marginTop: 16, marginBottom: 16 }}>
            <Button 
              type="default" 
              icon={<PlusOutlined />} 
              onClick={handleAddLineItem}
            >
              Add Line Item
            </Button>
          </div>

          <Row gutter={16}>
            <Col span={16}>
              <Form.Item
                name="notes"
                label="Notes"
              >
                <TextArea rows={3} placeholder="Enter notes or additional information" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <div style={{ textAlign: 'right', padding: '20px 0', backgroundColor: '#f9f9f9', borderRadius: '4px', paddingRight: '16px' }}>
                <div style={{ marginBottom: 8 }}>
                  <span style={{ width: 100, display: 'inline-block', textAlign: 'left' }}>Subtotal</span>
                  <span style={{ width: 100, display: 'inline-block', textAlign: 'right' }}>{subtotal.toFixed(2)}</span>
                </div>
                <div style={{ marginBottom: 8 }}>
                  <span style={{ width: 100, display: 'inline-block', textAlign: 'left' }}>Tax</span>
                  <span style={{ width: 100, display: 'inline-block', textAlign: 'right' }}>{tax.toFixed(2)}</span>
                </div>
                <Divider style={{ margin: '8px 0' }} />
                <div style={{ fontWeight: 'bold' }}>
                  <span style={{ width: 100, display: 'inline-block', textAlign: 'left' }}>TOTAL</span>
                  <span style={{ width: 100, display: 'inline-block', textAlign: 'right' }}>{totalAmount.toFixed(2)}</span>
                </div>
              </div>
            </Col>
          </Row>
        </Form>
      </Spin>
    </Drawer>
  );
};

export default XeroBillDrawer;