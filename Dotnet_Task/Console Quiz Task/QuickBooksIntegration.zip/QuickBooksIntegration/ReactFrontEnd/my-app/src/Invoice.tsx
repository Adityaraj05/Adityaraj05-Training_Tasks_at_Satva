import React, { useEffect, useState, useRef } from 'react';
import { Table, Button, Input, Space, Popconfirm, message, Drawer, Pagination, Spin, Empty, Upload, Modal, Select } from 'antd';
import { SearchOutlined, ReloadOutlined, PlusOutlined, EditOutlined, DeleteOutlined, UploadOutlined, FileExcelOutlined } from '@ant-design/icons';
import { InvoiceDto, InvoiceInputModel } from './types/invoice';
import InvoiceDrawer from './InvoiceDrawer';
import dayjs from 'dayjs';

const { Option } = Select;

const Invoice: React.FC = () => {
  // State hooks
  const [invoices, setInvoices] = useState<InvoiceDto[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchText, setSearchText] = useState<string>('');
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0
  });
  const [drawerVisible, setDrawerVisible] = useState<boolean>(false);
  const [editingInvoice, setEditingInvoice] = useState<InvoiceDto | null>(null);
  const [sortField, setSortField] = useState<string>('CreatedAt');
  const [sortDirection, setSortDirection] = useState<string>('desc');
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [uploadModalVisible, setUploadModalVisible] = useState<boolean>(false);
  const [validatingCsv, setValidatingCsv] = useState<boolean>(false);
  const [importingCsv, setImportingCsv] = useState<boolean>(false);
  const [validationErrors, setValidationErrors] = useState<Array<{rowNumber: number, message: string}>>([]);
  const [selectedSource, setSelectedSource] = useState<string>('QuickBooks');
  const [isXeroConnected, setIsXeroConnected] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchTimeout = useRef<NodeJS.Timeout | null>(null);

  // Check if Xero is connected
  useEffect(() => {
    const checkXeroAuth = () => {
      const xeroAccessToken = localStorage.getItem('xero_access_token');
      const xeroTenantId = localStorage.getItem('xero_tenant_id');
      setIsXeroConnected(Boolean(xeroAccessToken && xeroTenantId));
    };
    
    checkXeroAuth();
    
    // Set up an event listener for storage changes
    window.addEventListener('storage', checkXeroAuth);
    return () => window.removeEventListener('storage', checkXeroAuth);
  }, []);

  // Fetch invoices from backend
  const fetchInvoices = async (
    page: number = pagination.current,
    pageSize: number = pagination.pageSize,
    search: string = searchText,
    sortBy: string = sortField,
    sortDir: string = sortDirection,
    source: string = selectedSource
  ) => {
    setLoading(true);
    try {
      if (source === 'QuickBooks') {
        // Fetch from QuickBooks API endpoint
        const realmId = localStorage.getItem('qb_realm_id');
        
        if (!realmId) {
          message.error('QuickBooks RealmID is required');
          return;
        }
        
        const url = `${import.meta.env.VITE_API_BASE_URL}/api/invoice?page=${page}&pageSize=${pageSize}&search=${search}&sortBy=${sortBy}&sortDirection=${sortDir}&realmId=${realmId}`;
        const res = await fetch(url);
        
        if (!res.ok) {
          const errorData = await res.json();
          console.error('Error response:', errorData);
          throw new Error(errorData.title || `HTTP error! status: ${res.status}`);
        }
        
        const data = await res.json();
        setInvoices(data.data);
        setPagination({
          ...pagination,
          current: data.page,
          pageSize: data.pageSize,
          total: data.totalRecords
        });
      } else if (source === 'Xero') {
        // Fetch from Xero API endpoint
        const tenantId = localStorage.getItem('xero_tenant_id');
        
        if (!tenantId) {
          message.error('Xero Tenant ID is required');
          return;
        }
        
        const url = `${import.meta.env.VITE_API_BASE_URL}/api/XeroInvoices?tenantId=${tenantId}&page=${page}&pageSize=${pageSize}&filter=${search}&sortBy=${sortBy}&sortOrder=${sortDir}`;
        const res = await fetch(url);

   
        
        
        if (!res.ok) {
          const errorData = await res.json();
          console.error('Error response:', errorData);
          throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
        }
        
        const data = await res.json();
        console.log(data);
        
        if (!data.success) {
          throw new Error(data.message || 'Failed to fetch Xero invoices');
        }
        
        setInvoices(data.data);
        setPagination({
          ...pagination,
          current: page,
          pageSize: pageSize,
          total: data.totalCount || data.data.length
        });
      }
    } catch (error) {
      console.error('Error fetching invoices:', error);
      message.error(`Failed to load invoices: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Sync invoices from QuickBooks
  const syncInvoicesFromQuickBooks = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('qb_access_token');
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!token || !realmId) {
        message.error('QuickBooks authentication required');
        return;
      }
  
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/invoice/fetch?realmId=${realmId}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          }
        }
      );
  
      if (!res.ok) {
        const errorData = await res.json();
        console.error('Error response:', errorData);
        throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
      }
  
      const data = await res.json();
      message.success(`${data.invoicesAdded} invoices added, ${data.invoicesUpdated} invoices updated!`);
      
      // Refresh the list
      fetchInvoices();
    } catch (error) {
      console.error('Error syncing invoices from QuickBooks:', error);
      message.error(`Failed to sync invoices from QuickBooks: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Sync invoices from Xero
  const syncInvoicesFromXero = async () => {
    if (!isXeroConnected) {
      message.error('Please connect to Xero first');
      return;
    }
    
    setLoading(true);
    try {
      const tenantId = localStorage.getItem('xero_tenant_id');
      
      if (!tenantId) {
        message.error('Xero Tenant ID is required');
        return;
      }
  
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/XeroInvoices/sync?tenantId=${tenantId}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          }
        }
      
      );
  
      if (!res.ok) {
        const errorData = await res.json();
        console.error('Error response:', errorData);
        throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
      }
  
      const data = await res.json();
      
      if (!data.success) {
        throw new Error(data.message || 'Failed to sync Xero invoices');
      }
      
      message.success('Invoices synced successfully from Xero!');
      
      // Refresh the list
      fetchInvoices(pagination.current, pagination.pageSize, searchText, sortField, sortDirection, 'Xero');
      setSelectedSource('Xero');
    } catch (error) {
      console.error('Error syncing invoices from Xero:', error);
      message.error(`Failed to sync invoices from Xero: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Delete invoice
  const deleteInvoice = async (invoiceId: string | number, source: string, externalId:string) => {
    try {
      if (source === 'QuickBooks') {
        const token = localStorage.getItem('qb_access_token');
        const realmId = localStorage.getItem('qb_realm_id');
        
        if (!token || !realmId) {
          message.error('QuickBooks authentication required');
          return;
        }
    
        const res = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/api/invoice/${invoiceId}?realmId=${realmId}`,
          {
            method: 'DELETE',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            }
          }
        );
    
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
        }
      } else if (source === 'Xero') {
        const tenantId = localStorage.getItem('xero_tenant_id');
        
        if (!tenantId) {
          message.error('Xero Tenant ID is required');
          return;
        }
    
        const res = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/api/XeroInvoices/${externalId}?tenantId=${tenantId}`,
          {
            method: 'DELETE'
          }
        );
    
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
        }
      }
  
      message.success('Invoice deleted successfully');
      fetchInvoices(pagination.current, pagination.pageSize, searchText, sortField, sortDirection, selectedSource);
    } catch (error) {
      console.error('Error deleting invoice:', error);
      message.error(`Failed to delete invoice: ${error.message}`);
    }
  };

  // Handle search input change with debounce
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchText(value);
    
    if (searchTimeout.current) {
      clearTimeout(searchTimeout.current);
    }
    
    searchTimeout.current = setTimeout(() => {
      fetchInvoices(1, pagination.pageSize, value, sortField, sortDirection, selectedSource);
    }, 500);
  };

  // Handle table sorting
  const handleTableChange = (paginationInfo: any, filters: any, sorter: any) => {
    const { current, pageSize } = paginationInfo;
    
    let sortBy = 'CreatedAt';
    let sortDir = 'desc';
    
    if (sorter.field) {
      sortBy = sorter.field;
      sortDir = sorter.order === 'ascend' ? 'asc' : 'desc';
    }
    
    setSortField(sortBy);
    setSortDirection(sortDir);
    
    setPagination(prev => ({
      ...prev,
      current,
      pageSize
    }));
    
    fetchInvoices(current, pageSize, searchText, sortBy, sortDir, selectedSource);
  };

  // Handle source selection change
  const handleSourceChange = (value: string) => {
    console.log("Selected source:", value);
    setSelectedSource(value);
    
    // Reset pagination
    setPagination(prev => ({
      ...prev,
      current: 1
    }));
    
    // Fetch data with the new source filter
    fetchInvoices(1, pagination.pageSize, searchText, sortField, sortDirection, value);
  };

  // CSV Upload functions
  const showUploadModal = () => {
    setUploadModalVisible(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCsvFile(e.target.files[0]);
      setValidationErrors([]);
    }
  };

  const validateCsvFile = async () => {
    if (!csvFile) {
      message.error('Please select a CSV file to upload');
      return;
    }

    setValidatingCsv(true);
    try {
      // Only supporting QuickBooks CSV validation for now
      if (selectedSource !== 'QuickBooks') {
        message.error('CSV validation is only available for QuickBooks invoices');
        return false;
      }

      const token = localStorage.getItem('qb_access_token');
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!token || !realmId) {
        message.error('QuickBooks authentication required');
        return;
      }

      const formData = new FormData();
      formData.append('file', csvFile);

      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/csvimport/validate`,
        {
          method: 'POST',
          body: formData
        }
      );

      const data = await res.json();
      
      if (!data.isValid) {
        setValidationErrors(data.errors || []);
        message.error('CSV validation failed. Please correct the errors and try again.');
        return false;
      } else {
        message.success('CSV file is valid!');
        return true;
      }
    } catch (error) {
      console.error('Error validating CSV file:', error);
      message.error('Failed to validate CSV file');
      return false;
    } finally {
      setValidatingCsv(false);
    }
  };

  const importCsvFile = async () => {
    const isValid = await validateCsvFile();
    
    if (!isValid || !csvFile) {
      return;
    }

    setImportingCsv(true);
    try {
      // Only supporting QuickBooks CSV import for now
      if (selectedSource !== 'QuickBooks') {
        message.error('CSV import is only available for QuickBooks invoices');
        return;
      }

      const token = localStorage.getItem('qb_access_token');
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!token || !realmId) {
        message.error('QuickBooks authentication required');
        return;
      }

      const formData = new FormData();
      formData.append('file', csvFile);

      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/csvimport/import?accessToken=${encodeURIComponent(token)}&realmId=${encodeURIComponent(realmId)}`,
        {
          method: 'POST',
          body: formData
        }
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
      }

      const data = await res.json();
      
      if (data.success) {
        message.success(`CSV import successful! Created ${data.createdInvoices} invoices and updated ${data.updatedInvoices} invoices.`);
        setUploadModalVisible(false);
        setCsvFile(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
        fetchInvoices(pagination.current, pagination.pageSize, searchText, sortField, sortDirection, selectedSource);
      } else {
        message.error(`CSV import failed: ${data.errors?.join(', ')}`);
      }
    } catch (error) {
      console.error('Error importing CSV file:', error);
      message.error(`Failed to import CSV file: ${error.message}`);
    } finally {
      setImportingCsv(false);
    }
  };

  // Open drawer for creating new invoice
  const openCreateDrawer = () => {
    setEditingInvoice(null);
    setDrawerVisible(true);
  };

  // Open drawer for editing invoice
  const openEditDrawer = (invoice: InvoiceDto) => {
    setEditingInvoice(invoice);
    setDrawerVisible(true);
  };

  // Handle drawer close
  const handleDrawerClose = () => {
    setDrawerVisible(false);
    setEditingInvoice(null);
  };


const handleFormSubmit = async (values: any) => {
  try {
    if (selectedSource === 'QuickBooks') {
      // Handle QuickBooks invoice submission
      const token = localStorage.getItem('qb_access_token');
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!token || !realmId) {
        message.error('QuickBooks authentication required');
        return;
      }
      
      // Ensure we're using the invoiceInput wrapper as expected by the API
      const invoiceInput = values.invoiceInput;
      
      const method = editingInvoice ? 'PUT' : 'POST';
      const url = editingInvoice 
        ? `${import.meta.env.VITE_API_BASE_URL}/api/invoice/${editingInvoice.invoiceId}?realmId=${realmId}`
        : `${import.meta.env.VITE_API_BASE_URL}/api/invoice?realmId=${realmId}`;
  
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(values) // Send the entire payload with invoiceInput
      });
  
      if (!res.ok) {
        const errorData = await res.json();
        console.error("API error:", errorData);
        throw new Error(errorData.message || errorData.title || `HTTP error! status: ${res.status}`);
      }
    } else if (selectedSource === 'Xero') {
      // Handle Xero invoice submission
      const tenantId = localStorage.getItem('xero_tenant_id');
      
      if (!tenantId) {
        message.error('Xero Tenant ID is required');
        return;
      }
      
      // Make sure we're sending the proper structure with invoiceInput
      const method = editingInvoice ? 'PUT' : 'POST';
      const url = editingInvoice 
        ? `${import.meta.env.VITE_API_BASE_URL}/api/XeroInvoices/${editingInvoice.externalId}?tenantId=${tenantId}`
        : `${import.meta.env.VITE_API_BASE_URL}/api/XeroInvoices?tenantId=${tenantId}`;
      
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(values) // Send the entire payload with invoiceInput
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        console.error("API error:", errorData);
        throw new Error(errorData.message || errorData.title || `HTTP error! status: ${res.status}`);
      }
    }

    message.success(editingInvoice ? 'Invoice updated successfully' : 'Invoice created successfully');
    handleDrawerClose();
    fetchInvoices(pagination.current, pagination.pageSize, searchText, sortField, sortDirection, selectedSource);
  } catch (error) {
    console.error('Error saving invoice:', error);
    message.error(`Failed to save invoice: ${error.message}`);
  }
};
  // Initial fetch on component mount
  useEffect(() => {
    const initialSource = isXeroConnected ? 'QuickBooks' : 'QuickBooks';
    setSelectedSource(initialSource);
    fetchInvoices(1, pagination.pageSize, searchText, sortField, sortDirection, initialSource);
  }, [isXeroConnected]);

  // Define table columns
  const getColumns = () => {
    // Common columns for both sources
    const commonColumns = [
      {
        title: 'Actions',
        key: 'actions',
        render: (_: any, record: InvoiceDto) => (
          <Space size="middle">
            <Button 
              icon={<EditOutlined />} 
              type="primary" 
              size="small" 
              onClick={() => openEditDrawer(record)}
            />
            <Popconfirm
              title="Are you sure you want to delete this invoice?"
              onConfirm={() => deleteInvoice(record.invoiceId, selectedSource)}
              okText="Yes"
              cancelText="No"
            >
              <Button icon={<DeleteOutlined />} type="primary" danger size="small" />
            </Popconfirm>
          </Space>
        ),
      }
    ];
    
    // QuickBooks specific columns
    if (selectedSource === 'QuickBooks') {
      return [
        {
          title: 'Invoice #',
          dataIndex: 'invoiceId',
          key: 'invoiceId',
          sorter: true,
        },
        {
          title: 'Due Date',
          dataIndex: 'dueDate',
          key: 'dueDate',
          render: (text: string) => text ? dayjs(text).format('MM/DD/YYYY') : 'N/A',
          sorter: true,
        },
        {
          title: 'Store',
          dataIndex: 'store',
          key: 'store',
        },
        {
          title: 'Billing Address',
          dataIndex: 'billingAddress',
          key: 'billingAddress',
          render: (text: string) => text || 'N/A',
        },
        {
          title: 'Total',
          dataIndex: 'total',
          key: 'total',
          render: (text: number) => `$${text.toFixed(2)}`,
          sorter: true,
        },
        ...commonColumns
      ];
    } 
    // Xero specific columns
    else if (selectedSource === 'Xero') {
      return [
        {
          title: 'Invoice #',
          dataIndex: 'invoiceNumber',
          key: 'invoiceNumber',
          sorter: true,
        },
        {
          title: 'Due Date',
          dataIndex: 'dueDate',
          key: 'dueDate',
          render: (text: string) => text ? dayjs(text).format('MM/DD/YYYY') : 'N/A',
          sorter: true,
        },
        {
          title: 'Customer',
          dataIndex: 'customerName',
          key: 'customerName',
        },
        {
          title: 'Status',
          dataIndex: 'status',
          key: 'status',
        },
        {
          title: 'Total',
          dataIndex: 'total',
          key: 'total',
          render: (text: number) => `$${text.toFixed(2)}`,
          sorter: true,
        },
        ...commonColumns
      ];
    }
  };

  return (
    <div className="invoice-container" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="invoice-header" style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
        <div className="invoice-title" style={{ fontWeight: 'bold', marginLeft: '20px', fontSize: '24px' }}>Invoices</div>
        <div className="invoice-actions" style={{ display: 'flex' }}>
          {/* Source selection dropdown */}
          <Select
            value={selectedSource}
            onChange={handleSourceChange}
            style={{ width: 130, marginRight: 16 }}
          >
            <Option value="QuickBooks">QuickBooks</Option>
            {isXeroConnected && <Option value="Xero">Xero</Option>}
          </Select>
          
          <Input
            placeholder="Search invoices"
            value={searchText}
            onChange={handleSearchChange}
            prefix={<SearchOutlined />}
            style={{ width: 250, marginRight: 16 }}
          />
          
          {selectedSource === 'QuickBooks' && (
            <Button 
              type="primary" 
              icon={<FileExcelOutlined />}
              onClick={showUploadModal}
              className="action-button"
              style={{ marginRight: 8 }}
            >
              Upload CSV
            </Button>
          )}
          
          {selectedSource === 'QuickBooks' ? (
            <Button 
              type="primary" 
              icon={<ReloadOutlined />} 
              onClick={() => syncInvoicesFromQuickBooks()}
              className="action-button"
              loading={loading}
              style={{ marginRight: 8 }}
            >
              Sync from QuickBooks
            </Button>
          ) : (
            <Button 
              type="primary" 
              icon={<ReloadOutlined />} 
              onClick={() => syncInvoicesFromXero()}
              className="action-button"
              loading={loading}
              style={{ marginRight: 8 }}
              disabled={!isXeroConnected}
            >
              Sync from Xero
            </Button>
          )}
          
          <Button 
            type="primary" 
            icon={<PlusOutlined />} 
            onClick={openCreateDrawer}
            className="action-button"
          >
            Create Invoice
          </Button>
        </div>
      </div>

      <div className="content-container" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {loading ? (
          <div className="loading-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1 }}>
            <Spin size="large" />
            <p>Loading Invoices...</p>
          </div>
        ) : invoices.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            <div className="table-container" style={{ flex: 1, overflow: 'auto' }}>
              <Table
                columns={getColumns()}
                dataSource={invoices}
                rowKey={selectedSource === 'QuickBooks' ? "invoiceId" : "externalId"} 
                pagination={false}
                onChange={handleTableChange}
                scroll={{ x: 'max-content' }}
                bordered
                className="invoices-table"
                expandable={{
                  expandedRowRender: (record: InvoiceDto) => (
                    <div style={{ margin: 0 }}>
                      <h4>Line Items:</h4>
                      <Table
                        columns={[
                          { title: 'Description', dataIndex: 'description', key: 'description' },
                          { title: 'Quantity', dataIndex: 'quantity', key: 'quantity' },
                          { title: 'Rate', dataIndex: 'rate', key: 'rate', render: (rate: number) => `$${rate?.toFixed(2) || '0.00'}` },
                          { title: 'Amount', dataIndex: 'amount', key: 'amount', render: (amount: number) => `$${amount?.toFixed(2) || '0.00'}` },
                        ]}
                        dataSource={record.lineItems || []}
                        pagination={false}
                        rowKey={selectedSource === 'QuickBooks' ? "lineId" : "lineItemId"}
                      />
                    </div>
                  ),
                }}
              />
            </div>
            <div className="pagination-container" style={{ padding: '16px 0', backgroundColor: '#fff', display: 'flex', justifyContent: 'flex-end', borderTop: '1px solid #f0f0f0' }}>
              <Pagination
                current={pagination.current}
                pageSize={pagination.pageSize}
                total={pagination.total}
                onChange={(page, pageSize) => fetchInvoices(page, pageSize, searchText, sortField, sortDirection, selectedSource)}
                showSizeChanger
                showTotal={(total) => `Total ${total} items`}
                style={{ textAlign: 'right' }}
              />
            </div>
          </div>
        ) : (
          <div className="empty-data-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1 }}>
            <Empty
              description={`No invoice data available for ${selectedSource}. Click "Sync from ${selectedSource}" to load invoices.`}
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
            <Button
              type="primary"
              onClick={() => selectedSource === 'QuickBooks' ? syncInvoicesFromQuickBooks() : syncInvoicesFromXero()}
              icon={<ReloadOutlined />}
              className="empty-download-button"
              style={{ marginTop: 16 }}
              disabled={selectedSource === 'Xero' && !isXeroConnected}
            >
              Sync from {selectedSource}
            </Button>
          </div>
        )}
      </div>

      {/* CSV Upload Modal */}
      <Modal
        title="Upload CSV File"
        open={uploadModalVisible}
        onCancel={() => {
          setUploadModalVisible(false);
          setCsvFile(null);
          setValidationErrors([]);
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
        }}
        footer={[
          <Button key="cancel" onClick={() => setUploadModalVisible(false)}>
            Cancel
          </Button>,
          <Button
            key="validate"
            type="default"
            loading={validatingCsv}
            onClick={validateCsvFile}
            disabled={!csvFile}
          >
            Validate CSV
          </Button>,
          <Button
            key="import"
            type="primary"
            loading={importingCsv}
            onClick={importCsvFile}
            disabled={!csvFile}
          >
            Import CSV
          </Button>,
        ]}
      >
        <div style={{ marginBottom: 16 }}>
          <p>Upload a CSV file with invoice data to import into QuickBooks.</p>
          <p>The CSV must include the following columns:</p>
          <ul>
            <li>InvoiceNumber (unique identifier)</li>
            <li>CustomerName (full name of the customer)</li>
            <li>CustomerEmail (optional)</li>
            <li>InvoiceDate (date of the invoice)</li>
            <li>DueDate (due date for payment)</li>
            <li>ItemName (name of the product/service)</li>
            <li>ItemDescription (description of the item)</li>
            <li>Quantity (quantity of the item)</li>
            <li>Rate (price per item)</li>
          </ul>
        </div>
        
        <input
          type="file"
          accept=".csv"
          onChange={handleFileChange}
          ref={fileInputRef}
          style={{ marginBottom: 16 }}
        />
        
        {validationErrors.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <h4 style={{ color: '#ff4d4f' }}>Validation Errors:</h4>
            <ul style={{ color: '#ff4d4f' }}>
              {validationErrors.map((error, index) => (
                <li key={index}>Row {error.rowNumber}: {error.message}</li>
              ))}
            </ul>
          </div>
        )}
      </Modal>

      <InvoiceDrawer
        visible={drawerVisible}
        onClose={handleDrawerClose}
        onSubmit={handleFormSubmit}
        invoice={editingInvoice}
      />
    </div>
  );
};

export default Invoice;