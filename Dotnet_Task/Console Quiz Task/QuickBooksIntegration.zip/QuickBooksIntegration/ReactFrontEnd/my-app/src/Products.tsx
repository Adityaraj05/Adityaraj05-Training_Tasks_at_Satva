import React, { useEffect, useState } from 'react';
import { Table, Button, Spin, Empty, message, Popconfirm } from 'antd';
import { DeleteOutlined, DownloadOutlined, EditOutlined, LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import SearchBar from './SearchBar';
import ProductServiceDrawer from './ProductDrawer';
import ProductFormDrawer from './ProductForm';
import axios from 'axios';

interface Product {
  id: number;
  quickBooksItemId: string;
  name: string;
  type: string;
  unitPrice: number;
  quantityOnHand?: number;
  incomeAccountName: string;
  expenseAccountName?: string;
  assetAccountName?: string;
  active: boolean;
  syncToken: string;
}

const Product = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [mode, setMode] = useState<'add' | 'edit'>('add');
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [selectedType, setSelectedType] = useState<'Inventory' | 'Service' | null>(null);
  const [formDrawerVisible, setFormDrawerVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [accountOptions, setAccountOptions] = useState(null);
  const [accountOptionsLoading, setAccountOptionsLoading] = useState(false);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });

  const fetchProducts = async (page = pagination.current, pageSize = pagination.pageSize, search = searchTerm) => {
    setLoading(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/fetch-product-from-db-paginated?page=${page}&pageSize=${pageSize}&searchTerm=${encodeURIComponent(search)}`
      );
      const result = await res.json();

      if (!res.ok || result.Error) throw new Error(result.Error || 'Fetch failed');

      setProducts(result.data || []);
      setPagination({
        current: result.currentPage,
        pageSize: result.pageSize,
        total: result.totalRecords,
      });
    } catch (err) {
      console.error(err);
      setProducts([]);
      message.error('Failed to fetch products from database.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    fetchProducts(1, pagination.pageSize, value);
  };

  const handleTableChange = (paginationInfo: any) => {
    const { current, pageSize } = paginationInfo;
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
    fetchProducts(current, pageSize, searchTerm);
  };

  const handleSelect = async (type: 'inventory' | 'service') => {
    setDrawerVisible(false);
    setSelectedType(type === 'inventory' ? 'Inventory' : 'Service');
    setMode('add'); // Ensure we're in add mode
    setSelectedProduct(null); // Reset any selected product
    await fetchAccountOptions();
  };
  
  const fetchAccountOptions = async (productId?: number) => {
    setAccountOptionsLoading(true);
    try {
      const url = productId
        ? `${import.meta.env.VITE_API_BASE_URL}/api/ChartOfAccount/product-accounts?productId=${productId}`
        : `${import.meta.env.VITE_API_BASE_URL}/api/ChartOfAccount/product-accounts`;
  
      const res = await fetch(url);
      const result = await res.json();
  
      if (!res.ok || result.Error) throw new Error(result.Error || 'Failed to fetch account options');
  
      setAccountOptions(result);
      setFormDrawerVisible(true);
      return result;
    } catch (err) {
      console.error('❌ Failed to fetch account options:', err);
      message.error('Could not load account options.');
      return null;
    } finally {
      setAccountOptionsLoading(false);
    }
  };
  
  const handleEdit = async (record: Product) => {
    try {
      setSelectedProduct(record);
      setSelectedType(record.type === 'Inventory' || record.type === 'Service' ? record.type : null);
      setMode('edit');
  
      const options = await fetchAccountOptions(record.id);
      if (!options) {
        return;
      }
    } catch (error) {
      console.error("Error in handleEdit:", error);
      message.error('An error occurred while preparing to edit the product');
    }
  };
  
  const handleDelete = async (record: Product) => {
    try {
      console.log("deleting record",record);
      
      await axios.delete(`${import.meta.env.VITE_API_BASE_URL}/api/product/delete/${record.id}`);
      message.success('Product deleted');
      fetchProducts(); 
    } catch (error) {
      message.error('Failed to delete product');
    }
  };

  // Handle product download from QuickBooks
  const handleDownload = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/product/fetch-product-from-quickbooks`);
      const result = await res.json();

      if (!res.ok || result.Error) throw new Error(result.Error || 'Sync failed');

      message.success('Products synced from QuickBooks.');
      fetchProducts(1, pagination.pageSize);
    } catch (err) {
      console.error(err);
      message.error('Failed to sync products.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch products on component mount
  useEffect(() => {
    fetchProducts(1, 10);
  }, []);

  const columns = [
    { title: 'Name', dataIndex: 'name', key: 'name' },
    { title: 'Type', dataIndex: 'type', key: 'type' },
    {
      title: 'Unit Price',
      dataIndex: 'unitPrice',
      key: 'unitPrice',
      render: (value: number) => `$${value?.toFixed(2) || '0.00'}`,
    },
    { title: 'Quantity On Hand', dataIndex: 'quantityOnHand', key: 'quantityOnHand' },
    { title: 'Income Account', dataIndex: 'incomeAccountName', key: 'incomeAccountName' },
    { title: 'Expense Account', dataIndex: 'expenseAccountName', key: 'expenseAccountName' },
    { title: 'Asset Account', dataIndex: 'assetAccountName', key: 'assetAccountName' },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Product) => (
        <div className="action-buttons">
          <Button
            type="default"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            className="edit-button"
          >
            Edit
          </Button>
          <Popconfirm
            title="Are you sure you want to delete this product?"
            onConfirm={() => handleDelete(record)}
            okText="Yes"
            cancelText="No"
          >
            <Button type="default" danger icon={<DeleteOutlined />} className="delete-button">
              Delete
            </Button>
          </Popconfirm>
        </div>
      ),
    },
  ];

  const antIcon = <LoadingOutlined style={{ fontSize: 40, color: '#00A551' }} spin />;

  return (
    <div className="chart-accounts-container">
      <div className="chart-accounts-header">
        <div className="chart-accounts-title">Products & Services</div>
        <div className="chart-accounts-actions">
          <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => setDrawerVisible(true)}
            className="action-button"
            style={{ backgroundColor: '#00A551', borderColor: '#00A551' }}
          >
            Add
          </Button>
          <ProductServiceDrawer
            visible={drawerVisible}
            onClose={() => setDrawerVisible(false)}
            onSelect={handleSelect}
          />
          {selectedType && (
            <ProductFormDrawer
              visible={formDrawerVisible}
              onClose={() => {
                setFormDrawerVisible(false);
                setSelectedType(null);
                setSelectedProduct(null);
                setMode('add');
              }}
              type={selectedType}
              mode={mode}
              initialValues={selectedProduct}
              accountOptions={accountOptions}
              loading={accountOptionsLoading}
              onSubmit={async (formValues) => {
                try {
                  let incomeAccountName = '';
                  let expenseAccountName = '';
                  let assetAccountName = '';
                  
                  // Find income account name from options if needed
                  if (selectedType === 'Inventory' || formValues.sellToCustomers) {
                    if (accountOptions?.incomeAccounts && formValues.incomeAccountId) {
                      const incomeAccount = accountOptions.incomeAccounts.find(
                        acc => acc.quickBooksAccountId === formValues.incomeAccountId
                      );
                      incomeAccountName = incomeAccount?.name || '';
                    } else if (selectedProduct?.incomeAccountName) {
                      incomeAccountName = selectedProduct.incomeAccountName;
                    }
                  }
                  
                  // Find expense account name if needed
                  if (selectedType === 'Inventory' || formValues.purchaseFromSupplier) {
                    if (accountOptions?.expenseAccounts && formValues.expenseAccountId) {
                      const expenseAccount = accountOptions.expenseAccounts.find(
                        acc => acc.quickBooksAccountId === formValues.expenseAccountId
                      );
                      expenseAccountName = expenseAccount?.name || '';
                    } else if (selectedProduct?.expenseAccountName && formValues.purchaseFromSupplier) {
                      expenseAccountName = selectedProduct.expenseAccountName;
                    }
                  }
                  
                  // Find asset account name if type is Inventory
                  if (selectedType === 'Inventory' && accountOptions?.inventoryAssetAccounts && formValues.assetAccountId) {
                    const assetAccount = accountOptions.inventoryAssetAccounts.find(
                      acc => acc.quickBooksAccountId === formValues.assetAccountId
                    );
                    assetAccountName = assetAccount?.name || '';
                  } else if (selectedProduct?.assetAccountName) {
                    assetAccountName = selectedProduct.assetAccountName;
                  }
                  
                  // Create a base payload
                  const basicPayload = {
                    Id: selectedProduct?.id,
                    QuickBooksItemId: selectedProduct?.quickBooksItemId,
                    SyncToken: selectedProduct?.syncToken,
                    Name: formValues.name,
                    Type: selectedType,
                    Active: true
                  };
                  
                  let payload;
                  
                  if (selectedType === 'Inventory') {
                    // For Inventory type, include all required fields
                    payload = {
                      ...basicPayload,
                      UnitPrice: formValues.unitPrice || 0,
                      Taxable: formValues.taxable || false,
                      QuantityOnHand: formValues.quantityOnHand || 0,
                      IncomeAccountId: formValues.incomeAccountId,
                      IncomeAccountName: incomeAccountName,
                      ExpenseAccountId: formValues.expenseAccountId,
                      ExpenseAccountName: expenseAccountName,
                      AssetAccountId: formValues.assetAccountId,
                      AssetAccountName: assetAccountName,
                      InventoryStartDate: formValues.inventoryStartDate ? formValues.inventoryStartDate.format('YYYY-MM-DD') : undefined,
                    };
                  } else {
                    // For Service type, include fields based on checkboxes
                    payload = { ...basicPayload };
                    
                    // Add Income account related fields if selling to customers
                    if (formValues.sellToCustomers) {
                      payload.UnitPrice = formValues.unitPrice || 0;
                      payload.Taxable = formValues.taxable || false;
                      payload.IncomeAccountId = formValues.incomeAccountId;
                      payload.IncomeAccountName = incomeAccountName;
                    } else {
                      // Explicitly set to null/undefined if not checked
                      payload.IncomeAccountId = undefined;
                      payload.IncomeAccountName = undefined;
                    }
                    
                    // Add Expense account related fields if purchasing from supplier
                    if (formValues.purchaseFromSupplier) {
                      payload.ExpenseAccountId = formValues.expenseAccountId;
                      payload.ExpenseAccountName = expenseAccountName;
                      payload.PurchaseDescription = formValues.purchaseDescription;
                      payload.Cost = formValues.cost;
                    } else {
                      // Explicitly set to null/undefined if not checked
                      payload.ExpenseAccountId = undefined;
                      payload.ExpenseAccountName = undefined;
                    }
                    
                    // QuickBooks requires at least one account (income or expense)
                    if (!formValues.sellToCustomers && !formValues.purchaseFromSupplier) {
                      throw new Error('At least one option (sell to customers or purchase from supplier) must be selected');
                    }
                  }
                  
                  console.log('Submitting product with payload:', payload);
                  
                  const url = mode === 'edit'
                    ? `${import.meta.env.VITE_API_BASE_URL}/api/Product/update/${selectedProduct?.id}`
                    : `${import.meta.env.VITE_API_BASE_URL}/api/product/add`;
                  
                  const method = mode === 'edit' ? 'PUT' : 'POST';
                  
                  const response = await fetch(url, {
                    method,
                    headers: {
                      'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload),
                  });
                  
                  const result = await response.json();
                  if (!response.ok || result.Error) {
                    console.error('API error response:', result);
                    throw new Error(result.Error || result.title || 'Failed to save product');
                  }
                  
                  message.success(mode === 'edit' ? 'Product updated successfully!' : 'Product added successfully!');
                  setFormDrawerVisible(false);
                  setSelectedType(null);
                  setSelectedProduct(null);
                  setMode('add');
                  fetchProducts(1, pagination.pageSize);
                } catch (err) {
                  console.error('❌ Error saving product:', err);
                  message.error(err.message || 'Failed to save product.');
                }
              }}
            />
          )}
          <Button
            type="primary"
            onClick={handleDownload}
            icon={<DownloadOutlined />}
            style={{ backgroundColor: '#00A551', borderColor: '#00A551' }}
          >
            Download
          </Button>
        </div>
      </div>

      <div className="scrollable-table-container">
        {loading ? (
          <div className="loading-container">
            <Spin indicator={antIcon} size="large" />
            <p style={{ color: '#00A551' }}>Loading Products...</p>
          </div>
        ) : products.length > 0 ? (
          <Table
            dataSource={products}
            columns={columns}
            rowKey={(record) => String(record.id)}
            pagination={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              showSizeChanger: true,
            }}
            onChange={handleTableChange}
            scroll={{ x: 'max-content' }}
            bordered
            className="accounts-table"
          />
        ) : (
          <div className="empty-data-container">
            <Empty
              description='No products available. Click "Download" to load products.'
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default Product;