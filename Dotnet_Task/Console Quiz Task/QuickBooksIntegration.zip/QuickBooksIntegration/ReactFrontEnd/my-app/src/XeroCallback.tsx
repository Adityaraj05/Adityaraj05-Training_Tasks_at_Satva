import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, Spin, Result, Typography } from 'antd';
import { CloudSyncOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import './Callback.css'; // Reusing the same CSS as QuickBooks callback

const { Title, Text } = Typography;

const XeroCallback: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    
    if (code) {
      // Make API call to your backend to exchange the code for tokens
      fetch(`${import.meta.env.VITE_API_BASE_URL}/api/xero/exchange`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, state }),
      })
        .then(res => {
          if (!res.ok) {
            throw new Error('Network response was not ok');
          }
          return res.json();
        })
        .then(data => {
          console.log('Response from backend:', data);
          
          // Store Xero tokens in localStorage
          if (data.accessToken && data.refreshToken && data.expiresIn) {
            // Store access token
            localStorage.setItem('xero_access_token', data.accessToken);
            
            // Store refresh token
            localStorage.setItem('xero_refresh_token', data.refreshToken);
            
            // Calculate and store expiration time
            const now = new Date();
            const expiryTime = now.getTime() + (parseInt(data.expiresIn) * 1000);
            localStorage.setItem('xero_token_expiry', expiryTime.toString());
            
            // Store tenant ID
            if (data.tenantId) {
              localStorage.setItem('xero_tenant_id', data.tenantId);
            }
            
            // Store ID token if available
            if (data.idToken) {
              localStorage.setItem('xero_id_token', data.idToken);
            }
            
            console.log('Xero tokens stored successfully');
          } else {
            console.warn('Token data incomplete in response', data);
            setError('Received incomplete authentication data from server.');
            setLoading(false);
            return;
          }
          
          setLoading(false);
          setTimeout(() => navigate('/home'), 1000);
        })
        .catch(err => {
          console.error('Token exchange failed:', err);
          setLoading(false);
          setError('Failed to connect to Xero. Please try again.');
        });
    } else {
      setLoading(false);
      setError('Missing required parameters from Xero.');
    }
  }, [searchParams, navigate]);

  return (
    <div className="qb-callback-container">
      <Card
        className="qb-callback-card"
        bordered={false}
      >
        {error ? (
          <Result
            status="error"
            icon={<ExclamationCircleOutlined className="qb-error-icon" />}
            title="Connection Failed"
            subTitle={error}
            extra={[
              <button 
                key="retry"
                className="qb-retry-button"
                onClick={() => navigate('/')}
              >
                Try Again
              </button>
            ]}
          />
        ) : (
          <div className="qb-callback-content">
            <CloudSyncOutlined className="qb-sync-icon" spin />
            <Title level={3} className="qb-callback-title">
              Xero Integration
            </Title>
            <div className="qb-callback-status">
              <Spin size="large" />
              <Text className="qb-status-text">
                {loading ? "Connecting to Xero..." : "Connection successful! Redirecting..."}
              </Text>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default XeroCallback;