import React, { useEffect, useState } from 'react';
import { Table, message, Spin, Button, Empty, Form, Space, Popconfirm, Select } from 'antd';
import { DownloadOutlined, PlusOutlined, EditOutlined, DeleteOutlined, ReloadOutlined, FilterOutlined } from '@ant-design/icons';
import SearchBar from './SearchBar';
import CustomerDrawer from './CustomerDrawer';
import './ChartOfAccount.css';

const { Option } = Select;

interface CustomerData {
    id: string;
    displayName: string;
    companyName: string;
    phone: string;
    balance: number;
    email?: string;
    
    // Backend field names (from API response)
    billingStreet1?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
    
    // Form field names (used in the component)
    billingLine1?: string;
    billingCity?: string;
    billingState?: string;
    billingPostalCode?: string;
    billingCountry?: string;
    
    companySource?: string;
    xeroContactId?: string;
    xeroTenantId?: string;
}

const Customers = () => {
    const [pagedData, setPagedData] = useState<CustomerData[]>([]);
    const [loading, setLoading] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [isDataFetched, setIsDataFetched] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [isXeroConnected, setIsXeroConnected] = useState(false);
    const [selectedCompany, setSelectedCompany] = useState<string>('ALL');
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0
    });
    const [drawerVisible, setDrawerVisible] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState<CustomerData | null>(null);
    const [form] = Form.useForm();
    const [availableSources, setAvailableSources] = useState<string[]>([]);

    const fetchCustomersFromDb = async (page = 1, pageSize = 10, search = searchTerm, source = selectedCompany) => {
        setLoading(true);
        try {
            // Send the source parameter to the backend even for 'ALL' option
            // The backend will handle filtering appropriately
            const sourceParam = `&source=${encodeURIComponent(source)}`;
            
            const res = await fetch(
                `${import.meta.env.VITE_API_BASE_URL}/api/customer/fetch-customer-from-db-paginated?page=${page}&pageSize=${pageSize}&searchTerm=${encodeURIComponent(search)}${sourceParam}`
            );

            const text = await res.text();
            let result;
            try {
                
                result = JSON.parse(text);
                console.log(result);
            } catch (e) {
                throw new Error(text);
            }
            console.log('Customers data received:', result);
            if (!res.ok) throw new Error(result.message || 'Failed to fetch data');

            setPagedData(result.data);
            setPagination({
                current: result.currentPage,
                pageSize: result.pageSize,
                total: result.totalRecords,
            });
            setIsDataFetched(true);
            
            // Extract unique company sources for the filter dropdown
            if (result.data && result.data.length > 0) {
                const sources = [...new Set(result.data
                    .map((customer: CustomerData) => customer.companySource)
                    .filter((source: string | undefined) => source))];
                setAvailableSources(sources);
            }
        } catch (err) {
            message.error('Failed to fetch customer data.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

      // Add this useEffect to check Xero authentication status
          useEffect(() => {
            const checkXeroAuth = () => {
                const xeroAccessToken = localStorage.getItem('xero_access_token');
                const xeroTenantId = localStorage.getItem('xero_tenant_id');
                setIsXeroConnected(Boolean(xeroAccessToken && xeroTenantId));
            };
            
            checkXeroAuth();
            
            // Set up an event listener for storage changes
            window.addEventListener('storage', checkXeroAuth);
            return () => window.removeEventListener('storage', checkXeroAuth);
        }, []);

    const fetchCustomersFromQuickBooks = async () => {
        console.log("Setting loading to true");
        setLoading(true);
        console.log("Loading set to true");

        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/customer/fetch-customers-from-quickbooks`, {
                method: 'GET',
            });

            const text = await res.text();
            let result;

            try {
                result = JSON.parse(text);
            } catch (e) {
                console.error("❌ Invalid JSON from QuickBooks download:", text);
                throw new Error(text);
            }

            if (!res.ok) {
                console.error("❌ Error response from QuickBooks download:", result);
                throw new Error(result.message || 'Failed to download accounts from QuickBooks');
            }

            if (result && result.length > 0) {
                message.success('Customers downloaded successfully from QuickBooks.');
            } else {
                message.warning('No new customers were downloaded from QuickBooks.');
            }
        } catch (err) {
            message.error('Failed to download customers from QuickBooks.');
            console.error(err);
        } finally {
            console.log("Setting loading to false");
            setLoading(false);
            console.log("Loading set to false");
            // Refresh the data from DB after download
            fetchCustomersFromDb(1, pagination.pageSize, searchTerm, selectedCompany);
        }
    };
    
    const fetchCustomersFromXero = async () => {
        console.log("Setting loading to true");
        setLoading(true);
        console.log("Loading set to true");

        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/xerocontacts/fetch`, {
                method: 'GET',
            });

            const text = await res.text();
            let result;

            try {
                result = JSON.parse(text);
            } catch (e) {
                console.error("❌ Invalid JSON from Xero download:", text);
                throw new Error(text);
            }

            if (!res.ok) {
                console.error("❌ Error response from Xero download:", result);
                throw new Error(result.message || 'Failed to download accounts from Xero');
            }

            if (result && result.length > 0) {
                message.success('Customers downloaded successfully from Xero.');
            } else {
                message.warning('No new customers were downloaded from Xero.');
            }
        } catch (err) {
            message.error('Failed to download customers from Xero.');
            console.error(err);
        } finally {
            console.log("Setting loading to false");
            setLoading(false);
            console.log("Loading set to false");
            // Refresh the data from DB after download
            fetchCustomersFromDb(1, pagination.pageSize, searchTerm, selectedCompany);
        }
    };

    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setSearchTerm(value);
        fetchCustomersFromDb(1, pagination.pageSize, value, selectedCompany);
    };

    const handleTableChange = (paginationInfo: any, filters: any, sorter: any) => {
        const { current, pageSize } = paginationInfo;
        setPagination(prev => ({
            ...prev,
            current,
            pageSize
        }));
        
        // Apply filters via API endpoint
        fetchCustomersFromDb(current, pageSize, searchTerm, selectedCompany);
    };

    const handleDownloadQuickBooks = async () => {
        try {
            setIsDataFetched(false);
            await fetchCustomersFromQuickBooks();
            // After downloading from QuickBooks, set the company filter to QuickBooks
            setSelectedCompany('QuickBooks');
            // This will fetch the filtered data from backend
            fetchCustomersFromDb(1, pagination.pageSize, searchTerm, 'QuickBooks');
        } catch (error) {
            console.error("Error during download:", error);
            message.error("Failed to fetch data from QuickBooks.");
        }
    };
    
    const handleDownloadXero = async () => {
        if (!isXeroConnected) {
            message.error('Please connect to Xero first.');
            return;
        }
        
        try {
            setIsDataFetched(false);
            await fetchCustomersFromXero();
            // After downloading from Xero, set the company filter to Xero
            setSelectedCompany('Xero');
            // This will fetch the filtered data from backend
            fetchCustomersFromDb(1, pagination.pageSize, searchTerm, 'Xero');
        } catch (error) {
            console.error("Error during download:", error);
            message.error("Failed to fetch data from Xero.");
        }
    };
    const handleAddCustomer = () => {
        setEditingCustomer(null);
        form.resetFields();
        setDrawerVisible(true);
    };

    const handleEditCustomer = (customer: CustomerData) => {
        console.log('Editing customer with ID:', customer.id);
        console.log('Full customer object:', customer);
        
        // Make sure we have all the required fields before editing
   
        if (customer.companySource === 'Xero' && !customer.xeroContactId) {
            console.error('Missing xeroContactId for Xero customer');
            message.error('Cannot edit customer: missing Xero contact ID');
            return;
        }
        
        setEditingCustomer(customer);
        
        
        // Format the data for the form
        const formData = {
            ...customer,
            // Make sure these fields have the correct keys
            companySource: customer.companySource || 'QuickBooks',
            xeroContactId: customer.xeroContactId || '',
            xeroTenantId: customer.xeroTenantId || '',
            // Map address fields from backend to form fields
            billingLine1: customer.billingStreet1 || customer.billingLine1 || '',
            billingCity: customer.city || customer.billingCity || '',
            billingState: customer.state || customer.billingState || '',
            billingPostalCode: customer.zipCode || customer.billingPostalCode || '',
            billingCountry: customer.country || customer.billingCountry || '',
        };
        
        // Add a hidden field for xeroContactId if needed
        form.setFieldsValue(formData);
        setDrawerVisible(true);
    };

    const handleDeleteCustomer = async (customerId: string, companySource: string, xeroContactId?: string) => {
        console.log(`Deleting customer: ID=${customerId}, Source=${companySource}, XeroID=${xeroContactId}`);
        setLoading(true);
    
        try {
            let apiUrl = '';
            
            if (companySource === 'Xero' && xeroContactId) {
                // Use Xero-specific delete endpoint
                apiUrl = `${import.meta.env.VITE_API_BASE_URL}/api/xerocontacts/${xeroContactId}`;
            } else {
                // Default to QuickBooks delete endpoint
                apiUrl = `${import.meta.env.VITE_API_BASE_URL}/api/customer/delete-customer/${customerId}`;
            }
            
            const res = await fetch(apiUrl, {
                method: 'DELETE',
            });
    
            const responseText = await res.text();
            
            if (!res.ok) {
                throw new Error(responseText);
            }
    
            message.success(`Customer deleted successfully from ${companySource} and local database.`);
            fetchCustomersFromDb(pagination.current, pagination.pageSize, searchTerm, selectedCompany);
        } catch (err: any) {
            if (err.message.includes("Balance must be 0")) {
                message.warning("Cannot delete customer: balance must be 0.");
            } else {
                message.error(err.message || 'Failed to delete customer.');
            }
            console.error('Delete Error:', err.message || err);
        } finally {
            setLoading(false);
        }
    };

    const handleDrawerClose = () => {
        setDrawerVisible(false);
        form.resetFields();
    };

    const handleSubmit = async () => {
        try {
            const values = await form.validateFields();
            console.log('Form values:', values);
            
            const isXero = editingCustomer?.companySource === 'Xero' || values.companySource === 'Xero';
            const isEditing = !!editingCustomer;
            
            // Create the base payload
            const customerData: any = {
                displayName: values.displayName,
                companyName: values.companyName,
                phone: values.phone,
                email: values.email,
                // Use the correct field names that match the backend model
                billingLine1: values.billingLine1,
                billingCity: values.billingCity,
                billingState: values.billingState,
                billingPostalCode: values.billingPostalCode,
                billingCountry: values.billingCountry,
            };
            
            
            setSubmitting(true);
    
            let apiUrl = '';
            let method = '';
            
            // Determine the correct API endpoint based on the source and operation
            if (isXero) {
                if (isEditing && editingCustomer?.xeroContactId) {
                    console.log('Updating Xero contact with ID:', editingCustomer.xeroContactId);
                    
                    // For Xero updates, use the xeroContactId in the URL
                    apiUrl = `${import.meta.env.VITE_API_BASE_URL}/api/xerocontacts/${editingCustomer.xeroContactId}`;
                    method = 'PUT';
                    
                    // CRITICAL: Add the xeroContactId to the payload for updates
                    customerData.xeroContactId = editingCustomer.xeroContactId;
                    
                    // If there's a tenant ID, include it too
                    if (editingCustomer.xeroTenantId) {
                        customerData.xeroTenantId = editingCustomer.xeroTenantId;
                    }
                } else {
                    console.log("Creating new Xero contact");
                    
                    apiUrl = `${import.meta.env.VITE_API_BASE_URL}/api/xerocontacts`;
                    method = 'POST';
                }
            } else {
                // QuickBooks
                if (isEditing) {
                    apiUrl = `${import.meta.env.VITE_API_BASE_URL}/api/customer/update-customer/${editingCustomer?.id}`;
                    method = 'PUT';
                } else {
                    apiUrl = `${import.meta.env.VITE_API_BASE_URL}/api/customer/add-customer`;
                    method = 'POST';
                }
            }
            
            console.log(`Sending ${method} request to ${apiUrl}`);
            console.log('Request data:', customerData);
    
            const response = await fetch(apiUrl, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(customerData),
            });
    
            if (!response.ok) {
                const errorText = await response.text();
                let errorData;
                try {
                    errorData = JSON.parse(errorText);
                } catch (e) {
                    errorData = { message: errorText };
                }
                throw new Error(errorData.message || `Failed to ${isEditing ? 'update' : 'add'} customer`);
            }
    
            message.success(`Customer ${isEditing ? 'updated' : 'added'} successfully!`);
            setDrawerVisible(false);
            form.resetFields();
            fetchCustomersFromDb(pagination.current, pagination.pageSize, searchTerm, selectedCompany);
        } catch (error) {
            if (error instanceof Error) {
                message.error(error.message);
            } else {
                message.error('An error occurred while saving the customer');
            }
            console.error('Submit error:', error);
        } finally {
            setSubmitting(false);
        }
    };

    useEffect(() => {
        // On initial load, fetch customers based on authentication status
        // If Xero is not connected, only show QuickBooks data
        const initialSource = isXeroConnected ? 'ALL' : 'QuickBooks';
        setSelectedCompany(initialSource);
        fetchCustomersFromDb(1, pagination.pageSize, searchTerm, initialSource);
    }, [isXeroConnected]); // Add isXeroConnected as dependency

    // Handle company selection change
    const handleCompanyChange = (value: string) => {
        console.log("🏢 Company filter changed:", value);
        setSelectedCompany(value);
        
        // Fetch data with the new company filter
        fetchCustomersFromDb(1, pagination.pageSize, searchTerm, value);
    };

    const columns = [
        {
            title: 'Display Name',
            dataIndex: 'displayName',
            key: 'displayName',
            sorter: (a: CustomerData, b: CustomerData) => a.displayName.localeCompare(b.displayName),
        },
        // {
        //     title: 'Company Name',
        //     dataIndex: 'companyName',
        //     key: 'companyName',
        // },
        {
            title:'Billing Address',
            dataIndex: 'billingStreet1',
            key:'billingStreet1',
        },
        {
            title: 'Email',
            dataIndex: 'email',
            key: 'email',
        },
        {
            title: 'Phone',
            dataIndex: 'phone',
            key: 'phone',
        },
        {
            title: 'Balance',
            dataIndex: 'balance',
            key: 'balance',
            render: (value: number) => {
                if (value === undefined || value === null) return '-';
                const isNegative = value < 0;
                const absValue = Math.abs(value);
                return isNegative
                    ? `-$${absValue.toFixed(2)}`
                    : `$${value.toFixed(2)}`;
            },
            sorter: (a: CustomerData, b: CustomerData) => a.balance - b.balance,
        },
        {
            title: "Source",
            dataIndex: "companySource",
            key: "companySource",
            render: (text: string) => text || 'N/A',
        },
        // {
        //     title: 'Xero ID',
        //     dataIndex: 'xeroContactId',
        //     key: 'xeroContactId',
        //     render: (text: string) => text || 'N/A',
           
        // },
        {
            title: 'Actions',
            key: 'actions',
            render: (_: any, record: CustomerData) => (
                <div className="action-buttons">
                    <Space>
                        <Button
                            type="primary"
                            icon={<EditOutlined />}
                            onClick={() => handleEditCustomer(record)}
                        >
                            Edit
                        </Button>

                        <Popconfirm
                            title="Are you sure you want to delete this customer?"
                            onConfirm={() => handleDeleteCustomer(record.id, record.companySource || 'QuickBooks', record.xeroContactId)}
                            okText="Yes"
                            cancelText="No"
                        >
                            <Button danger icon={<DeleteOutlined />}>
                                Delete
                            </Button>
                        </Popconfirm>
                    </Space>
                </div>
            ),
        },
    ];

    return (
        <div className="chart-accounts-container">
            <div className="chart-accounts-header">
                <div className="chart-accounts-title">Customers</div>
                <div className="chart-accounts-actions d-flex">
                <Select
    value={selectedCompany}
    onChange={handleCompanyChange}
    style={{ width: 120, marginRight: 16 }}
>
    {isXeroConnected ? (
        <>
            <Option value="ALL">ALL</Option>
            <Option value="QuickBooks">QuickBooks</Option>
            <Option value="Xero">Xero</Option>
        </>
    ) : (
        <Option value="QuickBooks">QuickBooks</Option>
    )}
</Select>
                    
                    <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />
                    
                    <Button
                        type="primary"
                        icon={<PlusOutlined />}
                        onClick={handleAddCustomer}
                        className="action-button"
                    >
                        Add Customer
                    </Button>
                    <Button
                        type="primary"
                        onClick={handleDownloadQuickBooks}
                        icon={<ReloadOutlined />}
                        className="action-button"
                    >
                        Sync from QuickBooks
                    </Button>
                    <Button
                        type="primary"
                        onClick={handleDownloadXero}
                        icon={<ReloadOutlined />}
                        className="action-button"
                    >
                        Sync from Xero
                    </Button>
                </div>
            </div>

            <div className="scrollable-table-container">
                {loading ? (
                    <div className="loading-container">
                        <Spin size="large" />
                        <p>Loading Customers...</p>
                    </div>
                ) : pagedData.length > 0 ? (
                    <Table
                        dataSource={pagedData}
                        columns={columns}
                        rowKey={(record) => record.id}
                        pagination={{
                            current: pagination.current,
                            pageSize: pagination.pageSize,
                            total: pagination.total,
                            showSizeChanger: true,
                            pageSizeOptions: ['5', '10', '20', '50'],
                            showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
                        }}
                        onChange={handleTableChange}
                        scroll={{ x: 'max-content' }}
                        bordered
                        className="accounts-table"
                    />
                ) : (
                    <div className="empty-data-container">
                        <Empty
                            description='No customer data available. Click "Sync" to load from QuickBooks or Xero.'
                            image={Empty.PRESENTED_IMAGE_SIMPLE}
                        />
                        <div className="empty-action-buttons">
                            <Button
                                type="primary"
                                onClick={handleDownloadQuickBooks}
                                icon={<ReloadOutlined />}
                                className="empty-download-button"
                            >
                                Sync from QuickBooks
                            </Button>
                            <Button
                                type="primary"
                                onClick={handleDownloadXero}
                                icon={<ReloadOutlined />}
                                className="empty-download-button"
                                style={{ marginLeft: '10px' }}
                            >
                                Sync from Xero
                            </Button>
                        </div>
                    </div>
                )}
            </div>

            <CustomerDrawer
                visible={drawerVisible}
                onClose={handleDrawerClose}
                onSubmit={handleSubmit}
                editingCustomer={editingCustomer}
                form={form}
                submitting={submitting}
            />
        </div>
    );
};

export default Customers;