import React, { useState, useEffect } from "react";
import {
  Table,
  message,
  Spin,
  Button,
  Empty,
  Drawer,
  Form,
  Input,
  Divider,
  Popconfirm,
  Checkbox,
} from "antd";
import {
  DownloadOutlined,
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  DownOutlined,
  UpOutlined,
  EnvironmentOutlined,
  FileTextOutlined,
  LoadingOutlined,
} from "@ant-design/icons";
import SearchBar from "./SearchBar";
import "./ChartOfAccount.css";
import "@ant-design/v5-patch-for-react-19";

interface CustomerData {
  id: string;
  displayName: string;
  companyName: string;
  phone: string;
  balance: number;
  email?: string;
  billingStreet1?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  streetAddress2?: string;
}

interface CustomerFormData extends Omit<CustomerData, "id" | "balance"> {
  id?: string;
}

const Customers = () => {
  const [pagedData, setPagedData] = useState<CustomerData[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<CustomerData | null>(
    null
  );
  const [form] = Form.useForm();

  const [nameContactCollapsed, setNameContactCollapsed] = useState(false);
  const [addressesCollapsed, setAddressesCollapsed] = useState(false);

  const fetchCustomersFromDb = async (
    page = 1,
    pageSize = 10,
    search = searchTerm
  ) => {
    setLoading(true);
    try {
      const res = await fetch(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/customer/fetch-customer-from-db-paginated?page=${page}&pageSize=${pageSize}&searchTerm=${encodeURIComponent(
          search
        )}`
      );

      const text = await res.text();
      let result;
      try {
        result = JSON.parse(text);
      } catch (e) {
        throw new Error(text);
      }

      if (!res.ok) throw new Error(result.message || "Failed to fetch data");

      console.log("Customers data received:", result);
      setPagedData(result.data);
      setPagination({
        current: result.currentPage,
        pageSize: result.pageSize,
        total: result.totalRecords,
      });
      setIsDataFetched(true);
    } catch (err) {
      message.error("Failed to fetch customer data.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomersFromQuickBooks = async () => {
    console.log("Setting loading to true");
    setLoading(true);
    console.log("Loading set to true");

    try {
      const res = await fetch(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/customer/fetch-customers-from-quickbooks`,
        {
          method: "GET",
        }
      );

      const text = await res.text();
      let result;

      try {
        result = JSON.parse(text);
      } catch (e) {
        console.error("❌ Invalid JSON from QuickBooks download:", text);
        throw new Error(text);
      }

      if (!res.ok) {
        console.error("❌ Error response from QuickBooks download:", result);
        throw new Error(
          result.message || "Failed to download accounts from QuickBooks"
        );
      }

      if (result && result.length > 0) {
        setPagedData(result);
        setIsDataFetched(true);
      } else {
        message.warning("No new accounts were downloaded from QuickBooks.");
      }
    } catch (err) {
      message.error("Failed to download chart of accounts from QuickBooks.");
      console.error(err);
    } finally {
      console.log("Setting loading to false");
      setLoading(false);
      console.log("Loading set to false");
    }
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    fetchCustomersFromDb(1, pagination.pageSize, value);
  };

  const handleTableChange = (paginationInfo: any) => {
    const { current, pageSize } = paginationInfo;
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
    fetchCustomersFromDb(current, pageSize, searchTerm);
  };

  const handleDownload = async () => {
    try {
      setIsDataFetched(false);
      await fetchCustomersFromQuickBooks();
      await fetchCustomersFromDb();
      setIsDataFetched(true);
      message.success("Data from QuickBooks fetched and updated!");
    } catch (error) {
      console.error("Error during download:", error);
      message.error("Failed to fetch data from QuickBooks.");
    }
  };

  const handleAddCustomer = () => {
    setEditingCustomer(null);
    form.setFieldsValue({});
    form.resetFields();
    setDrawerVisible(true);
  };

  const handleEditCustomer = (customer: CustomerData) => {
    console.log("Editing customer with ID:", customer.id);
    console.log("Full customer object:", customer);
    setEditingCustomer(customer);
    form.setFieldsValue(customer);
    setDrawerVisible(true);
  };

  const handleDeleteCustomer = async (customerId: string) => {
    console.log("deleting", customerId);
    setLoading(true);

    try {
      const res = await fetch(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/customer/delete-customer/${customerId}`,
        {
          method: "DELETE",
        }
      );

      const responseText = await res.text();

      if (!res.ok) {
        throw new Error(responseText);
      }
      message.success(
        "Customer deleted successfully from QuickBooks and local database."
      );
      fetchCustomersFromDb(pagination.current, pagination.pageSize, searchTerm);
    } catch (err: any) {
      if (err.message.includes("Balance must be 0")) {
        message.warning("Cannot delete customer: balance must be 0.");
      }
      console.error("Delete Error:", err.message || err);
    } finally {
      setLoading(false);
    }
  };

  const toggleNameContactSection = () => {
    setNameContactCollapsed(!nameContactCollapsed);
  };

  const toggleAddressesSection = () => {
    setAddressesCollapsed(!addressesCollapsed);
  };

  const handleDrawerClose = () => {
    setDrawerVisible(false);
    form.resetFields();
    setEditingCustomer(null);
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      const mappedValues = {
        displayName: values.displayName,
        companyName: values.companyName,
        phone: values.phone,
        email: values.email,
        billingLine1: values.billingStreet1,
        billingCity: values.city,
        billingState: values.state,
        billingPostalCode: values.zipCode,
        billingCountry: values.country,
      };

      setSubmitting(true);

      const isEditing = !!editingCustomer;
      const apiEndpoint = isEditing
        ? `${import.meta.env.VITE_API_BASE_URL}/api/customer/update-customer/${
            editingCustomer?.id
          }`
        : `${import.meta.env.VITE_API_BASE_URL}/api/customer/add-customer`;

      const method = isEditing ? "PUT" : "POST";
      console.log("🧾 Form values before submit:", mappedValues);

      const response = await fetch(apiEndpoint, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(mappedValues),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to save customer");
      }

      message.success(
        `Customer ${isEditing ? "updated" : "added"} successfully!`
      );
      setDrawerVisible(false);
      form.resetFields();
      fetchCustomersFromDb(pagination.current, pagination.pageSize, searchTerm);
    } catch (error) {
      if (error instanceof Error) {
        message.error(error.message);
      } else {
        message.error("An error occurred while saving the customer");
      }
      console.error("Submit error:", error);
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    fetchCustomersFromDb();
  }, []);

  const columns = [
    {
      title: "Display Name",
      dataIndex: "displayName",
      key: "displayName",
      sorter: (a: CustomerData, b: CustomerData) =>
        a.displayName.localeCompare(b.displayName),
    },
    {
      title: "Company Name",
      dataIndex: "companyName",
      key: "companyName",
    },
    {
      title: "Phone",
      dataIndex: "phone",
      key: "phone",
    },
    {
      title: "Balance",
      dataIndex: "balance",
      key: "balance",
      render: (value: number) => {
        if (value === undefined || value === null) return "-";
        const isNegative = value < 0;
        const absValue = Math.abs(value);
        return isNegative ? `-$${absValue.toFixed(2)}` : `$${value.toFixed(2)}`;
      },
      sorter: (a: CustomerData, b: CustomerData) => a.balance - b.balance,
    },
    {
      title: "Actions",
      key: "actions",
      render: (_: any, record: CustomerData) => (
        <div className="action-buttons">
          <Button
            type="default"
            icon={<EditOutlined />}
            onClick={() => handleEditCustomer(record)}
            className="edit-button"
          >
            Edit
          </Button>
          <Popconfirm
            title="Are you sure you want to delete this customer?"
            onConfirm={() => handleDeleteCustomer(record.id)}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="default"
              danger
              icon={<DeleteOutlined />}
              className="delete-button"
            >
              Delete
            </Button>
          </Popconfirm>
        </div>
      ),
    },
  ];

  const antIcon = (
    <LoadingOutlined style={{ fontSize: 40, color: "#00A551" }} spin />
  );

  return (
    <div className="chart-accounts-container">
      <div className="chart-accounts-header">
        <div className="chart-accounts-title">Customers</div>
        <div className="chart-accounts-actions">
          <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={handleAddCustomer}
            className="action-button"
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Add Customer
          </Button>
          <Button
            type="primary"
            onClick={handleDownload}
            icon={<DownloadOutlined />}
            className="action-button"
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Download
          </Button>
        </div>
      </div>

      <div className="scrollable-table-container">
        {loading ? (
          <div className="loading-container">
            <Spin indicator={antIcon} size="large" />
            <p style={{ color: "#00A551" }}>Loading Customers...</p>
          </div>
        ) : pagedData.length > 0 ? (
          <Table
            dataSource={pagedData}
            columns={columns} // Use the pre-defined columns
            rowKey={(record) => record.id}
            pagination={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              showSizeChanger: true,
            }}
            onChange={handleTableChange}
            scroll={{ x: "max-content" }}
            bordered
            className="accounts-table"
          />
        ) : (
          <div className="empty-data-container">
            <Empty
              description='No customer data available. Click "Download" to load from QuickBooks.'
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
          </div>
        )}
      </div>
      <Drawer
        title={editingCustomer ? "Edit Customer" : "Add Customer"}
        placement="right"
        onClose={handleDrawerClose}
        open={drawerVisible}
        width={500}
        className="customer-drawer"
        footer={
          <div
            style={{ display: "flex", justifyContent: "flex-end", gap: "8px" }}
          >
            <Button onClick={handleDrawerClose}>Cancel</Button>
            <Button
              type="primary"
              onClick={handleSubmit}
              loading={submitting}
              style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
            >
              {editingCustomer ? "Update Customer" : "Save"}
            </Button>
          </div>
        }
      >
        <Form
          form={form}
          layout="vertical"
          initialValues={editingCustomer || {}}
          className="customer-form"
        >
          {/* Name and Contact Section */}
          <div
            style={{
              padding: "16px",
              backgroundColor: "#fff",
              marginBottom: "16px",
              border: "1px solid #f0f0f0",
              borderRadius: "8px",
            }}
          >
            {/* Clickable header */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: nameContactCollapsed ? 0 : "16px",
                cursor: "pointer",
              }}
              onClick={toggleNameContactSection}
            >
              <div style={{ marginRight: "8px" }}>
                <FileTextOutlined />
              </div>
              <div style={{ fontSize: "16px", fontWeight: 500 }}>
                Name and contact
              </div>
              <div style={{ marginLeft: "auto" }}>
                {nameContactCollapsed ? <DownOutlined /> : <UpOutlined />}
              </div>
            </div>

            {/* Collapsible content */}
            {!nameContactCollapsed && (
              <>
                {/* Company Name and Display Name Row */}
                <div
                  style={{ display: "flex", gap: "16px", marginBottom: "16px" }}
                >
                  <Form.Item
                    label="Company Name"
                    name="companyName"
                    rules={[
                      { required: true, message: "Please enter company name" },
                    ]}
                    style={{ flex: 1 }}
                  >
                    <Input placeholder="Enter company name" />
                  </Form.Item>
                  <Form.Item
                    label="Customer display name *"
                    name="displayName"
                    rules={[
                      { required: true, message: "Please enter display name" },
                    ]}
                    style={{ flex: 1 }}
                  >
                    <Input
                      placeholder="Enter display name"
                    //   suffix={<DownOutlined />}
                    />
                  </Form.Item>
                </div>

                {/* Email and Phone Row */}
                <div
                  style={{ display: "flex", gap: "16px", marginBottom: "16px" }}
                >
                  <Form.Item
                    label="Email"
                    name="email"
                    rules={[
                      { type: "email", message: "Please enter a valid email" },
                    ]}
                    style={{ flex: 1 }}
                  >
                    <Input placeholder="Enter email" />
                  </Form.Item>
                  <Form.Item
                    label="Phone number"
                    name="phone"
                    rules={[
                      { required: true, message: "Please enter phone number" },
                      {
                        pattern: /^\(\d{3}\)\s\d{3}-\d{4}$/,
                        message:
                          "Please enter a valid phone number format: (650) 555-1234",
                      },
                    ]}
                    style={{ flex: 1 }}
                  >
                    <Input
                      placeholder="(650) 555-1234"
                      maxLength={14}
                      onChange={(e) => {
                        const input = e.target.value
                          .replace(/\D/g, "")
                          .substring(0, 10); // digits only, max 10
                        const areaCode = input.substring(0, 3);
                        const middle = input.substring(3, 6);
                        const last = input.substring(6, 10);

                        let formatted = input;
                        if (input.length > 6) {
                          formatted = `(${areaCode}) ${middle}-${last}`;
                        } else if (input.length > 3) {
                          formatted = `(${areaCode}) ${middle}`;
                        } else if (input.length > 0) {
                          formatted = `(${areaCode}`;
                        }

                        form.setFieldsValue({ phone: formatted });
                      }}
                    />
                  </Form.Item>
                </div>
              </>
            )}
          </div>

          {/* Addresses Section */}
          <div
            style={{
              padding: "16px",
              backgroundColor: "#fff",
              border: "1px solid #f0f0f0",
              borderRadius: "8px",
            }}
          >
            {/* Clickable header */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: addressesCollapsed ? 0 : "16px",
                cursor: "pointer",
              }}
              onClick={toggleAddressesSection}
            >
              <div style={{ marginRight: "8px" }}>
                <EnvironmentOutlined />
              </div>
              <div style={{ fontSize: "16px", fontWeight: 500 }}>Addresses</div>
              <div style={{ marginLeft: "auto" }}>
                {addressesCollapsed ? <DownOutlined /> : <UpOutlined />}
              </div>
            </div>

            {/* Collapsible content */}
            {!addressesCollapsed && (
              <>
                <div style={{ marginBottom: "24px" }}>
                  <div style={{ fontWeight: 500, marginBottom: "12px" }}>
                    Billing address
                  </div>

                  {/* Street Address Row */}
                  <div style={{ marginBottom: "16px" }}>
                    <Form.Item
                      label="Street address 1"
                      name="billingStreet1"
                      style={{ marginBottom: "8px" }}
                    >
                      <Input placeholder="Enter street address 1" />
                    </Form.Item>
                  </div>

                  {/* Add lines link */}
                  <div style={{ marginBottom: "16px" }}>
                    <a
                      style={{
                        display: "flex",
                        alignItems: "center",
                        color: "#595959",
                        cursor: "pointer",
                      }}
                    >
                      <DownOutlined
                        style={{ fontSize: "12px", marginRight: "4px" }}
                      />{" "}
                      Add lines
                    </a>
                  </div>

                  {/* City and State Row */}
                  <div
                    style={{
                      display: "flex",
                      gap: "16px",
                      marginBottom: "16px",
                    }}
                  >
                    <Form.Item
                      label="City"
                      name="city"
                      style={{ flex: 1, marginBottom: "8px" }}
                    >
                      <Input placeholder="Enter city" />
                    </Form.Item>
                    <Form.Item
                      label="State"
                      name="state"
                      style={{ flex: 1, marginBottom: "8px" }}
                    >
                      <Input placeholder="Enter state" />
                    </Form.Item>
                  </div>

                  {/* ZIP and Country Row */}
                  <div
                    style={{
                      display: "flex",
                      gap: "16px",
                      marginBottom: "16px",
                    }}
                  >
                    <Form.Item
                      label="ZIP code"
                      name="zipCode"
                      style={{ flex: 1, marginBottom: "8px" }}
                    >
                      <Input placeholder="Enter ZIP code" />
                    </Form.Item>
                    <Form.Item
                      label="Country"
                      name="country"
                      style={{ flex: 1, marginBottom: "8px" }}
                    >
                      <Input placeholder="Enter country" />
                    </Form.Item>
                  </div>
                </div>
              </>
            )}
          </div>
        </Form>
      </Drawer>
    </div>
  );
};

export default Customers;
