import React, { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Card, Spin, Result, Typography } from "antd";
import {
  CloudSyncOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";
import "./Callback.css";

const { Title, Text } = Typography;

const Callback: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const code = searchParams.get("code");
    const state = searchParams.get("state");
    const realmId = searchParams.get("realmId");

    if (code && realmId) {
      // Store the realmId immediately as we have it from the URL params
      localStorage.setItem("qb_realm_id", realmId);

      fetch(`${import.meta.env.VITE_API_BASE_URL}/api/auth/exchange`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, state, realmId }),
      })
        .then((res) => {
          if (!res.ok) {
            throw new Error("Network response was not ok");
          }
          return res.json();
        })
        .then((data) => {
          var tokenData = data.data;
          if (tokenData.accessToken && tokenData.refreshToken && tokenData.expiresIn) {
            localStorage.setItem("qb_access_token", tokenData.accessToken);

            localStorage.setItem("qb_refresh_token", tokenData.refreshToken);

            const now = new Date();
            const expiryTime = now.getTime() + tokenData.expiresIn * 1000;
            localStorage.setItem("qb_token_expiry", expiryTime.toString());

            if (tokenData.tokenId) {
              localStorage.setItem("qb_token_id", tokenData.tokenId.toString());
            }

            console.log("Tokens stored successfully");
          } else {
            console.warn("Token data incomplete in response", tokenData);
            setError("Received incomplete authentication data from server.");
            setLoading(false);
            return;
          }

          setLoading(false);
          setTimeout(() => navigate("/home"), 1000);
        })
        .catch((err) => {
          console.error("Token exchange failed:", err);
          setLoading(false);
          setError("Failed to connect to QuickBooks. Please try again.");
        });
    } else {
      setLoading(false);
      setError("Missing required parameters from QuickBooks.");
    }
  }, [searchParams, navigate]);

  return (
    <div className="qb-callback-container">
      <Card className="qb-callback-card" bordered={false}>
        {error ? (
          <Result
            status="error"
            icon={<ExclamationCircleOutlined className="qb-error-icon" />}
            title="Connection Failed"
            subTitle={error}
            extra={[
              <button
                key="retry"
                className="qb-retry-button"
                onClick={() => navigate("/")}
              >
                Try Again
              </button>,
            ]}
          />
        ) : (
          <div className="qb-callback-content">
            <CloudSyncOutlined className="qb-sync-icon" spin />
            <Title level={3} className="qb-callback-title">
              QuickBooks Integration
            </Title>
            <div className="qb-callback-status">
              <Spin size="large" />
              <Text className="qb-status-text">
                {loading
                  ? "Connecting to QuickBooks..."
                  : "Connection successful! Redirecting..."}
              </Text>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default Callback;
