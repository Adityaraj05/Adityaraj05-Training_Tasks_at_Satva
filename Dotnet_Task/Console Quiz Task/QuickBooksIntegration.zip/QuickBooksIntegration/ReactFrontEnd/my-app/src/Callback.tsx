import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, Spin, Result, Typography } from 'antd';
import { CloudSyncOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import './Callback.css';

const { Title, Text } = Typography;

const Callback: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    const realmId = searchParams.get('realmId');
  
    if (code && state && realmId) {
      fetch(`${import.meta.env.VITE_API_BASE_URL}/api/auth/exchange`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, state, realmId }),
      })
        .then(res => res.json())
        .then(data => {
          localStorage.setItem('quickbooks_realmId', realmId);
          setLoading(false);
          setTimeout(() => navigate('/home/customer'), 1000);
        })
        .catch(err => {
          console.error('Token exchange failed:', err);
          setLoading(false);
          setError('Failed to connect to QuickBooks. Please try again.');
        });
    } else {
      setLoading(false);
      setError('Missing required parameters from QuickBooks.');
    }
  }, [searchParams, navigate]);
  
  return (
    <div className="qb-callback-container">
      <Card 
        className="qb-callback-card"
        bordered={false}
      >
        {error ? (
          <Result
            status="error"
            icon={<ExclamationCircleOutlined className="qb-error-icon" />}
            title="Connection Failed"
            subTitle={error}
            extra={[
              <button 
                key="retry" 
                className="qb-retry-button"
                onClick={() => navigate('/')}
              >
                Try Again
              </button>
            ]}
          />
        ) : (
          <div className="qb-callback-content">
            <CloudSyncOutlined className="qb-sync-icon" spin />
            <Title level={3} className="qb-callback-title">
              QuickBooks Integration
            </Title>
            
          </div>
        )}
      </Card>
    </div>
  );
};

export default Callback;