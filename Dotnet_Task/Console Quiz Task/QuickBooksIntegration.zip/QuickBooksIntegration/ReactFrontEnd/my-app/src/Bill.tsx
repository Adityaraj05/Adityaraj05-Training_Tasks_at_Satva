import React, { useState, useEffect } from 'react';
import { Table, Input, Button, Space, DatePicker, Select, message, Tag, Spin, Tabs } from 'antd';
import { SearchOutlined, SyncOutlined, PlusOutlined } from '@ant-design/icons';
import type { TablePaginationConfig } from 'antd/es/table';
import type { FilterValue } from 'antd/es/table/interface';
import moment from 'moment';
import BillDrawer from './BillDrawer';
import XeroBillDrawer from './XeroBillDrawer'; 

const { RangePicker } = DatePicker;
const { Option } = Select;
const { TabPane } = Tabs;

interface Bill {
  id: number;
  docNumber: string;
  vendorName: string;
  txnDate: string;
  dueDate: string;
  totalAmt: number;
  balance: number;
  paid: boolean;
  currencyName: string;
  privateNote: string;
  sourceSystem?: string; // Add source system for tracking where the bill is from
}

interface XeroBill {
  id: string;
  xeroBillId: string;
  contactId: string;
  contactName: string;
  date: string;
  dueDate: string;
  totalAmount: number;
  remainingAmount: number;
  isPaid: boolean;
  currency: string;
  notes: string;
  lineItems: any[];
  tenantId: string;
}

interface BillTableParams {
  pagination: TablePaginationConfig;
  sortField?: string;
  sortOrder?: string;
  filters?: Record<string, FilterValue>;
  search?: string;
  startDate?: string;
  endDate?: string;
  vendorId?: string;
  isPaid?: boolean | null;
  sourceSystem?: string; // Add source system for filtering
}

const Bill: React.FC = () => {
  const [bills, setBills] = useState<Bill[]>([]);
  const [xeroBills, setXeroBills] = useState<XeroBill[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [search, setSearch] = useState<string>('');
  const [drawerVisible, setDrawerVisible] = useState<boolean>(false);
  const [xeroBillDrawerVisible, setXeroBillDrawerVisible] = useState<boolean>(false);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [selectedXeroBill, setSelectedXeroBill] = useState<XeroBill | null>(null);
  const [activeTab, setActiveTab] = useState<string>('qb');
  const [isXeroConnected, setIsXeroConnected] = useState<boolean>(false);
  const [xeroBillsLoading, setXeroBillsLoading] = useState<boolean>(false);
  const [tenantId, setTenantId] = useState<string>('');
  const [dateRange, setDateRange] = useState<[moment.Moment | null, moment.Moment | null] | null>(null);
  
  const [tableParams, setTableParams] = useState<BillTableParams>({
    pagination: {
      current: 1,
      pageSize: 10,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
    },
    sortField: 'createdAt',
    sortOrder: 'descend',
    search: '',
    startDate: undefined,
    endDate: undefined,
    vendorId: undefined,
    isPaid: null,
    sourceSystem: 'QuickBooks', // Default to QuickBooks
  });

  // Check Xero connection status on mount
  useEffect(() => {
    checkXeroAuth();
    
    // Set up an event listener for storage changes
    window.addEventListener("storage", checkXeroAuth);
    
    return () => window.removeEventListener("storage", checkXeroAuth);
  }, []);

  const checkXeroAuth = () => {
    const xeroAccessToken = localStorage.getItem("xero_access_token");
    const xeroTenantId = localStorage.getItem("xero_tenant_id");
    const isConnected = Boolean(xeroAccessToken && xeroTenantId);

    setIsXeroConnected(isConnected);
    if (isConnected && xeroTenantId) {
      setTenantId(xeroTenantId);
    }
  };

  // Use a dependency array with proper dependencies
  useEffect(() => {
    if (activeTab === 'qb') {
      fetchBills();
    } else if (activeTab === 'xero' && isXeroConnected) {
      fetchXeroBills();
    }
  }, [
    activeTab,
    tableParams.pagination.current,
    tableParams.pagination.pageSize,
    tableParams.sortField,
    tableParams.sortOrder,
    tableParams.search,
    tableParams.startDate,
    tableParams.endDate,
    tableParams.vendorId,
    tableParams.isPaid,
    tableParams.sourceSystem,
    isXeroConnected,
    tenantId
  ]);

  const getAuthCredentials = () => {
    const token = localStorage.getItem('qb_access_token');
    const realmId = localStorage.getItem('qb_realm_id');
    
    if (!token || !realmId) {
      message.error('QuickBooks authentication credentials not found');
      return null;
    }
    
    return { token, realmId };
  };

  const getXeroAuthCredentials = () => {
    const token = localStorage.getItem('xero_access_token');
    const tenantId = localStorage.getItem('xero_tenant_id');
    
    if (!token || !tenantId) {
      message.error('Xero authentication credentials not found');
      return null;
    }
    
    return { token, tenantId };
  };

  const fetchBills = async () => {
    const auth = getAuthCredentials();
    if (!auth) return;

    setLoading(true);
    
    try {
      const { pagination, sortField, sortOrder, search, startDate, endDate, vendorId, isPaid } = tableParams;
      
      const params = new URLSearchParams({
        page: String(pagination.current || 1),
        pageSize: String(pagination.pageSize || 10),
        search: search || '',
        sortBy: sortField || 'createdAt',
        descending: sortOrder === 'descend' ? 'true' : 'false',
      });
      
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      if (vendorId) params.append('vendorId', vendorId);
      if (isPaid !== null) params.append('isPaid', String(isPaid));
      
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/Bill/Pagination?${params.toString()}`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${auth.token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch bills');
      }
      
      const data = await response.json();
      
      // Add source system property to identify QuickBooks bills
      const billsWithSource = (data.bills || []).map(bill => ({
        ...bill,
        sourceSystem: 'QuickBooks'
      }));
      
      setBills(billsWithSource);
      
      // Directly update the tableParams with the returned pagination data
      setTableParams(prev => ({
        ...prev,
        pagination: {
          ...prev.pagination,
          total: data.totalCount,
          current: data.currentPage || pagination.current,
          pageSize: data.pageSize || pagination.pageSize,
        }
      }));
    } catch (error) {
      console.error('Error fetching QuickBooks bills:', error);
      message.error('Failed to load bills from QuickBooks');
    } finally {
      setLoading(false);
    }
  };

  const fetchXeroBills = async () => {
    if (!isXeroConnected || !tenantId) {
      message.error('Please connect to Xero first');
      return;
    }

    setXeroBillsLoading(true);
    
    try {
      const { pagination, sortField, sortOrder, search, startDate, endDate, isPaid } = tableParams;
      
      const params = new URLSearchParams({
        PageNumber: String(pagination.current || 1),
        PageSize: String(pagination.pageSize || 10),
        sortBy: sortField || 'Date',
        descending: sortOrder === 'descend' ? 'true' : 'false',
      });
      
      if (search) params.append('search', search);
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      if (isPaid !== null) params.append('isPaid', String(isPaid));
      params.append('TenantId', tenantId);
      
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/XeroBills?${params.toString()}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error('Failed to fetch Xero bills');
      }
      
      const data = await response.json();
      
      // Map Xero bills to our common format
      // Check if data.items exists based on the API response you shared
      const bills = data.items || [];
      
      const mappedXeroBills = bills.map((bill: any) => ({
        id: bill.id,
        xeroBillId: bill.xeroBillId,
        docNumber: bill.docNumber || bill.xeroBillId || bill.reference || '', // Use Xero bill ID as document number
        vendorName: bill.vendorName,
        txnDate: bill.date,
        dueDate: bill.dueDate,
        totalAmt: bill.total || 0,
        balance: bill.amountDue || 0,
        paid: bill.paid,
        currencyName: bill.currencyCode,
        privateNote: bill.privateNote,
        sourceSystem: 'Xero',
        lineItems: bill.lineItems || [],
        tenantId: bill.xeroTenantId
      }));
      
      setXeroBills(mappedXeroBills);
      
      // Update pagination info with correct property names from the API response
      setTableParams(prev => ({
        ...prev,
        pagination: {
          ...prev.pagination,
          total: data.totalCount,
          current: data.pageNumber || pagination.current,
          pageSize: data.pageSize || pagination.pageSize,
        }
      }));
    } catch (error) {
      console.error('Error fetching Xero bills:', error);
      message.error('Failed to load bills from Xero');
    } finally {
      setXeroBillsLoading(false);
    }
  };

  const handleTableChange = (
    newPagination: TablePaginationConfig,
    filters: Record<string, FilterValue>,
    sorter: any
  ) => {
    // Update tableParams with the new pagination, filters, and sorting
    setTableParams({
      ...tableParams,
      pagination: {
        ...newPagination,
        // Make sure we keep the total value when changing page or pageSize
        total: tableParams.pagination.total
      },
      filters,
      sortField: sorter.field,
      sortOrder: sorter.order,
    });
  };

  const handleSearch = () => {
    // Reset to first page when performing a new search
    setTableParams({
      ...tableParams,
      search,
      pagination: {
        ...tableParams.pagination,
        current: 1,
      },
    });
  };

  const handleDateRangeChange = (dates: [moment.Moment | null, moment.Moment | null] | null) => {
    setDateRange(dates);
    
    if (dates && dates[0] && dates[1]) {
      setTableParams({
        ...tableParams,
        startDate: dates[0].format('YYYY-MM-DD'),
        endDate: dates[1].format('YYYY-MM-DD'),
        pagination: {
          ...tableParams.pagination,
          current: 1,
        },
      });
    } else {
      setTableParams({
        ...tableParams,
        startDate: undefined,
        endDate: undefined,
        pagination: {
          ...tableParams.pagination,
          current: 1,
        },
      });
    }
  };

  const handleStatusChange = (value: string) => {
    const isPaid = value === 'all' ? null : value === 'paid';
    setTableParams({
      ...tableParams,
      isPaid,
      pagination: {
        ...tableParams.pagination,
        current: 1,
      },
    });
  };

  const handleSyncBills = async () => {
    if (activeTab === 'qb') {
      await syncQuickBooksBills();
    } else if (activeTab === 'xero') {
      await syncXeroBills();
    }
  };

  const syncQuickBooksBills = async () => {
    const auth = getAuthCredentials();
    if (!auth) return;

    setLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/Bill/Sync`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${auth.token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to sync bills from QuickBooks');
      }

      const result = await response.json();
      message.success(`Successfully synced: Created ${result.created}, Updated ${result.updated}, Total ${result.total} bills from QuickBooks`);
      
      // Reset pagination to first page after sync
      setTableParams({
        ...tableParams,
        pagination: {
          ...tableParams.pagination,
          current: 1,
        },
      });
      
      // Refresh bills
      fetchBills();
    } catch (error) {
      console.error('Error syncing QuickBooks bills:', error);
      message.error('Failed to sync bills from QuickBooks');
    } finally {
      setLoading(false);
    }
  };

  const syncXeroBills = async () => {
    if (!isXeroConnected || !tenantId) {
      message.error('Please connect to Xero first');
      return;
    }

    setXeroBillsLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/XeroBills/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ tenantId })
      });

      if (!response.ok) {
        throw new Error('Failed to sync bills from Xero');
      }

      const result = await response.json();
      message.success(`Successfully synced ${result.length} bills from Xero`);
      
      // Reset pagination to first page after sync
      setTableParams({
        ...tableParams,
        pagination: {
          ...tableParams.pagination,
          current: 1,
        },
      });
      
      // Refresh Xero bills
      fetchXeroBills();
    } catch (error) {
      console.error('Error syncing Xero bills:', error);
      message.error('Failed to sync bills from Xero');
    } finally {
      setXeroBillsLoading(false);
    }
  };

  const handleAddBill = () => {
    if (activeTab === 'qb') {
      setSelectedBill(null);
      setDrawerVisible(true);
    } else if (activeTab === 'xero') {
      setSelectedXeroBill(null);
      setXeroBillDrawerVisible(true);
    }
  };

  const handleEditBill = (record: Bill) => {
    if (record.sourceSystem === 'QuickBooks') {
      setSelectedBill(record);
      setDrawerVisible(true);
    } else if (record.sourceSystem === 'Xero') {
      // Find the original Xero bill with all details
      const xeroBillRecord = xeroBills.find(bill => bill.id === record.id);
      if (xeroBillRecord) {
        setSelectedXeroBill(xeroBillRecord);
        setXeroBillDrawerVisible(true);
      } else {
        message.error('Failed to find Xero bill details');
      }
    }
  };

  const handleDrawerClose = (refreshList: boolean = false) => {
    setDrawerVisible(false);
    if (refreshList && activeTab === 'qb') {
      fetchBills();
    }
  };

  const handleXeroBillDrawerClose = (refreshList: boolean = false) => {
    setXeroBillDrawerVisible(false);
    if (refreshList && activeTab === 'xero') {
      fetchXeroBills();
    }
  };

  const handleTabChange = (key: string) => {
    setActiveTab(key);
    
    // Reset pagination when switching tabs
    setTableParams({
      ...tableParams,
      pagination: {
        ...tableParams.pagination,
        current: 1,
      },
      sourceSystem: key === 'qb' ? 'QuickBooks' : 'Xero',
    });
    
    // Clear selected bills
    setSelectedBill(null);
    setSelectedXeroBill(null);
  };

  const columns = [
    {
      title: 'Vendor',
      dataIndex: 'vendorName',
      key: 'vendorName',
      sorter: true,
    },
    {
      title: 'Date',
      dataIndex: 'txnDate',
      key: 'txnDate',
      sorter: true,
      render: (date: string) => date ? moment(date).format('MM/DD/YYYY') : '-'
    },
    {
      title: 'Due Date',
      dataIndex: 'dueDate',
      key: 'dueDate',
      sorter: true,
      render: (date: string) => date ? moment(date).format('MM/DD/YYYY') : '-'
    },
    {
      title: 'Amount',
      dataIndex: 'totalAmt',
      key: 'totalAmt',
      sorter: true,
      render: (amount: number, record: Bill) => (
        <span>{record.currencyName || '$'} {amount?.toFixed(2) || '0.00'}</span>
      ),
    },
    {
      title: 'Balance',
      dataIndex: 'balance',
      key: 'balance',
      sorter: true,
      render: (balance: number, record: Bill) => (
        <span>{record.currencyName || '$'} {balance?.toFixed(2) || '0.00'}</span>
      ),
    },
    {
      title: 'Source',
      dataIndex: 'sourceSystem',
      key: 'sourceSystem',
      render: (source: string) => (
        <Tag color={source === 'QuickBooks' ? 'blue' : 'green'}>
          {source}
        </Tag>
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Bill) => (
        <Space>
          <Button type="link" onClick={() => handleEditBill(record)}>Edit</Button>
        </Space>
      ),
    },
  ];

  return (
    <div className="bill-container">
      <Tabs activeKey={activeTab} onChange={handleTabChange}>
        <TabPane tab="QuickBooks Bills" key="qb">
          <div className="bill-header" style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
            <Space>
              <Input 
                placeholder="Search bills..." 
                value={search}
                onChange={e => setSearch(e.target.value)}
                onPressEnter={handleSearch}
                style={{ width: 250 }}
                prefix={<SearchOutlined />} 
              />
              <Button type="primary" onClick={handleSearch}>Search</Button>
              <RangePicker 
                onChange={handleDateRangeChange}
                value={dateRange}
                format="YYYY-MM-DD"
              />
            </Space>
            <Space>
              <Button 
                icon={<SyncOutlined />} 
                onClick={handleSyncBills}
                loading={loading}
              >
                Sync with QuickBooks
              </Button>
              <Button 
                type="primary" 
                icon={<PlusOutlined />} 
                onClick={handleAddBill}
              >
                Add Bill
              </Button>
            </Space>
          </div>

          <Table
            columns={columns}
            rowKey={record => record.id.toString()}
            dataSource={bills}
            pagination={tableParams.pagination}
            loading={loading}
            onChange={handleTableChange}
            scroll={{ x: 'max-content', y: 'calc(100vh - 90px)' }}
            style={{ flex: 1 }}
          />
        </TabPane>
        
        <TabPane tab="Xero Bills" key="xero" disabled={!isXeroConnected}>
          <div className="bill-header" style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
            <Space>
              <Input 
                placeholder="Search Xero bills..." 
                value={search}
                onChange={e => setSearch(e.target.value)}
                onPressEnter={handleSearch}
                style={{ width: 250 }}
                prefix={<SearchOutlined />} 
              />
              <Button type="primary" onClick={handleSearch}>Search</Button>
              <RangePicker 
                onChange={handleDateRangeChange}
                value={dateRange}
                format="YYYY-MM-DD"
              />
  
            </Space>
            <Space>
              <Button 
                icon={<SyncOutlined />} 
                onClick={handleSyncBills}
                loading={xeroBillsLoading}
              >
                Sync with Xero
              </Button>
              <Button 
                type="primary" 
                icon={<PlusOutlined />} 
                onClick={handleAddBill}
              >
                Add Xero Bill
              </Button>
            </Space>
          </div>

          <Table
            columns={columns}
            rowKey={record => record.id.toString()}
            dataSource={xeroBills}
            pagination={tableParams.pagination}
            loading={xeroBillsLoading}
            onChange={handleTableChange}
            scroll={{ x: 'max-content', y: 'calc(100vh - 290px)' }}
            style={{ flex: 1 }}
          />
        </TabPane>
      </Tabs>

      {drawerVisible && (
        <BillDrawer
          visible={drawerVisible}
          onClose={handleDrawerClose}
          bill={selectedBill}
        />
      )}

      {xeroBillDrawerVisible && (
        <XeroBillDrawer
          visible={xeroBillDrawerVisible}
          onClose={handleXeroBillDrawerClose}
          bill={selectedXeroBill}
          tenantId={tenantId}
        />
      )}
    </div>
  );
};

export default Bill;