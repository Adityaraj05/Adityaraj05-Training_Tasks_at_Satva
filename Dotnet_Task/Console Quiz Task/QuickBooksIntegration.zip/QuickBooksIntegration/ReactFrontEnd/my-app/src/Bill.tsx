import React, { useEffect, useState } from "react";
import {
  Table,
  Button,
  Empty,
  Spin,
  Form,
  Input,
  message,
  Popconfirm,
  Modal,
  Select,
  DatePicker,
  Space,
  Collapse,
  Upload,
  Typography,
  InputNumber,
  Checkbox,
} from "antd";
import {
  DownloadOutlined,
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  LoadingOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import SearchBar from "./SearchBar";
import dayjs from "dayjs";
import axios from "axios";

const { Option } = Select;
const { TextArea } = Input;
const { Panel } = Collapse;
const { Text } = Typography;

interface BillData {
  quickBooksBillId: number;
  vendorName: string;
  txnDate: string;
  dueDate: string;
  totalAmt: number;
  status?: string;
}

interface VendorData {
  id: number;
  displayName: string;
  primaryEmailAddr: string;
}

interface CategoryData {
  quickBooksAccountId: string;
  name: string;
}

interface ProductData {
  quickBooksItemId: string;
  name: string;
  unitPrice: number;
}
interface Customerdata {
  quickBooksCustomerId: string;
  displayName: string;
}

interface CategoryItem {
  key: number;
  category?: string;
  description?: string;
  amount?: number;
  billable?: boolean;
  tax?: boolean;
  customer?: string;
}

interface ProductItem {
  key: number;
  product?: string;
  description?: string;
  qty?: number;
  rate?: number;
  amount?: number;
  billable?: boolean;
  tax?: boolean;
  customer?: string;
}

const Bill = () => {
  const [categoryItems, setCategoryItems] = useState<CategoryItem[]>([]);
  const [productItems, setProductItems] = useState<ProductItem[]>([]);
  const [categoryOptions, setCategoryOptions] = useState<
    { value: string; label: string }[]
  >([]);
  const [vendorItems, setVendorItems] = useState<
    { key: number; vendor?: number }[]
  >([]);
  const [productOptions, setProductOptions] = useState<
    { value: string; label: string }[]
  >([]);
  const [bills, setBills] = useState<BillData[]>([]);
  const [customerDetails, setCustomerDetails] = useState<Customerdata[]>([]);
  const [customerOptions, setCustomerOptions] = useState<
    { value: string; label: string }[]
  >([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [vendorDetails, setVendorDetails] = useState<VendorData[]>([]);
  const [chartOfAccounts, setChartOfAccounts] = useState<CategoryData[]>([]);
  const [productDetails, setProductDetails] = useState<ProductData[]>([]);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [form] = Form.useForm();

  // fetch bills from the database

  const fetchBillsFromDb = async (
    page = 1,
    pageSize = 10,
    search = searchTerm
  ) => {
    setLoading(true);
    try {
      const response = await fetch(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/bill/fetch-bills-from-db?page=${page}&pageSize=${pageSize}&searchTerm=${encodeURIComponent(
          search || ""
        )}`
      );

      const result = await response.json();

      setBills(result.data);
      setPagination((prev) => ({
        ...prev,
        current: page,
        pageSize: pageSize,
        total: result.totalCount,
      }));
    } catch (error) {
      console.error("Error fetching bills:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    fetchBillsFromDb(1, pagination.pageSize, value);
  };

  const handleTableChange = (paginationInfo: any) => {
    const { current, pageSize } = paginationInfo;
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
    fetchBillsFromDb(current, pageSize, searchTerm);
  };

  useEffect(() => {
    fetchBillsFromDb(pagination.current, pagination.pageSize, searchTerm);
  }, [pagination.pageSize, pagination.current, searchTerm]);

  // fetching all the api data here , chartof accounts, vendors, products and customers

  const showModal = async () => {
    setIsModalVisible(true);

    try {
      const vendorResponse = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/bill/all`
      );
      const chartOfAccountsResponse = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/bill/chartofaccounts/id-names`
      );
      const productDetailsResponse = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/bill/productsDetails`
      );
      const customerDetailsResponse = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/bill/get-all-customers`
      );

      if (
        vendorResponse.ok &&
        chartOfAccountsResponse.ok &&
        productDetailsResponse.ok &&
        customerDetailsResponse.ok
      ) {
        const vendorData = await vendorResponse.json();
        const chartOfAccountData = await chartOfAccountsResponse.json();
        const productDataResponse = await productDetailsResponse.json();
        const customerDataResponse = await customerDetailsResponse.json();

        setVendorDetails(vendorData);
        setChartOfAccounts(chartOfAccountData);
        setProductDetails(productDataResponse);
        setCustomerDetails(customerDataResponse);

        const categoryData = chartOfAccountData.map((item: CategoryData) => ({
          value: item.quickBooksAccountId,
          label: item.name,
        }));
        setCategoryOptions(categoryData);

        const productOptions = productDataResponse.map((item: ProductData) => ({
          value: item.quickBooksItemId,
          label: item.name,
        }));
        setProductOptions(productOptions);
        const customerOption = customerDataResponse.map(
          (item: Customerdata) => ({
            value: item.quickBooksCustomerId,
            label: item.displayName,
          })
        );
        setCustomerOptions(customerOption); 
      } else {
        console.error("Failed to fetch data from one or more APIs.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
  };


  // handle save 
  const handleSave = () => {
    form
      .validateFields()
      .then(async (values) => {
        try {
          setLoading(true);
  
          const categoryLines = categoryItems.map((item, index) => ({
            quickBooksLineId: (index + 1).toString(),
            amount: item.amount,
            description: item.description,
            itemId: item.category,
            itemName: "",
            unitPrice: 0,
            qty: 1,
            billableStatus: "",
            taxCodeRef: "",
            detailType: "Account", // Mark as AccountBased
          }));
  
          const productLines = productItems.map((item, index) => ({
            quickBooksLineId: (index + 100).toString(),
            amount: item.amount,
            description: item.description,
            itemId: item.product,
            itemName: "",
            unitPrice: item.rate,
            qty: item.qty,
            billableStatus: "",
            taxCodeRef: "",
            detailType: "Item", // Mark as ItemBased
          }));
  
          const lines = [...categoryLines, ...productLines];
  
          const billData = {
            vendorId: String(values.vendor),
            mailingAddress: values.mailingAddress,
            billDate: values.billDate ? values.billDate.toISOString() : null,
            dueDate: values.dueDate ? values.dueDate.toISOString() : null,
            memo: values.memo,
            billNumber: values.billNumber,
            lines: lines,
          };
  
          const response = await fetch(
            `${import.meta.env.VITE_API_BASE_URL}/api/bill/create-bill`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(billData),
            }
          );
  
          console.log("Sending payload", billData);
  
          if (response.ok) {
            const result = await response.json();
            message.success("Bill created successfully");
            setIsModalVisible(false);
            form.resetFields();
            handleDownload();
          } else {
            const errorData = await response.json();
            message.error(
              `Failed to create bill: ${errorData.message || "Unknown error"}`
            );
          }
        } catch (error) {
          console.error("Error creating bill:", error);
          message.error("Failed to create bill. Please try again.");
        } finally {
          setLoading(false);
        }
      })
      .catch((info) => {
        console.log("Validation failed:", info);
      });
  };
  

  const handleDownload = async () => {
    console.log("Syncing Bills from QuickBooks...");
    try {
      setLoading(true);
      const response = await fetch(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/bill/fetch-bills-from-quickbooks`
      );
      const data = await response.json();
      setBills(data);
      setPagination((prev) => ({ ...prev, total: data.length }));
      setLoading(false);
    } catch (error) {
      console.error("Error fetching vendors:", error);
      setLoading(false);
    }
  };

  const handleEdit = (bill: BillData) => {
    console.log("Editing bill:", bill);
  };

  const handleDelete = (billId: number) => {
    console.log("Deleting bill with ID:", billId);
  };

  const handleAddCategoryItem = () => {
    const newKey =
      categoryItems.length > 0
        ? Math.max(...categoryItems.map((item) => item.key)) + 1
        : 1;
    setCategoryItems([...categoryItems, { key: newKey }]);
  };

  const handleRemoveCategoryItem = (key: number) => {
    setCategoryItems(categoryItems.filter((item) => item.key !== key));
  };

  const handleAddProductItem = () => {
    const newKey =
      productItems.length > 0
        ? Math.max(...productItems.map((item) => item.key)) + 1
        : 1;
    setProductItems([...productItems, { key: newKey }]);
  };

  const handleRemoveProductItem = (key: number) => {
    setProductItems(productItems.filter((item) => item.key !== key));
  };

  const clearAllCategoryLines = () => {
    setCategoryItems([]);
  };

  const clearAllProductLines = () => {
    setProductItems([]);
  };

  const handleCategoryChange = (value: string, key: number) => {
    const updatedCategoryItems = categoryItems.map((item) =>
      item.key === key ? { ...item, category: value } : item
    );
    setCategoryItems(updatedCategoryItems);
  };

  const handleProductChange = (value: string, key: number) => {
    const updatedProductItems = productItems.map((item) =>
      item.key === key ? { ...item, product: value } : item
    );
    setProductItems(updatedProductItems);
  };

  const handleVendorChange = (value: number) => {
    form.setFieldsValue({ vendor: value });
    const selectedVendor = vendorDetails.find((vendor) => vendor.id === value);
    if (selectedVendor && selectedVendor.primaryEmailAddr) {
      form.setFieldsValue({ mailingAddress: selectedVendor.primaryEmailAddr });
    }
  };

  const handleCategoryDescriptionChange = (value: string, key: number) => {
    const updatedItems = categoryItems.map((item) =>
      item.key === key ? { ...item, description: value } : item
    );
    setCategoryItems(updatedItems);
  };

  const handleCategoryAmountChange = (value: number | null, key: number) => {
    const updatedItems = categoryItems.map((item) =>
      item.key === key ? { ...item, amount: value || 0 } : item
    );
    setCategoryItems(updatedItems);
  };

  const handleCategoryBillableChange = (value: boolean, key: number) => {
    const updatedItems = categoryItems.map((item) =>
      item.key === key ? { ...item, billable: value } : item
    );
    setCategoryItems(updatedItems);
  };

  const handleCategoryTaxChange = (value: boolean, key: number) => {
    const updatedItems = categoryItems.map((item) =>
      item.key === key ? { ...item, tax: value } : item
    );
    setCategoryItems(updatedItems);
  };

  const handleCategoryCustomerChange = (value: string, key: number) => {
    const updatedItems = categoryItems.map((item) =>
      item.key === key ? { ...item, customer: value } : item
    );
    setCategoryItems(updatedItems);
  };

  const handleProductDescriptionChange = (value: string, key: number) => {
    const updatedItems = productItems.map((item) =>
      item.key === key ? { ...item, description: value } : item
    );
    setProductItems(updatedItems);
  };

  const handleProductQtyChange = (value: number | null, key: number) => {
    const updatedItems = productItems.map((item) => {
      if (item.key === key) {
        const qty = value || 0;
        const rate = item.rate || 0;
        return {
          ...item,
          qty: qty,
          amount: qty * rate,
        };
      }
      return item;
    });
    setProductItems(updatedItems);
  };

  const handleProductRateChange = (value: number | null, key: number) => {
    const updatedItems = productItems.map((item) => {
      if (item.key === key) {
        const rate = value || 0;
        const qty = item.qty || 0;
        return {
          ...item,
          rate: rate,
          amount: qty * rate,
        };
      }
      return item;
    });
    setProductItems(updatedItems);
  };

  const handleProductBillableChange = (value: boolean, key: number) => {
    const updatedItems = productItems.map((item) =>
      item.key === key ? { ...item, billable: value } : item
    );
    setProductItems(updatedItems);
  };

  const handleProductTaxChange = (value: boolean, key: number) => {
    const updatedItems = productItems.map((item) =>
      item.key === key ? { ...item, tax: value } : item
    );
    setProductItems(updatedItems);
  };

  const handleProductCustomerChange = (value: string, key: number) => {
    const updatedItems = productItems.map((item) =>
      item.key === key ? { ...item, customer: value } : item
    );
    setProductItems(updatedItems);
  };

  const columns = [
    {
      title: "Vendor",
      dataIndex: "vendorName",
      key: "vendorName",
    },
    {
      title: "Bill Date",
      dataIndex: "txnDate",
      key: "txnDate",
      render: (date: string) => new Date(date).toLocaleDateString(),
    },
    {
      title: "Due Date",
      dataIndex: "dueDate",
      key: "dueDate",
      render: (date: string) => new Date(date).toLocaleDateString(),
    },
    {
      title: "Bill Amount",
      dataIndex: "totalAmt",
      key: "totalAmt",
      render: (amount: number) => `$${amount.toFixed(2)}`,
    },
    {
      title: "Actions",
      key: "actions",
      render: (_: any, bill: BillData) => (
        <div className="action-buttons">
          <Button
            type="default"
            icon={<EditOutlined />}
            onClick={() => handleEdit(bill)}
            className="edit-button"
          >
            Edit
          </Button>
          <Popconfirm
            title="Are you sure you want to delete this bill?"
            onConfirm={() => handleDelete(bill.quickBooksBillId)}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="default"
              danger
              icon={<DeleteOutlined />}
              className="delete-button"
            >
              Delete
            </Button>
          </Popconfirm>
        </div>
      ),
    },
  ];

  const categoryColumns = [
    { title: "#", dataIndex: "key", key: "key", width: 50 },
    {
      title: "CATEGORY",
      dataIndex: "category",
      key: "category",
      render: (text: string, record: CategoryItem) => (
        <Select
          placeholder="Choose a category"
          showSearch
          style={{ width: "100%" }}
          value={record.category}
          onChange={(value) => handleCategoryChange(value, record.key)}
          optionFilterProp="children"
        >
          {categoryOptions.map((option) => (
            <Select.Option key={option.value} value={option.value}>
              {option.label}
            </Select.Option>
          ))}
        </Select>
      ),
    },
    {
      title: "DESCRIPTION",
      dataIndex: "description",
      key: "description",
      render: (text: string, record: CategoryItem) => (
        <Input
          placeholder="Enter description"
          value={record.description}
          onChange={(e) =>
            handleCategoryDescriptionChange(e.target.value, record.key)
          }
        />
      ),
    },
    {
      title: "AMOUNT",
      dataIndex: "amount",
      key: "amount",
      width: 120,
      render: (text: string, record: CategoryItem) => (
        <InputNumber
          style={{ width: "100%" }}
          prefix="$"
          value={record.amount}
          onChange={(value) => handleCategoryAmountChange(value, record.key)}
        />
      ),
    },
    {
      title: "BILLABLE",
      dataIndex: "billable",
      key: "billable",
      width: 100,
      render: (checked: boolean, record: CategoryItem) => (
        <Checkbox
          checked={record.billable}
          onChange={(e) =>
            handleCategoryBillableChange(e.target.checked, record.key)
          }
        />
      ),
    },
    {
      title: "TAX",
      dataIndex: "tax",
      key: "tax",
      width: 80,
      render: (checked: boolean, record: CategoryItem) => (
        <Checkbox
          checked={record.tax}
          onChange={(e) =>
            handleCategoryTaxChange(e.target.checked, record.key)
          }
        />
      ),
    },
    {
      title: "CUSTOMER",
      dataIndex: "customer",
      key: "customer",
      width: 120,
      render: (text: string, record: CategoryItem) => (
        <Select
          placeholder="Select customer"
          style={{ width: "100%" }}
          value={record.customer} 
          onChange={(value) => handleCategoryCustomerChange(value, record.key)}
        >
          {customerOptions.map((customer) => (
            <Select.Option key={customer.value} value={customer.value}>
              {customer.label}
            </Select.Option>
          ))}
        </Select>
      ),
    },    
    {
      title: "",
      key: "action",
      width: 50,
      render: (_: any, record: CategoryItem) => (
        <Button
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveCategoryItem(record.key)}
        />
      ),
    },
  ];

  const productColumns = [
    { title: "#", dataIndex: "key", key: "key", width: 50 },
    {
      title: "PRODUCT/SERVICE",
      dataIndex: "product",
      key: "product",
      render: (text: string, record: ProductItem) => (
        <Select
          placeholder="Choose a product"
          showSearch
          style={{ width: "100%" }}
          value={record.product}
          onChange={(value) => handleProductChange(value, record.key)}
          optionFilterProp="children"
        >
          {productOptions.map((option) => (
            <Select.Option key={option.value} value={option.value}>
              {option.label}
            </Select.Option>
          ))}
        </Select>
      ),
    },
    {
      title: "DESCRIPTION",
      dataIndex: "description",
      key: "description",
      render: (text: string, record: ProductItem) => (
        <Input
          placeholder="Enter description"
          value={record.description}
          onChange={(e) =>
            handleProductDescriptionChange(e.target.value, record.key)
          }
        />
      ),
    },
    {
      title: "QTY",
      dataIndex: "qty",
      key: "qty",
      width: 80,
      render: (text: string, record: ProductItem) => (
        <InputNumber
          style={{ width: "100%" }}
          value={record.qty}
          onChange={(value) => handleProductQtyChange(value, record.key)}
        />
      ),
    },
    {
      title: "RATE",
      dataIndex: "rate",
      key: "rate",
      width: 100,
      render: (text: string, record: ProductItem) => (
        <InputNumber
          style={{ width: "100%" }}
          prefix="$"
          value={record.rate}
          onChange={(value) => handleProductRateChange(value, record.key)}
        />
      ),
    },
    {
      title: "AMOUNT",
      dataIndex: "amount",
      key: "amount",
      width: 120,
      render: (amount: number) => (
        <div style={{ textAlign: "right" }}>
          ${amount?.toFixed(2) || "0.00"}
        </div>
      ),
    },
    {
      title: "BILLABLE",
      dataIndex: "billable",
      key: "billable",
      width: 100,
      render: (checked: boolean, record: ProductItem) => (
        <Checkbox
          checked={record.billable}
          onChange={(e) =>
            handleProductBillableChange(e.target.checked, record.key)
          }
        />
      ),
    },
    {
      title: "TAX",
      dataIndex: "tax",
      key: "tax",
      width: 80,
      render: (checked: boolean, record: ProductItem) => (
        <Checkbox
          checked={record.tax}
          onChange={(e) => handleProductTaxChange(e.target.checked, record.key)}
        />
      ),
    },
    {
      title: "CUSTOMER",
      dataIndex: "customer",
      key: "customer",
      width: 120,
      render: (text: string, record: ProductItem) => (
        <Select
          placeholder="Select customer"
          style={{ width: "100%" }}
          value={record.customer}  
          onChange={(value) => handleProductCustomerChange(value, record.key)}
        >
          {customerOptions.map((customer) => (
            <Select.Option key={customer.value} value={customer.value}>
              {customer.label}
            </Select.Option>
          ))}
        </Select>
      ),
    }
    ,
    {
      title: "",
      key: "action",
      width: 50,
      render: (_: any, record: ProductItem) => (
        <Button
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveProductItem(record.key)}
        />
      ),
    },
  ];

  const calculateTotalAmount = () => {
    const categoryTotal = categoryItems.reduce(
      (sum, item) => sum + (item.amount || 0),
      0
    );
    const productTotal = productItems.reduce(
      (sum, item) => sum + (item.amount || 0),
      0
    );
    return (categoryTotal + productTotal).toFixed(2);
  };

  const antIcon = (
    <LoadingOutlined style={{ fontSize: 40, color: "#00A551" }} spin />
  );

  return (
    <div className="chart-accounts-container">
      <div className="chart-accounts-header">
        <div className="chart-accounts-title">Bills</div>
        <div className="chart-accounts-actions">
          <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={showModal}
            className="action-button"
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Create Bill
          </Button>
          <Button
            type="primary"
            onClick={handleDownload}
            icon={<DownloadOutlined />}
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Sync from QuickBooks
          </Button>
        </div>
      </div>

      <div className="scrollable-table-container">
        {loading ? (
          <div className="loading-container">
            <Spin indicator={antIcon} size="large" />
            <p style={{ color: "#00A551" }}>Loading Bills...</p>
          </div>
        ) : bills.length > 0 ? (
          <Table
            dataSource={bills}
            columns={columns}
            rowKey={(record) => String(record.quickBooksBillId)}
            pagination={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              showSizeChanger: true,
            }}
            onChange={handleTableChange}
            scroll={{ x: "max-content" }}
            bordered
            className="vendors-table"
          />
        ) : (
          <div className="empty-data-container">
            <Empty
              description="No bills available. Click 'Sync from QuickBooks' to load bills."
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
          </div>
        )}
      </div>

      <Modal
        title="Bill"
        open={isModalVisible}
        onCancel={handleCancel}
        width={1200}
        style={{ top: 20 }}
        footer={[
          <Button key="cancel" onClick={handleCancel}>
            Cancel
          </Button>,
          <Button key="print" onClick={() => console.log("Print")}>
            Print
          </Button>,
          <Button key="recurring" onClick={() => console.log("Make recurring")}>
            Make recurring
          </Button>,
          <Button
            key="save"
            type="primary"
            onClick={handleSave}
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Save
          </Button>,
          <Button
            key="saveSchedule"
            type="primary"
            onClick={() => console.log("Save and schedule")}
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            Save and schedule payment
          </Button>,
        ]}
        closeIcon={<span style={{ fontSize: "24px" }}>×</span>}
      >
        <Form
          form={form}
          layout="vertical"
          initialValues={{
            billDate: dayjs(),
            dueDate: dayjs(),
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "24px",
            }}
          >
            <div style={{ flex: "1" }}>
              <Form.Item
                label="Vendor"
                name="vendor"
                rules={[{ required: true, message: "Please select a vendor" }]}
              >
                <Select
                  placeholder="Choose a vendor"
                  showSearch
                  style={{ width: "100%" }}
                  onChange={handleVendorChange}
                  optionFilterProp="children"
                >
                  {vendorDetails.length > 0 ? (
                    vendorDetails.map((vendor) => (
                      <Select.Option key={vendor.id} value={vendor.id}>
                        {vendor.displayName}
                      </Select.Option>
                    ))
                  ) : (
                    <Select.Option value="" disabled>
                      No vendors available
                    </Select.Option>
                  )}
                </Select>
              </Form.Item>

              <Form.Item label="Mailing address" name="mailingAddress">
                <TextArea rows={4} />
              </Form.Item>
            </div>

            <div style={{ flex: "1", marginLeft: "24px" }}>
              <div style={{ textAlign: "right", marginBottom: "20px" }}>
                <div style={{ fontSize: "12px", color: "#666" }}>
                  BALANCE DUE
                </div>
                <div style={{ fontSize: "28px", fontWeight: "bold" }}>
                  ${calculateTotalAmount()}
                </div>
              </div>

              <div style={{ display: "flex", gap: "16px" }}>
                <Form.Item label="Terms" name="terms" style={{ flex: "1" }}>
                  <Select placeholder="Select terms">
                    <Option value="net15">Net 15</Option>
                    <Option value="net30">Net 30</Option>
                    <Option value="net60">Net 60</Option>
                  </Select>
                </Form.Item>

                <Form.Item
                  label="Bill date"
                  name="billDate"
                  style={{ flex: "1" }}
                  rules={[
                    { required: true, message: "Please select bill date" },
                  ]}
                >
                  <DatePicker style={{ width: "100%" }} format="MM/DD/YYYY" />
                </Form.Item>
              </div>

              <div style={{ display: "flex", gap: "16px" }}>
                <Form.Item
                  label="Due date"
                  name="dueDate"
                  style={{ flex: "1" }}
                  rules={[
                    { required: true, message: "Please select due date" },
                  ]}
                >
                  <DatePicker style={{ width: "100%" }} format="MM/DD/YYYY" />
                </Form.Item>

                <Form.Item
                  label="Bill no."
                  name="billNumber"
                  style={{ flex: "1" }}
                >
                  <Input placeholder="Enter bill number" />
                </Form.Item>
              </div>
            </div>
          </div>

          <Form.Item label="Tags" name="tags">
            <Input placeholder="Start typing to add a tag" />
          </Form.Item>

          <Collapse
            defaultActiveKey={["category"]}
            style={{ marginBottom: "16px" }}
            expandIconPosition="end"
          >
            <Panel header="Category details" key="category">
              <Table
                dataSource={categoryItems}
                columns={categoryColumns}
                pagination={false}
                size="small"
                bordered
                style={{ marginBottom: "16px" }}
              />
              <Space>
                <Button onClick={handleAddCategoryItem}>Add lines</Button>
                <Button onClick={clearAllCategoryLines}>Clear all lines</Button>
              </Space>
            </Panel>
          </Collapse>

          <Collapse defaultActiveKey={["item"]} expandIconPosition="end">
            <Panel header="Item details" key="item">
              <Table
                dataSource={productItems}
                columns={productColumns}
                pagination={false}
                size="small"
                bordered
                style={{ marginBottom: "16px" }}
              />
              <Space style={{ marginBottom: "16px" }}>
                <Button onClick={handleAddProductItem}>Add lines</Button>
                <Button onClick={clearAllProductLines}>Clear all lines</Button>
              </Space>

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  marginBottom: "16px",
                }}
              >
                <div style={{ textAlign: "right" }}>
                  <Text>Total</Text>
                  <div style={{ fontSize: "16px", fontWeight: "bold" }}>
                    ${calculateTotalAmount()}
                  </div>
                </div>
              </div>
            </Panel>
          </Collapse>

          <div style={{ display: "flex", gap: "24px", marginTop: "24px" }}>
            <div style={{ flex: "1" }}>
              <Form.Item label="Memo" name="memo">
                <TextArea rows={4} />
              </Form.Item>
            </div>
            <div style={{ flex: "1" }}>
              <Form.Item label="Attachments">
                <Upload>
                  <Button icon={<UploadOutlined />}>Add attachment</Button>
                </Upload>
                <div
                  style={{ marginTop: "8px", color: "#999", fontSize: "12px" }}
                >
                  Max file size: 20 MB
                </div>
                <div style={{ marginTop: "8px" }}>
                  <a href="#">Show existing</a>
                </div>
                <div style={{ marginTop: "24px", textAlign: "right" }}>
                  <a href="#">Privacy</a>
                </div>
              </Form.Item>
            </div>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default Bill;
