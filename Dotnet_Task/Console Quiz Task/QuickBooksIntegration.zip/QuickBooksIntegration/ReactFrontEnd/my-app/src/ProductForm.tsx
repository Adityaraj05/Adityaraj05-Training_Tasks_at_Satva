import React, { useEffect, useState } from "react";
import {
  Drawer,
  Form,
  Input,
  Select,
  InputNumber,
  DatePicker,
  Checkbox,
  Button,
  Divider,
  Typography,
  Space,
  Spin,
} from "antd";
import dayjs from "dayjs";
import { CloseOutlined } from "@ant-design/icons";

const { Option } = Select;
const { Title } = Typography;

const layout = {
  labelCol: { span: 24 },
  wrapperCol: { span: 24 },
};

interface Product {
  id: number;
  quickBooksItemId: string;
  name: string;
  type: string;
  unitPrice: number;
  quantityOnHand?: number;
  incomeAccountName: string;
  expenseAccountName?: string;
  assetAccountName?: string;
  active: boolean;
  syncToken: string;
  sku?: string;
  category?: string;
  description?: string;
  inventoryStartDate?: string;
  reorderPoint?: number;
  incomeAccountId?: string;
  assetAccountId?: string;
  expenseAccountId?: string;
  taxable?: boolean;
  purchaseDescription?: string;
  cost?: number;
  preferredVendor?: string;
}

interface AccountOption {
  quickBooksAccountId: string;
  name: string;
}

interface ProductAccountOptions {
  inventoryAssetAccounts: AccountOption[];
  incomeAccounts: AccountOption[];
  expenseAccounts: AccountOption[];
}

interface ProductFormDrawerProps {
  visible: boolean;
  onClose: () => void;
  type: string;
  mode: "add" | "edit";
  initialValues: Product | null;
  onSubmit: (values: any) => void;
  accountOptions: ProductAccountOptions | null;
  loading: boolean;
}

const ProductFormDrawer: React.FC<ProductFormDrawerProps> = ({
  visible,
  onClose,
  type,
  onSubmit,
  accountOptions,
  loading,
  mode,
  initialValues,
}) => {
  const [form] = Form.useForm();
  const isInventory = type?.toLowerCase() === "inventory";
  
  const [sellToCustomers, setSellToCustomers] = useState(true); 
  const [purchaseFromSupplier, setPurchaseFromSupplier] = useState(false);

  const validateAtLeastOneChecked = () => {
    if (!isInventory && !sellToCustomers && !purchaseFromSupplier) {
      return Promise.reject('At least one option must be selected');
    }
    return Promise.resolve();
  };

  const handleFinish = (values: any) => {
    if (!isInventory) {
      values.sellToCustomers = sellToCustomers;
      values.purchaseFromSupplier = purchaseFromSupplier;
    }
    onSubmit(values);
  };

  useEffect(() => {
    try {
      if (visible) {
        if (mode === "edit" && initialValues) {
          console.log("Setting form values for edit:", initialValues);

          const formattedValues = {
            ...initialValues,
            inventoryStartDate: initialValues.inventoryStartDate
              ? dayjs(initialValues.inventoryStartDate)
              : null,
          };

          form.setFieldsValue(formattedValues);
          
          // If editing a service product, check which options should be enabled
          if (!isInventory) {
            // Check if it has an income account (sells to customers)
            setSellToCustomers(!!initialValues.incomeAccountId);
            
            // Check if it has an expense account (purchases from supplier)
            setPurchaseFromSupplier(!!initialValues.expenseAccountId);
          }
        } else {
          console.log("Resetting form for add mode");
          form.resetFields();
          
          // Default for new products
          setSellToCustomers(true);
          setPurchaseFromSupplier(false);
        }
      }
    } catch (error) {
      console.error("Error setting form values:", error);
    }
  }, [form, initialValues, mode, visible, isInventory]);

  return (
    <Drawer
      title={
        <Title level={5} style={{ margin: 0 }}>
          Product/Service information
        </Title>
      }
      placement="right"
      width={480}
      onClose={onClose}
      open={visible}
      closeIcon={<CloseOutlined />}
      footer={
        <div style={{ textAlign: "right" }}>
          <Button onClick={onClose} style={{ marginRight: 8 }}>
            Cancel
          </Button>
          <Button
            type="primary"
            onClick={() => form.submit()}
            loading={loading}
            style={{ backgroundColor: "#00A551", borderColor: "#00A551" }}
          >
            {loading
              ? mode === "edit"
                ? "Updating..."
                : "Saving..."
              : "Save and Close"}
          </Button>
        </div>
      }
    >
      <Spin spinning={loading}>
        <div style={{ marginBottom: 16 }}>
          <Space>
            <b>{isInventory ? "Inventory" : "Service"}</b>
          </Space>
        </div>

        <Form {...layout} form={form} layout="vertical" onFinish={handleFinish}>
          <Form.Item
            name="name"
            label="Name"
            rules={[
              { required: true, message: "Please enter the product name" },
            ]}
          >
            <Input placeholder="" />
          </Form.Item>

          <Form.Item name="sku" label="SKU">
            <Input placeholder="" />
          </Form.Item>

          <Form.Item name="category" label="Category">
            <Select allowClear placeholder="Choose a category">
              <Option value="cat1">Category 1</Option>
              <Option value="cat2">Category 2</Option>
            </Select>
          </Form.Item>

          {/* Service type specific options */}
          {!isInventory && (
            <Form.Item
              label="How you use this service"
              required
              tooltip="At least one option must be selected"
            >
              <div style={{ marginBottom: 8 }}>
                <Checkbox 
                  checked={sellToCustomers}
                  onChange={(e) => {
                    setSellToCustomers(e.target.checked);
                    validateAtLeastOneChecked();
                  }}
                >
                  I sell this service to my customers
                </Checkbox>
              </div>
              <div>
                <Checkbox 
                  checked={purchaseFromSupplier}
                  onChange={(e) => {
                    setPurchaseFromSupplier(e.target.checked);
                    validateAtLeastOneChecked();
                  }}
                >
                  I purchase this service from a supplier
                </Checkbox>
              </div>
            </Form.Item>
          )}

          {isInventory && (
            <>
              <Form.Item
                name="quantityOnHand"
                label="Initial quantity on hand"
                rules={[{ required: true }]}
              >
                <InputNumber style={{ width: "100%" }} min={0} />
              </Form.Item>

              <Form.Item
                name="inventoryStartDate"
                label="As of date"
                rules={[{ required: true }]}
              >
                <DatePicker style={{ width: "100%" }} format="MM/DD/YYYY" />
              </Form.Item>

              <Form.Item name="reorderPoint" label="Reorder point">
                <InputNumber style={{ width: "100%" }} min={0} />
              </Form.Item>

              <Form.Item
                name="assetAccountId"
                label="Inventory asset account"
                rules={[
                  {
                    required: true,
                    message: "Please select an inventory asset account",
                  },
                ]}
              >
                <Select allowClear placeholder="Select inventory asset account">
                  {accountOptions?.inventoryAssetAccounts?.map((account) => (
                    <Option
                      key={account.quickBooksAccountId}
                      value={account.quickBooksAccountId}
                    >
                      {account.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </>
          )}

          <Divider />

          {/* Show sales-related fields for inventory OR service with sellToCustomers */}
          {(isInventory || sellToCustomers) && (
            <>
              <Form.Item name="description" label="Description">
                <Input.TextArea rows={2} placeholder="Description on sales forms" />
              </Form.Item>

              <Form.Item name="unitPrice" label="Sales price/rate">
                <InputNumber style={{ width: "100%" }} min={0} />
              </Form.Item>

              <Form.Item
                name="incomeAccountId"
                label="Income account"
                rules={[
                  { required: isInventory || sellToCustomers, message: "Please select an income account" },
                ]}
              >
                <Select allowClear placeholder="Select income account">
                  {accountOptions?.incomeAccounts?.map((account) => (
                    <Option
                      key={account.quickBooksAccountId}
                      value={account.quickBooksAccountId}
                    >
                      {account.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item name="taxable" label="Sales tax" valuePropName="checked">
                <Checkbox>Taxable – standard rate</Checkbox>
              </Form.Item>
            </>
          )}

          {/* Show purchase-related fields for inventory OR service with purchaseFromSupplier */}
          {(isInventory || purchaseFromSupplier) && (
            <>
              <Form.Item
                name="purchaseDescription"
                label="Purchasing information"
              >
                <Input.TextArea
                  rows={2}
                  placeholder="Description on purchase forms"
                />
              </Form.Item>

              <Form.Item name="cost" label="Cost">
                <InputNumber style={{ width: "100%" }} min={0} />
              </Form.Item>

              <Form.Item
                name="expenseAccountId"
                label="Expense account"
                rules={[
                  {
                    required: isInventory || purchaseFromSupplier,
                    message: "Please select an expense account",
                  },
                ]}
              >
                <Select allowClear placeholder="Select expense account">
                  {accountOptions?.expenseAccounts?.map((account) => (
                    <Option
                      key={account.quickBooksAccountId}
                      value={account.quickBooksAccountId}
                    >
                      {account.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>

              {isInventory && (
                <Form.Item
                  name="preferredVendor"
                  label="Preferred Vendor"
                >
                  <Select allowClear>
                    <Option value="vendor1">Vendor 1</Option>
                    <Option value="vendor2">Vendor 2</Option>
                  </Select>
                </Form.Item>
              )}
            </>
          )}
        </Form>
      </Spin>
    </Drawer>
  );
};

export default ProductFormDrawer;