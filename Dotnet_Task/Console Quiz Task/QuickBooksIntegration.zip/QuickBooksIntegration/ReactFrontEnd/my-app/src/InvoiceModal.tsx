import React, { useState, useEffect } from "react";
import {
  Modal,
  Form,
  Input,
  DatePicker,
  Select,
  Checkbox,
  Button,
  Space,
  Table,
  InputNumber,
  message,
  Spin,
} from "antd";
import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import dayjs from "dayjs";
import axios from "axios";

interface Customer {
  quickBooksCustomerId: number;
  displayName: string;
  realmId: number;
}
interface Product {
  id: number;
  quickBooksItemId: string;
  name: string;
}
interface InvoiceItem {
  description: string;
  quickBooksItemId: string;
  key: string;
//   quick: number;
  productName: string;
  quantity: number;
  rate: number;
  amount: number;
}

interface CustomerDetails {
  id: number;
  email?: string;
  billingAddress?: string;
}

interface InvoiceModalProps {
  visible: boolean;
  onCancel: () => void;
  onSave: (invoiceData: any) => void;
  invoice?: any;
  mode: "add" | "edit";
  customers: Customer[];
}

const InvoiceModal: React.FC<InvoiceModalProps> = ({
  visible,
  onCancel,
  onSave,
  invoice = null,
  mode = "add",
  customers = [],
}) => {
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState<InvoiceItem[]>([
    {
      key: "1",
    //   productId: 0,
      quickBooksItemId: "",
      description: "",
      productName: "",
      quantity: 0,
      rate: 0,
      amount: 0,
    },
    {
      key: "2",
    //   productId: 0,
      quickBooksItemId: "",
      description: "",
      productName: "",
      quantity: 0,
      rate: 0,
      amount: 0,
    },
  ]);
  const [products, setProducts] = useState<any[]>([]); // State to hold products
  const [loading, setLoading] = useState<boolean>(false); // State for loading spinner
  const [subtotal, setSubtotal] = useState<number>(0);
  const [loadingCustomerDetails, setLoadingCustomerDetails] =
    useState<boolean>(false);
  const [productsLoaded, setProductsLoaded] = useState<boolean>(false);

  const today = dayjs();

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/invoice/active-products`
      );
      setProducts(response.data);
      setProductsLoaded(true); // Mark products as loaded
    } catch (error) {
      console.error("Failed to fetch products", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts(); // Fetch products on mount
  }, []);

  useEffect(() => {
    // Debug log to check what invoice data we're receiving
    console.log("Modal received invoice data:", invoice);
    console.log("Current mode:", mode);
  }, [invoice, mode]);

  useEffect(() => {
    if (mode === "edit" && invoice) {
      console.log("Attempting to populate form with invoice data:", invoice);
  
      // Populate form with invoice data
      form.setFieldsValue({
        customer:
          invoice.customerId || invoice.customer_id || invoice.CustomerId,
        customerEmail: invoice.customerEmail || invoice.email,
        billingAddress:
          invoice.billingAddress ||
          invoice.billing_address ||
          invoice.BillingAddress,
        invoiceDate: invoice.date ? dayjs(invoice.date) : today,
        dueDate: invoice.dueDate ? dayjs(invoice.dueDate) : today,
        store: invoice.store || "mainStore",
        message: invoice.message,
      });
  
      // Check if there's line item data
      if (invoice.Line && Array.isArray(invoice.Line)) {
        console.log("Found Line items:", invoice.Line);
  
        // Process line items
        const formattedItems = invoice.Line.map((item, index) => ({
          key: (index + 1).toString(),
          // Map ProductId to quickBooksItemId
          quickBooksItemId: item.ItemRef?.value || item.ProductId || 0,  // Fix: Mapping ProductId to quickBooksItemId
          productName: item.ProductName || "",
          description: item.Description || "",
          quantity: item.Quantity || 0,
          rate: item.UnitPrice || 0,
          amount: item.Amount || 0,
        }));
  
        setDataSource(formattedItems);
      } else if (invoice.items && Array.isArray(invoice.items)) {
        // Alternative property name for line items
        console.log("Found items array:", invoice.items);
  
        const formattedItems = invoice.items.map((item, index) => ({
          key: (index + 1).toString(),
          // Correctly use quickBooksItemId
          quickBooksItemId: item.quickBooksItemId || item.productId || 0,  // Fix: Ensure proper mapping
          productName: item.productName || item.name || "",
          description: item.description || "",
          quantity: item.quantity || 0,
          rate: item.rate || item.unitPrice || 0,
          amount: item.amount || 0,
        }));
  
        setDataSource(formattedItems);
      } else {
        console.warn("No line items found in invoice data");
      }
  
      // Calculate subtotal after populating form
      setTimeout(() => calculateSubtotal(), 0);
    } else {
      // Reset form for new invoice
      form.resetFields();
      form.setFieldsValue({
        invoiceDate: today,
        dueDate: today,
      });
  
      setDataSource([
        {
          key: "1",
          quickBooksItemId: "", // Use quickBooksItemId here
          productName: "",
          description: "",
          quantity: 0,
          rate: 0,
          amount: 0,
        },
        {
          key: "2",
          quickBooksItemId: "", // Use quickBooksItemId here
          productName: "",
          description: "",
          quantity: 0,
          rate: 0,
          amount: 0,
        },
      ]);
    }
  }, [invoice, mode, form]);
  

  const handleCustomerChange = async (customerId: number) => {
    console.log("Customer changed:", customerId);
    if (!customerId) return;

    setLoadingCustomerDetails(true);
    try {
      const response = await axios.get(
        `${
          import.meta.env.VITE_API_BASE_URL
        }/api/invoice/customer-details/${customerId}`
      );
      const customerDetails = response.data;

      form.setFieldsValue({
        customerEmail: customerDetails.email || "",
        billingAddress: customerDetails.billingAddress || "",
      });
    } catch (error) {
      console.error("Error fetching customer details:", error);
      message.error("Failed to fetch customer details");
    } finally {
      setLoadingCustomerDetails(false);
    }
  };

  const handleFormSubmit = () => {
    form
      .validateFields()
      .then((values) => {
        const selectedCustomerId = values.customer;
        const selectedCustomer = customers.find(
          (c) => c.quickBooksCustomerId === selectedCustomerId
        );
  
        if (!selectedCustomer) {
          console.error("Customer not found");
          return;
        }
  
        const lineItems = dataSource.map((item) => ({
          QuickBooksItemId: String(item.quickBooksItemId),
          ProductName: item.productName,
          Description: item.description || "",
          Qty: item.quantity,
          Rate: item.rate,
          Amount: item.amount
        }));
  
        // Create invoice data with the structure matching InvoiceRequestDto
        const invoiceData = {
          CustomerId: selectedCustomerId.toString(),
          InvoiceDate: values.invoiceDate.toISOString(),
          DueDate: values.dueDate?.toISOString(),
          Store: values.store || "mainStore",
          BillingAddress: values.billingAddress,
          Subtotal: subtotal,
          Total: subtotal,
          RealmId: selectedCustomer?.realmId?.toString(),
          Line: lineItems
        };
  
        // Add quickBooksInvoiceId if in edit mode
        if (mode === "edit" && invoice && invoice.quickBooksInvoiceId) {
          invoiceData.QuickBooksInvoiceId = invoice.quickBooksInvoiceId;
        }
  
        console.log("Invoice data to send:", invoiceData);
        onSave(invoiceData);
      })
      .catch((info) => {
        console.log("Validate Failed:", info);
      });
  };
  
  const addRow = () => {
    const newKey = (dataSource.length + 1).toString();
    setDataSource([
      ...dataSource,
      {
        key: newKey,
        productId: 0,
        productName: "",
        quickBooksItemId: "", // 👈 Add this
        description: "",
        quantity: 0,
        rate: 0,
        amount: 0,
      },
    ]);
  };
  
  const handleClearAllLines = () => {
    setDataSource([]);
    setSubtotal(0);
  };

  const handleDelete = (key: string) => {
    const newData = dataSource.filter((item) => item.key !== key);
    setDataSource(newData);
    calculateSubtotal();
  };

  const calculateAmount = (record: InvoiceItem) => {
    return record.quantity * record.rate;
  };

  const calculateSubtotal = () => {
    const total = dataSource.reduce(
      (sum, item) => sum + calculateAmount(item),
      0
    );
    setSubtotal(total);
    return total;
  };

  const handleQuantityChange = (value: number | null, record: InvoiceItem) => {
    const newData = [...dataSource];
    const index = newData.findIndex((item) => item.key === record.key);
    newData[index].quantity = value || 0;
    newData[index].amount = newData[index].quantity * newData[index].rate;
    setDataSource(newData);
    calculateSubtotal();
  };

  const handleRateChange = (value: number | null, record: InvoiceItem) => {
    const newData = [...dataSource];
    const index = newData.findIndex((item) => item.key === record.key);
    newData[index].rate = value || 0;
    newData[index].amount = newData[index].quantity * newData[index].rate;
    setDataSource(newData);
    calculateSubtotal();
  };

  const handleProductChange = (value: string, record: InvoiceItem) => {
    const newData = [...dataSource];
    const index = newData.findIndex((item) => item.key === record.key);
    const selectedProduct = products.find((product) => product.name === value);
  
    if (selectedProduct) {
      newData[index].productId = selectedProduct.id;
      newData[index].productName = selectedProduct.name;
      newData[index].quickBooksItemId = selectedProduct.quickBooksItemId; 
      newData[index].rate = selectedProduct.rate || 0;
      newData[index].amount = newData[index].quantity * newData[index].rate;
    }
  
    setDataSource(newData);
    calculateSubtotal();
  };

  const handleDescriptionChange = (value: string, record: InvoiceItem) => {
    const newData = [...dataSource];
    const index = newData.findIndex((item) => item.key === record.key);
    newData[index].description = value;
    setDataSource(newData);
  };

  const columns: ColumnsType<InvoiceItem> = [
    {
      title: "#",
      dataIndex: "key",
      key: "key",
      width: 50,
    },
    {
      title: "PRODUCT/SERVICE",
      dataIndex: "productName",
      key: "productName",
      render: (text: string, record: any) => (
        <Select
          placeholder="Select a product"
          value={record.productName || undefined} // Ensure undefined if empty string
          onChange={(value) => handleProductChange(value, record)}
          loading={loading}
          style={{ width: "100%" }}
        >
          {loading ? (
            <Option value="loading">
              <Spin size="small" />
            </Option>
          ) : (
            products.map((product: any) => (
              <Option key={product.id} value={product.name}>
                {product.name}
              </Option>
            ))
          )}
        </Select>
      ),
    },
    {
      title: "DESCRIPTION",
      dataIndex: "description",
      key: "description",
      render: (text, record) => (
        <Input
          placeholder="Enter description"
          value={record.description}
          onChange={(e) => handleDescriptionChange(e.target.value, record)}
        />
      ),
    },
    {
      title: "QTY",
      dataIndex: "quantity",
      key: "quantity",
      width: 80,
      render: (text, record) => (
        <InputNumber
          min={0}
          value={record.quantity}
          onChange={(value) => handleQuantityChange(value, record)}
        />
      ),
    },
    {
      title: "RATE",
      dataIndex: "rate",
      key: "rate",
      width: 100,
      render: (text, record) => (
        <InputNumber
          min={0}
          value={record.rate}
          onChange={(value) => handleRateChange(value, record)}
          formatter={(value) =>
            `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
          }
          parser={(value) => value!.replace(/\$\s?|(,*)/g, "")}
        />
      ),
    },
    {
      title: "AMOUNT (USD)",
      dataIndex: "amount",
      key: "amount",
      width: 150,
      render: (_, record) => <span>${calculateAmount(record).toFixed(2)}</span>,
    },
    {
      key: "action",
      width: 50,
      render: (_, record) => (
        <Button
          icon={<DeleteOutlined />}
          type="text"
          onClick={() => handleDelete(record.key)}
        />
      ),
    },
  ];

  return (
    <Modal
      title={mode === "add" ? "Create Invoice" : "Edit Invoice"}
      open={visible}
      onCancel={onCancel}
      width={1000}
      footer={[
        <Button key="back" onClick={onCancel}>
          Cancel
        </Button>,
        <Button key="submit" type="primary" onClick={handleFormSubmit}>
          {mode === "add" ? "Save Invoice" : "Update Invoice"}
        </Button>,
      ]}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          invoiceDate: today,
          dueDate: today,
          store: "mainStore",
        }}
      >
        <div style={{ display: "flex", gap: "20px", marginBottom: "20px" }}>
          <Form.Item label="Customer" name="customer" style={{ flex: 1 }}>
            <Select
              placeholder="Select a customer"
              onChange={handleCustomerChange}
              loading={loadingCustomerDetails}
              showSearch
              optionFilterProp="children"
            >
              {customers.map((customer) => (
                <Select.Option
                  key={customer.quickBooksCustomerId || customer.id}
                  value={customer.quickBooksCustomerId || customer.id}
                >
                  {customer.displayName || customer.name}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item
            label="Customer email"
            name="customerEmail"
            style={{ flex: 1 }}
          >
            <Input placeholder="Separate emails with a comma" />
          </Form.Item>
          <Form.Item label="Cc/Bcc" style={{ flex: 0.3 }}>
            <a>Cc/Bcc</a>
          </Form.Item>
        </div>

        <Form.Item name="sendLater" valuePropName="checked">
          <Checkbox>Send later</Checkbox>
        </Form.Item>

        <div style={{ display: "flex", gap: "20px", marginBottom: "20px" }}>
          <Form.Item
            label="Billing address"
            name="billingAddress"
            style={{ flex: 1 }}
          >
            <Input.TextArea rows={4} />
          </Form.Item>

          <div
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              gap: "10px",
            }}
          >
            <div style={{ display: "flex", gap: "10px" }}>
              <Form.Item
                label="Invoice date"
                name="invoiceDate"
                style={{ flex: 1 }}
              >
                <DatePicker style={{ width: "100%" }} />
              </Form.Item>
              <Form.Item label="Due date" name="dueDate" style={{ flex: 1 }}>
                <DatePicker style={{ width: "100%" }} />
              </Form.Item>
            </div>
            <Form.Item label="Store" name="store">
              <Select>
                <Select.Option value="mainStore">Main Store</Select.Option>
                <Select.Option value="branch1">Branch 1</Select.Option>
              </Select>
            </Form.Item>
          </div>
        </div>

        <Form.Item>
          <Button type="link" icon={<PlusOutlined />}>
            Shipping information
          </Button>
        </Form.Item>

        <Table
          dataSource={dataSource}
          columns={columns}
          pagination={false}
          bordered
          rowKey="key"
        />

        <div style={{ marginTop: "16px", display: "flex", gap: "10px" }}>
          <Button onClick={addRow}>Add lines</Button>
          <Button onClick={handleClearAllLines}>Clear all lines</Button>
          <Button>Add subtotal</Button>
        </div>

        <Form.Item
          label="Message on invoice"
          name="message"
          style={{ marginTop: "16px" }}
        >
          <Input.TextArea rows={2} />
        </Form.Item>

        <div
          style={{
            display: "flex",
            justifyContent: "flex-end",
            marginTop: "16px",
          }}
        >
          <div style={{ textAlign: "right" }}>
            <p>
              <span style={{ marginRight: "20px" }}>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </p>
            <p>
              <span style={{ marginRight: "20px" }}>Taxable subtotal</span>
              <span>$0.00</span>
            </p>
          </div>
        </div>
      </Form>
    </Modal>
  );
};

export default InvoiceModal;
