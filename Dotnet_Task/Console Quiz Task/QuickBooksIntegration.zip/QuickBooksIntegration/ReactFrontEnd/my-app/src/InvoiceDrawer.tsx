import React, { useState, useEffect } from 'react';
import {
  Drawer,
  Form,
  Input,
  DatePicker,
  Button,
  Space,
  Select,
  Checkbox,
  Table,
  InputNumber,
  Row,
  Col,
  message,
  Divider,
  Typography,
  Spin,
  Radio
} from 'antd';
import {
  PlusOutlined,
  DeleteOutlined,
  SaveOutlined,
  CloseOutlined
} from '@ant-design/icons';
import dayjs from 'dayjs';

const { Option } = Select;
const { TextArea } = Input;
const { Title } = Typography;

interface InvoiceLineItem {
  lineId?: string;
  invoiceId?: number;
  productId: string | number;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

interface Invoice {
  id?: number;
  invoiceId?: number;
  customerId: number | string; // Modified to accept string for Xero
  customerEmail?: string;
  invoiceDate: string;
  dueDate: string;
  store: string;
  billingAddress: string;
  subtotal?: number;
  total?: number;
  sendLater: boolean;
  createdAt?: string;
  updatedAt?: string;
  lineItems: InvoiceLineItem[];
  source?: string; // Added to track invoice source (QuickBooks or Xero)
  externalId?: string; // Added to store external ID from Xero/QuickBooks
}

interface CustomerOption {
  value: number | string;
  label: string;
  email?: string;
  billingAddress?: string;
  source?: string; // Added to track customer source
}

interface ProductOption {
  value: number | string;
  label: string;
  price: number;
  source?: string; // Added to track product source
}

interface Props {
  visible: boolean;
  onClose: () => void;
  onSubmit: (invoice: any) => void;
  invoice: Invoice | null;
  token?: string;
  dataSource?: string; // Added to specify data source - 'quickbooks' or 'xero'
}

// Store options - can be fetched from API if needed
const storeOptions = [
  { value: 'Main Store', label: 'Main Store' },
  { value: 'Downtown Branch', label: 'Downtown Branch' },
  { value: 'Online Store', label: 'Online Store' }
];

const InvoiceDrawer: React.FC<Props> = ({ visible, onClose, onSubmit, invoice, token, dataSource = 'quickbooks' }) => {
  const [form] = Form.useForm();
  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>([]);
  const [subtotal, setSubtotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [customers, setCustomers] = useState<CustomerOption[]>([]);
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [loadingCustomers, setLoadingCustomers] = useState<boolean>(false);
  const [loadingProducts, setLoadingProducts] = useState<boolean>(false);
  const [activeSource, setActiveSource] = useState<string>(dataSource);

  // Fetch customers and products when drawer becomes visible
  useEffect(() => {
    if (visible) {
      fetchCustomers();
      fetchProducts();
    }
  }, [visible, activeSource]);

  // Fetch customers based on active source
  const fetchCustomers = async () => {
    setLoadingCustomers(true);
    try {
      if (activeSource === 'quickbooks') {
        await fetchQuickBooksCustomers();
      } else if (activeSource === 'xero') {
        await fetchXeroCustomers();
      }
    } catch (error) {
      console.error('Error fetching customers:', error);
      message.error('Failed to load customers');
    } finally {
      setLoadingCustomers(false);
    }
  };

  // Fetch QuickBooks customers
  const fetchQuickBooksCustomers = async () => {
    const realmId = localStorage.getItem('qb_realm_id');
    if (!realmId) {
      message.error('QuickBooks RealmID is required');
      return;
    }

    const response = await fetch(
      `${import.meta.env.VITE_API_BASE_URL}/api/customer/fetch-customer-from-db-paginated?page=1&pageSize=100`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'realmId': realmId
        }
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    // Transform the data to format required by Select component
    const customerOptions = data.data ? data.data.map((customer: any) => ({
      value: customer.id,
      label: customer.displayName || customer.companyName || `Customer ${customer.id}`,
      email: customer.email || '',
      billingAddress: `${customer.billingStreet1 || ''}\n${customer.city || ''}, ${customer.state || ''} ${customer.zipCode || ''}\n${customer.country || ''}`.trim(),
      source: 'quickbooks'
    })) : [];
    
    setCustomers(customerOptions);
  };

  // Fetch Xero customers - FIXED to properly handle Xero contact IDs
  const fetchXeroCustomers = async () => {
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/xerocontacts/fetch`, {
        method: 'GET',
      });

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      const data = await res.json();
      
   
      // Using xeroContactId as the value for Xero contacts
      const customerOptions = data.data ? data.data.map((contact: any) => ({
        value: contact.xeroContactId || contact.id, // Use xeroContactId from response
        label: contact.displayName || contact.companyName || `Contact ${contact.id}`,
        email: contact.email || '',
        billingAddress: constructBillingAddress(contact),
        source: 'xero'
      })) : [];
      
      setCustomers(customerOptions);
    } catch (error) {
      console.error('Error fetching Xero contacts:', error);
      throw error;
    }
  };

  // Helper function to construct billing address from contact data
  const constructBillingAddress = (contact: any) => {
    const lines = [];
    if (contact.billingLine1) lines.push(contact.billingLine1);
    
    const cityStateZip = [
      contact.billingCity, 
      contact.billingState, 
      contact.billingPostalCode
    ].filter(Boolean).join(', ');
    
    if (cityStateZip) lines.push(cityStateZip);
    if (contact.billingCountry) lines.push(contact.billingCountry);
    
    return lines.join('\n');
  };

  // Fetch products based on active source
  const fetchProducts = async () => {
    setLoadingProducts(true);
    try {
      if (activeSource === 'quickbooks') {
        await fetchQuickBooksProducts();
      } else if (activeSource === 'xero') {
        await fetchXeroProducts();
      }
    } catch (error) {
      console.error('Error fetching products:', error);
      message.error('Failed to load products');
    } finally {
      setLoadingProducts(false);
    }
  };

  // Fetch QuickBooks products
  const fetchQuickBooksProducts = async () => {
    try {
      const realmId = localStorage.getItem('qb_realm_id');
      if (!realmId) {
        message.error('QuickBooks RealmID is required');
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/get-all?pageNumber=1&pageSize=100`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'realmId': realmId
          }
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      // Transform the data to format required by Select component
      const productOptions = Array.isArray(data.data?.data)
        ? data.data.data.map((product: any) => ({
            value: product.id,
            label: product.name || `Product ${product.id}`,
            price: product.unitPrice || 0,
            source: 'quickbooks'
          }))
        : [];
      
      setProducts(productOptions);
    } catch (error) {
      console.error('Error fetching QuickBooks products:', error);
      throw error;
    }
  };

  // Fetch Xero products - FIXED to properly handle Xero product IDs
  const fetchXeroProducts = async () => {
    try {
      const tenantId = localStorage.getItem('xero_tenant_id');
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/products?tenantId=${tenantId}`
      );

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      const data = await res.json();
      
      // Transform Xero products to the format required by Select component
      // Using xeroItemId as the value for Xero products
      const productOptions = data.data ? data.data.map((product: any) => ({
        value: product.xeroItemId || product.id, // Use xeroItemId
        label: product.name || product.description || `Product ${product.id}`,
        price: product.unitPrice || 0,
        source: 'xero'
      })) : [];
      
      setProducts(productOptions);
    } catch (error) {
      console.error('Error fetching Xero products:', error);
      throw error;
    }
  };

  // Set form values when invoice is provided (for editing)
  useEffect(() => {
    if (invoice) {
      // Set the active source based on the invoice source
      if (invoice.source) {
        setActiveSource(invoice.source.toLowerCase());
      }

      form.setFieldsValue({
        customerId: invoice.customerId,
        customerEmail: invoice.customerEmail || '',
        invoiceDate: invoice.invoiceDate ? dayjs(invoice.invoiceDate) : dayjs(),
        dueDate: invoice.dueDate ? dayjs(invoice.dueDate) : dayjs().add(30, 'day'),
        store: invoice.store,
        billingAddress: invoice.billingAddress,
        sendLater: invoice.sendLater,
        source: invoice.source?.toLowerCase() || activeSource,
      });
      
      setLineItems(invoice.lineItems || []);
      calculateSubtotal(invoice.lineItems || []);
    } else {
      resetForm();
    }
  }, [invoice, visible]);

  // Reset form to initial state
  const resetForm = () => {
    form.resetFields();
    form.setFieldsValue({
      invoiceDate: dayjs(),
      dueDate: dayjs().add(30, 'day'),
      store: 'Main Store',
      sendLater: false,
      source: activeSource,
    });
    setLineItems([]);
    setSubtotal(0);
  };

  // Handle data source change
  const handleSourceChange = (e: any) => {
    const newSource = e.target.value;
    setActiveSource(newSource);
    form.setFieldsValue({ source: newSource });
    
    // Reset customer and product selection when changing source
    form.setFieldsValue({ customerId: undefined });
    setLineItems([]);
    setSubtotal(0);
  };

  // Add an empty line item to the list
  const addLineItem = () => {
    const newLineItem: InvoiceLineItem = {
      productId: '',
      description: '',
      quantity: 1,
      rate: 0,
      amount: 0
    };
    
    const updatedItems = [...lineItems, newLineItem];
    setLineItems(updatedItems);
  };

  // Remove a line item by index
  const removeLineItem = (index: number) => {
    const updatedItems = [...lineItems];
    updatedItems.splice(index, 1);
    setLineItems(updatedItems);
    calculateSubtotal(updatedItems);
  };

  // Update a line item at the specified index
  const updateLineItem = (index: number, field: keyof InvoiceLineItem, value: any) => {
    const updatedItems = [...lineItems];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    
    // If productId changes, update description and rate if product exists
    if (field === 'productId') {
      const selectedProduct = products.find(p => p.value === value);
      if (selectedProduct) {
        updatedItems[index].description = selectedProduct.label;
        updatedItems[index].rate = selectedProduct.price;
        updatedItems[index].amount = updatedItems[index].quantity * selectedProduct.price;
      }
    }
    
    // Calculate amount when quantity or rate changes
    if (field === 'quantity' || field === 'rate') {
      const quantity = field === 'quantity' ? value : updatedItems[index].quantity;
      const rate = field === 'rate' ? value : updatedItems[index].rate;
      updatedItems[index].amount = quantity * rate;
    }
    
    setLineItems(updatedItems);
    calculateSubtotal(updatedItems);
  };

  // Calculate the subtotal based on line items
  const calculateSubtotal = (items: InvoiceLineItem[]) => {
    const total = items.reduce((sum, item) => sum + (item.amount || 0), 0);
    setSubtotal(total);
  };

  // Handle customer selection to auto-fill email and billing address
  const handleCustomerChange = (value: number | string) => {
    const selectedCustomer = customers.find(c => c.value === value);
    if (selectedCustomer) {
      form.setFieldsValue({
        customerEmail: selectedCustomer.email || '',
        billingAddress: selectedCustomer.billingAddress || ''
      });
    }
  };

  // Handle form submission
  const handleSubmit = async () => {
    try {
      await form.validateFields();
      
      if (lineItems.length === 0) {
        message.error('Please add at least one line item');
        return;
      }
      
      setLoading(true);
      
      const values = form.getFieldsValue();
      
      // Format line items properly based on source
      const formattedLineItems = lineItems.map(item => ({
        productId: String(item.productId), // Ensure productId is a string
        description: item.description,
        quantity: item.quantity,
        rate: item.rate,
        amount: item.amount
      }));
      
     let invoiceData;
    
    if (values.source === 'quickbooks') {
      invoiceData = {
        id: invoice?.id,
        customerId: Number(values.customerId), // Ensure customerId is a number for QuickBooks
        customerEmail: values.customerEmail,
        invoiceDate: values.invoiceDate.toISOString(),
        dueDate: values.dueDate.toISOString(),
        store: values.store,
        billingAddress: values.billingAddress,
        sendLater: values.sendLater,
        subtotal: subtotal,
        total: subtotal,
        lineItems: formattedLineItems,
        source: 'QuickBooks'
      };
    } else if (values.source === 'xero') {
      invoiceData = {
        id: invoice?.id,
        externalId: invoice?.externalId,
        customerId: String(values.customerId), // Ensure customerId is a string for Xero
        customerEmail: values.customerEmail,
        invoiceDate: values.invoiceDate.toISOString(),
        dueDate: values.dueDate.toISOString(),
        store: values.store,
        billingAddress: values.billingAddress,
        sendLater: values.sendLater,
        subtotal: subtotal,
        total: subtotal,
        lineItems: formattedLineItems,
        source: 'Xero'
      };
    }
    
    // Wrap the invoice data in an invoiceInput object as required by the API
    const payload = {
      invoiceInput: invoiceData
    };
    
    onSubmit(payload);
  } catch (error) {
    message.error('Please check the form fields');
    console.error('Form validation error:', error);
  } finally {
    setLoading(false);
  }
};

  // Line item table columns
  const lineItemColumns = [
    {
      title: '#',
      key: 'index',
      width: '50px',
      render: (_: any, __: any, index: number) => index + 1,
    },
    {
      title: 'Product/Service',
      dataIndex: 'productId',
      key: 'productId',
      width: '200px',
      render: (productId: string | number, _: any, index: number) => (
        <Select
          value={productId || undefined}
          placeholder="Select product"
          style={{ width: '100%' }}
          onChange={(value) => updateLineItem(index, 'productId', value)}
          loading={loadingProducts}
          showSearch
          filterOption={(input, option) =>
            (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
          }
        >
          {products.filter(product => 
            // Only show products from the active source
            product.source === activeSource
          ).map(product => (
            <Option key={product.value} value={product.value}>
              {product.label}
            </Option>
          ))}
        </Select>
      ),
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
      width: '300px',
      render: (text: string, _: any, index: number) => (
        <Input
          value={text}
          placeholder="Description"
          onChange={(e) => updateLineItem(index, 'description', e.target.value)}
        />
      ),
    },
    {
      title: 'Qty',
      dataIndex: 'quantity',
      key: 'quantity',
      width: '100px',
      render: (value: number, _: any, index: number) => (
        <InputNumber
          min={1}
          value={value}
          style={{ width: '100%' }}
          onChange={(value) => updateLineItem(index, 'quantity', value)}
        />
      ),
    },
    {
      title: 'Rate',
      dataIndex: 'rate',
      key: 'rate',
      width: '120px',
      render: (value: number, _: any, index: number) => (
        <InputNumber
          min={0}
          step={0.01}
          precision={2}
          value={value}
          style={{ width: '100%' }}
          formatter={(value) => `$ ${value}`}
          parser={(value) => parseFloat((value || '').replace(/\$\s?/g, ''))}
          onChange={(value) => updateLineItem(index, 'rate', value)}
        />
      ),
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      width: '120px',
      render: (value: number) => `$ ${(value || 0).toFixed(2)}`,
    },
    {
      title: '',
      key: 'action',
      width: '50px',
      render: (_: any, __: any, index: number) => (
        <Button
          type="text"
          danger
          icon={<DeleteOutlined />}
          onClick={() => removeLineItem(index)}
        />
      ),
    },
  ];

  return (
    <Drawer
      title={invoice ? `Edit Invoice #${invoice.invoiceId}` : "Create New Invoice"}
      placement="top"
      height="100vh"
      onClose={onClose}
      open={visible}
      extra={
        <Space>
          <Button onClick={onClose} icon={<CloseOutlined />}>
            Cancel
          </Button>
          <Button
            type="primary"
            onClick={handleSubmit}
            loading={loading}
            icon={<SaveOutlined />}
          >
            Save
          </Button>
        </Space>
      }
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          invoiceDate: dayjs(),
          dueDate: dayjs().add(30, 'day'),
          store: 'Main Store',
          sendLater: false,
          source: activeSource,
        }}
      >
        <Row gutter={24}>
          <Col span={8}>
            <Form.Item
              name="source"
              label="Data Source"
            >
              <Radio.Group onChange={handleSourceChange} value={activeSource}>
                <Radio.Button value="quickbooks">QuickBooks</Radio.Button>
                <Radio.Button value="xero">Xero</Radio.Button>
              </Radio.Group>
            </Form.Item>
          </Col>
        </Row>
        
        <Row gutter={24}>
          <Col span={8}>
            <Form.Item
              name="customerId"
              label="Customer"
              rules={[{ required: true, message: 'Please select a customer' }]}
            >
            <Select
  placeholder={loadingCustomers ? "Loading customers..." : "Select customer"}
  showSearch
  loading={loadingCustomers}
  onChange={handleCustomerChange}
  filterOption={(input, option) =>
    (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
  }
  notFoundContent={loadingCustomers ? <Spin size="small" /> : null}
>
  {customers.filter(customer => 
    // Only show customers from the active source
    customer.source === activeSource
  ).map(customer => (
    <Option key={customer.value} value={customer.value}>
      {customer.label}
    </Option>
  ))}
</Select>
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="customerEmail"
              label="Customer Email"
            >
              <Input placeholder="customer@example.com" />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item name="sendLater" valuePropName="checked">
              <Checkbox>Send Later</Checkbox>
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={24}>
          <Col span={8}>
            <Form.Item
              name="invoiceDate"
              label="Invoice Date"
              rules={[{ required: true, message: 'Please select invoice date' }]}
            >
              <DatePicker style={{ width: '100%' }} />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="dueDate"
              label="Due Date"
              rules={[{ required: true, message: 'Please select due date' }]}
            >
              <DatePicker style={{ width: '100%' }} />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="store"
              label="Store"
              rules={[{ required: true, message: 'Please select a store' }]}
            >
              <Select placeholder="Select store">
                {storeOptions.map(option => (
                  <Option key={option.value} value={option.value}>
                    {option.label}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
        </Row>

        <Form.Item
          name="billingAddress"
          label="Billing Address"
          rules={[{ required: true, message: 'Please enter billing address' }]}
        >
          <TextArea rows={3} placeholder="Enter billing address" />
        </Form.Item>

        <Divider orientation="left">Line Items</Divider>

        <Table
          dataSource={lineItems}
          columns={lineItemColumns}
          pagination={false}
          rowKey={(_, index) => `line-item-${index}`}
          size="small"
          scroll={{ x: 'max-content' }}
          footer={() => (
            <Row justify="space-between">
              <Button
                type="dashed"
                onClick={addLineItem}
                icon={<PlusOutlined />}
              >
                Add Line Item
              </Button>
              <div>
                <span style={{ marginRight: 8 }}>Subtotal:</span>
                <span style={{ fontWeight: 'bold' }}>${subtotal.toFixed(2)}</span>
              </div>
            </Row>
          )}
        />
      </Form>
    </Drawer>
  );
};

export default InvoiceDrawer;