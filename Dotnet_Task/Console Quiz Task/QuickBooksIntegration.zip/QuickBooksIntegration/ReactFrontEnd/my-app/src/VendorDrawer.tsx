import React, { useEffect } from 'react';
import { Drawer, Form, Input, Button, Space, Checkbox, Select, Divider, message } from 'antd';
import { SaveOutlined, CloseOutlined } from '@ant-design/icons';

interface VendorFormData {
  displayName: string;
  givenName?: string;
  familyName?: string;
  companyName?: string;
  email?: string;
  phone?: string;
  webAddr?: string;
  billingLine1?: string;
  billingCity?: string;
  billingState?: string;
  billingPostalCode?: string;
  billingCountry?: string;
  vendor1099: boolean;
  currencyValue: string;
}

interface Vendor extends VendorFormData {
  id: number;
  active: boolean;
  balance: number;
  currencyName: string;
}

interface VendorDrawerProps {
  visible: boolean;
  vendor: Vendor | null;
  onClose: (refreshData?: boolean) => void;
}

const { Option } = Select;

const VendorDrawer: React.FC<VendorDrawerProps> = ({ visible, vendor, onClose }) => {
  const [form] = Form.useForm<VendorFormData>();
  const isNewVendor = !vendor;

  const currencies = [
    { value: 'USD', label: 'US Dollar' },
    { value: 'EUR', label: 'Euro' },
    { value: 'GBP', label: 'British Pound' },
    { value: 'CAD', label: 'Canadian Dollar' },
    { value: 'AUD', label: 'Australian Dollar' },
    { value: 'JPY', label: 'Japanese Yen' },
  ];

  // Get authentication credentials
  const getAuthCredentials = () => {
    const token = localStorage.getItem('qb_access_token');
    const realmId = localStorage.getItem('qb_realm_id');
    
    if (!token || !realmId) {
      message.error('QuickBooks authentication required');
      return null;
    }
    
    return { token, realmId };
  };

  // Reset form when drawer opens/closes
  useEffect(() => {
    if (visible) {
      if (vendor) {
        form.setFieldsValue({
          displayName: vendor.displayName,
          givenName: vendor.givenName,
          familyName: vendor.familyName,
          companyName: vendor.companyName,
          email: vendor.email,
          phone: vendor.phone,
          webAddr: vendor.webAddr,
          billingLine1: vendor.billingLine1,
          billingCity: vendor.billingCity,
          billingState: vendor.billingState,
          billingPostalCode: vendor.billingPostalCode,
          billingCountry: vendor.billingCountry,
          vendor1099: vendor.vendor1099,
          currencyValue: vendor.currencyValue || 'USD',
        });
      } else {
        form.resetFields();
        form.setFieldsValue({
          vendor1099: false,
          currencyValue: 'USD',
        });
      }
    }
  }, [visible, vendor, form]);

  // Handle form submission
  const handleSubmit = async () => {
    const auth = getAuthCredentials();
    if (!auth) return;
    
    try {
      const values = await form.validateFields();
      
      const apiUrl = isNewVendor 
        ? `${import.meta.env.VITE_API_BASE_URL}/api/Vendor?realmId=${auth.realmId}` 
        : `${import.meta.env.VITE_API_BASE_URL}/api/Vendor/${vendor!.id}?realmId=${auth.realmId}`;
      
      const method = isNewVendor ? 'POST' : 'PUT';
      
      const response = await fetch(apiUrl, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.token}`
        },
        body: JSON.stringify(values),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      message.success(`Vendor successfully ${isNewVendor ? 'created' : 'updated'}`);
      onClose(true); // Close drawer and refresh data
      
    } catch (error) {
      console.error('Error saving vendor:', error);
      message.error(`Failed to ${isNewVendor ? 'create' : 'update'} vendor`);
    }
  };

  return (
    <Drawer
      title={isNewVendor ? 'Create New Vendor' : 'Edit Vendor'}
      width={600}
      onClose={() => onClose()}
      open={visible}
      extra={
        <Space>
          <Button onClick={() => onClose()} icon={<CloseOutlined />}>
            Cancel
          </Button>
          <Button 
            type="primary" 
            onClick={handleSubmit} 
            icon={<SaveOutlined />}
          >
            Save
          </Button>
        </Space>
      }
    >
      <Form
        form={form}
        layout="vertical"
        requiredMark="optional"
      >
        <Divider orientation="left">Basic Information</Divider>
        
        <Form.Item
          name="displayName"
          label="Display Name"
          rules={[{ required: true, message: 'Please enter the display name' }]}
        >
          <Input placeholder="Display Name (required)" />
        </Form.Item>
        
        <Form.Item 
          name="givenName" 
          label="First Name" 
          rules={[{ required: isNewVendor, message: 'Please enter the first name' }]}
        >
          <Input placeholder="First Name" />
        </Form.Item>
        
        <Form.Item 
          name="familyName" 
          label="Last Name"
          rules={[{ required: isNewVendor, message: 'Please enter the last name' }]}
        >
          <Input placeholder="Last Name" />
        </Form.Item>
        
        <Form.Item name="companyName" label="Company Name">
          <Input placeholder="Company Name" />
        </Form.Item>
        
        <Form.Item 
          name="email" 
          label="Email" 
          rules={[
            { required: isNewVendor, message: 'Please enter an email address' },
            { type: 'email', message: 'Please enter a valid email address' }
          ]}
        >
          <Input placeholder="Email Address" />
        </Form.Item>
        
        <Form.Item 
          name="phone" 
          label="Phone"
          rules={[{ required: isNewVendor, message: 'Please enter a phone number' }]}
        >
          <Input placeholder="Phone Number" />
        </Form.Item>
        
        <Form.Item name="webAddr" label="Website">
          <Input placeholder="Website URL" />
        </Form.Item>

        <Divider orientation="left">Billing Address</Divider>
        
        <Form.Item 
          name="billingLine1" 
          label="Street Address"
          rules={[{ required: isNewVendor, message: 'Please enter the street address' }]}
        >
          <Input placeholder="Street Address" />
        </Form.Item>
        
        <Form.Item 
          name="billingCity" 
          label="City"
          rules={[{ required: isNewVendor, message: 'Please enter the city' }]}
        >
          <Input placeholder="City" />
        </Form.Item>
        
        <Form.Item 
          name="billingState" 
          label="State/Province"
          rules={[{ required: isNewVendor, message: 'Please enter the state/province' }]}
        >
          <Input placeholder="State/Province" />
        </Form.Item>
        
        <Form.Item 
          name="billingPostalCode" 
          label="Postal Code"
          rules={[{ required: isNewVendor, message: 'Please enter the postal code' }]}
        >
          <Input placeholder="Postal Code" />
        </Form.Item>
        
        <Form.Item name="billingCountry" label="Country">
          <Input placeholder="Country" />
        </Form.Item>

        <Divider orientation="left">Additional Information</Divider>
        
        <Form.Item name="vendor1099" valuePropName="checked">
          <Checkbox>1099 Vendor</Checkbox>
        </Form.Item>
        
        <Form.Item 
          name="currencyValue" 
          label="Currency"
          rules={[{ required: true, message: 'Please select a currency' }]}
        >
          <Select placeholder="Select currency">
            {currencies.map(currency => (
              <Option key={currency.value} value={currency.value}>
                {currency.label} ({currency.value})
              </Option>
            ))}
          </Select>
        </Form.Item>
      </Form>
    </Drawer>
  );
};

export default VendorDrawer;