import React, { useEffect, useState } from 'react';
import { Table, message, Spin, Button, Empty, Select } from 'antd';
import SearchBar from './SearchBar';
import { DownloadOutlined } from '@ant-design/icons';
import './ChartOfAccount.css';

interface AccountData {
    id: string;
    name: string;
    accountType: string;
    accountSubType: string;
    currentBalance: number;
    classification: string;
    active: boolean;
    companySource?: string;
    currencyRef?: {
        value: string;
        name?: string;
    };
}

const ChartOfAccounts = () => {
    const [pagedData, setPagedData] = useState<AccountData[]>([]);
    const [loading, setLoading] = useState(false);
    const [isDataFetched, setIsDataFetched] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0
    });
    const [isXeroConnected, setIsXeroConnected] = useState(false);
    const [selectedCompany, setSelectedCompany] = useState<string>('ALL');

      // Add this useEffect to check Xero authentication status
      useEffect(() => {
        const checkXeroAuth = () => {
            const xeroAccessToken = localStorage.getItem('xero_access_token');
            const xeroTenantId = localStorage.getItem('xero_tenant_id');
            setIsXeroConnected(Boolean(xeroAccessToken && xeroTenantId));
        };
        
        checkXeroAuth();
        
        // Set up an event listener for storage changes
        window.addEventListener('storage', checkXeroAuth);
        return () => window.removeEventListener('storage', checkXeroAuth);
    }, []);
    // Fetch data based on selected company
    const fetchData = async (
        page = pagination.current,
        pageSize = pagination.pageSize,
        search = searchTerm,
        company = selectedCompany
    ) => {
        setLoading(true);
        
        try {
            let data;
            
            if (company === 'QuickBooks') {
                data = await fetchQuickBooksData(page, pageSize, search);
            } else if (company === 'Xero' && isXeroConnected) {
                data = await fetchXeroData(page, pageSize, search);
            } else if (company === 'ALL' && isXeroConnected) {
                const qboData = await fetchQuickBooksData(page, pageSize, search);
                const xeroData = await fetchXeroData(page, pageSize, search);
                
                data = {
                    data: [...(qboData.data || []), ...(xeroData.data || [])],
                    totalRecords: (qboData.totalRecords || 0) + (xeroData.totalRecords || 0),
                    currentPage: page,
                    pageSize: pageSize
                };
            } else {
                // Default to QuickBooks if Xero is not connected
                data = await fetchQuickBooksData(page, pageSize, search);
            }

            // Rest of the function stays the same...
            setPagedData(data.data || []);
            setPagination({
                current: data.currentPage || page,
                pageSize: data.pageSize || pageSize,
                total: data.totalRecords || 0,
            });
            setIsDataFetched(true);
        } catch (err) {
            message.error('Failed to fetch chart of accounts.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    // Fetch QuickBooks data from the API
    const fetchQuickBooksData = async (page: number, pageSize: number, search: string) => {
        const params = new URLSearchParams({
            page: page.toString(),
            pageSize: pageSize.toString(),
            searchTerm: search || ''
        });

        const url = `${import.meta.env.VITE_API_BASE_URL}/api/quickbooks/fetch-from-db-paginated?${params.toString()}`;
        const response = await fetch(url);
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(errorText);
        }
        
        const result = await response.json();
        
        // Mark each record as coming from QuickBooks
        if (result.data && Array.isArray(result.data)) {
            result.data = result.data.map((item: any) => ({
                ...item,
                companySource: 'QuickBooks'
            }));
        }
        
        return result;
    };

    // Fetch Xero data from the API
    const fetchXeroData = async (page: number, pageSize: number, search: string) => {
        const params = new URLSearchParams({
            page: page.toString(),
            pageSize: pageSize.toString(), 
            searchTerm: search || ''
        });

        const url = `${import.meta.env.VITE_API_BASE_URL}/api/xeroaccounts/fetch-from-db-paginated?${params.toString()}`;
        const response = await fetch(url);
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(errorText);
        }
        
        const result = await response.json();
        
        // Mark each record as coming from Xero
        if (result.data && Array.isArray(result.data)) {
            result.data = result.data.map((item: any) => ({
                ...item,
                companySource: 'Xero'
            }));
        }
        
        return result;
    };

    // Download accounts from QuickBooks
    const downloadFromQuickBooks = async () => {
        setLoading(true);
        console.log("⬇️ Downloading from QuickBooks...");

        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/quickbooks/fetch-from-quickbooks`, {
                method: 'GET',
            });

            if (!res.ok) {
                const errorText = await res.text();
                throw new Error(errorText);
            }

            const result = await res.json();

            if (result && Array.isArray(result) && result.length > 0) {
                // Set company to QuickBooks after downloading
                setSelectedCompany('QuickBooks');
                await fetchData(1, pagination.pageSize, searchTerm, 'QuickBooks');
                message.success('Chart of accounts loaded successfully from QuickBooks.');
            } else {
                message.warning('No chart of accounts data found in QuickBooks.');
            }
        } catch (err) {
            message.error('Failed to fetch chart of accounts from QuickBooks.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    // Download accounts from Xero
    const downloadFromXero = async () => {
        if (!isXeroConnected) {
            message.error('Please connect to Xero first.');
            return;
        }
        setLoading(true);
        console.log("⬇️ Downloading from Xero...");

        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/xeroaccounts/fetch-from-xero`, {
                method: 'GET',
            });

            if (!res.ok) {
                const errorText = await res.text();
                throw new Error(errorText);
            }

            const result = await res.json();

            if (result && Array.isArray(result) && result.length > 0) {
                // Set company to Xero after downloading
                setSelectedCompany('Xero');
                await fetchData(1, pagination.pageSize, searchTerm, 'Xero');
                message.success('Chart of accounts loaded successfully from Xero.');
            } else {
                message.warning('No chart of accounts data found in Xero.');
            }
        } catch (err) {
            message.error('You are not connected to Xero.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    // Handle search input change
    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        console.log("🔍 Searching:", value);
        setSearchTerm(value);
        fetchData(1, pagination.pageSize, value, selectedCompany);
    };

    // Handle table pagination change
    const handleTableChange = (paginationInfo: any, filters: any, sorter: any) => {
        console.log("📃 Table pagination change:", paginationInfo);
        console.log("🔍 Filter change:", filters);
        console.log("⬆️⬇️ Sort change:", sorter);
        
        const { current, pageSize } = paginationInfo;

        setPagination(prev => ({
            ...prev,
            current,
            pageSize
        }));

        // If sorting is applied, sort the data locally
        if (sorter && sorter.field && sorter.order) {
            const { field, order } = sorter;
            const sortedData = [...pagedData].sort((a: any, b: any) => {
                const aValue = a[field];
                const bValue = b[field];
                
                if (field === 'currentBalance') {
                    const aBalance = a.currentBalance || 0;
                    const bBalance = b.currentBalance || 0;
                    return order === 'ascend' ? aBalance - bBalance : bBalance - aBalance;
                } else if (typeof aValue === 'string' && typeof bValue === 'string') {
                    return order === 'ascend' 
                        ? aValue.localeCompare(bValue) 
                        : bValue.localeCompare(aValue);
                }
                return 0;
            });
            
            setPagedData(sortedData);
        } else {
            // If no sorting, fetch data normally
            fetchData(current, pageSize, searchTerm, selectedCompany);
        }
    };

    // Handle company selection change
    const handleCompanyChange = (value: string) => {
        console.log("🏢 Company filter changed:", value);
        setSelectedCompany(value);
        fetchData(1, pagination.pageSize, searchTerm, value);
    };

    // Initial data fetch on component mount
    useEffect(() => {
        fetchData();
    }, []);

    // Table columns definition
    const columns = [
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
            sorter: true
        },
        {
            title: 'Account Type',
            dataIndex: 'accountType',
            key: 'accountType',
            filters: Array.from(new Set(pagedData.map(item => item.accountType)))
                .filter(Boolean)
                .map(type => ({ text: type, value: type })),
            onFilter: (value: any, record: AccountData) => record.accountType === String(value),
        },
        {
            title: 'Detail Type',
            dataIndex: 'accountSubType',
            key: 'accountSubType',
        },
        {
            title: 'Classification',
            dataIndex: 'classification',
            key: 'classification',
        },
        {
            title: 'Company',
            dataIndex: 'companySource',
            key: 'companySource',
            filters: [
                { text: 'QuickBooks', value: 'QuickBooks' },
                { text: 'Xero', value: 'Xero' }
            ],
            onFilter: (value: any, record: AccountData) => record.companySource === value,
        },
        {
            title: 'Balance',
            dataIndex: 'currentBalance',
            key: 'balance',
            render: (value: number) => {
                if (value === undefined || value === null) return '-';
                const isNegative = value < 0;
                const absValue = Math.abs(value);
                return isNegative
                    ? `-$${absValue.toFixed(2)}`
                    : `$${value.toFixed(2)}`;
            },
            sorter: true
        }
    ];

    return (
        <div className="chart-accounts-container">
            <div className="chart-accounts-header">
                <div className="chart-accounts-title">Chart of Accounts</div>
                <div className="chart-accounts-actions">
                    <Select
                        value={selectedCompany}
                        onChange={handleCompanyChange}
                        style={{ width: 120, marginRight: 16 }}
                    >
                        {isXeroConnected ? (
                        <>
                            <Select.Option value="ALL">ALL</Select.Option>
                            <Select.Option value="QuickBooks">QuickBooks</Select.Option>
                            <Select.Option value="Xero">Xero</Select.Option>
                        </>
                    ) : (
                        <Select.Option value="QuickBooks">QuickBooks</Select.Option>
                    )}
                </Select>
                    <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />
                    <Button
                        type="primary"
                        onClick={downloadFromQuickBooks}
                        icon={<DownloadOutlined />}
                        style={{ backgroundColor: '#52c41a', borderColor: '#52c41a' }}
                    >
                        Download From QuickBooks
                    </Button>
                    <Button
                        type="primary"
                        onClick={downloadFromXero}
                        icon={<DownloadOutlined />}
                    >
                        Download From Xero
                    </Button>
                </div>
            </div>

            <div className="scrollable-table-container">
                {loading ? (
                    <div className="loading-container">
                        <Spin size="large" />
                        <p>Loading Accounts...</p>
                    </div>
                ) : pagedData.length > 0 ? (
                    <Table
                        dataSource={pagedData}
                        columns={columns}
                        rowKey="id"
                        pagination={{
                            current: pagination.current,
                            pageSize: pagination.pageSize,
                            total: pagination.total,
                            showSizeChanger: true,
                            pageSizeOptions: ['5', '10', '20', '50'],
                            showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
                        }}
                        onChange={handleTableChange}
                        scroll={{ x: 'max-content' }}
                        bordered
                        className="accounts-table"
                    />
                ) : (
                    <div className="empty-data-container">
                        <Empty
                            description='No data available. Click "Download" to load chart of accounts.'
                            image={Empty.PRESENTED_IMAGE_SIMPLE}
                        />
                    </div>
                )}
            </div>
        </div>
    );
};

export default ChartOfAccounts;