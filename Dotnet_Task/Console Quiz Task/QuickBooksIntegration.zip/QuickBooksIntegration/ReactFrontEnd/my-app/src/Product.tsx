import React, { useEffect, useState } from "react";
import {
  Button,
  Input,
  Table,
  message,
  Space,
  Popconfirm,
  Badge,
  Tooltip,
  Select,
  Empty,
  Spin,
  Tag,
} from "antd";
import {
  EditOutlined,
  PoweroffOutlined,
  PlusOutlined,
  ReloadOutlined,
  CheckCircleOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import ProductDrawer from "./ProductDrawer";
import SearchBar from "./SearchBar"; // Assuming you have the same SearchBar component

const { Option } = Select;

interface Product {
  id: number;
  name: string;
  description: string | null;
  type: string;
  unitPrice: number | null;
  incomeAccountId: string | null;
  incomeAccountName: string | null;
  assetAccountId: string | null;
  assetAccountName: string | null;
  expenseAccountId: string | null;
  expenseAccountName: string | null;
  quantityOnHand: number | null;
  inventoryStartDate: string | null;
  active: boolean;
  sourceSystem: string;
  quickBooksItemId?: string;
  xeroItemId?: string;
  syncToken?: string;
  createdAt: string;
  updatedAt: string;
}

const Products: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<string>("ALL");
  const [typeFilter, setTypeFilter] = useState<string>("All");
  const [tenantId, setTenantId] = useState<string>("");
  const [isXeroConnected, setIsXeroConnected] = useState<boolean>(false);
  const [sourceSystem, setSourceSystem] = useState<string>("QuickBooks");
  const [isDataFetched, setIsDataFetched] = useState(false);

  // Check Xero connection status on mount
  useEffect(() => {
    checkXeroAuth();
    
    // Set up an event listener for storage changes
    window.addEventListener("storage", checkXeroAuth);
    
    // Fetch products with initial filters
    fetchProducts(1, pagination.pageSize, searchTerm);
    
    return () => window.removeEventListener("storage", checkXeroAuth);
  }, []);

  const checkXeroAuth = () => {
    const xeroAccessToken = localStorage.getItem("xero_access_token");
    const xeroTenantId = localStorage.getItem("xero_tenant_id");
    const isConnected = Boolean(xeroAccessToken && xeroTenantId);

    setIsXeroConnected(isConnected);
    if (isConnected && xeroTenantId) {
      setTenantId(xeroTenantId);
    }
  };

  // Single centralized function to refresh data with current filters
  const refreshData = async () => {
    return fetchProducts(
      pagination.current,
      pagination.pageSize,
      searchTerm,
      selectedCompany,
      typeFilter
    );
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    fetchProducts(1, pagination.pageSize, value, selectedCompany, typeFilter);
  };

  const handleTableChange = (tablePagination) => {
    const { current, pageSize } = tablePagination;
    fetchProducts(current, pageSize, searchTerm, selectedCompany, typeFilter);
  };

  const handleCompanyChange = (value) => {
    console.log("🏢 Company filter changed:", value);
    setSelectedCompany(value);
    fetchProducts(1, pagination.pageSize, searchTerm, value, typeFilter);
  };

  const handleTypeFilterChange = (value) => {
    setTypeFilter(value);
    fetchProducts(1, pagination.pageSize, searchTerm, selectedCompany, value);
  };

  // Fetch products from QuickBooks with proper error handling
  const handleDownloadQuickBooks = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/fetch-products-from-quickbooks`
      );

      const text = await res.text();
      let result;

      try {
        result = JSON.parse(text);
      } catch (e) {
        console.error("❌ Invalid QuickBooks response:", text);
        throw new Error("Failed to parse QuickBooks response: " + text);
      }

      if (!res.ok) {
        console.error("❌ QuickBooks error:", result);
        throw new Error(result.message || "Failed to fetch from QuickBooks");
      }

      message.success("Products downloaded from QuickBooks!");

      // Set to QuickBooks after download and refresh data
      setSelectedCompany("QuickBooks");
      await fetchProducts(1, pagination.pageSize, searchTerm, "QuickBooks", typeFilter);
    } catch (err) {
      message.error("Error fetching from QuickBooks: " + (err.message || "Unknown error"));
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch products from Xero with proper error handling
  const handleDownloadXero = async () => {
    if (!isXeroConnected) {
      message.error("Please connect to Xero first.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/products?tenantId=${tenantId}`
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to fetch from Xero");
      }

      const result = await res.json();
      
      if (!result.success) {
        throw new Error(result.message || "Failed to fetch from Xero");
      }

      message.success("Products downloaded from Xero!");

      // Set to Xero after download and refresh data
      setSelectedCompany("Xero");
      await fetchProducts(1, pagination.pageSize, searchTerm, "Xero", typeFilter);
    } catch (err) {
      message.error("Error fetching from Xero: " + (err.message || "Unknown error"));
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch products from the database based on filters
const fetchProducts = async (
    page = 1,
    pageSize = 10,
    search = searchTerm,
    source = selectedCompany,
    type = typeFilter
  ) => {
    setLoading(true);

    try {
      // Build query parameters
      const queryParams = new URLSearchParams({
        pageNumber: page.toString(),
        pageSize: pageSize.toString(),
        search: search || "",
      });

      if (source && source !== "ALL") queryParams.append("source", source);
      if (type && type !== "All") queryParams.append("type", type);

      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/get-all?${queryParams}`
      );

      const text = await res.text();
      let result;

      try {
        result = JSON.parse(text);
      } catch (e) {
        console.error("❌ Invalid JSON:", text);
        throw new Error("Failed to parse response: " + text);
      }

      if (!res.ok) {
        console.error("❌ Error response:", result);
        throw new Error(result.message || "Failed to fetch data");
      }

      // Handle the new nested data structure: data.data contains products array
      const productsData = result.data?.data || [];
      setProducts(productsData);
      
      setPagination({
        current: page,
        pageSize: pageSize,
        total: result.data?.totalCount || 0,
      });
      setIsDataFetched(true);
      return productsData;
    } catch (err) {
      message.error("Error loading products: " + (err.message || "Unknown error"));
      console.error(err);
      return [];
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = () => {
    setEditingProduct(null);
    setSourceSystem("QuickBooks"); // Default to QuickBooks for new products
    setDrawerVisible(true);
  };

  const handleEditProduct = (product: Product) => {
    // Set the source system for the product being edited
    setSourceSystem(product.sourceSystem);

    const mappedProduct = {
      ...product,
      initialQuantity: product.quantityOnHand,
      asOfDate: product.inventoryStartDate,
      reorderPoint: 0, // Adjust if you later add this field
    };

    setEditingProduct(mappedProduct);
    setDrawerVisible(true);
  };

  // Handle product deactivation with unified flow
  const handleDeactivateProduct = async (product: Product) => {
    setLoading(true);
    try {
      if (product.sourceSystem === "QuickBooks") {
        await handleDeleteQuickBooksProduct(product.id);
      } else if (product.sourceSystem === "Xero") {
        await handleDeleteXeroProduct(product.xeroItemId!, tenantId);
      }

      // Update local state to reflect the deactivation
      setProducts((prevProducts) =>
        prevProducts.map((p) =>
          p.id === product.id ? { ...p, active: false } : p
        )
      );

      message.success(
        `Product deactivated successfully in ${product.sourceSystem}.`
      );
      
      // Refresh data to ensure consistency
      await refreshData();
    } catch (err) {
      message.error(
        `Failed to deactivate product in ${product.sourceSystem}: ${err.message || "Unknown error"}`
      );
      console.error("Deactivate Error:", err);
    } finally {
      setLoading(false);
    }
  };

  // QuickBooks specific deactivation
  const handleDeleteQuickBooksProduct = async (productId: number) => {
    // First deactivate in our database
    const response = await fetch(
      `${import.meta.env.VITE_API_BASE_URL}/api/product/deactivate/${productId}`,
      { method: "PUT" }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || "Failed to deactivate product");
    }

    const product = products.find((p) => p.id === productId);

    // If product exists in QuickBooks, sync the deactivation
    if (product && product.quickBooksItemId) {
      const syncRes = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/make-product-inactive/${product.quickBooksItemId}`,
        { method: "PUT" }
      );

      if (!syncRes.ok) {
        const syncErrorText = await syncRes.text();
        console.error("QuickBooks sync error:", syncErrorText);
        throw new Error(syncErrorText || "Failed to sync with QuickBooks");
      }
    }
    
    return true;
  };

  // Xero specific deactivation
  const handleDeleteXeroProduct = async (xeroItemId: string, tenantId: string) => {
    const response = await fetch(
      `${import.meta.env.VITE_API_BASE_URL}/api/products/${xeroItemId}?tenantId=${tenantId}`,
      { method: "DELETE" }
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to delete product in Xero");
    }
    
    return true;
  };

  // Send product to QuickBooks with unified error handling
  const handleSendToQuickBooks = async (productId) => {
    // Add validation to ensure productId is a valid number
    if (!productId || isNaN(parseInt(productId))) {
        message.error("Invalid product ID");
        return;
    }
    
    try {
        const res = await fetch(
            `${import.meta.env.VITE_API_BASE_URL}/api/product/send-to-quickbooks/${productId}`,
            { method: "POST" }
        );
        
        if (!res.ok) {
            const errorText = await res.text();
            throw new Error(errorText || "Failed to sync product with QuickBooks");
        }
        
        const result = await res.json();
        
        // Update the product in local state with QuickBooks info
        setProducts((prevProducts) =>
            prevProducts.map((p) =>
                p.id === productId
                ? {
                    ...p,
                    quickBooksItemId: result.quickBooksItemId || p.quickBooksItemId,
                    syncToken: result.syncToken || p.syncToken,
                  }
                : p
            )
        );
        
        message.success("Product successfully synced with QuickBooks!");
        return result;
    } catch (err) {
        message.error((err.message || "Failed to sync with QuickBooks"));
        console.error("QuickBooks Sync Error:", err);
        throw err;
    }
};

  // Send product to Xero with unified error handling
  const handleSendToXero = async (productId: number) => {
    if (!tenantId) {
      message.error("No Xero tenant connected. Please connect to Xero first.");
      return null;
    }

    try {
      // First get the product details from the database
      const productRes = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/${productId}`,
   
      );
      console.log('productId', productId)
      if (!productRes.ok) {
        const errorText = await productRes.text();
        console.error("Error fetching product:", productRes.status, errorText);
        throw new Error("Failed to get product details");
      }
      

      const productData = await productRes.json();

      // Convert the product data to Xero format and send to Xero
      const xeroRes = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/products?tenantId=${tenantId}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(productData),
        }
      );

      if (!xeroRes.ok) {
        const errorData = await xeroRes.json();
        throw new Error(
          errorData.message || "Failed to create product in Xero"
        );
      }

      const result = await xeroRes.json();

      // Update the product in local state with Xero info
      setProducts((prevProducts) =>
        prevProducts.map((p) =>
          p.id === productId
            ? {
                ...p,
                xeroItemId: result.data.xeroItemId,
                sourceSystem:
                  result.data.sourceSystem !== "QuickBooks"
                    ? "Xero"
                    : p.sourceSystem,
              }
            : p
        )
      );

      message.success("Product successfully sent to Xero!");
      return result;
    } catch (err) {
      message.error((err.message || "Failed to sync with Xero"));
      console.error("Xero Sync Error:", err);
      throw err;
    }
  };

  // Update product in QuickBooks with unified error handling
  const handleUpdateInQuickBooks = async (productId: number) => {
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/update-in-quickbooks/${productId}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
        }
      );

      if (!response.ok) {
        const errorData = await response.text();
        console.error("QuickBooks update error:", errorData);

        if (response.status === 401) {
          throw new Error("QuickBooks authentication error. Please reconnect your QuickBooks account.");
        } else {
          throw new Error(`Failed to update product in QuickBooks (${response.status})`);
        }
      }

      const result = await response.json();

      // Update product's sync token in local state if available
      if (result && result.NewSyncToken) {
        setProducts((prevProducts) =>
          prevProducts.map((p) =>
            p.id === productId
              ? {
                  ...p,
                  syncToken: result.NewSyncToken,
                }
              : p
          )
        );
      }

      message.success("Product updated successfully in QuickBooks");
      return result;
    } catch (error) {
      console.error("Error updating in QuickBooks:", error);
      throw error;
    }
  };

  // Update product in Xero with unified error handling
  const handleUpdateInXero = async (productId: number) => {
    if (!tenantId) {
      throw new Error("No Xero tenant connected. Please connect to Xero first.");
    }

    // Get product from database
    const product = products.find((p) => p.id === productId);
    if (!product || !product.xeroItemId) {
      throw new Error("Product not found or not synced with Xero");
    }

    // Update product in Xero
    const response = await fetch(
      `${import.meta.env.VITE_API_BASE_URL}/api/products/${product.xeroItemId}?tenantId=${tenantId}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(product),
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(
        errorData.message || "Failed to update product in Xero"
      );
    }

    const result = await response.json();
    message.success("Product updated successfully in Xero");
    return result;
  };

  // Unified product submission function
  const handleSubmitProduct = async (
    values: any,
    syncToExternalSystem: boolean = false
  ) => {
    setSubmitting(true);
    let savedProduct = null;
    let localUpdateSuccess = false;

    try {
      // Determine which system we're working with
      const currentSourceSystem = values.id
        ? values.sourceSystem || sourceSystem
        : sourceSystem;

      // First determine the correct endpoint based on source system
      let endpoint;
      let method;
      
      if (values.id) {
        // Update existing product
        if (currentSourceSystem === "QuickBooks") {
          endpoint = `${import.meta.env.VITE_API_BASE_URL}/api/Product/update/${values.id}`;
          method = "PUT";
        } else { // Xero
          if (!values.xeroItemId || !tenantId) {
            throw new Error("Missing Xero item ID or tenant ID for update");
          }
          endpoint = `${import.meta.env.VITE_API_BASE_URL}/api/products/${values.xeroItemId}?tenantId=${tenantId}`;
          method = "PUT";
        }
      } else {
        // Create new product
        if (currentSourceSystem === "QuickBooks") {
          endpoint = `${import.meta.env.VITE_API_BASE_URL}/api/Product/create`;
          method = "POST";
        } else { // Xero
          if (!tenantId) {
            throw new Error("Missing tenant ID for Xero product creation");
          }
          endpoint = `${import.meta.env.VITE_API_BASE_URL}/api/products?tenantId=${tenantId}`;
          method = "POST";
        }
      }

      // Add source system to the product data
      const productData = {
        ...values,
        sourceSystem: currentSourceSystem,
      };

      // Save to our database
      const res = await fetch(endpoint, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(productData),
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Failed to save product");
      }

      savedProduct = await res.json();
      localUpdateSuccess = true;

      // Close drawer after successful save
      setDrawerVisible(false);

      // Sync to external system if requested
      if (syncToExternalSystem && savedProduct) {
        try {
          if (currentSourceSystem === "QuickBooks") {
            // For new products, sync to QuickBooks
            if (!values.id || !values.quickBooksItemId) {
              await handleSendToQuickBooks(savedProduct.id);
            }
            // For existing products in QuickBooks, update them
            else if (values.id && values.quickBooksItemId) {
              await handleUpdateInQuickBooks(values.id);
            }
          } else if (currentSourceSystem === "Xero") {
            // For new products, send to Xero
            if (!values.id || !values.xeroItemId) {
              await handleSendToXero(savedProduct.id);
            }
            // For existing products in Xero, update them
            else if (values.id && values.xeroItemId) {
              await handleUpdateInXero(values.id);
            }
          }
        } catch (syncError) {
          console.error(
            `Error syncing product to ${currentSourceSystem}:`,
            syncError
          );
          // message.warning(
          //   `Product was updated locally but failed to update in ${currentSourceSystem}: ${syncError.message || "Unknown error"}`
          // );
        }
      }

      message.success(`Product ${values.id ? "updated" : "created"} successfully!`);
      
      // Refresh data to ensure all changes are reflected
      await refreshData();
    } catch (err) {
      message.error(`Error ${values.id ? "updating" : "creating"} product: ${err.message || "Unknown error"}`);
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const columns: ColumnsType<Product> = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      ellipsis: true,
      width: 180,
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
      ellipsis: true,
      width: 180,
    },
    {
      title: "Type",
      dataIndex: "type",
      key: "type",
      width: 100,
    },
    {
      title: "Unit Price",
      dataIndex: "unitPrice",
      key: "unitPrice",
      width: 100,
      render: (value) => (value ? `$${parseFloat(value).toFixed(2)}` : "-"),
    },
    {
      title: "Income Account",
      dataIndex: "incomeAccountName",
      key: "incomeAccountName",
      ellipsis: true,
      width: 160,
    },
    {
      title: "Source",
      dataIndex: "sourceSystem",
      key: "sourceSystem",
      width: 120,
      render: (text: string) => (
        <Tag color={text === "QuickBooks" ? "blue" : "green"}>
          {text || "N/A"}
        </Tag>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      fixed: "right",
      width: 120,
      render: (_, record) => (
        <div className="action-buttons">
          <Space>
            <Button
              type="primary"
              icon={<EditOutlined />}
              onClick={() => handleEditProduct(record)}
            >
              Edit
            </Button>
            <Popconfirm
              title="Are you sure you want to deactivate this product?"
              onConfirm={() => handleDeactivateProduct(record)}
              okText="Yes"
              cancelText="No"
            >
              <Button danger icon={<DeleteOutlined />}>
                Delete
              </Button>
            </Popconfirm>
          </Space>
        </div>
      ),
    },
  ];

  return (
    <div className="chart-accounts-container">
      <div className="chart-accounts-header">
        <div className="chart-accounts-title">Products</div>
        <div className="chart-accounts-actions d-flex">
          <Select
            value={selectedCompany}
            onChange={handleCompanyChange}
            style={{ width: 120, marginRight: 16 }}
          >
            {isXeroConnected ? (
              <>
                <Option value="ALL">ALL</Option>
                <Option value="QuickBooks">QuickBooks</Option>
                <Option value="Xero">Xero</Option>
              </>
            ) : (
              <Option value="QuickBooks">QuickBooks</Option>
            )}
          </Select>

          <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />

          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={handleAddProduct}
            className="action-button"
          >
            Add Product
          </Button>
          <Button
            type="primary"
            onClick={handleDownloadQuickBooks}
            icon={<ReloadOutlined />}
            className="action-button"
            disabled={loading}
          >
            Sync from QuickBooks
          </Button>
          {isXeroConnected && (
            <Button
              type="primary"
              onClick={handleDownloadXero}
              icon={<ReloadOutlined />}
              className="action-button"
              disabled={loading}
            >
              Sync from Xero
            </Button>
          )}
        </div>
      </div>

      <div className="scrollable-table-container">
        {loading ? (
          <div className="loading-container">
            <Spin size="large" />
            <p>Loading Products...</p>
          </div>
        ) : products.length > 0 ? (
          <Table
            dataSource={products}
            columns={columns}
            rowKey="id"
            pagination={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              showSizeChanger: true,
              pageSizeOptions: ["5", "10", "20", "50"],
              showTotal: (total, range) =>
                `${range[0]}-${range[1]} of ${total} items`,
            }}
            onChange={handleTableChange}
            scroll={{ x: "max-content" }}
            bordered
            className="accounts-table"
          />
        ) : (
          <div className="empty-data-container">
            <Empty
              description='No product data available. Click "Sync" to load from QuickBooks or Xero.'
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
            <div className="empty-action-buttons">
              <Button
                type="primary"
                onClick={handleDownloadQuickBooks}
                icon={<ReloadOutlined />}
                className="empty-download-button"
                disabled={loading}
              >
                Sync from QuickBooks
              </Button>
              {isXeroConnected && (
                <Button
                  type="primary"
                  onClick={handleDownloadXero}
                  icon={<ReloadOutlined />}
                  className="empty-download-button"
                  style={{ marginLeft: "10px" }}
                  disabled={loading}
                >
                  Sync from Xero
                </Button>
              )}
            </div>
          </div>
        )}
      </div>

      <ProductDrawer
        visible={drawerVisible}
        onClose={() => setDrawerVisible(false)}
        onSubmit={handleSubmitProduct}
        editingProduct={editingProduct}
        loading={submitting}
        sourceSystem={sourceSystem}
        setSourceSystem={setSourceSystem}
        xeroEnabled={isXeroConnected}
        tenantId={tenantId}
      />
    </div>
  );
};

export default Products;