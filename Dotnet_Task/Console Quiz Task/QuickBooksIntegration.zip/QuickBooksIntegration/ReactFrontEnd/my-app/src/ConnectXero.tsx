import React from 'react';

const ConnectXero = () => {
  const connectToXero = () => {
    window.location.href = "https://localhost:5001/api/xero/auth"; 
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Connect to Xero</h2>
      <button onClick={connectToXero}>Login with Xero</button>
    </div>
  );
};

export default ConnectXero;
