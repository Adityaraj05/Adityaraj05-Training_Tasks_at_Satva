// services/xeroAuthService.ts

export const isXeroTokenExpired = (): boolean => {
    const expiryTime = localStorage.getItem('xero_token_expiry');
    if (!expiryTime) return true;
    
    const now = new Date().getTime();
    return now >= parseInt(expiryTime);
  };
  
  export const clearXeroTokens = (): void => {
    localStorage.removeItem('xero_access_token');
    localStorage.removeItem('xero_refresh_token');
    localStorage.removeItem('xero_token_expiry');
    localStorage.removeItem('xero_id_token');
    localStorage.removeItem('xero_tenant_id');
  };
  
  export const refreshXeroToken = async (): Promise<boolean> => {
    try {
      const refreshTokenValue = localStorage.getItem('xero_refresh_token');
      if (!refreshTokenValue) return false;
      
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/xero/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: refreshTokenValue }),
      });
      
      if (!response.ok) {
        console.error('Failed to refresh Xero token');
        return false;
      }
      
      const data = await response.json();
      
      // Update tokens in localStorage
      localStorage.setItem('xero_access_token', data.accessToken);
      localStorage.setItem('xero_refresh_token', data.refreshToken);
      
      // Calculate new expiry time
      const now = new Date();
      const expiryTime = now.getTime() + (parseInt(data.expiresIn) * 1000);
      localStorage.setItem('xero_token_expiry', expiryTime.toString());
      
      return true;
    } catch (error) {
      console.error('Error refreshing Xero token:', error);
      return false;
    }
  };
  
  export const initiateXeroAuth = (): void => {
    window.location.href = `${import.meta.env.VITE_API_BASE_URL}/api/xero/auth`;
  };