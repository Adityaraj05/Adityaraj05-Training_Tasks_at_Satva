﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xero.Interface
{
    public interface IXeroAccountService
    {
        Task<List<ChartOfAccount>> FetchAccountsFromXeroAsync();
        Task<List<ChartOfAccount>> GetAccountsFromDatabaseAsync(string tenantId, int page = 1, int pageSize = 10, string searchTerm = null);
    }
}
