﻿using Data_Access_Layer.Models;
using Data_Access_Layer.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xero.Interface
{
    public interface IXeroInvoiceService
    {
        Task<ApiResponse<List<Invoice>>> GetInvoicesAsync(
            string tenantId,
            int page = 1,
            int pageSize = 10,
            string filter = null,
            string sortBy = null,
            string sortOrder = "asc");

        Task<ApiResponse<Invoice>> GetInvoiceByIdAsync(string tenantId, string invoiceId);

        Task<ApiResponse<Invoice>> CreateInvoiceAsync(string tenantId, InvoiceInputModel invoiceInput);

        Task<ApiResponse<Invoice>> UpdateInvoiceAsync(string tenantId, string invoiceId, InvoiceInputModel invoiceInput);

        Task<ApiResponse<bool>> DeleteInvoiceAsync(string tenantId, string invoiceId);

        Task<ApiResponse<bool>> SyncInvoicesFromXeroAsync(string tenantId);
    }
}
