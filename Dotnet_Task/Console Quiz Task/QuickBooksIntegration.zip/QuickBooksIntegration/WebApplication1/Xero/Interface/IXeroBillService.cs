﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xero.Interface
{
    public interface IXeroBillService
    {

        Task<List<Bill>> FetchBillsFromXeroAsync();
        Task<(List<Bill> Bills, int TotalCount)> GetBillsFromDatabaseAsync(BillQueryParameters parameters);
        Task<Bill> GetBillByIdAsync(string billId);
        Task<Bill> CreateBillAsync(XeroBillDto billDto);
        Task<Bill> UpdateBillAsync(string billId, XeroBillDto billDto);
        Task<bool> DeleteBillAsync(string billId);
    }
}
