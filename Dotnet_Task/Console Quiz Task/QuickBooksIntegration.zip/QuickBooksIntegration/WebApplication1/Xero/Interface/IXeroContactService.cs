﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xero.Interface
{
    public interface IXeroContactService
    {
        Task<List<Customer>> FetchContactsFromXeroAsync();
        Task<List<Customer>> GetContactsFromDatabaseAsync(string tenantId, int page = 1, int pageSize = 10, string searchTerm = null);
        Task<Customer> GetContactByIdAsync(string contactId);
        Task<Customer> CreateContactAsync(Customer customer);
        Task<Customer> UpdateContactAsync(Customer customer);
        Task<bool> DeleteContactAsync(string contactId);
    }
}
