﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xero.Interface
{
    public interface IXeroProductService
    {
        Task<ApiResponse<List<Product>>> GetProductsAsync(string tenantId, string type = null, int page = 1, int pageSize = 10,
            string searchTerm = null);
        Task<ApiResponse<Product>> GetProductByIdAsync(string tenantId, string xeroItemId);
        Task<ApiResponse<Product>> CreateProductAsync(string tenantId, Product product);
        Task<ApiResponse<Product>> UpdateProductAsync(string tenantId, string xeroItemId, Product product);
        Task<ApiResponse<bool>> DeleteProductAsync(string tenantId, string xeroItemId);
    }
}
