﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xero.Interface
{
    public interface IXeroAuthService
    {
        string GetAuthorizationUrl();
        Task<XeroTokenResponse> ExchangeCodeForTokensAsync(string code);
        Task<XeroTokenResponse> RefreshTokenAsync(string refreshToken);
        string BuildFrontendRedirectUrl(string code, string state);
    }

    public class XeroTokenResponse
    {
        public string Message { get; set; }
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public string IdToken { get; set; }
        public string ExpiresIn { get; set; }
        public string TenantId { get; set; }
    }
}
