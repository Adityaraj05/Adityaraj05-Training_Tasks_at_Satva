﻿namespace Xero
{
    public class Class1
    {

    }
}
