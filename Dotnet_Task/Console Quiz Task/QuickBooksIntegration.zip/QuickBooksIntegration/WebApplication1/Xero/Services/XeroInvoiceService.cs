﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models.DTO;
using Data_Access_Layer.Models;
using Data_Access_Layer.Services;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xero.Interface;
using Microsoft.EntityFrameworkCore;

namespace Xero.Services
{
    public class XeroInvoiceService : IXeroInvoiceService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<XeroInvoiceService> _logger;
        private readonly InvoiceMappingService _mappingService;
        private readonly ApplicationDbContext _context;
        private readonly XeroSettings _xeroSettings;

        public XeroInvoiceService(
            HttpClient httpClient,
            ILogger<XeroInvoiceService> logger,
            InvoiceMappingService mappingService,
            ApplicationDbContext context,
            IOptions<XeroSettings> xeroSettings)
        {
            _httpClient = httpClient;
            _logger = logger;
            _mappingService = mappingService;
            _context = context;
            _xeroSettings = xeroSettings.Value;
        }

        private async Task<(string accessToken, string tenantId)> GetXeroAuthTokenAsync(string providedTenantId = null)
        {
            // Get the most recent token from database
            var token = await _context.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            if (string.IsNullOrEmpty(token.AccessToken))
            {
                _logger.LogError("Invalid Xero token data - missing access token");
                throw new ApplicationException("Xero access token is invalid.");
            }

            // Use provided tenantId if specified, otherwise use the one from the token
            var tenantId = !string.IsNullOrEmpty(providedTenantId) ? providedTenantId : token.TenantId;

            if (string.IsNullOrEmpty(tenantId))
            {
                _logger.LogError("Invalid Xero token data - missing tenant ID");
                throw new ApplicationException("Xero tenant ID is invalid.");
            }

            return (token.AccessToken, tenantId);
        }

        public async Task<ApiResponse<List<Invoice>>> GetInvoicesAsync(
            string tenantId,
            int page = 1,
            int pageSize = 10,
            string filter = null,
            string sortBy = null,
            string sortOrder = "asc")
        {
            try
            {
                var (accessToken, resolvedTenantId) = await GetXeroAuthTokenAsync(tenantId);

                var url = $"{_xeroSettings.ApiBaseUrl}/Invoices";

                // Add filter if provided
                if (!string.IsNullOrEmpty(filter))
                {
                    url += $"?where={Uri.EscapeDataString(filter)}";
                }

                // Add sort if provided
                if (!string.IsNullOrEmpty(sortBy))
                {
                    var sortParam = sortOrder.ToLower() == "desc" ? $"order by {sortBy} desc" : $"order by {sortBy}";
                    url += url.Contains("?") ? $"&{sortParam}" : $"?{sortParam}";
                }

                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Headers.Add("Xero-Tenant-Id", resolvedTenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();
                var jsonDocument = JsonDocument.Parse(content);
                var root = jsonDocument.RootElement;

                // Process the Xero response using our mapping service
                var invoices = _mappingService.ProcessXeroInvoicesResponse(root, resolvedTenantId);

                // Calculate pagination in memory since Xero API doesn't support it directly
                var totalItems = invoices.Count;
                var pagedInvoices = invoices
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                return ApiResponse<List<Invoice>>.SuccessResponse(
                    pagedInvoices,
                    totalItems,
                    page,
                    pageSize,
                    "Successfully retrieved invoices from Xero"
                );
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving invoices from Xero");
                return ApiResponse<List<Invoice>>.ErrorResponse($"Error retrieving invoices: {ex.Message}");
            }
        }

        public async Task<ApiResponse<Invoice>> GetInvoiceByIdAsync(string tenantId, string invoiceId)
        {
            try
            {
                var (accessToken, resolvedTenantId) = await GetXeroAuthTokenAsync(tenantId);

                var url = $"{_xeroSettings.ApiBaseUrl}/Invoices/{invoiceId}";

                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Headers.Add("Xero-Tenant-Id", resolvedTenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();
                var jsonDocument = JsonDocument.Parse(content);
                var root = jsonDocument.RootElement;

                // Process the single invoice
                var invoices = _mappingService.ProcessXeroInvoicesResponse(root, resolvedTenantId);
                if (invoices.Count == 0)
                {
                    return ApiResponse<Invoice>.ErrorResponse($"Invoice not found with ID: {invoiceId}");
                }

                return ApiResponse<Invoice>.SuccessResponse(invoices[0], "Successfully retrieved invoice from Xero");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving invoice {invoiceId} from Xero");
                return ApiResponse<Invoice>.ErrorResponse($"Error retrieving invoice: {ex.Message}");
            }
        }

        public async Task<ApiResponse<Invoice>> CreateInvoiceAsync(string tenantId, InvoiceInputModel invoiceInput)
        {
            try
            {
                var (accessToken, resolvedTenantId) = await GetXeroAuthTokenAsync(tenantId);

                var url = $"{_xeroSettings.ApiBaseUrl}/Invoices";

                // Prepare the Xero invoice request
                var xeroInvoiceRequest = _mappingService.CreateXeroInvoiceRequest(invoiceInput);
                var jsonContent = JsonSerializer.Serialize(xeroInvoiceRequest);

                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Headers.Add("Xero-Tenant-Id", resolvedTenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                var content = await response.Content.ReadAsStringAsync();
                var jsonDocument = JsonDocument.Parse(content);
                var root = jsonDocument.RootElement;

                // Process the response to get the created invoice
                var invoices = _mappingService.ProcessXeroInvoicesResponse(root, resolvedTenantId);
                if (invoices.Count == 0)
                {
                    return ApiResponse<Invoice>.ErrorResponse("Failed to create invoice in Xero");
                }

                var createdInvoice = invoices[0];

                // Now save to our database
                _context.Invoices.Add(createdInvoice);
                await _context.SaveChangesAsync();

                // Process line items if available in response
                if (root.TryGetProperty("Invoices", out var invoicesElement) && invoicesElement.GetArrayLength() > 0)
                {
                    var invoiceElement = invoicesElement[0];
                    var lineItems = _mappingService.ProcessXeroInvoiceLineItems(invoiceElement, createdInvoice.Id);

                    if (lineItems.Count > 0)
                    {
                        _context.InvoiceLineItem.AddRange(lineItems);
                        await _context.SaveChangesAsync();
                    }
                }

                return ApiResponse<Invoice>.SuccessResponse(createdInvoice, "Invoice successfully created in Xero");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating invoice in Xero");
                return ApiResponse<Invoice>.ErrorResponse($"Error creating invoice: {ex.Message}");
            }
        }

        public async Task<ApiResponse<Invoice>> UpdateInvoiceAsync(string tenantId, string invoiceId, InvoiceInputModel invoiceInput)
        {
            try
            {
                var (accessToken, resolvedTenantId) = await GetXeroAuthTokenAsync(tenantId);

                // First, check if the invoice exists in our database
                var existingInvoice = await _context.Invoices
                    .FirstOrDefaultAsync(i => i.ExternalId == invoiceId && i.SourceCompany == "Xero");

                if (existingInvoice == null)
                {
                    return ApiResponse<Invoice>.ErrorResponse($"Invoice not found with ID: {invoiceId}");
                }

                var url = $"{_xeroSettings.ApiBaseUrl}/Invoices/{invoiceId}";

                // Prepare the Xero invoice request with the existing ID
                var lineItems = await _context.InvoiceLineItem
                    .Where(li => li.InvoiceId == existingInvoice.Id)
                    .ToListAsync();

                var xeroInvoiceRequest = _mappingService.MapInvoiceToXeroFormat(existingInvoice, lineItems);
                var jsonContent = JsonSerializer.Serialize(xeroInvoiceRequest);

                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Headers.Add("Xero-Tenant-Id", resolvedTenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();
                var jsonDocument = JsonDocument.Parse(content);
                var root = jsonDocument.RootElement;

                // Process the response to get the updated invoice
                var invoices = _mappingService.ProcessXeroInvoicesResponse(root, resolvedTenantId);
                if (invoices.Count == 0)
                {
                    return ApiResponse<Invoice>.ErrorResponse("Failed to update invoice in Xero");
                }

                var updatedInvoice = invoices[0];

                // Update our database entry
                existingInvoice.InvoiceDate = updatedInvoice.InvoiceDate;
                existingInvoice.DueDate = updatedInvoice.DueDate;
                existingInvoice.BillingAddress = updatedInvoice.BillingAddress;
                existingInvoice.Subtotal = updatedInvoice.Subtotal;
                existingInvoice.Total = updatedInvoice.Total;
                existingInvoice.UpdatedAt = DateTime.UtcNow;

                _context.Invoices.Update(existingInvoice);
                await _context.SaveChangesAsync();

                // Process line items if available in response
                if (root.TryGetProperty("Invoices", out var invoicesElement) && invoicesElement.GetArrayLength() > 0)
                {
                    var invoiceElement = invoicesElement[0];

                    // Remove existing line items
                    _context.InvoiceLineItem.RemoveRange(lineItems);
                    await _context.SaveChangesAsync();

                    // Add new line items
                    var newLineItems = _mappingService.ProcessXeroInvoiceLineItems(invoiceElement, existingInvoice.Id);
                    if (newLineItems.Count > 0)
                    {
                        _context.InvoiceLineItem.AddRange(newLineItems);
                        await _context.SaveChangesAsync();
                    }
                }

                return ApiResponse<Invoice>.SuccessResponse(existingInvoice, "Invoice successfully updated in Xero");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating invoice {invoiceId} in Xero");
                return ApiResponse<Invoice>.ErrorResponse($"Error updating invoice: {ex.Message}");
            }
        }

        public async Task<ApiResponse<bool>> DeleteInvoiceAsync(string tenantId, string invoiceId)
        {
            try
            {
                var (accessToken, resolvedTenantId) = await GetXeroAuthTokenAsync(tenantId);

                // Note: Xero doesn't allow true deletion, we can only void or mark as deleted
                var url = $"{_xeroSettings.ApiBaseUrl}/Invoices/{invoiceId}";

                // Create a request to void the invoice
                var voidRequest = new
                {
                    Invoices = new[]
                    {
                        new { InvoiceID = invoiceId, Status = "VOIDED" }
                    }
                };

                var jsonContent = JsonSerializer.Serialize(voidRequest);

                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Headers.Add("Xero-Tenant-Id", resolvedTenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);
                var content = response.Content.ReadAsStringAsync();

                // Now remove from our database
                var invoice = await _context.Invoices
                    .FirstOrDefaultAsync(i => i.ExternalId == invoiceId && i.SourceCompany == "Xero");

                if (invoice != null)
                {
                    // Remove line items first
                    var lineItems = await _context.InvoiceLineItem
                        .Where(li => li.InvoiceId == invoice.Id)
                        .ToListAsync();

                    _context.InvoiceLineItem.RemoveRange(lineItems);
                    _context.Invoices.Remove(invoice);
                    await _context.SaveChangesAsync();
                }

                return ApiResponse<bool>.SuccessResponse(true, "Invoice successfully deleted");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting invoice {invoiceId} from Xero");
                return ApiResponse<bool>.ErrorResponse($"Error deleting invoice: {ex.Message}");
            }
        }

        public async Task<ApiResponse<bool>> SyncInvoicesFromXeroAsync(string tenantId)
        {
            try
            {
                var (accessToken, resolvedTenantId) = await GetXeroAuthTokenAsync(tenantId);

                var url = $"{_xeroSettings.ApiBaseUrl}/Invoices";

                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Headers.Add("Xero-Tenant-Id", resolvedTenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();
                var jsonDocument = JsonDocument.Parse(content);
                var root = jsonDocument.RootElement;

                // Process all invoices from Xero
                var xeroInvoices = _mappingService.ProcessXeroInvoicesResponse(root, resolvedTenantId);
                int addedCount = 0;
                int updatedCount = 0;

                foreach (var xeroInvoice in xeroInvoices)
                {
                    // Check if invoice already exists in our database
                    var existingInvoice = await _context.Invoices
                        .FirstOrDefaultAsync(i => i.ExternalId == xeroInvoice.ExternalId && i.SourceCompany == "Xero");

                    if (existingInvoice != null)
                    {
                        // Update existing invoice
                        existingInvoice.InvoiceDate = xeroInvoice.InvoiceDate;
                        existingInvoice.DueDate = xeroInvoice.DueDate;
                        existingInvoice.BillingAddress = xeroInvoice.BillingAddress;
                        existingInvoice.Subtotal = xeroInvoice.Subtotal;
                        existingInvoice.Total = xeroInvoice.Total;
                        existingInvoice.UpdatedAt = DateTime.UtcNow;

                        _context.Invoices.Update(existingInvoice);
                        updatedCount++;
                    }
                    else
                    {
                        // Add new invoice
                        _context.Invoices.Add(xeroInvoice);
                        await _context.SaveChangesAsync(); // Save to get the ID for line items
                        addedCount++;

                        // Find the corresponding invoice element to get line items
                        if (root.TryGetProperty("Invoices", out var invoicesElement))
                        {
                            foreach (var invoiceElement in invoicesElement.EnumerateArray())
                            {
                                if (GetStringProperty(invoiceElement, "InvoiceID") == xeroInvoice.ExternalId)
                                {
                                    var lineItems = _mappingService.ProcessXeroInvoiceLineItems(invoiceElement, xeroInvoice.Id);
                                    if (lineItems.Count > 0)
                                    {
                                        _context.InvoiceLineItem.AddRange(lineItems);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }

                await _context.SaveChangesAsync();
                return ApiResponse<bool>.SuccessResponse(true, $"Successfully synced invoices from Xero. Added: {addedCount}, Updated: {updatedCount}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing invoices from Xero");
                return ApiResponse<bool>.ErrorResponse($"Error syncing invoices: {ex.Message}");
            }
        }

        private string GetStringProperty(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property))
            {
                return property.ValueKind == JsonValueKind.String ? property.GetString() : null;
            }
            return null;
        }
    }
}
