﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Data_Access_Layer.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xero.Interface;

namespace Xero.Services
{
    public class XeroContactService : IXeroContactService
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _db;
        private readonly ILogger<XeroContactService> _logger;
        private readonly ContactMappingService _mappingService;
        private readonly XeroSettings _xeroSettings;
        public XeroContactService(
            HttpClient httpClient,
            ApplicationDbContext db,
            ILogger<XeroContactService> logger,
              IOptions<XeroSettings> xeroSettings,

            ContactMappingService mappingService)
        {
            _httpClient = httpClient;
            _db = db;
            _logger = logger;
            _xeroSettings = xeroSettings.Value;
            _mappingService = mappingService;
        }

        public async Task<List<Customer>> FetchContactsFromXeroAsync()
        {
            _logger.LogInformation("Starting Xero contacts fetch process...");

            // Get the most recent token from database
            var token = await _db.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            if (string.IsNullOrEmpty(token.AccessToken) || string.IsNullOrEmpty(token.TenantId))
            {
                _logger.LogError("Invalid Xero token data - missing access token or tenant ID");
                throw new ApplicationException("Xero access token or tenant ID is invalid.");
            }

            var accessToken = token.AccessToken;
            var tenantId = token.TenantId;

            _logger.LogInformation($"Using tenantId: {tenantId}");

            // Create the request
            var url = $"{_xeroSettings.ApiBaseUrl}/Contacts";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            request.Headers.Add("Xero-Tenant-Id", tenantId);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Send the request
            _logger.LogInformation("Sending request to Xero API...");
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero contacts fetch failed: {response.StatusCode} - {content}");
            }

            _logger.LogInformation("Xero API request successful, processing response...");

            // Parse the response
            var jsonDoc = JsonDocument.Parse(content);
            var jsonResponse = jsonDoc.RootElement;

            // Process contacts using the mapping service
            var contacts = _mappingService.ProcessXeroResponse(jsonResponse, tenantId);

            _logger.LogInformation($"Successfully processed {contacts.Count} contacts from Xero");

            using (var transaction = await _db.Database.BeginTransactionAsync())
            {
                try
                {
                    // Remove existing Xero contacts for this tenant
                    _logger.LogInformation($"Removing existing Xero contacts for tenant {tenantId}");
                    var existingContacts = await _db.Customers
                        .Where(c => c.XeroTenantId == tenantId && c.CompanySource == "Xero")
                        .ToListAsync();

                    if (existingContacts.Any())
                    {
                        _db.Customers.RemoveRange(existingContacts);
                        await _db.SaveChangesAsync();
                    }

                    // Add new contacts to database
                    _logger.LogInformation($"Adding {contacts.Count} new Xero contacts to database");
                    await _db.Customers.AddRangeAsync(contacts);
                    await _db.SaveChangesAsync();

                    await transaction.CommitAsync();
                    _logger.LogInformation("Successfully updated Xero contacts in database");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError(ex, "Error saving Xero contacts to database");
                    throw new ApplicationException($"Error saving Xero contacts: {ex.Message}", ex);
                }
            }

            return contacts;
        }

        public async Task<List<Customer>> GetContactsFromDatabaseAsync(
            string tenantId,
            int page = 1,
            int pageSize = 10,
            string searchTerm = null)
        {
            _logger.LogInformation($"Retrieving Xero contacts from database for tenant {tenantId}");

            var query = _db.Customers
                .Where(c => c.XeroTenantId == tenantId && c.CompanySource == "Xero");

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                query = query.Where(c =>
                    c.DisplayName.Contains(searchTerm) ||
                    (c.GivenName != null && c.GivenName.Contains(searchTerm)) ||
                    (c.FamilyName != null && c.FamilyName.Contains(searchTerm)) ||
                    (c.Email != null && c.Email.Contains(searchTerm))
                );
            }

            return await query
                .OrderBy(c => c.DisplayName)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }

        public async Task<Customer> GetContactByIdAsync(string contactId)
        {
            _logger.LogInformation($"Retrieving Xero contact with ID {contactId}");

            var contact = await _db.Customers
                .FirstOrDefaultAsync(c => c.XeroContactId == contactId && c.CompanySource == "Xero");

            if (contact == null)
            {
                _logger.LogWarning($"No Xero contact found with ID {contactId}");
                throw new ApplicationException($"Xero contact with ID {contactId} not found.");
            }

            return contact;
        }

        public async Task<Customer> CreateContactAsync(Customer customer)
        {
            _logger.LogInformation("Creating new Xero contact");

            // Get the most recent token from database
            var token = await _db.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            var accessToken = token.AccessToken;
            var tenantId = token.TenantId;

            // Set the source and tenant ID
            customer.CompanySource = "Xero";
            customer.XeroTenantId = tenantId;
            customer.CreatedAt = DateTime.UtcNow;
            customer.UpdatedAt = DateTime.UtcNow;

            // Create the request payload
            var requestPayload = _mappingService.CreateXeroContactRequest(customer);
            var jsonContent = JsonSerializer.Serialize(requestPayload);

            // Create the HTTP request
            var url = $"{_xeroSettings.ApiBaseUrl}/Contacts";
            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            request.Headers.Add("Xero-Tenant-Id", tenantId);
            request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Send the request
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero contact creation failed: {response.StatusCode} - {content}");
            }

            // Parse the response to get the created contact ID
            var jsonDoc = JsonDocument.Parse(content);
            var jsonResponse = jsonDoc.RootElement;

            if (jsonResponse.TryGetProperty("Contacts", out JsonElement contactsElement) &&
                contactsElement.GetArrayLength() > 0)
            {
                var createdContact = contactsElement[0];
                if (createdContact.TryGetProperty("ContactID", out JsonElement contactIdElement))
                {
                    customer.XeroContactId = contactIdElement.GetString();
                }
            }

            // Save to database
            await _db.Customers.AddAsync(customer);
            await _db.SaveChangesAsync();

            return customer;
        }

        public async Task<Customer> UpdateContactAsync(Customer customer)
        {


            _logger.LogInformation($"Updating Xero contact with ID {customer.XeroContactId}");

            // Validate that we have a XeroContactId
            if (string.IsNullOrEmpty(customer.XeroContactId))
            {
                _logger.LogError("Cannot update Xero contact: XeroContactId is missing");
                throw new ArgumentException("XeroContactId is required for updating a contact");
            }

            // Get the most recent token from database
            var token = await _db.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            var accessToken = token.AccessToken;
            var tenantId = token.TenantId;

            // Ensure the contact exists
            var existingContact = await _db.Customers
                .FirstOrDefaultAsync(c => c.XeroContactId == customer.XeroContactId && c.CompanySource == "Xero");

            if (existingContact == null)
            {
                _logger.LogWarning($"No Xero contact found with ID {customer.XeroContactId}");
                throw new ApplicationException($"Xero contact with ID {customer.XeroContactId} not found.");
            }

            // Preserve ID and created date from existing record
            customer.Id = existingContact.Id; // Ensure we don't lose the primary key
            customer.CreatedAt = existingContact.CreatedAt;

            // Update the contact properties
            customer.CompanySource = "Xero";
            customer.XeroTenantId = tenantId;
            customer.UpdatedAt = DateTime.UtcNow;

            // Create the request payload - This method should include ContactID in the payload
            var requestPayload = _mappingService.CreateXeroContactRequest(customer);
            var jsonContent = JsonSerializer.Serialize(requestPayload);

            _logger.LogInformation($"Sending update request to Xero API for contact {customer.XeroContactId}");
            _logger.LogDebug($"Request payload: {jsonContent}");

            // Create the HTTP request
            var url = $"{_xeroSettings.ApiBaseUrl}/Contacts";
            var request = new HttpRequestMessage(HttpMethod.Post, url);

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            request.Headers.Add("Xero-Tenant-Id", tenantId);
            request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Send the request
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero contact update failed: {response.StatusCode} - {content}");
            }

            _logger.LogInformation($"Successfully updated Xero contact with ID {customer.XeroContactId}");

            // Update the database entry
            _db.Entry(existingContact).CurrentValues.SetValues(customer);
            await _db.SaveChangesAsync();

            return customer;
        }

        public async Task<bool> DeleteContactAsync(string contactId)
        {
            _logger.LogInformation($"Soft deleting Xero contact with ID {contactId}");

            // Find the contact
            var contact = await _db.Customers
                .FirstOrDefaultAsync(c => c.XeroContactId == contactId && c.CompanySource == "Xero");

            if (contact == null)
            {
                _logger.LogWarning($"No Xero contact found with ID {contactId}");
                throw new ApplicationException($"Xero contact with ID {contactId} not found.");
            }

            // Set as inactive (soft delete)
            contact.Active = false;
            contact.UpdatedAt = DateTime.UtcNow;

            // Get the most recent token from database
            var token = await _db.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            var accessToken = token.AccessToken;
            var tenantId = token.TenantId;

            // Create the request payload
            var requestPayload = _mappingService.CreateXeroContactRequest(contact);
            var jsonContent = JsonSerializer.Serialize(requestPayload);

            // Create the HTTP request
            var url = $"{_xeroSettings.ApiBaseUrl}/Contacts";
            var request = new HttpRequestMessage(HttpMethod.Post, url);

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            request.Headers.Add("Xero-Tenant-Id", tenantId);
            request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Send the request
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero contact deletion failed: {response.StatusCode} - {content}");
            }

            // Update the database
            await _db.SaveChangesAsync();

            return true;
        }
    }
}

