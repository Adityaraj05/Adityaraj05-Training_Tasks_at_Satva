﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using Xero.Interface;



namespace Xero.Services
{


    public class XeroAuthService : IXeroAuthService
    {
        private readonly IConfiguration _config;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ApplicationDbContext _context;
        private readonly ILogger<XeroAuthService> _logger;
        private readonly XeroSettings _xeroSettings;

        public XeroAuthService(
            IConfiguration config,
            IHttpClientFactory httpClientFactory,
            ApplicationDbContext context,
                IOptions<XeroSettings> xeroSettings,
            ILogger<XeroAuthService> logger)
        {
            _config = config;
            _httpClientFactory = httpClientFactory;
            _context = context;
            _logger = logger;
            _xeroSettings = xeroSettings.Value;
        }

        public string GetAuthorizationUrl()
        {
            _logger.LogInformation("Generating Xero authorization URL...");

            var clientId = _config["Xero:ClientId"];
            var redirectUri = _config["Xero:RedirectUri"];
            var scope = _config["Xero:Scopes"];
            var state = Guid.NewGuid().ToString();

            var url = $"{_xeroSettings.AuthUrl}?" +
                             $"response_type=code&client_id={clientId}&redirect_uri={Uri.EscapeDataString(redirectUri)}" +
                      $"&scope={Uri.EscapeDataString(scope)}&state={state}";

            _logger.LogInformation($"Xero auth URL generated: {url}");
            return url;
        }

        public async Task<XeroTokenResponse> ExchangeCodeForTokensAsync(string code)
        {
            _logger.LogInformation("Starting Xero token exchange process...");

            if (string.IsNullOrWhiteSpace(code))
            {
                _logger.LogWarning("Missing authorization code.");
                throw new ArgumentException("Code is missing.");
            }

            try
            {
                var clientId = _config["Xero:ClientId"];
                var clientSecret = _config["Xero:ClientSecret"];
                var redirectUri = _config["Xero:RedirectUri"];

                _logger.LogInformation("Preparing HTTP request to Xero token endpoint...");

                var client = _httpClientFactory.CreateClient();
                var credentials = new List<KeyValuePair<string, string>>()
        {
            new("grant_type", "authorization_code"),
            new("code", code),
            new("redirect_uri", redirectUri),
            new("client_id", clientId),
            new("client_secret", clientSecret)
        };

                var tokenRequest = new HttpRequestMessage(HttpMethod.Post, _xeroSettings.TokenUrl)
                {
                    Content = new FormUrlEncodedContent(credentials)
                };


                var response = await client.SendAsync(tokenRequest);
                var body = await response.Content.ReadAsStringAsync();

                _logger.LogInformation("Xero token endpoint response received");

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Token exchange failed: {StatusCode} - {Content}", response.StatusCode, body);
                    throw new Exception($"Token exchange failed: {body}");
                }

                var tokenResponse = JsonSerializer.Deserialize<Dictionary<string, object>>(body);

                // Get tenantId
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokenResponse["access_token"].ToString());
                var tenantResp = await client.GetAsync(_xeroSettings.ConnectionsUrl);
                var tenantBody = await tenantResp.Content.ReadAsStringAsync();

                _logger.LogInformation("Retrieved tenant information from Xero");

                var tenants = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(tenantBody);
                var tenantId = tenants?.FirstOrDefault()?["tenantId"]?.ToString() ?? string.Empty;

                // Handle id_token properly for null values
                string idToken = null;
                if (tokenResponse.ContainsKey("id_token") && tokenResponse["id_token"] != null)
                {
                    idToken = tokenResponse["id_token"].ToString();
                }

                // Parse ExpiresIn as int
                int expiresIn = int.Parse(tokenResponse["expires_in"].ToString());

                // Save to DB
                var token = new XeroToken
                {
                    AccessToken = tokenResponse["access_token"].ToString(),
                    RefreshToken = tokenResponse["refresh_token"].ToString(),
                    IdToken = idToken, // Could be null
                    ExpiresIn = expiresIn, // Store as int
                    TenantId = tenantId,
                    TokenType = "Bearer",
                    CreatedAt = DateTime.UtcNow
                };

                _context.XeroTokens.Add(token);
                await _context.SaveChangesAsync();

                _logger.LogInformation("Token successfully saved to database");

                return new XeroTokenResponse
                {
                    Message = "Token saved successfully",
                    AccessToken = token.AccessToken,
                    RefreshToken = token.RefreshToken,
                    IdToken = token.IdToken,
                    ExpiresIn = expiresIn.ToString(), // Convert back to string for the response if needed
                    TenantId = token.TenantId
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during Xero token exchange");
                throw;
            }
        }

        public async Task<XeroTokenResponse> RefreshTokenAsync(string refreshToken)
        {
            _logger.LogInformation("Starting Xero token refresh process...");

            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                _logger.LogWarning("Missing refresh token.");
                throw new ArgumentException("RefreshToken is missing.");
            }

            try
            {
                var clientId = _config["Xero:ClientId"];
                var clientSecret = _config["Xero:ClientSecret"];

                _logger.LogInformation("Preparing HTTP request to Xero token refresh endpoint...");

                // Update the code to use the correct method for IHttpClientFactory
                var client = _httpClientFactory.CreateClient();
                var tokenRequest = new HttpRequestMessage(HttpMethod.Post, _xeroSettings.TokenUrl);

                var credentials = new List<KeyValuePair<string, string>>()
        {
            new("grant_type", "refresh_token"),
            new("refresh_token", refreshToken),
            new("client_id", clientId),
            new("client_secret", clientSecret)
        };

                tokenRequest.Content = new FormUrlEncodedContent(credentials);
                var response = await client.SendAsync(tokenRequest);
                var body = await response.Content.ReadAsStringAsync();

                _logger.LogInformation("Xero token refresh response received");

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Token refresh failed: {StatusCode} - {Content}", response.StatusCode, body);
                    throw new Exception($"Token refresh failed: {body}");
                }

                var tokenResponse = JsonSerializer.Deserialize<Dictionary<string, object>>(body);

                // Get tenantId
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokenResponse["access_token"].ToString());
                var tenantResp = await client.GetAsync("https://api.xero.com/connections");
                var tenantBody = await tenantResp.Content.ReadAsStringAsync();
                var tenants = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(tenantBody);
                var tenantId = tenants?.FirstOrDefault()?["tenantId"]?.ToString() ?? string.Empty;

                // Handle id_token properly for null values
                string idToken = null;
                if (tokenResponse.ContainsKey("id_token") && tokenResponse["id_token"] != null)
                {
                    idToken = tokenResponse["id_token"].ToString();
                }

                // Parse ExpiresIn as int
                int expiresIn = int.Parse(tokenResponse["expires_in"].ToString());

                // Update in database
                var existingToken = await _context.XeroTokens.OrderByDescending(t => t.CreatedAt).FirstOrDefaultAsync();
                if (existingToken != null)
                {
                    existingToken.AccessToken = tokenResponse["access_token"].ToString();
                    existingToken.RefreshToken = tokenResponse["refresh_token"].ToString();
                    existingToken.ExpiresIn = expiresIn; // Store as int
                    existingToken.IdToken = idToken; // Could be null
                    existingToken.TenantId = tenantId;
                    existingToken.UpdatedAt = DateTime.UtcNow;


                    await _context.SaveChangesAsync();
                    _logger.LogInformation("Token successfully refreshed and updated in database");
                }

                return new XeroTokenResponse
                {
                    AccessToken = tokenResponse["access_token"].ToString(),
                    RefreshToken = tokenResponse["refresh_token"].ToString(),
                    ExpiresIn = expiresIn.ToString(), // Convert back to string for the response if needed
                    IdToken = idToken,
                    TenantId = tenantId
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during Xero token refresh");
                throw;
            }
        }

        public string BuildFrontendRedirectUrl(string code, string state)
        {
            var redirectUri = _config["Xero:RedirectUri"];
            return $"{redirectUri}?code={Uri.EscapeDataString(code)}&state={Uri.EscapeDataString(state ?? "")}";
        }
    }
}