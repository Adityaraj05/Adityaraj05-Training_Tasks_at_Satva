﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xero.Interface;

namespace Xero.Services
{
    public class XeroProductService : IXeroProductService
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _db;
        private readonly ILogger<XeroProductService> _logger;
        private readonly XeroSettings _xeroSettings;

        public XeroProductService(
            HttpClient httpClient,
            ApplicationDbContext db,
            ILogger<XeroProductService> logger,
            IOptions<XeroSettings> xeroSettings)
        {
            _httpClient = httpClient;
            _db = db;
            _logger = logger;
            _xeroSettings = xeroSettings.Value;
        }

        public async Task<ApiResponse<List<Product>>> GetProductsAsync(
            string tenantId,
            string type = null,
            int page = 1,
            int pageSize = 10,
            string searchTerm = null)
        {
            try
            {
                // Get latest token
                var token = await GetLatestXeroToken();

                // Build request
                var url = $"{_xeroSettings.ApiBaseUrl}/Items";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                request.Headers.Add("Xero-Tenant-Id", tenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Execute request
                var response = await _httpClient.SendAsync(request);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                    return ApiResponse<List<Product>>.ErrorResponse($"Xero products fetch failed: {response.StatusCode}");
                }

                // Parse the response
                var jsonDoc = JsonDocument.Parse(content);
                var itemsArray = jsonDoc.RootElement.GetProperty("Items");

                // Map to our product model
                var allProducts = new List<Product>();
                foreach (var item in itemsArray.EnumerateArray())
                {
                    var product = MapXeroItemToProduct(item, tenantId);
                    allProducts.Add(product);
                }

                // Apply filters
                var filteredProducts = allProducts.AsQueryable();

                // Filter by type
                if (!string.IsNullOrWhiteSpace(type))
                {
                    bool isInventory = type.Equals("Inventory", StringComparison.OrdinalIgnoreCase);
                    filteredProducts = filteredProducts.Where(p => p.IsTrackedAsInventory == isInventory);
                }

                // Search
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    searchTerm = searchTerm.ToLower();
                    filteredProducts = filteredProducts.Where(p =>
                        (p.Name != null && p.Name.ToLower().Contains(searchTerm)) ||
                        (p.Description != null && p.Description.ToLower().Contains(searchTerm)) ||
                        (p.Code != null && p.Code.ToLower().Contains(searchTerm)));
                }

                // Get total count after filtering but before pagination
                var totalCount = filteredProducts.Count();

                // Apply pagination
                var pagedProducts = filteredProducts
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                // Save to database if needed
                await SyncProductsToDatabase(allProducts);

                return ApiResponse<List<Product>>.SuccessResponse(
                    pagedProducts,
                    totalCount,
                    page,
                    pageSize,
                    "Products retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving products from Xero");
                return ApiResponse<List<Product>>.ErrorResponse($"Error retrieving products: {ex.Message}");
            }
        }

        public async Task<ApiResponse<Product>> GetProductByIdAsync(string tenantId, string xeroItemId)
        {
            try
            {
                // Check if product exists in database first
                var dbProduct = await _db.Products
                    .FirstOrDefaultAsync(p => p.XeroItemId == xeroItemId && p.SourceSystem == "Xero");

                if (dbProduct != null)
                {
                    return ApiResponse<Product>.SuccessResponse(dbProduct, "Product retrieved from database");
                }

                // If not found in database, fetch from Xero
                var token = await GetLatestXeroToken();

                var url = $"{_xeroSettings.ApiBaseUrl}/Items/{xeroItemId}";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                request.Headers.Add("Xero-Tenant-Id", tenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(request);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                    return ApiResponse<Product>.ErrorResponse($"Xero product fetch failed: {response.StatusCode}");
                }

                var jsonDoc = JsonDocument.Parse(content);
                var itemElement = jsonDoc.RootElement.GetProperty("Items")[0];
                var product = MapXeroItemToProduct(itemElement, tenantId);

                // Save to database
                await SaveProductToDatabase(product);

                return ApiResponse<Product>.SuccessResponse(product, "Product retrieved successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving product {xeroItemId} from Xero");
                return ApiResponse<Product>.ErrorResponse($"Error retrieving product: {ex.Message}");
            }
        }

        public async Task<ApiResponse<Product>> CreateProductAsync(string tenantId, Product product)
        {
            try
            {
                // Get latest token
                var token = await GetLatestXeroToken();

                // Prepare the request body
                var xeroItem = new
                {
                    Code = product.Code ?? GenerateProductCode(product.Name),
                    Name = product.Name,
                    Description = product.Description,
                    PurchaseDescription = product.PurchaseDescription,
                    PurchaseDetails = new
                    {
                        UnitPrice = product.XeroPurchaseUnitPrice,
                        TaxType = product.XeroPurchaseTaxType ?? "OUTPUT",
                        COGSAccountCode = 310
                    },
                    SalesDetails = new
                    {
                        UnitPrice = product.UnitPrice,
                        AccountCode = product.IncomeAccountId,
                        TaxType = product.XeroSalesTaxType ?? "INPUT"
                    },
                    IsTrackedAsInventory = product.IsTrackedAsInventory,
                    InventoryAssetAccountCode = product.IsTrackedAsInventory ? product.AssetAccountId : null,
                    TotalCostPool = product.IsTrackedAsInventory ? product.TotalCostPool : null,
                    QuantityOnHand = product.IsTrackedAsInventory ? product.QuantityOnHand : null,
                    IsSold = product.IsSold,
                    IsPurchased = product.IsPurchased
                };

                var json = JsonSerializer.Serialize(new { Items = new[] { xeroItem } });
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Build request
                var url = $"{_xeroSettings.ApiBaseUrl}/Items";
                var request = new HttpRequestMessage(HttpMethod.Put, url)
                {
                    Content = content
                };
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                request.Headers.Add("Xero-Tenant-Id", tenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Execute request
                var response = await _httpClient.SendAsync(request);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {responseContent}");
                    return ApiResponse<Product>.ErrorResponse($"Xero product creation failed: {response.StatusCode} - {responseContent}");
                }

                // Parse the response
                var jsonDoc = JsonDocument.Parse(responseContent);
                var createdItem = jsonDoc.RootElement.GetProperty("Items")[0];
                var createdProduct = MapXeroItemToProduct(createdItem, tenantId);

                // Save to database
                await SaveProductToDatabase(createdProduct);

                return ApiResponse<Product>.SuccessResponse(createdProduct, "Product created successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating product in Xero");
                return ApiResponse<Product>.ErrorResponse($"Error creating product: {ex.Message}");
            }
        }

        public async Task<ApiResponse<Product>> UpdateProductAsync(string tenantId, string xeroItemId, Product product)
        {
            try
            {
                // Get latest token
                var token = await GetLatestXeroToken();

                // Prepare the request body
                var xeroItem = new
                {
                    ItemID = xeroItemId,
                    Code = product.Code,
                    Name = product.Name,
                    Description = product.Description,
                    PurchaseDescription = product.PurchaseDescription,
                    PurchaseDetails = new
                    {
                        UnitPrice = product.XeroPurchaseUnitPrice,
                        AccountCode = product.XeroPurchaseAccountCode,
                        TaxType = product.XeroPurchaseTaxType ?? "NONE",
                        COGSAccountCode = product.XeroCOGSAccountCode
                    },
                    SalesDetails = new
                    {
                        UnitPrice = product.UnitPrice,
                        AccountCode = product.IncomeAccountId,
                        TaxType = product.XeroSalesTaxType ?? "NONE"
                    },
                    IsTrackedAsInventory = product.IsTrackedAsInventory,
                    InventoryAssetAccountCode = product.IsTrackedAsInventory ? product.AssetAccountId : null,
                    TotalCostPool = product.IsTrackedAsInventory ? product.TotalCostPool : null,
                    QuantityOnHand = product.IsTrackedAsInventory ? product.QuantityOnHand : null,
                    IsSold = product.IsSold,
                    IsPurchased = product.IsPurchased
                };

                var json = JsonSerializer.Serialize(new { Items = new[] { xeroItem } });
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Build request
                var url = $"{_xeroSettings.ApiBaseUrl}/Items/{xeroItemId}";
                var request = new HttpRequestMessage(HttpMethod.Post, url)
                {
                    Content = content
                };
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                request.Headers.Add("Xero-Tenant-Id", tenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Execute request
                var response = await _httpClient.SendAsync(request);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {responseContent}");
                    return ApiResponse<Product>.ErrorResponse($"Xero product update failed: {response.StatusCode} - {responseContent}");
                }

                // Parse the response
                var jsonDoc = JsonDocument.Parse(responseContent);
                var updatedItem = jsonDoc.RootElement.GetProperty("Items")[0];
                var updatedProduct = MapXeroItemToProduct(updatedItem, tenantId);

                // Update in database
                await SaveProductToDatabase(updatedProduct);

                return ApiResponse<Product>.SuccessResponse(updatedProduct, "Product updated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating product {xeroItemId} in Xero");
                return ApiResponse<Product>.ErrorResponse($"Error updating product: {ex.Message}");
            }
        }

        public async Task<ApiResponse<bool>> DeleteProductAsync(string tenantId, string xeroItemId)
        {
            try
            {
                // Get latest token
                var token = await GetLatestXeroToken();

                // Build request
                var url = $"{_xeroSettings.ApiBaseUrl}/Items/{xeroItemId}";
                var request = new HttpRequestMessage(HttpMethod.Delete, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                request.Headers.Add("Xero-Tenant-Id", tenantId);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Execute request
                var response = await _httpClient.SendAsync(request);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                    return ApiResponse<bool>.ErrorResponse($"Xero product deletion failed: {response.StatusCode} - {content}");
                }

                // Soft delete in database
                await SoftDeleteProductInDatabase(xeroItemId);

                return ApiResponse<bool>.SuccessResponse(true, "Product deleted successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting product {xeroItemId} from Xero");
                return ApiResponse<bool>.ErrorResponse($"Error deleting product: {ex.Message}");
            }
        }

        #region Helper Methods

        private async Task<XeroToken> GetLatestXeroToken()
        {
            var token = await _db.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            if (string.IsNullOrEmpty(token.AccessToken) || string.IsNullOrEmpty(token.TenantId))
            {
                _logger.LogError("Invalid Xero token data - missing access token or tenant ID");
                throw new ApplicationException("Xero access token or tenant ID is invalid.");
            }

            return token;
        }

        private Product MapXeroItemToProduct(JsonElement item, string tenantId)
        {
            var product = new Product
            {
                // Common fields
                Name = item.TryGetProperty("Name", out var name) ? name.GetString() : null,
                Description = item.TryGetProperty("Description", out var desc) ? desc.GetString() : null,
                Active = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,

                // Source tracking
                SourceSystem = "Xero",
                XeroItemId = item.TryGetProperty("ItemID", out var itemId) ? itemId.GetString() : null,
                Code = item.TryGetProperty("Code", out var code) ? code.GetString() : null,
                UpdatedDateUTC = item.TryGetProperty("UpdatedDateUTC", out var updatedDate) ?
    ParseXeroDate(updatedDate.GetString()) : (DateTime?)null,


                // Xero specific fields
                IsTrackedAsInventory = item.TryGetProperty("IsTrackedAsInventory", out var tracked) ? tracked.GetBoolean() : false,
                IsSold = item.TryGetProperty("IsSold", out var sold) ? sold.GetBoolean() : false,
                IsPurchased = item.TryGetProperty("IsPurchased", out var purchased) ? purchased.GetBoolean() : false,
                PurchaseDescription = item.TryGetProperty("PurchaseDescription", out var purchaseDesc) ? purchaseDesc.GetString() : null,
                TotalCostPool = item.TryGetProperty("TotalCostPool", out var costPool) ? costPool.GetDouble() : null,
                InventoryAssetAccountCode = item.TryGetProperty("InventoryAssetAccountCode", out var assetCode) ? assetCode.GetString() : null,

                // Type mapping
                Type = item.TryGetProperty("IsTrackedAsInventory", out var isInventory) && isInventory.GetBoolean()
                    ? "Inventory" : "Service"
            };

            // Parse QuantityOnHand
            if (item.TryGetProperty("QuantityOnHand", out var qoh) && !qoh.ValueKind.Equals(JsonValueKind.Null))
            {
                product.QuantityOnHand = (int)qoh.GetDouble();
            }

            // Parse SalesDetails
            if (item.TryGetProperty("SalesDetails", out var salesDetails))
            {
                product.UnitPrice = salesDetails.TryGetProperty("UnitPrice", out var unitPrice) ?
                    (decimal)unitPrice.GetDouble() : null;
                product.IncomeAccountId = salesDetails.TryGetProperty("AccountCode", out var accountCode) ?
                    accountCode.GetString() : null;
                product.XeroSalesTaxType = salesDetails.TryGetProperty("TaxType", out var taxType) ?
                    taxType.GetString() : null;
                product.XeroSalesUnitPrice = salesDetails.TryGetProperty("UnitPrice", out var salesUnitPrice) ?
                    salesUnitPrice.GetDouble() : null;
                product.XeroSalesAccountCode = salesDetails.TryGetProperty("AccountCode", out var salesAccountCode) ?
                    salesAccountCode.GetString() : null;
            }

            // Parse PurchaseDetails
            if (item.TryGetProperty("PurchaseDetails", out var purchaseDetails))
            {
                product.XeroPurchaseUnitPrice = purchaseDetails.TryGetProperty("UnitPrice", out var purchaseUnitPrice) ?
                    purchaseUnitPrice.GetDouble() : null;
                product.XeroPurchaseAccountCode = purchaseDetails.TryGetProperty("AccountCode", out var purchaseAccountCode) ?
                    purchaseAccountCode.GetString() : null;
                product.XeroPurchaseTaxType = purchaseDetails.TryGetProperty("TaxType", out var purchaseTaxType) ?
                    purchaseTaxType.GetString() : null;
                product.XeroCOGSAccountCode = purchaseDetails.TryGetProperty("COGSAccountCode", out var cogsCode) ?
                    cogsCode.GetString() : null;
                product.ExpenseAccountId = purchaseDetails.TryGetProperty("AccountCode", out var expenseCode) ?
                    expenseCode.GetString() : null;
            }

            return product;
        }

        private async Task SyncProductsToDatabase(List<Product> products)
        {
            using (var transaction = await _db.Database.BeginTransactionAsync())
            {
                try
                {
                    foreach (var product in products)
                    {
                        var existingProduct = await _db.Products
                            .FirstOrDefaultAsync(p => p.XeroItemId == product.XeroItemId && p.SourceSystem == "Xero");

                        if (existingProduct != null)
                        {
                            // Update each property individually, except for Id
                            existingProduct.Name = product.Name;
                            existingProduct.Description = product.Description;
                            existingProduct.UnitPrice = product.UnitPrice;
                            existingProduct.IncomeAccountId = product.IncomeAccountId;
                            existingProduct.IncomeAccountName = product.IncomeAccountName;
                            existingProduct.ExpenseAccountId = product.ExpenseAccountId;
                            existingProduct.ExpenseAccountName = product.ExpenseAccountName;
                            existingProduct.AssetAccountId = product.AssetAccountId;
                            existingProduct.AssetAccountName = product.AssetAccountName;
                            existingProduct.QuantityOnHand = product.QuantityOnHand;
                            existingProduct.InventoryStartDate = product.InventoryStartDate;
                            existingProduct.IsTrackedAsInventory = product.IsTrackedAsInventory;
                            existingProduct.IsSold = product.IsSold;
                            existingProduct.IsPurchased = product.IsPurchased;
                            existingProduct.Taxable = product.Taxable;
                            existingProduct.Active = product.Active;

                            // Don't update CreatedAt
                            existingProduct.UpdatedAt = DateTime.UtcNow;

                            // Source tracking fields
                            existingProduct.SourceSystem = product.SourceSystem;
                            existingProduct.QuickBooksItemId = product.QuickBooksItemId;
                            existingProduct.QuickBooksUserId = product.QuickBooksUserId;
                            existingProduct.SyncToken = product.SyncToken;
                            existingProduct.Type = product.Type;
                            existingProduct.XeroItemId = product.XeroItemId;
                            existingProduct.Code = product.Code;
                            existingProduct.UpdatedDateUTC = product.UpdatedDateUTC;
                            existingProduct.PurchaseDescription = product.PurchaseDescription;
                            existingProduct.TotalCostPool = product.TotalCostPool;
                            existingProduct.InventoryAssetAccountCode = product.InventoryAssetAccountCode;

                            // Flattened PurchaseDetails (Xero)
                            existingProduct.XeroPurchaseUnitPrice = product.XeroPurchaseUnitPrice;
                            existingProduct.XeroPurchaseAccountCode = product.XeroPurchaseAccountCode;
                            existingProduct.XeroPurchaseTaxType = product.XeroPurchaseTaxType;
                            existingProduct.XeroCOGSAccountCode = product.XeroCOGSAccountCode;
                            existingProduct.XeroSalesUnitPrice = product.XeroSalesUnitPrice;
                            existingProduct.XeroSalesAccountCode = product.XeroSalesAccountCode;
                            existingProduct.XeroSalesTaxType = product.XeroSalesTaxType;

                            // No need to call Update - EF Core will track the changes
                        }
                        else
                        {
                            // Set creation timestamp for new products
                            product.CreatedAt = DateTime.UtcNow;
                            product.UpdatedAt = DateTime.UtcNow;

                            // Add new product
                            await _db.Products.AddAsync(product);
                        }
                    }

                    await _db.SaveChangesAsync();
                    await transaction.CommitAsync();
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError(ex, "Error syncing products to database");
                    throw;
                }
            }
        }

        private async Task SaveProductToDatabase(Product product)
        {
            var existingProduct = await _db.Products
                .FirstOrDefaultAsync(p => p.XeroItemId == product.XeroItemId && p.SourceSystem == "Xero");

            if (existingProduct != null)
            {
                // Manually update each property, excluding Id
                existingProduct.Name = product.Name;
                existingProduct.Description = product.Description;
                existingProduct.UnitPrice = product.UnitPrice;

                existingProduct.IncomeAccountId = product.IncomeAccountId;
                existingProduct.IncomeAccountName = product.IncomeAccountName;
                existingProduct.ExpenseAccountId = product.ExpenseAccountId;
                existingProduct.ExpenseAccountName = product.ExpenseAccountName;
                existingProduct.AssetAccountId = product.AssetAccountId;
                existingProduct.AssetAccountName = product.AssetAccountName;

                existingProduct.QuantityOnHand = product.QuantityOnHand;
                existingProduct.InventoryStartDate = product.InventoryStartDate;

                existingProduct.IsTrackedAsInventory = product.IsTrackedAsInventory;
                existingProduct.IsSold = product.IsSold;
                existingProduct.IsPurchased = product.IsPurchased;
                existingProduct.Taxable = product.Taxable;
                existingProduct.Active = product.Active;

                existingProduct.SourceSystem = product.SourceSystem;
                existingProduct.QuickBooksItemId = product.QuickBooksItemId;
                existingProduct.QuickBooksUserId = product.QuickBooksUserId;
                existingProduct.SyncToken = product.SyncToken;
                existingProduct.Type = product.Type;
                existingProduct.XeroItemId = product.XeroItemId;
                existingProduct.Code = product.Code;

                existingProduct.UpdatedDateUTC = product.UpdatedDateUTC;
                existingProduct.PurchaseDescription = product.PurchaseDescription;
                existingProduct.TotalCostPool = product.TotalCostPool;
                existingProduct.InventoryAssetAccountCode = product.InventoryAssetAccountCode;

                existingProduct.XeroPurchaseUnitPrice = product.XeroPurchaseUnitPrice;
                existingProduct.XeroPurchaseAccountCode = product.XeroPurchaseAccountCode;
                existingProduct.XeroPurchaseTaxType = product.XeroPurchaseTaxType;
                existingProduct.XeroCOGSAccountCode = product.XeroCOGSAccountCode;

                existingProduct.XeroSalesUnitPrice = product.XeroSalesUnitPrice;
                existingProduct.XeroSalesAccountCode = product.XeroSalesAccountCode;
                existingProduct.XeroSalesTaxType = product.XeroSalesTaxType;

                // Update timestamp
                existingProduct.UpdatedAt = DateTime.UtcNow;
            }
            else
            {


                // Add new product
                product.CreatedAt = DateTime.UtcNow;
                product.UpdatedAt = DateTime.UtcNow;
                await _db.Products.AddAsync(product);
            }

            await _db.SaveChangesAsync();
        }


        private async Task SoftDeleteProductInDatabase(string xeroItemId)
        {
            var existingProduct = await _db.Products
                .FirstOrDefaultAsync(p => p.XeroItemId == xeroItemId && p.SourceSystem == "Xero");

            if (existingProduct != null)
            {
                existingProduct.Active = false;
                existingProduct.UpdatedAt = DateTime.UtcNow;
                await _db.SaveChangesAsync();
            }
        }

        private string GenerateProductCode(string productName)
        {
            if (string.IsNullOrEmpty(productName))
                return $"PROD-{DateTime.UtcNow.Ticks.ToString().Substring(10)}";

            // Create a code from the first letters of each word in the name
            var words = productName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (words.Length > 1)
            {
                var code = string.Join("", words.Select(w => w[0])).ToUpper();
                return $"{code}-{DateTime.UtcNow.Ticks.ToString().Substring(10)}";
            }

            // If only one word, use the first 3-4 characters
            var prefix = productName.Length > 3 ? productName.Substring(0, 4) : productName;
            return $"{prefix.ToUpper()}-{DateTime.UtcNow.Ticks.ToString().Substring(10)}";
        }

        private DateTime? ParseXeroDate(string dateString)
        {
            if (string.IsNullOrEmpty(dateString) || !dateString.StartsWith("/Date(") || !dateString.EndsWith(")/"))
                return null;

            try
            {
                // Extract the timestamp in milliseconds
                var timestamp = dateString.Substring(6, dateString.Length - 8);
                var milliseconds = long.Parse(timestamp.Split('+')[0]); // Ignore timezone offset
                return DateTimeOffset.FromUnixTimeMilliseconds(milliseconds).UtcDateTime;
            }
            catch
            {
                return null; // Return null if parsing fails
            }
        }




        #endregion
    }
}
