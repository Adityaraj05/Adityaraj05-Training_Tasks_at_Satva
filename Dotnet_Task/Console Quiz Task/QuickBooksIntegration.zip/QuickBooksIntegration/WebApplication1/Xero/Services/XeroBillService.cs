﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xero.Interface;

namespace Xero.Services
{
    public class XeroBillService : IXeroBillService
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _db;
        private readonly ILogger<XeroBillService> _logger;
        private readonly XeroSettings _xeroSettings;
        private readonly string _apiBaseUrl;

        public XeroBillService(
            HttpClient httpClient,
            ApplicationDbContext db,
            ILogger<XeroBillService> logger,
            IOptions<XeroSettings> xeroSettings)
        {
            _httpClient = httpClient;
            _db = db;
            _logger = logger;
            _xeroSettings = xeroSettings.Value;
            _apiBaseUrl = _xeroSettings.ApiBaseUrl;
        }

        public async Task<List<Bill>> FetchBillsFromXeroAsync()
        {
            _logger.LogInformation("Starting Xero bills fetch process...");

            // Get the most recent token from database
            var token = await GetMostRecentXeroTokenAsync();

            // Create the request
            var url = $"{_apiBaseUrl}/Invoices?where=Type==\"ACCPAY\"";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
            request.Headers.Add("Xero-Tenant-Id", token.TenantId);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Send the request
            _logger.LogInformation("Sending request to Xero API...");
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero bills fetch failed: {response.StatusCode} - {content}");
            }

            _logger.LogInformation("Xero API request successful, processing response...");

            // Parse the response
            var jsonDoc = JsonDocument.Parse(content);
            var jsonResponse = jsonDoc.RootElement;

            // Process bills
            var bills = ProcessXeroBillsResponse(jsonResponse, token.TenantId);

            _logger.LogInformation($"Successfully processed {bills.Count} bills from Xero");

            using (var transaction = await _db.Database.BeginTransactionAsync())
            {
                try
                {
                    // Remove existing Xero bills for this tenant
                    _logger.LogInformation($"Removing existing Xero bills for tenant {token.TenantId}");
                    var existingBills = await _db.Bills
                        .Where(b => b.XeroTenantId == token.TenantId && b.CompanySource == "Xero")
                        .ToListAsync();

                    if (existingBills.Any())
                    {
                        _db.Bills.RemoveRange(existingBills);
                        await _db.SaveChangesAsync();
                    }

                    // Add new bills to database
                    _logger.LogInformation($"Adding {bills.Count} new Xero bills to database");
                    await _db.Bills.AddRangeAsync(bills);
                    await _db.SaveChangesAsync();

                    await transaction.CommitAsync();
                    _logger.LogInformation("Successfully updated Xero bills in database");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError(ex, "Error saving Xero bills to database");
                    throw new ApplicationException($"Error saving Xero bills: {ex.Message}", ex);
                }
            }

            return bills;
        }


        public async Task<(List<Bill> Bills, int TotalCount)> GetBillsFromDatabaseAsync(BillQueryParameters parameters)
        {
            _logger.LogInformation($"Retrieving Xero bills from database for tenant {parameters.TenantId}");

            var query = _db.Bills.AsQueryable()
                .Where(b => b.XeroTenantId == parameters.TenantId && b.CompanySource == "Xero");

            // Apply filters
            if (!string.IsNullOrWhiteSpace(parameters.SearchTerm))
            {
                query = query.Where(b =>
                    (b.InvoiceNumber != null && b.InvoiceNumber.Contains(parameters.SearchTerm)) ||
                    (b.Reference != null && b.Reference.Contains(parameters.SearchTerm)) ||
                    (b.VendorName != null && b.VendorName.Contains(parameters.SearchTerm))
                );
            }

            if (!string.IsNullOrWhiteSpace(parameters.Status))
            {
                query = query.Where(b => b.Status == parameters.Status);
            }

            if (parameters.FromDate.HasValue)
            {
                query = query.Where(b => b.Date >= parameters.FromDate);
            }

            if (parameters.ToDate.HasValue)
            {
                query = query.Where(b => b.Date <= parameters.ToDate);
            }

            // Get total count for pagination
            var totalCount = await query.CountAsync();

            // Apply sorting
            query = parameters.SortBy?.ToLower() switch
            {
                "invoicenumber" => parameters.SortAscending
                    ? query.OrderBy(b => b.InvoiceNumber)
                    : query.OrderByDescending(b => b.InvoiceNumber),
                "duedate" => parameters.SortAscending
                    ? query.OrderBy(b => b.DueDate)
                    : query.OrderByDescending(b => b.DueDate),
                "total" => parameters.SortAscending
                    ? query.OrderBy(b => b.Total)
                    : query.OrderByDescending(b => b.Total),
                "amountdue" => parameters.SortAscending
                    ? query.OrderBy(b => b.AmountDue)
                    : query.OrderByDescending(b => b.AmountDue),
                "vendorname" => parameters.SortAscending
                    ? query.OrderBy(b => b.VendorName)
                    : query.OrderByDescending(b => b.VendorName),
                "status" => parameters.SortAscending
                    ? query.OrderBy(b => b.Status)
                    : query.OrderByDescending(b => b.Status),
                _ => parameters.SortAscending
                    ? query.OrderBy(b => b.Date)
                    : query.OrderByDescending(b => b.Date), // Default sort by date
            };

            // Apply pagination
            var bills = await query
                .Skip((parameters.PageNumber - 1) * parameters.PageSize)
                .Take(parameters.PageSize)
                .Include(b => b.LineItems)
                .ToListAsync();

            return (bills, totalCount);
        }


        public async Task<Bill> GetBillByIdAsync(string billId)
        {
            _logger.LogInformation($"Retrieving Xero bill with ID {billId}");

            var bill = await _db.Bills
                .Include(b => b.LineItems)
                .FirstOrDefaultAsync(b => b.XeroBillId == billId && b.CompanySource == "Xero");

            if (bill == null)
            {
                _logger.LogWarning($"No Xero bill found with ID {billId}");
                throw new ApplicationException($"Xero bill with ID {billId} not found.");
            }

            return bill;
        }


        public async Task<Bill> CreateBillAsync(XeroBillDto billDto)
        {
            _logger.LogInformation("Creating new Xero bill");

            // Get token
            var token = await GetMostRecentXeroTokenAsync();

            // Create the request payload
            var requestObj = new
            {
                Invoices = new[] { billDto }
            };

            var jsonContent = JsonSerializer.Serialize(requestObj);

            // Create the HTTP request
            var url = $"{_apiBaseUrl}/Invoices";
            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
            request.Headers.Add("Xero-Tenant-Id", token.TenantId);
            request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Send the request
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero bill creation failed: {response.StatusCode} - {content}");
            }

            // Parse the response
            var jsonDoc = JsonDocument.Parse(content);
            var jsonResponse = jsonDoc.RootElement;

            // Extract the bill from the response
            var createdBill = ParseSingleBillFromResponse(jsonResponse, token.TenantId);

            // Save to database
            await _db.Bills.AddAsync(createdBill);
            await _db.SaveChangesAsync();

            return createdBill;
        }


        public async Task<Bill> UpdateBillAsync(string billId, XeroBillDto billDto)
        {
            _logger.LogInformation($"Updating Xero bill with ID {billId}");

            // Ensure billDto has the correct ID
            billDto.Id = billId;

            // Get token
            var token = await GetMostRecentXeroTokenAsync();

            // Check if bill exists
            var existingBill = await _db.Bills
                .Include(b => b.LineItems)
                .FirstOrDefaultAsync(b => b.XeroBillId == billId && b.CompanySource == "Xero");

            if (existingBill == null)
            {
                _logger.LogWarning($"No Xero bill found with ID {billId}");
                throw new ApplicationException($"Xero bill with ID {billId} not found.");
            }

            // Create the request payload
            var requestObj = new
            {
                Invoices = new[] { billDto }
            };

            var jsonContent = JsonSerializer.Serialize(requestObj);

            // Create the HTTP request
            var url = $"{_apiBaseUrl}/Invoices/{billId}";
            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
            request.Headers.Add("Xero-Tenant-Id", token.TenantId);
            request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Send the request
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero bill update failed: {response.StatusCode} - {content}");
            }

            // Parse the response
            var jsonDoc = JsonDocument.Parse(content);
            var jsonResponse = jsonDoc.RootElement;

            // Extract the updated bill from the response
            var updatedBill = ParseSingleBillFromResponse(jsonResponse, token.TenantId);

            // Update existing record
            _db.BillLineItems.RemoveRange(existingBill.LineItems);

            // Copy updated values
            existingBill.InvoiceNumber = updatedBill.InvoiceNumber;
            existingBill.Reference = updatedBill.Reference;
            existingBill.ContactId = updatedBill.ContactId;
            existingBill.VendorName = updatedBill.VendorName;
            existingBill.Date = updatedBill.Date;
            existingBill.DueDate = updatedBill.DueDate;
            existingBill.Status = updatedBill.Status;
            existingBill.LineAmountTypes = updatedBill.LineAmountTypes;
            existingBill.CurrencyCode = updatedBill.CurrencyCode;
            existingBill.SubTotal = updatedBill.SubTotal;
            existingBill.TotalTax = updatedBill.TotalTax;
            existingBill.Total = updatedBill.Total;
            existingBill.AmountDue = updatedBill.AmountDue;
            existingBill.AmountPaid = updatedBill.AmountPaid;
            existingBill.CurrencyRate = updatedBill.CurrencyRate;
            existingBill.UpdatedAt = DateTime.UtcNow;
            existingBill.XeroUpdateTime = updatedBill.XeroUpdateTime;

            // Add line items
            foreach (var lineItem in updatedBill.LineItems)
            {
                lineItem.BillId = existingBill.Id;
                existingBill.LineItems.Add(lineItem);
            }

            await _db.SaveChangesAsync();

            return existingBill;
        }

        public async Task<bool> DeleteBillAsync(string billId)
        {
            _logger.LogInformation($"Soft deleting (VOIDING) Xero bill with ID {billId}");

            // Get token
            var token = await GetMostRecentXeroTokenAsync();

            // Find the bill
            var bill = await _db.Bills
                .FirstOrDefaultAsync(b => b.XeroBillId == billId && b.CompanySource == "Xero");

            if (bill == null)
            {
                _logger.LogWarning($"No Xero bill found with ID {billId}");
                throw new ApplicationException($"Xero bill with ID {billId} not found.");
            }

            // First, get the current bill data from Xero to ensure we have all required fields
            var getUrl = $"{_apiBaseUrl}/Invoices/{billId}";
            var getRequest = new HttpRequestMessage(HttpMethod.Get, getUrl);
            getRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
            getRequest.Headers.Add("Xero-Tenant-Id", token.TenantId);

            var getResponse = await _httpClient.SendAsync(getRequest);
            if (!getResponse.IsSuccessStatusCode)
            {
                var errorContent = await getResponse.Content.ReadAsStringAsync();
                _logger.LogError($"Failed to get bill from Xero: {getResponse.StatusCode}, Content: {errorContent}");
                throw new ApplicationException($"Couldn't retrieve Xero bill with ID {billId}: {getResponse.StatusCode} - {errorContent}");
            }

            var billData = await getResponse.Content.ReadAsStringAsync();

            try
            {
                // Parse the response to get the invoice details
                using JsonDocument doc = JsonDocument.Parse(billData);
                var invoiceElement = doc.RootElement.GetProperty("Invoices")[0];

                // Build the request object with only necessary fields for voiding
                var requestObj = new
                {
                    Invoices = new[] {
                new {
                    InvoiceID = billId,
                    Status = "VOIDED",
                    // Use the exact DateString format from the response
                    Date = invoiceElement.GetProperty("DateString").GetString(),
                    DueDate = invoiceElement.GetProperty("DueDateString").GetString()
                }
            }
                };

                var jsonContent = JsonSerializer.Serialize(requestObj, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                // Create the HTTP request
                var url = $"{_apiBaseUrl}/Invoices/{billId}";
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                request.Headers.Add("Xero-Tenant-Id", token.TenantId);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                // Send the request
                var response = await _httpClient.SendAsync(request);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                    throw new ApplicationException($"Xero bill deletion failed: {response.StatusCode} - {content}");
                }

                // Update the database record
                bill.Status = "VOIDED";
                bill.UpdatedAt = DateTime.UtcNow;
                await _db.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing Xero bill void: {ex.Message}");
                throw new ApplicationException($"Failed to void Xero bill: {ex.Message}", ex);
            }
        }



        #region Helper Methods


        private async Task<XeroToken> GetMostRecentXeroTokenAsync()
        {
            var token = await _db.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            if (string.IsNullOrEmpty(token.AccessToken) || string.IsNullOrEmpty(token.TenantId))
            {
                _logger.LogError("Invalid Xero token data - missing access token or tenant ID");
                throw new ApplicationException("Xero access token or tenant ID is invalid.");
            }

            return token;
        }


        private List<Bill> ProcessXeroBillsResponse(JsonElement jsonResponse, string tenantId)
        {
            var bills = new List<Bill>();

            if (jsonResponse.TryGetProperty("Invoices", out JsonElement invoicesElement))
            {
                foreach (var invoiceElement in invoicesElement.EnumerateArray())
                {
                    try
                    {
                        var bill = new Bill
                        {
                            CompanySource = "Xero",
                            XeroTenantId = tenantId,
                            CreatedAt = DateTime.UtcNow,
                            UpdatedAt = DateTime.UtcNow
                        };

                        // Extract bill properties
                        if (invoiceElement.TryGetProperty("InvoiceID", out JsonElement idElement))
                            bill.XeroBillId = idElement.GetString();

                        if (invoiceElement.TryGetProperty("InvoiceNumber", out JsonElement invNumberElement))
                            bill.InvoiceNumber = invNumberElement.GetString();

                        if (invoiceElement.TryGetProperty("Reference", out JsonElement refElement))
                            bill.Reference = refElement.GetString();

                        if (invoiceElement.TryGetProperty("Type", out JsonElement typeElement))
                            bill.Status = typeElement.GetString(); // Using Type field for status

                        if (invoiceElement.TryGetProperty("Status", out JsonElement statusElement))
                            bill.Status = statusElement.GetString();

                        if (invoiceElement.TryGetProperty("LineAmountTypes", out JsonElement lineAmountTypesElement))
                            bill.LineAmountTypes = lineAmountTypesElement.GetString();

                        // Extract financial information
                        if (invoiceElement.TryGetProperty("SubTotal", out JsonElement subTotalElement))
                            bill.SubTotal = subTotalElement.GetDecimal();

                        if (invoiceElement.TryGetProperty("TotalTax", out JsonElement totalTaxElement))
                            bill.TotalTax = totalTaxElement.GetDecimal();

                        if (invoiceElement.TryGetProperty("Total", out JsonElement totalElement))
                            bill.Total = totalElement.GetDecimal();

                        if (invoiceElement.TryGetProperty("AmountDue", out JsonElement amountDueElement))
                            bill.AmountDue = amountDueElement.GetDecimal();

                        if (invoiceElement.TryGetProperty("AmountPaid", out JsonElement amountPaidElement))
                            bill.AmountPaid = amountPaidElement.GetDecimal();

                        if (invoiceElement.TryGetProperty("AmountCredited", out JsonElement amountCreditedElement))
                            bill.AmountCredited = amountCreditedElement.GetDecimal();

                        if (invoiceElement.TryGetProperty("CurrencyRate", out JsonElement currencyRateElement))
                            bill.CurrencyRate = currencyRateElement.GetDecimal();

                        if (invoiceElement.TryGetProperty("CurrencyCode", out JsonElement currencyCodeElement))
                            bill.CurrencyCode = currencyCodeElement.GetString();

                        // Extract dates
                        if (invoiceElement.TryGetProperty("DateString", out JsonElement dateElement))
                        {
                            if (DateTime.TryParse(dateElement.GetString(), out DateTime date))
                                bill.Date = date;
                        }

                        if (invoiceElement.TryGetProperty("DueDateString", out JsonElement dueDateElement))
                        {
                            if (DateTime.TryParse(dueDateElement.GetString(), out DateTime dueDate))
                                bill.DueDate = dueDate;
                        }

                        if (invoiceElement.TryGetProperty("UpdatedDateUTC", out JsonElement updatedDateElement))
                        {
                            if (DateTime.TryParse(updatedDateElement.GetString(), out DateTime updatedDate))
                                bill.XeroUpdateTime = updatedDate;
                        }

                        // Extract contact (vendor) information
                        if (invoiceElement.TryGetProperty("Contact", out JsonElement contactElement))
                        {
                            if (contactElement.TryGetProperty("ContactID", out JsonElement contactIdElement))
                                bill.ContactId = contactIdElement.GetString();

                            if (contactElement.TryGetProperty("Name", out JsonElement contactNameElement))
                                bill.VendorName = contactNameElement.GetString();
                        }

                        // Extract has attachments flag
                        if (invoiceElement.TryGetProperty("HasAttachments", out JsonElement hasAttachmentsElement))
                            bill.HasAttachments = hasAttachmentsElement.GetBoolean();

                        // Check if paid
                        bill.Paid = bill.AmountDue == 0 && bill.Total > 0;

                        // Extract line items
                        if (invoiceElement.TryGetProperty("LineItems", out JsonElement lineItemsElement))
                        {
                            foreach (var lineItemElement in lineItemsElement.EnumerateArray())
                            {
                                var lineItem = new BillLineItem
                                {
                                    // Default values
                                    Quantity = 1
                                };

                                if (lineItemElement.TryGetProperty("LineItemID", out JsonElement lineItemIdElement))
                                    lineItem.XeroLineId = lineItemIdElement.GetString();

                                if (lineItemElement.TryGetProperty("Description", out JsonElement descriptionElement))
                                    lineItem.Description = descriptionElement.GetString();

                                if (lineItemElement.TryGetProperty("Quantity", out JsonElement quantityElement))
                                    lineItem.Quantity = quantityElement.GetDecimal();

                                if (lineItemElement.TryGetProperty("UnitAmount", out JsonElement unitAmountElement))
                                    lineItem.UnitPrice = unitAmountElement.GetDecimal();

                                if (lineItemElement.TryGetProperty("LineAmount", out JsonElement lineAmountElement))
                                    lineItem.Amount = lineAmountElement.GetDecimal();

                                if (lineItemElement.TryGetProperty("AccountCode", out JsonElement accountCodeElement))
                                    lineItem.AccountId = accountCodeElement.GetString();

                                if (lineItemElement.TryGetProperty("ItemCode", out JsonElement itemCodeElement))
                                    lineItem.ItemId = itemCodeElement.GetString();

                                if (lineItemElement.TryGetProperty("TaxType", out JsonElement taxTypeElement))
                                    lineItem.TaxType = taxTypeElement.GetString();

                                if (lineItemElement.TryGetProperty("TaxAmount", out JsonElement taxAmountElement))
                                    lineItem.TaxAmount = taxAmountElement.GetDecimal();

                                // Add the line item to the bill
                                bill.LineItems.Add(lineItem);
                            }
                        }

                        bills.Add(bill);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error processing Xero bill from API response");
                        // Continue processing other bills
                    }
                }
            }

            return bills;
        }


        private Bill ParseSingleBillFromResponse(JsonElement jsonResponse, string tenantId)
        {
            // Get the first invoice from the response
            if (jsonResponse.TryGetProperty("Invoices", out JsonElement invoicesElement) &&
                invoicesElement.GetArrayLength() > 0)
            {
                // Use the ProcessXeroBillsResponse method to parse the bill
                var bills = ProcessXeroBillsResponse(jsonResponse, tenantId);

                if (bills.Count > 0)
                {
                    return bills[0];
                }
            }

            throw new ApplicationException("Failed to parse Xero bill from API response");
        }

        #endregion
    }
}
