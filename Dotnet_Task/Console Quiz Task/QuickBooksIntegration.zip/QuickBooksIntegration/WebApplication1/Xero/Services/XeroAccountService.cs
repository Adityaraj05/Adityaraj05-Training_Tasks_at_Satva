﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Data_Access_Layer.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xero.Interface;

namespace Xero.Services
{
    public class XeroAccountService : IXeroAccountService
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _db;
        private readonly ILogger<XeroAccountService> _logger;
        private readonly AccountMappingService _mappingService;
        private readonly XeroSettings _xeroSettings;


        public XeroAccountService(
            HttpClient httpClient,
            ApplicationDbContext db,
            ILogger<XeroAccountService> logger,
              IOptions<XeroSettings> xeroSettings,
            AccountMappingService mappingService)
        {
            _httpClient = httpClient;
            _db = db;
            _logger = logger;
            _mappingService = mappingService;
            _xeroSettings = xeroSettings.Value;
        }

        public async Task<List<ChartOfAccount>> FetchAccountsFromXeroAsync()
        {
            _logger.LogInformation("Starting Xero accounts fetch process...");

            // Get the most recent token from database
            var token = await _db.XeroTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
            {
                _logger.LogError("No valid Xero token found in database");
                throw new ApplicationException("Xero access token not found.");
            }

            if (string.IsNullOrEmpty(token.AccessToken) || string.IsNullOrEmpty(token.TenantId))
            {
                _logger.LogError("Invalid Xero token data - missing access token or tenant ID");
                throw new ApplicationException("Xero access token or tenant ID is invalid.");
            }

            var accessToken = token.AccessToken;
            var tenantId = token.TenantId;

            _logger.LogInformation($"Using tenantId: {tenantId}");

            // Create the request
            var url = $"{_xeroSettings.ApiBaseUrl}/Accounts";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            request.Headers.Add("Xero-Tenant-Id", tenantId);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Send the request
            _logger.LogInformation("Sending request to Xero API...");
            var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Xero API request failed: {response.StatusCode}, Content: {content}");
                throw new ApplicationException($"Xero accounts fetch failed: {response.StatusCode} - {content}");
            }

            _logger.LogInformation("Xero API request successful, processing response...");

            // Parse the response
            var jsonDoc = JsonDocument.Parse(content);
            var jsonResponse = jsonDoc.RootElement;

            // Process accounts using the mapping service
            var accounts = _mappingService.ProcessXeroResponse(jsonResponse, tenantId);

            _logger.LogInformation($"Successfully processed {accounts.Count} accounts from Xero");

            using (var transaction = await _db.Database.BeginTransactionAsync())
            {
                try
                {
                    // Remove existing Xero accounts for this tenant
                    _logger.LogInformation($"Removing existing Xero accounts for tenant {tenantId}");
                    var existingAccounts = await _db.ChartOfAccounts
                        .Where(c => c.QuickBooksUserId == tenantId && c.CompanySource == "Xero")
                        .ToListAsync();

                    if (existingAccounts.Any())
                    {
                        _db.ChartOfAccounts.RemoveRange(existingAccounts);
                        await _db.SaveChangesAsync();
                    }

                    // Add new accounts to database
                    _logger.LogInformation($"Adding {accounts.Count} new Xero accounts to database");
                    await _db.ChartOfAccounts.AddRangeAsync(accounts);
                    await _db.SaveChangesAsync();

                    await transaction.CommitAsync();
                    _logger.LogInformation("Successfully updated Xero accounts in database");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError(ex, "Error saving Xero accounts to database");
                    throw new ApplicationException($"Error saving Xero accounts: {ex.Message}", ex);
                }
            }

            return accounts;
        }

        public async Task<List<ChartOfAccount>> GetAccountsFromDatabaseAsync(
            string tenantId,
            int page = 1,
            int pageSize = 10,
            string searchTerm = null)
        {
            _logger.LogInformation($"Retrieving Xero accounts from database for tenant {tenantId}");

            var query = _db.ChartOfAccounts
                .Where(c => c.QuickBooksUserId == tenantId && c.CompanySource == "Xero");

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                string likeTerm = $"%{searchTerm}%";
                query = query.Where(c =>
                    EF.Functions.Like(c.Name, likeTerm) ||
                    EF.Functions.Like(c.AccountType, likeTerm) ||
                    (c.AccountSubType != null && EF.Functions.Like(c.AccountSubType, likeTerm)) ||
                    (c.Classification != null && EF.Functions.Like(c.Classification, likeTerm))
                );
            }

            return await query
                .OrderBy(c => c.Name)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }
    }
}

