﻿using CsvHelper;
using CsvHelper.Configuration;
using Data_Access_Layer.Models.Import;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickBooks.Helpher
{
    public class CsvValidationHelper
    {
        public async Task<List<ValidationError>> ValidateCsvFile(IFormFile file)
        {
            var errors = new List<ValidationError>();

            if (file == null || file.Length == 0)
            {
                errors.Add(new ValidationError { RowNumber = 0, Message = "File is empty or not provided." });
                return errors;
            }

            if (!file.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
            {
                errors.Add(new ValidationError { RowNumber = 0, Message = "File is not a CSV format." });
                return errors;
            }

            try
            {
                // Check for required columns and data format validity
                using (var reader = new StreamReader(file.OpenReadStream()))
                using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
                {
                    // Validate header row exists
                    var hasHeader = csv.Read() && csv.ReadHeader();
                    if (!hasHeader)
                    {
                        errors.Add(new ValidationError { RowNumber = 0, Message = "CSV file does not have a valid header row." });
                        return errors;
                    }

                    // Validate required column headers exist
                    var headers = csv.HeaderRecord;
                    var requiredColumns = new[] { "InvoiceNumber", "CustomerName", "InvoiceDate", "DueDate", "ItemName", "Quantity", "Rate" };

                    foreach (var column in requiredColumns)
                    {
                        if (!headers.Contains(column))
                        {
                            errors.Add(new ValidationError { RowNumber = 0, Message = $"Required column '{column}' is missing." });
                        }
                    }

                    if (errors.Any())
                        return errors;

                    // Validate each row
                    int rowNumber = 1;
                    var invoiceNumbers = new HashSet<string>();

                    while (csv.Read())
                    {
                        rowNumber++;

                        // Check for empty required fields
                        foreach (var column in requiredColumns)
                        {
                            if (string.IsNullOrWhiteSpace(csv.GetField(column)))
                            {
                                errors.Add(new ValidationError { RowNumber = rowNumber, Message = $"Required field '{column}' is empty." });
                            }
                        }

                        // Check for duplicate invoice numbers
                        var invoiceNumber = csv.GetField("InvoiceNumber");
                        if (!string.IsNullOrWhiteSpace(invoiceNumber))
                        {
                            if (!invoiceNumbers.Add(invoiceNumber))
                            {
                                errors.Add(new ValidationError { RowNumber = rowNumber, Message = $"Duplicate InvoiceNumber '{invoiceNumber}'." });
                            }
                        }

                        // Validate date formats
                        if (!string.IsNullOrWhiteSpace(csv.GetField("InvoiceDate")) &&
                            !DateTime.TryParse(csv.GetField("InvoiceDate"), out _))
                        {
                            errors.Add(new ValidationError { RowNumber = rowNumber, Message = "Invalid InvoiceDate format." });
                        }

                        if (!string.IsNullOrWhiteSpace(csv.GetField("DueDate")) &&
                            !DateTime.TryParse(csv.GetField("DueDate"), out _))
                        {
                            errors.Add(new ValidationError { RowNumber = rowNumber, Message = "Invalid DueDate format." });
                        }

                        // Validate numeric fields
                        if (!string.IsNullOrWhiteSpace(csv.GetField("Quantity")) &&
                            !decimal.TryParse(csv.GetField("Quantity"), out _))
                        {
                            errors.Add(new ValidationError { RowNumber = rowNumber, Message = "Quantity must be a valid number." });
                        }

                        if (!string.IsNullOrWhiteSpace(csv.GetField("Rate")) &&
                            !decimal.TryParse(csv.GetField("Rate"), out _))
                        {
                            errors.Add(new ValidationError { RowNumber = rowNumber, Message = "Rate must be a valid number." });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errors.Add(new ValidationError { RowNumber = 0, Message = $"Error processing CSV file: {ex.Message}" });
            }

            return errors;
        }
    }
}
