﻿using Data_Access_Layer.Models.Import;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickBooks.Interface
{
    public interface ICsvImportService
    {
        Task<CsvImportResult> ProcessCsvFile(IFormFile file);
        Task<List<ValidationError>> ValidateCsvFile(IFormFile file);
    }
}
