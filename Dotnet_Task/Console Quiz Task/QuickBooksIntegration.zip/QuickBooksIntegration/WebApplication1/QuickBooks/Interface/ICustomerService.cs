﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickBooks.Interface
{
    public interface ICustomerService
    {
        Task<object> FetchCustomersFromDbPaginated(int page, int pageSize, string searchTerm, string? source);
        Task<List<Customer>> FetchCustomersFromQuickBooks();
        Task<Customer> AddCustomer(CustomerDto customerDto);
        Task<Customer> UpdateCustomer(int id, CustomerDto customerDto);
        Task<bool> DeleteCustomer(string id);
    }
}
