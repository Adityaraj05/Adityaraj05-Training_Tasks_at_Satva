﻿using Data_Access_Layer.Models;
using QuickBooks.DTOs;


namespace QuickBooks.Interface
{
    public interface IAuthService
    {
        public string GetLoginUrl();
        Task<ApiResponse> ExchangeCode(ExchangeRequest request);
        Task<ApiResponse> RefreshToken(RefreshTokenRequest request);
        Task<ApiResponse> GetCurrentToken(string realmId);
        Task<ApiResponse>Logout();
      
    }
}
