﻿using Data_Access_Layer.Models;
using QuickBooks.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickBooks.Interface
{
    public interface IProductQbService
    {
        Task<ApiResponse> FetchProductsFromQuickBooks();
        Task<ApiResponse> SendProductToQuickBooks(int id);
        Task<ApiResponse> GetAllProducts(int pageNumber = 1, int pageSize = 10, string search = null, string source = null,
         bool includeInactive = false);

        Task<ApiResponse> CreateProduct(Product product);
        Task<ApiResponse> GetProduct(int id);

        Task<ApiResponse> UpdateProduct(int id, Product productUpdate);

        Task<ApiResponse> UpdateProductInQuickBooks(int id);
        Task<ApiResponse> DeactivateProduct(int id);
        Task<ApiResponse> MakeProductInactive(string quickBooksItemId);
        Task<List<ApiResponse>> GetAccountsByType(string accountType);



    }
}
