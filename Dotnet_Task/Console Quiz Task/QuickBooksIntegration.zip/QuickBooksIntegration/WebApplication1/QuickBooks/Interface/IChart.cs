﻿using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Mvc;
using QuickBooks.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickBooks.Interface
{
    public interface IChart
    {
        Task<ApiResponse> FetchChartOfAccountsFromQuickBooks();

    }
}
