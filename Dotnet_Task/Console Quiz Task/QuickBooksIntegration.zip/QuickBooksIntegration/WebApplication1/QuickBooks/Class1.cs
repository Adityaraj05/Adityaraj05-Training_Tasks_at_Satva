﻿namespace QuickBooks
{
    public class Class1
    {

    }
}
