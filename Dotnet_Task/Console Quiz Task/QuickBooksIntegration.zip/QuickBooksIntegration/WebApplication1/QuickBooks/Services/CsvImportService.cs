﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models.DTO;
using Data_Access_Layer.Models.Import;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using QuickBooks.Interface;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using CsvHelper.Configuration;
using CsvHelper;
using QuickBooks.Helpher;

namespace QuickBooks.Services
{
    public class CsvImportService : ICsvImportService
    {
        private readonly ApplicationDbContext _context;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogger<CsvImportService> _logger;
        private readonly Helpher.QbHelpher _quickBooksHelper;
        private readonly Helpher.CsvValidationHelper _csvValidationHelper;

        public CsvImportService(
            ApplicationDbContext context,
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration,
            ILogger<CsvImportService> logger,
            QbHelpher quickBooksHelper)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _logger = logger;
            _quickBooksHelper = quickBooksHelper;
            _csvValidationHelper = new Helpher.CsvValidationHelper();
        }

        public async Task<List<ValidationError>> ValidateCsvFile(IFormFile file)
        {
            return await _csvValidationHelper.ValidateCsvFile(file);
        }

        public async Task<CsvImportResult> ProcessCsvFile(IFormFile file)
        {
            var result = new CsvImportResult();
            var validationErrors = await ValidateCsvFile(file);

            if (validationErrors.Any())
            {
                result.Success = false;
                result.Errors = validationErrors.Select(e => $"Row {e.RowNumber}: {e.Message}").ToList();
                return result;
            }

            try
            {
                // Get the valid token and realmId using the enhanced QuickBooksHelper
                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();

                // Dictionary to track invoices by their invoice number
                var invoiceTracker = new Dictionary<string, bool>();

                using (var reader = new StreamReader(file.OpenReadStream()))
                using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
                {
                    // Read and process all records
                    var records = csv.GetRecords<InvoiceCsvModel>().ToList();
                    result.TotalRows = records.Count;

                    // Group records by invoice number to process multiple line items together
                    var invoiceGroups = records.GroupBy(r => r.InvoiceNumber);

                    foreach (var invoiceGroup in invoiceGroups)
                    {
                        var invoiceNumber = invoiceGroup.Key;
                        var invoiceItems = invoiceGroup.ToList();
                        var firstRecord = invoiceItems.First();

                        // Process customer
                        var qbCustomerId = await EnsureCustomerExists(accessToken, realmId, firstRecord.CustomerName, firstRecord.CustomerEmail);
                        if (!string.IsNullOrEmpty(qbCustomerId))
                        {
                            // Process each line item to ensure items exist
                            var lineItems = new List<Dictionary<string, object>>();

                            foreach (var item in invoiceItems)
                            {
                                var qbItemId = await EnsureItemExists(accessToken, realmId, item.ItemName, item.ItemDescription, decimal.Parse(item.Rate));
                                if (!string.IsNullOrEmpty(qbItemId))
                                {
                                    decimal quantity = decimal.Parse(item.Quantity);
                                    decimal rate = decimal.Parse(item.Rate);

                                    lineItems.Add(new Dictionary<string, object>
                            {
                                { "DetailType", "SalesItemLineDetail" },
                                { "Amount", quantity * rate },
                                { "Description", item.ItemDescription ?? item.ItemName },
                                { "SalesItemLineDetail", new Dictionary<string, object>
                                    {
                                        { "ItemRef", new Dictionary<string, string> { { "value", qbItemId } } },
                                        { "Qty", quantity },
                                        { "UnitPrice", rate }
                                    }
                                }
                            });
                                }
                            }

                            // Check if this invoice already exists in QuickBooks
                            var existingInvoice = await GetInvoiceByDocNumber(accessToken, realmId, invoiceNumber);
                            DateTime invoiceDate = DateTime.Parse(firstRecord.InvoiceDate);
                            DateTime dueDate = DateTime.Parse(firstRecord.DueDate);

                            if (existingInvoice != null)
                            {
                                // Update existing invoice
                                await UpdateInvoiceInQuickBooks(accessToken, realmId, existingInvoice, qbCustomerId, invoiceNumber, invoiceDate, dueDate, lineItems);
                                result.UpdatedInvoices++;
                            }
                            else
                            {
                                // Create new invoice
                                await CreateInvoiceInQuickBooks(accessToken, realmId, qbCustomerId, invoiceNumber, invoiceDate, dueDate, lineItems);
                                result.CreatedInvoices++;
                            }
                        }

                        result.ProcessedRows += invoiceItems.Count;
                    }
                }

                result.Success = true;
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing CSV file");
                result.Success = false;
                result.Errors.Add($"Error processing CSV file: {ex.Message}");
                return result;
            }
        }

        private async Task<string> EnsureCustomerExists(string accessToken, string realmId, string customerName, string customerEmail)
        {
            try
            {
                // Get authenticated client
                var httpClient = await _quickBooksHelper.GetAuthenticatedClient();

                // Check if the customer exists in QuickBooks
                string escapedName = customerName.Replace("'", "\\'");
                string query = $"SELECT * FROM Customer WHERE DisplayName = '{escapedName}'";
                string url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query={Uri.EscapeDataString(query)}";

                var response = await httpClient.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error querying customer: {content}");
                    return null;
                }

                var jsonResponse = JObject.Parse(content);
                var customerArray = jsonResponse["QueryResponse"]?["Customer"] as JArray;

                if (customerArray != null && customerArray.Count > 0)
                {
                    // Customer exists, return ID
                    return customerArray[0]["Id"].ToString();
                }
                else
                {
                    // Customer doesn't exist, create a new one
                    var customerPayload = new
                    {
                        DisplayName = customerName,
                        PrimaryEmailAddr = !string.IsNullOrEmpty(customerEmail) ? new { Address = customerEmail } : null
                    };

                    var jsonContent = new StringContent(JsonConvert.SerializeObject(customerPayload), Encoding.UTF8, "application/json");
                    var createResponse = await httpClient.PostAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/customer", jsonContent);
                    var createContent = await createResponse.Content.ReadAsStringAsync();

                    if (!createResponse.IsSuccessStatusCode)
                    {
                        _logger.LogError($"Error creating customer: {createContent}");
                        return null;
                    }

                    var createResult = JObject.Parse(createContent);
                    string customerId = createResult["Customer"]["Id"].ToString();

                    // Save the new customer to our local database
                    await SaveCustomerToLocalDb(customerId, realmId, customerName, customerEmail);

                    return customerId;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error ensuring customer exists: {customerName}");
                return null;
            }
        }

        private async Task SaveCustomerToLocalDb(string quickBooksCustomerId, string realmId, string displayName, string email)
        {
            try
            {
                var quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                var customer = new Customer
                {
                    QuickBooksCustomerId = quickBooksCustomerId,
                    QuickBooksUserId = quickBooksUserId,
                    DisplayName = displayName,
                    CompanyName = displayName,
                    Email = email,
                    Active = true,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _context.Customers.Add(customer);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error saving customer to local DB: {displayName}");
            }
        }

        private async Task<string> EnsureItemExists(string accessToken, string realmId, string itemName, string itemDescription, decimal unitPrice)
        {
            try
            {
                // Check if the item exists in QuickBooks
                string escapedName = itemName.Replace("'", "\\'");
                string query = $"SELECT * FROM Item WHERE Name = '{escapedName}'";
                string url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query={Uri.EscapeDataString(query)}";

                var httpClient = _httpClientFactory.CreateClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await httpClient.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error querying item: {content}");
                    return null;
                }

                var jsonResponse = JObject.Parse(content);
                var itemArray = jsonResponse["QueryResponse"]?["Item"] as JArray;

                if (itemArray != null && itemArray.Count > 0)
                {
                    // Item exists, return ID
                    return itemArray[0]["Id"].ToString();
                }
                else
                {
                    // Item doesn't exist, create a new one
                    // Get the default income account ID from configuration
                    var incomeAccountId = _configuration["QuickBooks:DefaultIncomeAccountId"] ?? "1";

                    var itemPayload = new
                    {
                        Name = itemName,
                        Description = itemDescription ?? itemName,
                        Type = "Service",
                        IncomeAccountRef = new { value = incomeAccountId },
                        UnitPrice = unitPrice,
                        Taxable = false
                    };

                    var jsonContent = new StringContent(JsonConvert.SerializeObject(itemPayload), Encoding.UTF8, "application/json");
                    var createResponse = await httpClient.PostAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item", jsonContent);
                    var createContent = await createResponse.Content.ReadAsStringAsync();

                    if (!createResponse.IsSuccessStatusCode)
                    {
                        _logger.LogError($"Error creating item: {createContent}");
                        return null;
                    }

                    var createResult = JObject.Parse(createContent);
                    string itemId = createResult["Item"]["Id"].ToString();

                    // Save the new item to our local database
                    await SaveItemToLocalDb(itemId, itemName, itemDescription, unitPrice);


                    return itemId;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error ensuring item exists: {itemName}");
                return null;
            }
        }

        private async Task SaveItemToLocalDb(string qbItemId, string name, string description, decimal unitPrice)
        {
            try
            {
                // Get the default income account ID from configuration
                var incomeAccountId = _configuration["QuickBooks:DefaultIncomeAccountId"] ?? "1";

                var product = new Product
                {
                    QuickBooksItemId = qbItemId,
                    Name = name,
                    Description = description ?? name,
                    UnitPrice = unitPrice,
                    IncomeAccountId = incomeAccountId,  // Add this line
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _context.Products.Add(product);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error saving item to local DB: {name}");
            }
        }

        private async Task<JObject> GetInvoiceByDocNumber(string accessToken, string realmId, string docNumber)
        {
            try
            {
                string escapedDocNumber = docNumber.Replace("'", "\\'");
                string query = $"SELECT * FROM Invoice WHERE DocNumber = '{escapedDocNumber}'";
                string url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query={Uri.EscapeDataString(query)}";

                var httpClient = _httpClientFactory.CreateClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await httpClient.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error querying invoice: {content}");
                    return null;
                }

                var jsonResponse = JObject.Parse(content);
                var invoiceArray = jsonResponse["QueryResponse"]?["Invoice"] as JArray;

                if (invoiceArray != null && invoiceArray.Count > 0)
                {
                    return invoiceArray[0].ToObject<JObject>();
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting invoice by doc number: {docNumber}");
                return null;
            }
        }

        private async Task CreateInvoiceInQuickBooks(string accessToken, string realmId, string customerId, string docNumber, DateTime invoiceDate, DateTime dueDate, List<Dictionary<string, object>> lineItems)
        {
            try
            {
                var invoicePayload = new
                {
                    DocNumber = docNumber,
                    CustomerRef = new { value = customerId },
                    TxnDate = invoiceDate.ToString("yyyy-MM-dd"),
                    DueDate = dueDate.ToString("yyyy-MM-dd"),
                    Line = lineItems
                };

                var jsonContent = new StringContent(JsonConvert.SerializeObject(invoicePayload), Encoding.UTF8, "application/json");

                var httpClient = _httpClientFactory.CreateClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var createResponse = await httpClient.PostAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice", jsonContent);
                var createContent = await createResponse.Content.ReadAsStringAsync();

                if (!createResponse.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error creating invoice: {createContent}");
                    return;
                }

                var createResult = JObject.Parse(createContent);
                int qbInvoiceId = createResult["Invoice"]["Id"].ToObject<int>();
                decimal totalAmount = createResult["Invoice"]["TotalAmt"].ToObject<decimal>();

                // Save to local database
                await SaveInvoiceToLocalDb(qbInvoiceId, int.Parse(customerId), docNumber, invoiceDate, dueDate, totalAmount, lineItems);

                // For consistency, also refresh the customer balance after creating a new invoice
                await RefreshCustomerBalanceInQuickBooks(accessToken, realmId, customerId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error creating invoice in QuickBooks: {docNumber}");
            }
        }
        private async Task UpdateInvoiceInQuickBooks(string accessToken, string realmId, JObject existingInvoice, string customerId, string docNumber, DateTime invoiceDate, DateTime dueDate, List<Dictionary<string, object>> lineItems)
        {
            try
            {
                string invoiceId = existingInvoice["Id"].ToString();
                string syncToken = existingInvoice["SyncToken"].ToString();

                // Calculate the new total amount for the invoice
                decimal newTotalAmount = lineItems.Sum(li => (decimal)li["Amount"]);

                var invoicePayload = new
                {
                    Id = invoiceId,
                    SyncToken = syncToken,
                    DocNumber = docNumber,
                    CustomerRef = new { value = customerId },
                    TxnDate = invoiceDate.ToString("yyyy-MM-dd"),
                    DueDate = dueDate.ToString("yyyy-MM-dd"),
                    Line = lineItems
                };

                var jsonContent = new StringContent(JsonConvert.SerializeObject(invoicePayload), Encoding.UTF8, "application/json");

                var httpClient = _httpClientFactory.CreateClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var updateResponse = await httpClient.PostAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice?operation=update", jsonContent);
                var updateContent = await updateResponse.Content.ReadAsStringAsync();

                if (!updateResponse.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error updating invoice: {updateContent}");
                    return;
                }

                var updateResult = JObject.Parse(updateContent);
                int qbInvoiceId = updateResult["Invoice"]["Id"].ToObject<int>();
                decimal totalAmount = updateResult["Invoice"]["TotalAmt"].ToObject<decimal>();

                // Update in local database
                await UpdateInvoiceInLocalDb(qbInvoiceId, int.Parse(customerId), docNumber, invoiceDate, dueDate, totalAmount, lineItems);

                // After updating the invoice, refresh the customer balance by fetching the latest customer data
                await RefreshCustomerBalanceInQuickBooks(accessToken, realmId, customerId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating invoice in QuickBooks: {docNumber}");
            }
        }

        // Add this new method to refresh customer balance after invoice operations
        private async Task RefreshCustomerBalanceInQuickBooks(string accessToken, string realmId, string customerId)
        {
            try
            {
                // Fetch the customer to get their current data including balance
                string url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/customer/{customerId}";

                var httpClient = _httpClientFactory.CreateClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await httpClient.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Error refreshing customer balance: {content}");
                    return;
                }

                // The get operation should force QuickBooks to recalculate the customer's balance
                // We don't need to do anything else, as QuickBooks should handle the balance computation

                _logger.LogInformation($"Successfully refreshed customer {customerId} balance in QuickBooks");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error refreshing customer balance for customer ID {customerId}");
            }
        }
        private async Task SaveInvoiceToLocalDb(int invoiceId, int customerId, string docNumber, DateTime invoiceDate, DateTime dueDate, decimal totalAmount, List<Dictionary<string, object>> lineItems)
        {
            try
            {
                var invoice = new Invoice
                {
                    InvoiceId = invoiceId,
                    CustomerId = customerId,
                    InvoiceDate = invoiceDate,
                    DueDate = dueDate,
                    Store = docNumber, // Using docNumber as store reference
                    BillingAddress = string.Empty, // Not available in CSV
                    Subtotal = totalAmount,
                    Total = totalAmount,
                    SendLater = false,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _context.Invoices.Add(invoice);
                await _context.SaveChangesAsync();

                // Add line items
                foreach (var line in lineItems)
                {
                    var itemRef = ((Dictionary<string, object>)line["SalesItemLineDetail"])["ItemRef"] as Dictionary<string, string>;
                    var productId = itemRef["value"];
                    var description = line["Description"]?.ToString();
                    var quantity = (decimal)((Dictionary<string, object>)line["SalesItemLineDetail"])["Qty"];
                    var rate = (decimal)((Dictionary<string, object>)line["SalesItemLineDetail"])["UnitPrice"];
                    var amount = (decimal)line["Amount"];

                    var lineItem = new InvoiceLineItem
                    {
                        LineId = Guid.NewGuid().ToString(),
                        InvoiceId = invoice.Id,
                        ProductId = productId,
                        Description = description,
                        Quantity = (int)quantity,
                        Rate = rate,
                        Amount = amount
                    };

                    _context.InvoiceLineItem.Add(lineItem);
                }

                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error saving invoice to local DB: {invoiceId}");
            }
        }

        private async Task UpdateInvoiceInLocalDb(int invoiceId, int customerId, string docNumber, DateTime invoiceDate, DateTime dueDate, decimal totalAmount, List<Dictionary<string, object>> lineItems)
        {
            try
            {
                var existingInvoice = await _context.Invoices.FirstOrDefaultAsync(i => (int)i.InvoiceId == invoiceId);

                if (existingInvoice == null)
                {
                    // If the invoice doesn't exist in our local DB, create it
                    await SaveInvoiceToLocalDb(invoiceId, customerId, docNumber, invoiceDate, dueDate, totalAmount, lineItems);
                    return;
                }

                // Update existing invoice
                existingInvoice.CustomerId = customerId;
                existingInvoice.InvoiceDate = invoiceDate;
                existingInvoice.DueDate = dueDate;
                existingInvoice.Store = docNumber;
                existingInvoice.Subtotal = totalAmount;
                existingInvoice.Total = totalAmount;
                existingInvoice.UpdatedAt = DateTime.UtcNow;

                // Remove old line items
                var oldLineItems = _context.InvoiceLineItem.Where(li => li.InvoiceId == existingInvoice.Id);
                _context.InvoiceLineItem.RemoveRange(oldLineItems);

                // Add new line items
                foreach (var line in lineItems)
                {
                    var itemRef = ((Dictionary<string, object>)line["SalesItemLineDetail"])["ItemRef"] as Dictionary<string, string>;
                    var productId = itemRef["value"];
                    var description = line["Description"]?.ToString();
                    var quantity = (decimal)((Dictionary<string, object>)line["SalesItemLineDetail"])["Qty"];
                    var rate = (decimal)((Dictionary<string, object>)line["SalesItemLineDetail"])["UnitPrice"];
                    var amount = (decimal)line["Amount"];

                    var lineItem = new InvoiceLineItem
                    {
                        LineId = Guid.NewGuid().ToString(),
                        InvoiceId = existingInvoice.Id,
                        ProductId = productId,
                        Description = description,
                        Quantity = (int)quantity,
                        Rate = rate,
                        Amount = amount
                    };

                    _context.InvoiceLineItem.Add(lineItem);
                }

                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating invoice in local DB: {invoiceId}");
                throw;
            }
        }
    }
}
