﻿using Data_Access_Layer.Models;
using Data_Access_Layer.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace QuickBooks.Services
{
    public class QuickBooksService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly AccountMappingService _mappingService;
        private readonly string _apiBaseUrl;

        public QuickBooksService(HttpClient httpClient, IConfiguration configuration, AccountMappingService mappingService)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _mappingService = mappingService;
            _apiBaseUrl = _configuration["QuickBooks:ApiBaseUrl"] ?? "https://quickbooks.api.intuit.com/v3";
        }

        public async Task<List<ChartOfAccount>> FetchAccountsFromQuickBooks()
        {
            // Set up authentication for QuickBooks API
            string accessToken = await GetQuickBooksAccessToken();
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            // Get company ID from configuration
            string companyId = _configuration["QuickBooks:CompanyId"];

            var response = await _httpClient.GetAsync($"{_apiBaseUrl}/company/{companyId}/account/queryall");
            // Make the API call to QuickBooks

            if (!response.IsSuccessStatusCode)
            {
                string errorContent = await response.Content.ReadAsStringAsync();
                throw new Exception($"Failed to fetch accounts from QuickBooks: {response.StatusCode}, Details: {errorContent}");
            }

            var content = await response.Content.ReadAsStringAsync();
            var jsonResponse = JsonDocument.Parse(content).RootElement;

            // Get current user ID
            string userId = "current-user-id"; // Replace with actual user ID retrieval

            // Process the response
            return _mappingService.ProcessQuickBooksResponse(jsonResponse, userId);
        }

        private async Task<string> GetQuickBooksAccessToken()
        {
            // Implementation depends on how you're managing QuickBooks OAuth
            // Could be stored in a database, retrieved from a token service, etc.
            string clientId = _configuration["QuickBooks:ClientId"];
            string clientSecret = _configuration["QuickBooks:ClientSecret"];
            string refreshToken = _configuration["QuickBooks:RefreshToken"];

            // This would typically use refresh token to get new access token
            // For simplicity, we'll just return a configured value
            return _configuration["QuickBooks:AccessToken"];
        }
    }
}
