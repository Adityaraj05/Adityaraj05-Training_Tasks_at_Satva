﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using QuickBooks.DTOs;
using QuickBooks.Interface;
using System.Net.Http.Headers;
using System.Text.Json;

using Data_Access_Layer.Interface;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;





namespace QuickBooks.Services
{
    public class ChartService: IChart
    {
        private readonly IConfiguration _config;
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<ChartService> _logger;


        public ChartService(IConfiguration config, HttpClient httpClient, ILogger<ChartService> logger, ApplicationDbContext dbContext)
        {
            _config = config;
            _httpClient = httpClient;
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<ApiResponse> FetchChartOfAccountsFromQuickBooks()
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = "No QuickBooks token found.",
                        Data = null
                    };
                }

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                {
                    return new ApiResponse
                    {
                        Status = 400,
                        Message = "Missing access token or realm ID.",
                        Data = null
                    };
                }

                _logger.LogInformation("Fetching data from QuickBooks API.");
                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query=SELECT * FROM Account";

                var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(httpRequest);
                var json = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    return new ApiResponse
                    {
                        Status = (int)response.StatusCode,
                        Message = "QuickBooks API error.",
                        Data = json
                    };
                }

                var parsedAccounts = ParseAccountData(json, tokenRecord.QuickBooksUserId);

                using (var transaction = await _dbContext.Database.BeginTransactionAsync())
                {
                    try
                    {
                        _logger.LogInformation("Removing all existing chart of accounts data.");
                        _dbContext.ChartOfAccounts.RemoveRange(_dbContext.ChartOfAccounts);
                        await _dbContext.SaveChangesAsync();

                        _logger.LogInformation($"Adding {parsedAccounts.Count()} accounts from QuickBooks.");
                        await _dbContext.ChartOfAccounts.AddRangeAsync(parsedAccounts);
                        await _dbContext.SaveChangesAsync();

                        await transaction.CommitAsync();

                        _logger.LogInformation("Successfully refreshed chart of accounts data.");
                        return new ApiResponse
                        {
                            Status = 200,
                            Message = "Chart of accounts successfully fetched and saved.",
                            Data = parsedAccounts
                        };
                    }
                    catch (Exception ex)
                    {
                        await transaction.RollbackAsync();
                        _logger.LogError(ex, "Error processing QuickBooks data.");
                        return new ApiResponse
                        {
                            Status = 500,
                            Message = $"Error processing QuickBooks data: {ex.Message}",
                            Data = null
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching accounts from QuickBooks.");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Error fetching accounts from QuickBooks: {ex.Message}",
                    Data = null
                };
            }
        }
        private List<ChartOfAccount> ParseAccountData(string json, string quickBooksUserId)
        {
            var result = new List<ChartOfAccount>();

            using (JsonDocument document = JsonDocument.Parse(json))
            {
                var root = document.RootElement;

                if (root.TryGetProperty("QueryResponse", out JsonElement queryResponse) &&
                    queryResponse.TryGetProperty("Account", out JsonElement accounts))
                {
                    foreach (JsonElement acc in accounts.EnumerateArray())
                    {
                        var account = new ChartOfAccount
                        {
                            QuickBooksAccountId = GetJsonPropertyValue(acc, "Id"),
                            Name = GetJsonPropertyValue(acc, "Name"),
                            AccountType = GetJsonPropertyValue(acc, "AccountType"),
                            AccountSubType = GetJsonPropertyValue(acc, "AccountSubType"),
                            Classification = GetJsonPropertyValue(acc, "Classification"),
                            QuickBooksUserId = quickBooksUserId,
                            CreatedAt = DateTime.UtcNow
                        };

                        // Handle nullable decimal
                        if (acc.TryGetProperty("CurrentBalance", out JsonElement balanceElement) &&
                            balanceElement.ValueKind != JsonValueKind.Null)
                        {
                            account.CurrentBalance = balanceElement.GetDecimal();
                        }

                        // Handle CurrencyRef
                        if (acc.TryGetProperty("CurrencyRef", out JsonElement currencyRef))
                        {
                            account.CurrencyRef = new CurrencyRef
                            {
                                Value = GetJsonPropertyValue(currencyRef, "value"),
                                Name = GetJsonPropertyValue(currencyRef, "name")
                            };

                            // Update the flattened properties
                            account.UpdateCurrencyRefProperties();
                        }

                        result.Add(account);
                    }
                }
            }

            return result;
        }

        private string GetJsonPropertyValue(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property) &&
                property.ValueKind != JsonValueKind.Null)
            {
                return property.GetString();
            }

            return null;
        }

    }
}
