﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.Extensions.Configuration;
using QuickBooks.Interface;
using System.Text;
using System.Text.Json;
using System.Web;

using QuickBooks.DTOs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace QuickBooks.Services
{
    public class AuthService : IAuthService
    {
        private readonly IConfiguration _config;
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<AuthService> _logger;


        public AuthService(IConfiguration config, HttpClient httpClient, ILogger<AuthService> logger, ApplicationDbContext dbContext)
        {
            _config = config;
            _httpClient = httpClient;
            _dbContext = dbContext;
            _logger = logger;
        }

        public string GetLoginUrl()
        {
            var clientId = _config["QuickBooks:ClientId"];
            var redirectUri = _config["QuickBooks:RedirectUri"];
            var scope = "com.intuit.quickbooks.accounting openid profile email phone address";

            var query = HttpUtility.ParseQueryString(string.Empty);
            query["client_id"] = clientId;
            query["redirect_uri"] = redirectUri;
            query["response_type"] = "code";
            query["scope"] = scope;
            query["state"] = Guid.NewGuid().ToString();

            var authUrl = $"https://appcenter.intuit.com/connect/oauth2?{query}";

            return authUrl;
        }

        public async Task<ApiResponse> ExchangeCode(ExchangeRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Code) || string.IsNullOrWhiteSpace(request.RealmId))
            {
                throw new Exception("Code or RealmId is missing.");
            }

            try
            {
                var clientId = _config["QuickBooks:ClientId"];
                var clientSecret = _config["QuickBooks:ClientSecret"];
                var redirectUri = _config["QuickBooks:RedirectUri"];

                var httpClient = new HttpClient();
                var authHeader = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));

                var postData = new Dictionary<string, string>
                {
                    { "grant_type", "authorization_code" },
                    { "code", request.Code },
                    { "redirect_uri", redirectUri }
                };

                var httpRequest = new HttpRequestMessage(HttpMethod.Post, "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer")
                {
                    Headers = { { "Authorization", $"Basic {authHeader}" } },
                    Content = new FormUrlEncodedContent(postData)
                };

                var response = await httpClient.SendAsync(httpRequest);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Token exchange failed: " + content);
                }

                var tokenData = JsonSerializer.Deserialize<TokenResponse>(content);

                if (tokenData == null)
                {
                    throw new Exception("Token data could not be parsed.");
                }

                var quickBooksUserId = ExtractSubClaimFromIdToken(tokenData.IdToken);

                var token = new QuickBooksToken
                {
                    QuickBooksUserId = quickBooksUserId,
                    RealmId = request.RealmId,
                    AccessToken = tokenData.AccessToken,
                    RefreshToken = tokenData.RefreshToken,
                    IdToken = tokenData.IdToken,
                    TokenType = tokenData.TokenType,
                    ExpiresIn = tokenData.ExpiresIn,
                    XRefreshTokenExpiresIn = tokenData.XRefreshTokenExpiresIn,
                    CreatedAt = DateTime.UtcNow
                };

                _dbContext.QuickBooksTokens.Add(token);
                await _dbContext.SaveChangesAsync();

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Token exchanged successfully.",
                    Data = new
                    {
                        token.AccessToken,
                        token.RefreshToken,
                        token.IdToken,
                        token.TokenType,
                        token.ExpiresIn,
                        token.XRefreshTokenExpiresIn,
                        token.CreatedAt
                    }
                };                  ;
            }
            catch (Exception ex)
            {
                throw new Exception("Internal server error: " + ex.Message);
            }
        }
        private string ExtractSubClaimFromIdToken(string idToken)
        {
            if (string.IsNullOrWhiteSpace(idToken) || idToken.Split('.').Length < 2)
                return null;

            try
            {
                var payload = idToken.Split('.')[1];
                var padded = PadBase64(payload);
                var jsonBytes = Convert.FromBase64String(padded);
                var json = Encoding.UTF8.GetString(jsonBytes);

                using var doc = JsonDocument.Parse(json);

                if (doc.RootElement.TryGetProperty("sub", out JsonElement subElement))
                {
                    return subElement.GetString();
                }

                return null;
            }
            catch
            {
                return null; // Optionally log the error for debugging
            }
        }
        private string PadBase64(string base64)
        {
            return base64.PadRight(base64.Length + (4 - base64.Length % 4) % 4, '=');
        }


        public async Task<ApiResponse> RefreshToken( RefreshTokenRequest request)
        {
            _logger.LogInformation("Starting token refresh process...");

            if (string.IsNullOrWhiteSpace(request.RefreshToken) || string.IsNullOrWhiteSpace(request.RealmId))
            {
                _logger.LogWarning("Missing refresh token or realm ID.");
                return new ApiResponse
                {
                    Status = 400,
                    Message = "Refresh token or RealmId is missing.",
                    Data = null
                };
            }

            try
            {
                var clientId = _config["QuickBooks:ClientId"];
                var clientSecret = _config["QuickBooks:ClientSecret"];

                _logger.LogInformation("Preparing HTTP request to QuickBooks token refresh endpoint...");

                var httpClient = new HttpClient();
                var authHeader = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));

                var postData = new Dictionary<string, string>
                {
                    { "grant_type", "refresh_token" },
                    { "refresh_token", request.RefreshToken }
                };

                var httpRequest = new HttpRequestMessage(HttpMethod.Post, "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer")
                {
                    Headers = { { "Authorization", $"Basic {authHeader}" } },
                    Content = new FormUrlEncodedContent(postData)
                };

                var response = await httpClient.SendAsync(httpRequest);
                var content = await response.Content.ReadAsStringAsync();

                _logger.LogInformation("QuickBooks token refresh response: {Response}", content);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Token refresh failed: {StatusCode} - {Content}", response.StatusCode, content);
                    throw new Exception("Token refresh failed: " + content);
                }

                var tokenData = JsonSerializer.Deserialize<TokenResponse>(content);

                if (tokenData == null)
                {
                    _logger.LogError("Failed to deserialize token response.");

                    return new ApiResponse
                    {
                        Status = 500,
                        Message = "Failed to deserialize token response.",
                        Data = null
                    };
                }

                // Find the existing token record for this user and realm
                var existingToken = await _dbContext.QuickBooksTokens
                    .Where(t => t.RealmId == request.RealmId)
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (existingToken == null)
                {
                    _logger.LogWarning("No existing token found for realm ID: {RealmId}", request.RealmId);

                }

                // Update the token with new values
                existingToken.AccessToken = tokenData.AccessToken;
                existingToken.RefreshToken = tokenData.RefreshToken;
                existingToken.IdToken = tokenData.IdToken;
                existingToken.TokenType = tokenData.TokenType;
                existingToken.ExpiresIn = tokenData.ExpiresIn;
                existingToken.XRefreshTokenExpiresIn = tokenData.XRefreshTokenExpiresIn;
                existingToken.UpdatedAt = DateTime.UtcNow;

                await _dbContext.SaveChangesAsync();

                _logger.LogInformation("Token successfully refreshed and updated in database with ID: {TokenId}", existingToken.Id);

                return new ApiResponse
                {
                    Status = 200,
                    Data = new
                    {
                        existingToken.Id,
                        existingToken.AccessToken,
                        existingToken.RefreshToken,
                        existingToken.ExpiresIn,
                        existingToken.XRefreshTokenExpiresIn
                    },
                };  
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred during token refresh.");
                return new ApiResponse
                {
                    Status = 500,
                    Message = "Internal server error: " + ex.Message,
                    Data = null
                };
            }
        }


        public async Task<ApiResponse> GetCurrentToken(string realmId)
        {
            if (string.IsNullOrWhiteSpace(realmId))
            {
                return new ApiResponse
                {
                    Status = 400,
                    Message = "RealmId is missing.",
                    Data = null
                };
            }

            try
            {
                var token = await _dbContext.QuickBooksTokens
                    .Where(t => t.RealmId == realmId)
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (token == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = $"No token found for realm ID: {realmId}",
                        Data = null
                    };
                }

                var tokenAge = DateTime.UtcNow - token.CreatedAt;
                var isExpired = tokenAge.TotalSeconds >= token.ExpiresIn;
                var isNearExpiry = tokenAge.TotalSeconds >= (token.ExpiresIn - 300); // 5 minutes before expiry

                if (isExpired)
                {
                    return new ApiResponse
                    {
                        Status = 401,
                        Message = "Token has already expired. Please login again.",
                        Data = null
                    };
                }

                if (isNearExpiry)
                {
                    _logger.LogInformation("Access token is near expiry. Refreshing...");

                    var refreshedToken = await RefreshAccessTokenAsync(token.RefreshToken, realmId);
                    if (refreshedToken == null)
                    {
                        return new ApiResponse
                        {
                            Status = 500,
                            Message = "Failed to refresh token.",
                            Data = null
                        };
                    }

                    token = refreshedToken; // update the token for response
                }

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Token retrieved successfully.",
                    Data = new
                    {
                        tokenId = token.Id,
                        accessToken = token.AccessToken,
                        refreshToken = token.RefreshToken,
                        expiresIn = token.ExpiresIn,
                        isExpired = false,
                        createdAt = token.CreatedAt
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving current token");
                return new ApiResponse
                {
                    Status = 500,
                    Message = "Internal server error: " + ex.Message,
                    Data = null
                };
            }
        }

        private async Task<QuickBooksToken> RefreshAccessTokenAsync(string refreshToken, string realmId)
        {
            try
            {
                var clientId = _config["QuickBooks:ClientId"];
                var clientSecret = _config["QuickBooks:ClientSecret"];

                var httpClient = new HttpClient();
                var authHeader = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));

                var postData = new Dictionary<string, string>
        {
            { "grant_type", "refresh_token" },
            { "refresh_token", refreshToken }
        };

                var httpRequest = new HttpRequestMessage(HttpMethod.Post, "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer")
                {
                    Headers = { { "Authorization", $"Basic {authHeader}" } },
                    Content = new FormUrlEncodedContent(postData)
                };

                var response = await httpClient.SendAsync(httpRequest);
                var content = await response.Content.ReadAsStringAsync();

                _logger.LogInformation("QuickBooks token refresh response: {Response}", content);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Token refresh failed: {StatusCode} - {Content}", response.StatusCode, content);
                    return null;
                }

                var tokenData = JsonSerializer.Deserialize<TokenResponse>(content);
                if (tokenData == null)
                {
                    _logger.LogError("Failed to deserialize token response.");
                    return null;
                }

                var existingToken = await _dbContext.QuickBooksTokens
                    .Where(t => t.RealmId == realmId)
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (existingToken == null)
                {
                    _logger.LogWarning("No existing token found for realm ID during refresh: {RealmId}", realmId);
                    return null;
                }

                existingToken.AccessToken = tokenData.AccessToken;
                existingToken.RefreshToken = tokenData.RefreshToken;
                existingToken.IdToken = tokenData.IdToken;
                existingToken.TokenType = tokenData.TokenType;
                existingToken.ExpiresIn = tokenData.ExpiresIn;
                existingToken.XRefreshTokenExpiresIn = tokenData.XRefreshTokenExpiresIn;
                existingToken.UpdatedAt = DateTime.UtcNow;

                await _dbContext.SaveChangesAsync();

                _logger.LogInformation("Token successfully refreshed and updated in database with ID: {TokenId}", existingToken.Id);

                return existingToken;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during token refresh.");
                return null;
            }
        }

        public async Task<ApiResponse> Logout()
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = "No QuickBooks token found.",
                        Data = null
                    };
                }

                var quickBooksUserId = tokenRecord.QuickBooksUserId;

                var accountsToDelete = await _dbContext.ChartOfAccounts
                    .Where(c => c.QuickBooksUserId == quickBooksUserId)
                    .ToListAsync();

                int accountsDeleted = 0;
                if (accountsToDelete.Any())
                {
                    _dbContext.ChartOfAccounts.RemoveRange(accountsToDelete);
                    accountsDeleted = accountsToDelete.Count;
                }

                var customersToDelete = await _dbContext.Customers
                    .Where(c => c.QuickBooksUserId == quickBooksUserId)
                    .ToListAsync();

                int customersDeleted = 0;
                if (customersToDelete.Any())
                {
                    _dbContext.Customers.RemoveRange(customersToDelete);
                    customersDeleted = customersToDelete.Count;
                }

                _dbContext.QuickBooksTokens.Remove(tokenRecord);

                await _dbContext.SaveChangesAsync();

                _logger.LogInformation($"Deleted {accountsDeleted} Chart of Accounts and {customersDeleted} Customers for QuickBooksUserId: {quickBooksUserId}.");

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Token and associated data deleted successfully.",
                    Data = new
                    {
                        tokenId = tokenRecord.Id,
                        accountsDeleted,
                        customersDeleted
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during logout and data cleanup.");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Error during logout and deletion: {ex.Message}",
                    Data = null
                };
            }
        }

    }
}
