﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace QuickBooks.Services
{
    public class TokenRefreshService
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<TokenRefreshService> _logger;
        private readonly IConfiguration _config;

        public TokenRefreshService(
            HttpClient httpClient,
            ApplicationDbContext dbContext,
            ILogger<TokenRefreshService> logger,
            IConfiguration config)
        {
            _httpClient = httpClient;
            _dbContext = dbContext;
            _logger = logger;
            _config = config;
        }

        public async Task<string> ValidateAndRefreshTokenIfNeeded()
        {
            try
            {
                _logger.LogInformation("Validating QuickBooks token...");

                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                {
                    _logger.LogWarning("No QuickBooks token found in the database.");
                    throw new Exception("No QuickBooks token found.");
                }

                // Check if token is expired
                var tokenAge = DateTime.UtcNow - tokenRecord.CreatedAt;
                var isExpired = tokenAge.TotalSeconds >= tokenRecord.ExpiresIn;

                if (!isExpired)
                {
                    _logger.LogInformation("Token is still valid, no refresh needed.");
                    return tokenRecord.AccessToken;
                }

                _logger.LogInformation("Token expired. Refreshing token...");
                return await RefreshToken(tokenRecord);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating/refreshing token");
                throw;
            }
        }

        private async Task<string> RefreshToken(QuickBooksToken tokenRecord)
        {
            var clientId = _config["QuickBooks:ClientId"];
            var clientSecret = _config["QuickBooks:ClientSecret"];

            _logger.LogInformation("Preparing HTTP request to QuickBooks token refresh endpoint...");

            var authHeader = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));

            var postData = new Dictionary<string, string>
            {
                { "grant_type", "refresh_token" },
                { "refresh_token", tokenRecord.RefreshToken }
            };

            var httpRequest = new HttpRequestMessage(HttpMethod.Post, "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer")
            {
                Headers = { { "Authorization", $"Basic {authHeader}" } },
                Content = new FormUrlEncodedContent(postData)
            };

            var response = await _httpClient.SendAsync(httpRequest);
            var content = await response.Content.ReadAsStringAsync();

            _logger.LogInformation("QuickBooks token refresh response received.");

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Token refresh failed: {StatusCode} - {Content}", response.StatusCode, content);
                throw new Exception($"Token refresh failed: {content}");
            }

            var tokenData = JsonSerializer.Deserialize<TokenResponse>(content);

            if (tokenData == null)
            {
                _logger.LogError("Failed to deserialize token response.");
                throw new Exception("Token data could not be parsed.");
            }

            // Update token record
            tokenRecord.AccessToken = tokenData.AccessToken;
            tokenRecord.RefreshToken = tokenData.RefreshToken;
            tokenRecord.IdToken = tokenData.IdToken;
            tokenRecord.TokenType = tokenData.TokenType;
            tokenRecord.ExpiresIn = tokenData.ExpiresIn;
            tokenRecord.XRefreshTokenExpiresIn = tokenData.XRefreshTokenExpiresIn;
            tokenRecord.UpdatedAt = DateTime.UtcNow;

            await _dbContext.SaveChangesAsync();

            _logger.LogInformation("Token refreshed and updated in database");
            return tokenData.AccessToken;
        }
    }
}
