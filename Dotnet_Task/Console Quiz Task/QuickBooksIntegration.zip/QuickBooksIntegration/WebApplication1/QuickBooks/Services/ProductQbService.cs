﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using QuickBooks.DTOs;
using QuickBooks.Helpher;
using QuickBooks.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace QuickBooks.Services
{
    public class ProductQbService : IProductQbService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly HttpClient _httpClient;
        private readonly ILogger<ProductQbService> _logger;
        private readonly QbHelpher _quickBooksHelper;

        public ProductQbService(
            ApplicationDbContext dbContext,
            HttpClient httpClient,
            ILogger<ProductQbService> logger,
            QbHelpher quickBooksHelper)
        {
            _dbContext = dbContext;
            _httpClient = httpClient;
            _logger = logger;
            _quickBooksHelper = quickBooksHelper;
        }

        public async Task<ApiResponse> FetchProductsFromQuickBooks()
        {
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                return new ApiResponse { Status = 400, Message = "No QuickBooks token found." };

            var accessToken = tokenRecord.AccessToken;
            var realmId = tokenRecord.RealmId;

            if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                return new ApiResponse { Status = 400, Message = "Missing access token or realm ID." };

            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query=SELECT * FROM Item";

            var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(httpRequest);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                return new ApiResponse
                {
                    Status = (int)response.StatusCode,
                    Message = $"QuickBooks API Error: {json}"
                };
            }

            var parsedProducts = ParseProductData(json); // Assume it returns List<Product>

            using var transaction = await _dbContext.Database.BeginTransactionAsync();
            try
            {
                _dbContext.Products.RemoveRange(_dbContext.Products.Where(p => p.SourceSystem == "QuickBooks"));
                await _dbContext.SaveChangesAsync();

                await _dbContext.Products.AddRangeAsync(parsedProducts);
                await _dbContext.SaveChangesAsync();
                await transaction.CommitAsync();

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Products fetched and saved successfully.",
                    Data = parsedProducts
                };
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Error saving products");

                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Error saving products: {ex.Message}"
                };
            }
        }


        private List<Product> ParseProductData(string json)
        {
            var products = new List<Product>();
            var jsonResponse = JObject.Parse(json);

            if (jsonResponse["QueryResponse"]?["Item"] is JArray items)
            {
                foreach (var item in items)
                {
                    var product = new Product
                    {
                        QuickBooksItemId = item["Id"]?.ToString(),
                        Name = item["Name"]?.ToString() ?? "Unnamed",
                        QuickBooksUserId = item["ParentRef"]?["value"]?.ToString() ?? "",
                        Description = item["Description"]?.ToString() ?? "",
                        Type = item["Type"]?.ToString() ?? "Unknown",
                        SyncToken = item["SyncToken"]?.ToString() ?? "0",
                        UnitPrice = item["UnitPrice"]?.ToObject<decimal>() ?? 0m,
                        IncomeAccountId = item["IncomeAccountRef"]?["value"]?.ToString() ?? "Unknown",
                        IncomeAccountName = item["IncomeAccountRef"]?["name"]?.ToString() ?? "Unknown",
                        Active = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow,
                        SourceSystem = "QuickBooks" // Set SourceSystem to "QuickBooks"
                    };
                    products.Add(product);
                }
            }

            return products;
        }


        public async Task<ApiResponse> SendProductToQuickBooks(int id)
        {
            try
            {
                var product = await _dbContext.Products.FindAsync(id);
                if (product == null)
                    return new ApiResponse { Status = 404, Message = $"Product with ID {id} not found" };

                if (!string.IsNullOrEmpty(product.QuickBooksItemId))
                    return new ApiResponse { Status = 400, Message = "Product is already synced with QuickBooks" };

                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    return new ApiResponse { Status = 400, Message = "No QuickBooks token found." };

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    return new ApiResponse { Status = 400, Message = "Missing access token or realm ID." };

                var itemData = new
                {
                    Name = product.Name,
                    Type = product.Type == "Service" ? "Service" : "Inventory",
                    IncomeAccountRef = new { value = product.IncomeAccountId },
                    AssetAccountRef = product.Type == "Inventory" ? new { value = product.AssetAccountId } : null,
                    ExpenseAccountRef = product.Type == "Inventory" ? new { value = product.ExpenseAccountId } : null,
                    UnitPrice = product.UnitPrice,
                };

                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item";
                var httpRequest = new HttpRequestMessage(HttpMethod.Post, url);
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpRequest.Content = new StringContent(
                    JsonConvert.SerializeObject(itemData),
                    Encoding.UTF8,
                    "application/json");

                var response = await _httpClient.SendAsync(httpRequest);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    return new ApiResponse
                    {
                        Status = (int)response.StatusCode,
                        Message = $"QuickBooks API Error: {responseContent}"
                    };
                }

                var responseObject = JObject.Parse(responseContent);
                var quickBooksItemId = responseObject["Item"]?["Id"]?.ToString();
                var syncToken = responseObject["Item"]?["SyncToken"]?.ToString();

                product.QuickBooksItemId = quickBooksItemId;
                product.SyncToken = syncToken;
                product.UpdatedAt = DateTime.UtcNow;
                product.SourceSystem = "QuickBooks";

                await _dbContext.SaveChangesAsync();

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Product successfully created in QuickBooks",
                    Data = new
                    {
                        QuickBooksItemId = quickBooksItemId
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing product to QuickBooks");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                };
            }
        }


        public async Task<ApiResponse> GetAllProducts(
        int pageNumber = 1,
        int pageSize = 10,
        string search = null,
        string source = null,
        bool includeInactive = false)
        {
            try
            {
                var query = _dbContext.Products.AsQueryable();

                if (!includeInactive)
                {
                    query = query.Where(p => p.Active);
                }

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(p => p.Name.Contains(search));
                }

                if (!string.IsNullOrEmpty(source) && source.ToUpper() != "ALL")
                {
                    query = query.Where(p => p.SourceSystem == source);
                }

                var totalCount = await query.CountAsync();

                var products = await query
                    .OrderByDescending(p => p.UpdatedAt)
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToListAsync();

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Products fetched successfully",
                    Data = new
                    {
                        totalCount,
                        pageNumber,
                        pageSize,
                        data = products
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching products");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                };
            }
        }

        public async Task<ApiResponse> CreateProduct(Product product)
        {
            try
            {
                product.CreatedAt = DateTime.UtcNow;
                product.UpdatedAt = DateTime.UtcNow;

                if (string.IsNullOrEmpty(product.SyncToken))
                    product.SyncToken = "0";

                product.SourceSystem = "QuickBooks";

                await _dbContext.Products.AddAsync(product);
                await _dbContext.SaveChangesAsync();

                return new ApiResponse
                {
                    Status = 201,
                    Message = "Product created successfully",
                    Data = product
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating product");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                };
            }
        }


        public async Task<ApiResponse> GetProduct(int id)
        {
            try
            {
                var product = await _dbContext.Products.FindAsync(id);

                if (product == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = $"Product with ID {id} not found",
                        Data = null
                    };
                }

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Product retrieved successfully",
                    Data = product
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving product with ID {id}");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                };
            }
        }


        public async Task<ApiResponse> UpdateProduct(int id, Product productUpdate)
        {
            try
            {
                if (id != productUpdate.Id)
                {
                    return new ApiResponse
                    {
                        Status = 400,
                        Message = "Product ID mismatch"
                    };
                }

                var product = await _dbContext.Products.FindAsync(id);
                if (product == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = $"Product with ID {id} not found"
                    };
                }

                var updatedProduct = new Product
                {
                    Id = product.Id,
                    Name = productUpdate.Name,
                    Type = productUpdate.Type,
                    UnitPrice = productUpdate.UnitPrice,
                    QuantityOnHand = productUpdate.QuantityOnHand,
                    InventoryStartDate = productUpdate.InventoryStartDate,
                    Active = productUpdate.Active,
                    UpdatedAt = DateTime.UtcNow,
                    QuickBooksItemId = product.QuickBooksItemId,
                    SyncToken = product.SyncToken,
                    IncomeAccountId = productUpdate.IncomeAccountId,
                    IncomeAccountName = productUpdate.IncomeAccountName,
                    AssetAccountId = product.AssetAccountId,
                    ExpenseAccountId = product.ExpenseAccountId,
                    SourceSystem = product.SourceSystem ?? "QuickBooks"
                };

                if (!string.IsNullOrEmpty(product.QuickBooksItemId))
                {
                    try
                    {
                        var quickBooksResult = await UpdateProductInQuickBooks(updatedProduct);
                        if (quickBooksResult is JObject resultObj && resultObj["NewSyncToken"] != null)
                        {
                            updatedProduct.SyncToken = resultObj["NewSyncToken"]!.ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Failed to update product {id} in QuickBooks");
                        return new ApiResponse
                        {
                            Status = 500,
                            Message = $"QuickBooks update failed: {ex.Message}"
                        };
                    }
                }

                // Apply updates
                product.Name = updatedProduct.Name;
                product.Type = updatedProduct.Type;
                product.UnitPrice = updatedProduct.UnitPrice;
                product.QuantityOnHand = updatedProduct.QuantityOnHand;
                product.InventoryStartDate = updatedProduct.InventoryStartDate;
                product.Active = updatedProduct.Active;
                product.UpdatedAt = updatedProduct.UpdatedAt;
                product.IncomeAccountId = updatedProduct.IncomeAccountId;
                product.IncomeAccountName = updatedProduct.IncomeAccountName;
                product.SyncToken = updatedProduct.SyncToken;
                product.SourceSystem = updatedProduct.SourceSystem;

                _dbContext.Products.Update(product);
                await _dbContext.SaveChangesAsync();

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Product updated successfully",
                    Data = product
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating product {id}");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                };
            }
        }


        public async Task<object> UpdateProductInQuickBooks(Product product)
        {
            // Check if product is synced with QuickBooks
            if (string.IsNullOrEmpty(product.QuickBooksItemId))
                throw new Exception("Product is not yet synced with QuickBooks");

            // Get the latest QuickBooks token
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                throw new Exception("No QuickBooks token found.");

            var accessToken = tokenRecord.AccessToken;
            var realmId = tokenRecord.RealmId;

            if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                throw new Exception("Missing access token or realm ID.");

            // First, get the current item from QuickBooks to ensure we have latest data
            var getUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item/{product.QuickBooksItemId}";
            var getRequest = new HttpRequestMessage(HttpMethod.Get, getUrl);
            getRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            getRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var getResponse = await _httpClient.SendAsync(getRequest);

            if (!getResponse.IsSuccessStatusCode)
            {
                var errorContent = await getResponse.Content.ReadAsStringAsync();
                _logger.LogError($"Error fetching item from QuickBooks: {errorContent}");

                // If item not found in QuickBooks, clear local QuickBooks ID
                if (getResponse.StatusCode == HttpStatusCode.NotFound)
                {
                    throw new Exception("Item no longer exists in QuickBooks.");
                }

                throw new Exception($"Error fetching item from QuickBooks: {errorContent}");
            }

            var currentItemJson = await getResponse.Content.ReadAsStringAsync();
            var currentItem = JObject.Parse(currentItemJson);
            var currentSyncToken = currentItem["Item"]?["SyncToken"]?.ToString();

            // Use the latest SyncToken from QuickBooks
            if (!string.IsNullOrEmpty(currentSyncToken))
            {
                product.SyncToken = currentSyncToken;
            }

            // Prepare the QuickBooks Item data for update
            // Important: Format must exactly match QuickBooks expectations
            var itemData = new JObject
            {
                ["Id"] = product.QuickBooksItemId,
                ["SyncToken"] = product.SyncToken,
                ["Name"] = product.Name,
                ["Type"] = product.Type == "Service" ? "Service" : "Inventory"
            };

            // Always add Income Account Reference if available
            if (!string.IsNullOrEmpty(product.IncomeAccountId))
            {
                itemData["IncomeAccountRef"] = new JObject
                {
                    ["value"] = product.IncomeAccountId
                };
            }

            // Add UnitPrice according to QuickBooks format
            if (product.UnitPrice > 0)
            {
                itemData["UnitPrice"] = product.UnitPrice;
            }

            // Add other fields based on your product's properties
            // Adjust these mappings based on QuickBooks API documentation
            if (product.Type == "Inventory")
            {
                if (!string.IsNullOrEmpty(product.AssetAccountId))
                {
                    itemData["AssetAccountRef"] = new JObject
                    {
                        ["value"] = product.AssetAccountId
                    };
                }

                if (!string.IsNullOrEmpty(product.ExpenseAccountId))
                {
                    itemData["ExpenseAccountRef"] = new JObject
                    {
                        ["value"] = product.ExpenseAccountId
                    };
                }
            }

            _logger.LogInformation($"Sending update to QuickBooks: {itemData.ToString()}");

            // Call QuickBooks API to update the item
            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item";
            var httpRequest = new HttpRequestMessage(HttpMethod.Post, url);
            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            httpRequest.Content = new StringContent(
                itemData.ToString(),
                Encoding.UTF8,
                "application/json");

            var response = await _httpClient.SendAsync(httpRequest);
            var responseContent = await response.Content.ReadAsStringAsync();

            _logger.LogInformation($"QuickBooks API response: {responseContent}");

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"QuickBooks update failed: {responseContent}");

                // Check if token expired error
                if (responseContent.Contains("TokenExpired") || responseContent.Contains("AuthenticationFailed"))
                {
                    throw new Exception("QuickBooks authentication failed. Please reconnect to QuickBooks.");
                }

                throw new Exception($"QuickBooks update failed: {responseContent}");
            }

            // Parse the response to get the updated SyncToken
            var responseObject = JObject.Parse(responseContent);
            var newSyncToken = responseObject["Item"]?["SyncToken"]?.ToString();

            return new
            {
                Message = "Product successfully updated in QuickBooks",
                QuickBooksItemId = product.QuickBooksItemId,
                NewSyncToken = newSyncToken
            };
        }


        public async Task<ApiResponse> UpdateProductInQuickBooks(int id)
        {
            try
            {
                // Find the product in your database
                var product = await _dbContext.Products.FindAsync(id);
                if (product == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = $"Product with ID {id} not found",
                        Data = null
                    };
                }

                // Set SourceSystem if not already set
                if (string.IsNullOrEmpty(product.SourceSystem))
                    product.SourceSystem = "QuickBooks";

                // Prepare the data for QuickBooks update
                var quickBooksResponse = await UpdateProductInQuickBooks(product); 

                // If successful, update the sync token in the database
                if (quickBooksResponse is JObject resultObj && resultObj["NewSyncToken"] != null)
                {
                    product.SyncToken = resultObj["NewSyncToken"].ToString();
                    product.UpdatedAt = DateTime.UtcNow;
                    await _dbContext.SaveChangesAsync();
                }

                return new ApiResponse
                {
                    Status = 200,
                    Message = "Product updated successfully in QuickBooks",
                    Data = product
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating product with ID {id} in QuickBooks");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}",
                    Data = null
                };
            }
        }


        public async Task<ApiResponse> DeactivateProduct(int id)
        {
            try
            {
                var product = await _dbContext.Products.FindAsync(id);
                if (product == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = $"Product with ID {id} not found"
                    };
                }

                // For inventory products, check if quantity is zero
                if (product.Type == "Inventory" && product.QuantityOnHand > 0)
                {
                    return new ApiResponse
                    {
                        Status = 400,
                        Message = "Cannot deactivate inventory product with stock on hand. Please adjust inventory to zero first."
                    };
                }

                string result = "Product deactivated successfully.";

                // If the product has a QuickBooks ID, deactivate it in QuickBooks FIRST
                if (!string.IsNullOrEmpty(product.QuickBooksItemId))
                {
                    try
                    {
                        // Call QuickBooks API first
                        var qbResult = await _quickBooksHelper.DeactivateInQuickBooks(
                            product.QuickBooksItemId,
                            product.SyncToken,
                            product.Name);

                        // Update the SyncToken if QuickBooks returned a new one
                        if (qbResult.syncToken != null)
                        {
                            product.SyncToken = qbResult.syncToken;
                        }
                    }
                    catch (Exception qbEx)
                    {
                        _logger.LogError(qbEx, $"Error deactivating product {id} in QuickBooks");
                        return new ApiResponse
                        {
                            Status = 500,
                            Message = $"Failed to deactivate in QuickBooks: {qbEx.Message}"
                        };
                    }
                }

                // Now update the local database
                product.Active = false;
                product.UpdatedAt = DateTime.UtcNow;

                // Ensure SourceSystem is set to QuickBooks if not already set
                if (string.IsNullOrEmpty(product.SourceSystem))
                {
                    product.SourceSystem = "QuickBooks";
                }

                _dbContext.Products.Update(product);
                await _dbContext.SaveChangesAsync();

                return new ApiResponse
                {
                    Status = 200,
                    Message = result,
                    Data = product
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deactivating product {id}");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                };
            }
        }


        public async Task<ApiResponse> MakeProductInactive(string quickBooksItemId)
        {
            try
            {
                // Find the product in the database by QuickBooks ID
                var product = await _dbContext.Products
                    .FirstOrDefaultAsync(p => p.QuickBooksItemId == quickBooksItemId);

                if (product == null)
                {
                    return new ApiResponse
                    {
                        Status = 404,
                        Message = $"Product with QuickBooks ID {quickBooksItemId} not found"
                    };
                }

                // Call the main deactivation method using the product's ID
                var result = await DeactivateProduct(product.Id);

                // Check if DeactivateProduct returned an error
                if (result.Status != 200)
                {
                    return new ApiResponse
                    {
                        Status = result.Status,
                        Message = result.Message
                    };
                }

                // If deactivation was successful
                return new ApiResponse
                {
                    Status = 200,
                    Message = "Product deactivated successfully.",
                    Data = result.Data
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deactivating product with QuickBooks ID {quickBooksItemId}");
                return new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                };
            }
        }


        public async Task<List<ApiResponse>> GetAccountsByType(string accountType)

        {
            var apiResponses = new List<ApiResponse>();

            try
            {
                // Get the latest QuickBooks token
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null || string.IsNullOrEmpty(tokenRecord.AccessToken) || string.IsNullOrEmpty(tokenRecord.RealmId))
                {
                    apiResponses.Add(new ApiResponse
                    {
                        Status = 401,
                        Message = "No valid QuickBooks token or realm ID found."
                    });
                    return apiResponses;
                }

                string quickBooksAccountType = accountType?.ToLower() switch
                {
                    "income" => "Income",
                    "asset" => "Asset",
                    "expense" => "Expense",
                    _ => null
                };

                if (quickBooksAccountType == null)
                {
                    apiResponses.Add(new ApiResponse
                    {
                        Status = 400,
                        Message = $"Invalid account type: {accountType}. Supported types are: Income, Expense, Asset"
                    });
                    return apiResponses;
                }

                // Query QuickBooks for accounts
                var query = $"SELECT * FROM Account WHERE AccountType = '{quickBooksAccountType}' AND Active = true";
                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{tokenRecord.RealmId}/query?query={Uri.EscapeDataString(query)}";

                var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", tokenRecord.AccessToken);
                httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(httpRequest);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"QuickBooks API Error: {responseContent}");
                    apiResponses.Add(new ApiResponse
                    {
                        Status = (int)response.StatusCode,
                        Message = $"QuickBooks API error: {response.ReasonPhrase}"
                    });
                    return apiResponses;
                }

                return ParseAccountsResponse(responseContent); // Make sure this returns List<ApiResponse>
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving accounts from QuickBooks");

                apiResponses.Add(new ApiResponse
                {
                    Status = 500,
                    Message = $"Internal server error: {ex.Message}"
                });

                return apiResponses;
            }
        }


        private List<ApiResponse> ParseAccountsResponse(string json)
        {
            var responses = new List<ApiResponse>();
            var jsonObject = JObject.Parse(json);

            if (jsonObject["QueryResponse"]?["Account"] is JArray accountArray)
            {
                foreach (var account in accountArray)
                {
                    var accountData = new
                    {
                        Id = account["Id"]?.ToString(),
                        Name = account["Name"]?.ToString(),
                        AccountType = account["AccountType"]?.ToString(),
                        AccountSubType = account["AccountSubType"]?.ToString(),
                        Classification = account["Classification"]?.ToString(),
                        Active = account["Active"]?.ToObject<bool>() ?? true
                    };

                    responses.Add(new ApiResponse
                    {
                        Status = 200,
                        Message = "Success",
                        Data = accountData
                    });
                }
            }
            else
            {
                responses.Add(new ApiResponse
                {
                    Status = 204,
                    Message = "No accounts found",
                    Data = null
                });
            }

            return responses;
        }









    }
}


