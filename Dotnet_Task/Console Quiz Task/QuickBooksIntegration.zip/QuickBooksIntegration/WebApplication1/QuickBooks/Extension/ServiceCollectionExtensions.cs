﻿using Microsoft.Extensions.DependencyInjection;
using QuickBooks.Helpher;
using QuickBooks.Interface;
using QuickBooks.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickBooks.Extension
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddCsvImportServices(this IServiceCollection services)
        {
            services.AddScoped<ICsvImportService, CsvImportService>();
            services.AddScoped<CsvValidationHelper>();
            services.AddScoped<QbHelpher>();

            return services;
        }
    }
}
