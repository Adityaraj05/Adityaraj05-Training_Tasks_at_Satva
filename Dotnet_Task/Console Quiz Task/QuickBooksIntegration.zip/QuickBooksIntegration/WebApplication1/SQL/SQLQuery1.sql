﻿create database QuickBookDB
use QuickBookDB

CREATE TABLE QuickBooksTokens (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksUserId NVARCHAR(255) NOT NULL,
    RealmId NVARCHAR(50) NOT NULL,
    AccessToken NVARCHAR(MAX) NOT NULL,
    RefreshToken NVARCHAR(MAX) NOT NULL,
    IdToken NVARCHAR(MAX) NULL,
    TokenType NVARCHAR(20) NOT NULL,
    ExpiresIn INT NOT NULL,
    XRefreshTokenExpiresIn INT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    UpdatedAt DATETIME NULL
);

CREATE TABLE ChartOfAccounts (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksAccountId NVARCHAR(MAX) NOT NULL,
    Name NVARCHAR(MAX) NOT NULL,
    AccountType NVARCHAR(MAX) NOT NULL,
    AccountSubType NVARCHAR(MAX) NOT NULL,
    CurrentBalance DECIMAL(18, 2) NULL,
    CurrencyValue NVARCHAR(MAX) NOT NULL,
    CurrencyName NVARCHAR(MAX) NOT NULL,
    Classification NVARCHAR(MAX) NOT NULL,
    CreatedAt DATETIME2 NOT NULL,
    QuickBooksUserId NVARCHAR(MAX) NOT NULL
);

select @@SERVERNAME



ALTER TABLE ChartOfAccounts
ALTER COLUMN CurrencyValue NVARCHAR(MAX) NULL;

ALTER TABLE ChartOfAccounts
ALTER COLUMN CurrencyName NVARCHAR(MAX) NULL;



CREATE TABLE Customers (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksCustomerId VARCHAR(20),
    QuickBooksUserId VARCHAR(50),
    DisplayName NVARCHAR(150),
    CompanyName NVARCHAR(150),
    GivenName NVARCHAR(50),
    MiddleName NVARCHAR(50),
    FamilyName NVARCHAR(50),
    Email NVARCHAR(100),
    Phone NVARCHAR(30),
    
    BillingLine1 NVARCHAR(200),
    BillingCity NVARCHAR(100),
    BillingState NVARCHAR(50),
    BillingPostalCode NVARCHAR(20),
    BillingCountry NVARCHAR(50),

    ShippingLine1 NVARCHAR(200),
    ShippingCity NVARCHAR(100),
    ShippingState NVARCHAR(50),
    ShippingPostalCode NVARCHAR(20),
    ShippingCountry NVARCHAR(50),

    Balance DECIMAL(18,2),
    Taxable BIT,
    Active BIT,
    Notes NVARCHAR(MAX),

    PreferredDeliveryMethod NVARCHAR(20),
    PrintOnCheckName NVARCHAR(150),

    QuickBooksCreateTime DATETIME,
    QuickBooksLastUpdateTime DATETIME,
    
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE()
);

ALTER TABLE ChartOfAccounts
ADD UpdatedAt DATETIME NULL;


ALTER TABLE Customers
ADD Title NVARCHAR(50),
    Suffix NVARCHAR(50);



CREATE TABLE Products (
    Id INT PRIMARY KEY IDENTITY(1,1),

    QuickBooksItemId NVARCHAR(100) NOT NULL,
    Name NVARCHAR(255) NOT NULL,
    Type NVARCHAR(50) NOT NULL, -- "Inventory" or "Service"

    SyncToken NVARCHAR(100),
    UnitPrice DECIMAL(18, 2) NOT NULL,

    IncomeAccountId NVARCHAR(100),
    IncomeAccountName NVARCHAR(255),

    ExpenseAccountId NVARCHAR(100), -- Nullable
    ExpenseAccountName NVARCHAR(255),

    AssetAccountId NVARCHAR(100), -- Nullable
    AssetAccountName NVARCHAR(255),

    QuantityOnHand INT, -- Nullable
    InventoryStartDate DATETIME, -- Nullable

    Taxable BIT NOT NULL,
    Active BIT NOT NULL,

    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    UpdatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
);

go



select * from ChartOfAccounts where QuickBooksAccountId = 79

SELECT 
    QuickBooksAccountId, 
    Name, 
    AccountType,
    AccountSubType
FROM 
    ChartOfAccounts
WHERE 
    QuickBooksAccountId IN ('48', '79', '80')
   
select * from ChartOfAccounts where AccountSubType = 'Chequing - CAD'

truncate table  ChartOfAccounts
truncate table  QuickBooksTokens
truncate table Customers
truncate table Products
truncate table Invoices

DROP TRIGGER IF EXISTS SetUpdatedAtOnProducts;

ALTER TABLE QuickBooksTokens DROP COLUMN ExpiresAt 


select * from Customers where QuickBooksCustomerId = 62
delete from Customers where QuickBooksCustomerId = 58


SELECT * FROM ChartOfAccounts WHERE AccountType = 'Income' OR AccountType = 'Other Income'
SELECT * FROM ChartOfAccounts WHERE AccountType = 'Cost of Goods Sold'


delete from Products where Name = 'DemoService' 


CREATE TABLE Invoices (
    Id UNIQUEIDENTIFIER PRIMARY KEY,           -- Local unique ID (GUID recommended)
    QuickBooksInvoiceId NVARCHAR(100),         -- External ID from QuickBooks (DocNumber or Id)
    CustomerId UNIQUEIDENTIFIER NOT NULL,      -- FK to your Customers table
    InvoiceDate DATETIME NOT NULL,
    DueDate DATETIME,
    Store NVARCHAR(255),
    BillingAddress NVARCHAR(MAX),
    Subtotal DECIMAL(18, 2),
    Total DECIMAL(18, 2),
    SendLater BIT DEFAULT 0,
    
    SyncToken NVARCHAR(100),                   -- For QuickBooks concurrency control
    RealmId NVARCHAR(100) NOT NULL,            -- To associate invoice with the correct company
    
    LastSyncedAt DATETIME NULL,                -- Optional: Track last sync time
    NeedsSync BIT DEFAULT 0,                   -- Optional: Mark locally changed records
    
    CreatedAt DATETIME DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME DEFAULT GETUTCDATE()
);

CREATE TABLE InvoiceLineItems (
    Id INT PRIMARY KEY IDENTITY(1,1),

    InvoiceId INT NOT NULL, -- This will link to the Invoices table
    ProductId INT NULL,     -- Local Product reference (from Products.Id), soft reference
    QuickBooksItemId NVARCHAR(100) NULL, -- To directly match QuickBooks if needed

    Description NVARCHAR(1000) NOT NULL,
    Quantity INT NOT NULL,
    Rate DECIMAL(18, 2) NOT NULL,
    Amount AS (Quantity * Rate) PERSISTED, -- Auto-calculated for consistency

    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    UpdatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
);
alter table InvoiceLineItems
alter column Description NVARCHAR(1000) NULL



select * from Customers
select * from QuickBooksTokens
select * from ChartOfAccounts
select * from Products
select * from Invoices
select * from InvoiceLineItems

delete from InvoiceLineItems where Id =4

drop table Invoices
drop table InvoiceLineItems

truncate table Invoices
truncate table InvoiceLineItems


-- 🧾 Invoices Table
CREATE TABLE Invoices (
    Id INT PRIMARY KEY IDENTITY(1,1),              -- Local PK used in C# as int
    QuickBooksInvoiceId NVARCHAR(100),             -- From QuickBooks API (Id or DocNumber)
    CustomerId INT NOT NULL,                       -- Match your Customers table's int ID
    
    InvoiceDate DATETIME NOT NULL,
    DueDate DATETIME,
    Store NVARCHAR(255),
    BillingAddress NVARCHAR(MAX),
    Subtotal DECIMAL(18, 2),
    Total DECIMAL(18, 2),
    SendLater BIT DEFAULT 0,
    
    SyncToken NVARCHAR(100),                       -- Used for syncing with QuickBooks
    RealmId NVARCHAR(100) NOT NULL,                -- Company scope
    
    LastSyncedAt DATETIME NULL,
    NeedsSync BIT DEFAULT 0,
    
    CreatedAt DATETIME DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME DEFAULT GETUTCDATE()
);

Alter table Invoices Alter column RealmId nvarchar(100) null

-- 📦 InvoiceLineItems Table
CREATE TABLE InvoiceLineItems (
    Id INT PRIMARY KEY IDENTITY(1,1),

    InvoiceId INT NOT NULL,                        -- Linked to Invoices.Id
    ProductId INT NULL,                            -- Local reference (soft link)
    QuickBooksItemId NVARCHAR(100) NULL,           -- From QuickBooks item
    
    Description NVARCHAR(1000) NOT NULL,
    Quantity DECIMAL(10, 2) NOT NULL,              -- Allows decimal quantities like 3.5
    Rate DECIMAL(18, 2) NOT NULL,
    Amount DECIMAL(18, 2) NOT NULL,                -- Amount now a regular column
    
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),

    -- Foreign Key to Invoices table (ensure referential integrity)
    FOREIGN KEY (InvoiceId) REFERENCES Invoices(Id)
);
alter table InvoiceLineItems 
drop column InvoiceId
truncate table Invoices

select * from Invoices
select * from InvoiceLineItems
select * from Products
select * from InvoiceLineItems where QuickBooksItemId = 34
select * from Customers where QuickBooksCustomerId = 24
truncate table Invoices
truncate table InvoiceLineItems


ALTER TABLE InvoiceLineItems
ADD QuickBooksInvoiceId NVARCHAR(50);



select * from Invoices where QuickBooksInvoiceId = 1048
Select * from Customers where QuickBooksCustomerId = 8
select * from Customers where Email = 'Consulting@intuit.com'
select * from InvoiceLineItems 

SELECT 
    fk.name AS ForeignKey,
    tp.name AS ParentTable,
    ref.name AS ReferencedTable
FROM 
    sys.foreign_keys fk
JOIN 
    sys.tables tp ON fk.referenced_object_id = tp.object_id
JOIN 
    sys.tables ref ON fk.parent_object_id = ref.object_id
WHERE 
    tp.name = 'Invoices';  -- Replace with your table name
TRUNCATE TABLE InvoiceLineItems;
TRUNCATE TABLE Invoices;
drop table Invoices
drop table InvoiceLineItems

CREATE TABLE Invoices (
    Id INT PRIMARY KEY IDENTITY(1,1),              -- Local PK used in C# as int
    QuickBooksInvoiceId NVARCHAR(100) UNIQUE,        -- From QuickBooks API (Id or DocNumber), now unique
    CustomerId INT NOT NULL,                        -- Match your Customers table's int ID
    InvoiceDate DATETIME NOT NULL,
    DueDate DATETIME,
    Store NVARCHAR(255),
    BillingAddress NVARCHAR(MAX),
    Subtotal DECIMAL(18, 2),
    Total DECIMAL(18, 2),
    SendLater BIT DEFAULT 0,
    SyncToken NVARCHAR(100),                       -- Used for syncing with QuickBooks
    RealmId NVARCHAR(100) NOT NULL,                -- Company scope
    LastSyncedAt DATETIME NULL,
    NeedsSync BIT DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME DEFAULT GETUTCDATE()
);

CREATE TABLE InvoiceLineItems (
    Id INT PRIMARY KEY IDENTITY(1,1),
    InvoiceId INT NOT NULL,                        -- Linked to Invoices.Id, but no FK constraint
    ProductId INT NULL,                            -- Local reference (soft link)
    QuickBooksItemId NVARCHAR(100) NULL,           -- From QuickBooks item
    Description NVARCHAR(1000) NOT NULL,
    Quantity DECIMAL(10, 2) NOT NULL,              -- Allows decimal quantities like 3.5
    Rate DECIMAL(18, 2) NOT NULL,
    Amount DECIMAL(18, 2) NOT NULL,                -- Amount now a regular column
    QuickBooksInvoiceId  nvarchar(50) null,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);

truncate table InvoiceLineItems
truncate table Invoices

select * from Customers where Id = 8
select * from Invoices where Id = 77
select * from Invoices
select * from InvoiceLineItems
SELECT * FROM Customers 
select * from Products 

truncate table Invoices
select * from Products where Active = 1

-- SQL command
EXEC sp_rename 'InvoiceLineItems.Quantity', 'Qty', 'COLUMN';
alter table InvoiceLineItems 
drop column ProductId

SELECT 
    i.Id AS InvoiceId, 
    i.CustomerId AS InvoiceCustomerId, 
    i.QuickBooksInvoiceId, 
    c.Id AS CustomerDbId,
    c.QuickBooksCustomerId, 
    c.DisplayName
FROM Invoices i
LEFT JOIN Customers c ON i.CustomerId = c.QuickBooksCustomerId
WHERE i.QuickBooksInvoiceId = 1050;


EXEC sp_rename 'Invoices.CustomerId', 'QuickBooksCustomerId', 'COLUMN';
select * from InvoiceLineItems


sp_help 'Invoices'
alter table Invoices
alter column QuickBooksCustomerId nvarchar(100) not null

select * from Customers where QuickBooksCustomerId = 13
select * from Invoices where QuickBooksInvoiceId = 187


truncate table Customers
truncate table Invoices
truncate table InvoiceLineItems
truncate table ChartOfAccounts
truncate table Products


CREATE TABLE Vendors (
    Id INT PRIMARY KEY,                              -- QBO Vendor ID
    SyncToken NVARCHAR(50) NULL,                     -- Used by QBO for optimistic concurrency
    DisplayName NVARCHAR(255) NOT NULL,              -- Required by QBO
    AcctNum NVARCHAR(50) NULL,                       -- Optional account number

    -- Contact Info
    PrimaryEmailAddr NVARCHAR(255) NULL,
    PrimaryPhone NVARCHAR(50) NULL,
	Active BIT not null,
    -- Billing Address
    BillAddr_Line1 NVARCHAR(255) NULL,
    BillAddr_City NVARCHAR(100) NULL,
    BillAddr_PostalCode NVARCHAR(20) NULL,
    BillAddr_CountrySubDivisionCode NVARCHAR(10) NULL
);
ALTER TABLE Vendors DROP CONSTRAINT DF__Vendors__Active__625A9A57;

ALTER TABLE Vendors
DROP COLUMN Active;

ALTER TABLE Vendors
ADD Active BIT CONSTRAINT DF_Vendors_Active DEFAULT 1;


select * from Vendors
select * from ChartOfAccounts
ALTER TABLE Vendors
ADD Balance DECIMAL(18, 2) NULL;

CREATE TABLE Bills (
    QuickBooksBillId VARCHAR(50) PRIMARY KEY,
    SyncToken VARCHAR(10),
    TxnDate DATE,
    DueDate DATE,
    VendorId VARCHAR(50),
    VendorName VARCHAR(255),
    VendorAddrLine1 VARCHAR(255),
    VendorAddrCity VARCHAR(100),
    VendorAddrState VARCHAR(50),
    VendorAddrPostalCode VARCHAR(20),
    VendorAddrLat VARCHAR(50),
    VendorAddrLong VARCHAR(50),
    APAccountId VARCHAR(50),
    APAccountName VARCHAR(255),
    CurrencyValue VARCHAR(10),
    CurrencyName VARCHAR(50),
    TotalAmt DECIMAL(18, 2),
    Balance DECIMAL(18, 2),
    CreatedAt DATETIME,
    UpdatedAt DATETIME,
    LastModifiedBy VARCHAR(100)
);

CREATE TABLE BillLines (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksBillId VARCHAR(50) NOT NULL, -- FK to Bills
    LineNum INT,
    QuickBooksLineId VARCHAR(50),
    Description VARCHAR(500),
    Amount DECIMAL(18, 2),
    ItemId VARCHAR(50),
    ItemName VARCHAR(255),
    UnitPrice DECIMAL(18, 2),
    Qty DECIMAL(18, 2),
    BillableStatus VARCHAR(50),
    TaxCodeRef VARCHAR(50),
    FOREIGN KEY (QuickBooksBillId) REFERENCES Bills(QuickBooksBillId)
);

select * from Bills
Select * from BillLines
Select * from Vendors
select * from Customers

delete
FROM Bills
WHERE CAST(CreatedAt AS DATE) = CAST(GETDATE() AS DATE);

ALTER TABLE BillLines
ADD DetailType VARCHAR(50) NULL;

ALTER TABLE Vendors
ALTER COLUMN BillAddr_CountrySubDivisionCode VARCHAR(50);
