﻿using Data_Access_Layer.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Data_Access_Layer.Services
{
    public class ContactMappingService
    {
        private readonly ILogger<ContactMappingService> _logger;

        public ContactMappingService(ILogger<ContactMappingService> logger)
        {
            _logger = logger;
        }

        public List<Customer> ProcessXeroResponse(JsonElement jsonResponse, string tenantId)
        {
            _logger.LogInformation("Processing Xero contacts response");
            var customers = new List<Customer>();

            try
            {
                if (jsonResponse.TryGetProperty("Contacts", out JsonElement contactsElement))
                {
                    foreach (JsonElement contact in contactsElement.EnumerateArray())
                    {
                        var customer = new Customer
                        {
                            CompanySource = "Xero",
                            XeroTenantId = tenantId,
                            XeroContactId = GetStringProperty(contact, "ContactID"),
                            AccountNumber = GetStringProperty(contact, "AccountNumber"),
                            DisplayName = GetStringProperty(contact, "Name"),
                            GivenName = GetStringProperty(contact, "FirstName"),
                            FamilyName = GetStringProperty(contact, "LastName"),
                            Email = GetStringProperty(contact, "EmailAddress"),
                            Active = GetStringProperty(contact, "ContactStatus") == "ACTIVE",
                            XeroLastUpdateTime = ParseXeroDate(GetStringProperty(contact, "UpdatedDateUTC")),
                            CreatedAt = DateTime.UtcNow,
                            UpdatedAt = DateTime.UtcNow
                        };

                        // Process Addresses
                        if (contact.TryGetProperty("Addresses", out JsonElement addressesElement))
                        {
                            foreach (JsonElement address in addressesElement.EnumerateArray())
                            {
                                string addressType = GetStringProperty(address, "AddressType");

                                if (addressType == "POBOX")
                                {
                                    customer.BillingLine1 = GetStringProperty(address, "AddressLine1");
                                    customer.BillingCity = GetStringProperty(address, "City");
                                    customer.BillingState = GetStringProperty(address, "Region");
                                    customer.BillingPostalCode = GetStringProperty(address, "PostalCode");
                                    customer.BillingCountry = GetStringProperty(address, "Country");
                                }
                                else if (addressType == "STREET")
                                {
                                    customer.ShippingLine1 = GetStringProperty(address, "AddressLine1");
                                    customer.ShippingCity = GetStringProperty(address, "City");
                                    customer.ShippingState = GetStringProperty(address, "Region");
                                    customer.ShippingPostalCode = GetStringProperty(address, "PostalCode");
                                    customer.ShippingCountry = GetStringProperty(address, "Country");
                                }
                            }
                        }

                        // Process Phones
                        if (contact.TryGetProperty("Phones", out JsonElement phonesElement))
                        {
                            foreach (JsonElement phone in phonesElement.EnumerateArray())
                            {
                                string phoneType = GetStringProperty(phone, "PhoneType");

                                if (phoneType == "DEFAULT")
                                {
                                    customer.Phone = GetStringProperty(phone, "PhoneNumber");
                                }
                            }
                        }

                        customers.Add(customer);
                    }
                }

                _logger.LogInformation($"Successfully processed {customers.Count} contacts from Xero");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing Xero contacts response");
                throw;
            }

            return customers;
        }

        public object CreateXeroContactRequest(Customer customer)
        {
            var phonesList = new List<object>();
            if (!string.IsNullOrEmpty(customer.Phone))
            {
                phonesList.Add(new
                {
                    PhoneType = "DEFAULT",
                    PhoneNumber = customer.Phone
                });
            }

            var addresses = new List<object>();

            // Add billing address if available
            if (!string.IsNullOrEmpty(customer.BillingLine1))
            {
                addresses.Add(new
                {
                    AddressType = "POBOX",
                    AddressLine1 = customer.BillingLine1,
                    City = customer.BillingCity,
                    Region = customer.BillingState,
                    PostalCode = customer.BillingPostalCode,
                    Country = customer.BillingCountry
                });
            }

            // Add shipping address if available
            if (!string.IsNullOrEmpty(customer.ShippingLine1))
            {
                addresses.Add(new
                {
                    AddressType = "STREET",
                    AddressLine1 = customer.ShippingLine1,
                    City = customer.ShippingCity,
                    Region = customer.ShippingState,
                    PostalCode = customer.ShippingPostalCode,
                    Country = customer.ShippingCountry
                });
            }

            // Create a base contact object
            var contactObj = new Dictionary<string, object>
    {
        { "Name", customer.DisplayName },
        { "FirstName", customer.GivenName },
        { "LastName", customer.FamilyName },
        { "EmailAddress", customer.Email },
        { "AccountNumber", customer.AccountNumber },
        { "Phones", phonesList },
        { "Addresses", addresses },
        { "ContactStatus", customer.Active ? "ACTIVE" : "ARCHIVED" },
        { "IsCustomer", true },
        { "IsSupplier", false }
    };

            // Add ContactID only when it exists (for updates)
            if (!string.IsNullOrEmpty(customer.XeroContactId))
            {
                contactObj["ContactID"] = customer.XeroContactId;
            }

            return new { Contacts = new[] { contactObj } };
        }

        private string GetStringProperty(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property))
            {
                return property.ValueKind == JsonValueKind.String ? property.GetString() : null;
            }
            return null;
        }

        private DateTime? ParseXeroDate(string dateString)
        {
            if (string.IsNullOrEmpty(dateString) || !dateString.StartsWith("/Date(") || !dateString.EndsWith(")/"))
                return null;

            try
            {
                // Extract the timestamp in milliseconds
                var timestamp = dateString.Substring(6, dateString.Length - 8);
                var milliseconds = long.Parse(timestamp.Split('+')[0]); // Ignore timezone offset
                return DateTimeOffset.FromUnixTimeMilliseconds(milliseconds).UtcDateTime;
            }
            catch
            {
                return null; // Return null if parsing fails
            }
        }


    }
}
