﻿using Data_Access_Layer.Models;
using Data_Access_Layer.Models.DTO;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Data_Access_Layer.Services
{
    public class InvoiceMappingService
    {
        private readonly ILogger<InvoiceMappingService> _logger;
        private const string DEFAULT_CURRENCY = "INR"; // Change this to your organization's actual supported currency

        public InvoiceMappingService(ILogger<InvoiceMappingService> logger)
        {
            _logger = logger;
        }

        public List<Invoice> ProcessXeroInvoicesResponse(JsonElement jsonResponse, string tenantId)
        {
            // Existing code unchanged...
            _logger.LogInformation("Processing Xero invoices response");
            var invoices = new List<Invoice>();

            try
            {
                if (jsonResponse.TryGetProperty("Invoices", out JsonElement invoicesElement))
                {
                    foreach (JsonElement invoiceElement in invoicesElement.EnumerateArray())
                    {
                        var invoice = new Invoice
                        {
                            SourceCompany = "Xero",
                            XeroTenantId = tenantId,
                            ExternalId = GetStringProperty(invoiceElement, "InvoiceID"),
                            InvoiceNumber = GetStringProperty(invoiceElement, "InvoiceNumber"),
                            Type = GetStringProperty(invoiceElement, "Type"),
                            Status = GetStringProperty(invoiceElement, "Status"),
                            LineAmountTypes = GetStringProperty(invoiceElement, "LineAmountTypes"),
                            InvoiceDate = GetDateTimeProperty(invoiceElement, "Date"),
                            DueDate = GetDateTimeProperty(invoiceElement, "DueDate"),
                            Subtotal = GetDecimalProperty(invoiceElement, "SubTotal"),
                            Total = GetDecimalProperty(invoiceElement, "Total"),
                            TotalTax = GetDecimalProperty(invoiceElement, "TotalTax"),
                            AmountDue = GetDecimalProperty(invoiceElement, "AmountDue"),
                            AmountPaid = GetDecimalProperty(invoiceElement, "AmountPaid"),
                            Currency = GetStringProperty(invoiceElement, "CurrencyCode"),
                            CreatedAt = DateTime.UtcNow,
                            UpdatedAt = DateTime.UtcNow,
                            Store = "Xero" // Default store value for Xero
                        };

                        // Get customer information
                        if (invoiceElement.TryGetProperty("Contact", out JsonElement contactElement))
                        {
                            invoice.CustomerExternalId = GetStringProperty(contactElement, "ContactID");
                            invoice.CustomerName = GetStringProperty(contactElement, "Name");

                            // Try to extract billing address if available
                            if (contactElement.TryGetProperty("Addresses", out JsonElement addressesElement))
                            {
                                foreach (JsonElement address in addressesElement.EnumerateArray())
                                {
                                    if (GetStringProperty(address, "AddressType") == "POBOX" ||
                                        GetStringProperty(address, "AddressType") == "STREET")
                                    {
                                        invoice.BillingAddress = GetStringProperty(address, "AddressLine1");
                                        break;
                                    }
                                }
                            }
                        }

                        // Process line items if they exist
                        if (invoiceElement.TryGetProperty("LineItems", out JsonElement lineItemsElement))
                        {
                            invoice.LineItems = new List<InvoiceLineItem>();
                            foreach (JsonElement lineItemElement in lineItemsElement.EnumerateArray())
                            {
                                var lineItem = new InvoiceLineItem
                                {
                                    LineId = GetStringProperty(lineItemElement, "LineItemID"),
                                    ProductId = GetStringProperty(lineItemElement, "ItemCode"),
                                    Description = GetStringProperty(lineItemElement, "Description"),
                                    Quantity = (int)GetDecimalProperty(lineItemElement, "Quantity"),
                                    Rate = GetDecimalProperty(lineItemElement, "UnitAmount"),
                                    Amount = GetDecimalProperty(lineItemElement, "LineAmount"),
                                    TaxType = GetStringProperty(lineItemElement, "TaxType"),
                                    TaxAmount = GetDecimalProperty(lineItemElement, "TaxAmount"),
                                    AccountCode = GetStringProperty(lineItemElement, "AccountCode"),
                                    AccountId = GetStringProperty(lineItemElement, "AccountID")
                                };

                                // Extract Item information if available
                                if (lineItemElement.TryGetProperty("Item", out JsonElement itemElement))
                                {
                                    lineItem.ItemId = GetStringProperty(itemElement, "ItemID");
                                    lineItem.ItemName = GetStringProperty(itemElement, "Name");
                                }

                                invoice.LineItems.Add(lineItem);
                            }
                        }

                        invoices.Add(invoice);
                    }
                }

                _logger.LogInformation($"Successfully processed {invoices.Count} invoices from Xero");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing Xero invoices response");
                throw;
            }

            return invoices;
        }

        public List<InvoiceLineItem> ProcessXeroInvoiceLineItems(JsonElement invoiceElement, int invoiceId)
        {
            // Existing code unchanged...
            var lineItems = new List<InvoiceLineItem>();

            try
            {
                if (invoiceElement.TryGetProperty("LineItems", out JsonElement lineItemsElement))
                {
                    foreach (JsonElement lineItemElement in lineItemsElement.EnumerateArray())
                    {
                        var lineItem = new InvoiceLineItem
                        {
                            InvoiceId = invoiceId,
                            LineId = GetStringProperty(lineItemElement, "LineItemID"),
                            ProductId = GetStringProperty(lineItemElement, "ItemCode"),
                            Description = GetStringProperty(lineItemElement, "Description"),
                            Quantity = (int)GetDecimalProperty(lineItemElement, "Quantity"),
                            Rate = GetDecimalProperty(lineItemElement, "UnitAmount"),
                            Amount = GetDecimalProperty(lineItemElement, "LineAmount"),
                            TaxType = GetStringProperty(lineItemElement, "TaxType"),
                            TaxAmount = GetDecimalProperty(lineItemElement, "TaxAmount"),
                            AccountCode = GetStringProperty(lineItemElement, "AccountCode"),
                            AccountId = GetStringProperty(lineItemElement, "AccountID")
                        };

                        // Extract Item information if available
                        if (lineItemElement.TryGetProperty("Item", out JsonElement itemElement))
                        {
                            lineItem.ItemId = GetStringProperty(itemElement, "ItemID");
                            lineItem.ItemName = GetStringProperty(itemElement, "Name");
                        }

                        lineItems.Add(lineItem);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing Xero invoice line items");
                throw;
            }

            return lineItems;
        }

        public object CreateXeroInvoiceRequest(InvoiceInputModel inputModel, string contactId = null)
        {
            _logger.LogInformation("Creating Xero invoice request with input model");

            try
            {
                // First, log the input model to diagnose issues
                _logger.LogDebug($"Input model details: CustomerId: {inputModel.CustomerId}, " +
                    $"CustomerEmail: {inputModel.CustomerEmail}, LineItems count: {inputModel.LineItems?.Count ?? 0}");

                // Check for valid line items - with better logging
                if (inputModel.LineItems == null)
                {
                    _logger.LogWarning("LineItems collection is null");
                    throw new ArgumentException("Invoice line items collection cannot be null");
                }

                if (!inputModel.LineItems.Any())
                {
                    _logger.LogWarning("LineItems collection is empty");
                    throw new ArgumentException("At least one line item is required for the invoice");
                }

                foreach (var item in inputModel.LineItems)
                {
                    _logger.LogDebug($"Line item: ProductId: {item.ProductId}, Description: {item.Description}, " +
                        $"Quantity: {item.Quantity}, Rate: {item.Rate}, Amount: {item.Amount}");
                }

                var lineItems = inputModel.LineItems.Select(li => new
                {
                    Description = !string.IsNullOrEmpty(li.Description) ? li.Description : "Item",
                    Quantity = li.Quantity > 0 ? li.Quantity : 1,
                    UnitAmount = li.Rate > 0 ? li.Rate : 0,
                    AccountCode = !string.IsNullOrEmpty(li.AccountCode) ? li.AccountCode : "200", // Use provided account code or default
                    // FIXED: Don't pass ItemCode if it's a GUID - it's probably not a valid Xero item code
                    // ItemCode = li.ProductId, 
                    TaxType = !string.IsNullOrEmpty(li.TaxType) ? li.TaxType : "NONE" // Use provided tax type or default
                }).ToList();

                // Create contact object with proper identification
                var contactObject = new Dictionary<string, object>();

                // If ContactID is provided, use it
                if (!string.IsNullOrEmpty(contactId))
                {
                    contactObject.Add("ContactID", contactId);
                    _logger.LogDebug($"Using provided contactId: {contactId}");
                }
                else if (!string.IsNullOrEmpty(inputModel.CustomerExternalId))
                {
                    contactObject.Add("ContactID", inputModel.CustomerExternalId);
                    _logger.LogDebug($"Using CustomerExternalId: {inputModel.CustomerExternalId}");
                }
                else if (!string.IsNullOrEmpty(inputModel.CustomerId))
                {
                    contactObject.Add("ContactID", inputModel.CustomerId.ToString());
                    _logger.LogDebug($"Using CustomerId as ContactID: {inputModel.CustomerId}");
                }

                // If ContactName is provided, add it as well (as fallback identification)
                if (!string.IsNullOrEmpty(inputModel.CustomerName))
                {
                    contactObject.Add("Name", inputModel.CustomerName);
                    _logger.LogDebug($"Using CustomerName: {inputModel.CustomerName}");
                }
                else if (!string.IsNullOrEmpty((string?)inputModel.CustomerEmail))
                {
                    // If no name available, use email as a fallback for contact identification
                    contactObject.Add("EmailAddress", inputModel.CustomerEmail);
                    _logger.LogDebug($"Using CustomerEmail: {inputModel.CustomerEmail}");
                }

                // If neither ID nor Name/Email is available, throw exception
                if (contactObject.Count == 0)
                {
                    _logger.LogWarning("No contact identification provided");
                    throw new ArgumentException("Contact ID, Contact Name, or Contact Email must be provided");
                }

                // Ensure valid dates are used
                var today = DateTime.UtcNow.Date;
                var invoiceDate = inputModel.InvoiceDate != default(DateTime) ? inputModel.InvoiceDate.Date : today;
                var dueDate = inputModel.DueDate != default(DateTime) ? inputModel.DueDate.Date : today.AddDays(30);

                _logger.LogDebug($"Invoice date: {invoiceDate:yyyy-MM-dd}, Due date: {dueDate:yyyy-MM-dd}");

                // FIXED: Use DEFAULT_CURRENCY instead of hardcoded "NZD"
                var currencyCode = DEFAULT_CURRENCY;

                var invoiceObject = new Dictionary<string, object>
                {
                    { "Type", !string.IsNullOrEmpty(inputModel.Type) ? inputModel.Type : "ACCREC" }, // Use provided type or default to Accounts Receivable
                    { "Contact", contactObject },
                    { "Date", invoiceDate.ToString("yyyy-MM-dd") },
                    { "DueDate", dueDate.ToString("yyyy-MM-dd") },
                    { "LineAmountTypes", !string.IsNullOrEmpty(inputModel.LineAmountTypes) ? inputModel.LineAmountTypes : "Exclusive" }, // Use provided or default
                    { "Status", !string.IsNullOrEmpty(inputModel.Status) ? inputModel.Status : "DRAFT" },
                    { "CurrencyCode", currencyCode }, // FIXED: Use organization's currency
                    { "LineItems", lineItems }
                };

                // Add invoice number if provided
                if (!string.IsNullOrEmpty(inputModel.InvoiceNumber))
                {
                    invoiceObject.Add("InvoiceNumber", inputModel.InvoiceNumber);
                }

                // Add reference to store if available
                if (!string.IsNullOrEmpty(inputModel.Store))
                {
                    invoiceObject.Add("Reference", inputModel.Store);
                    _logger.LogDebug($"Added store as reference: {inputModel.Store}");
                }

                // Add billing address if available
                if (!string.IsNullOrEmpty(inputModel.BillingAddress))
                {
                    _logger.LogDebug($"Adding billing address: {inputModel.BillingAddress}");
                    // We can't directly add the address to the invoice, but we can update the contact
                    // This might require a separate contact update API call in practice
                }

                _logger.LogInformation("Successfully created Xero invoice request object");
                return new { Invoices = new[] { invoiceObject } };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating Xero invoice request");
                throw;
            }
        }

        // Helper methods for parsing JSON responses
        private string GetStringProperty(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property))
            {
                return property.ValueKind == JsonValueKind.String ? property.GetString() : null;
            }
            return null;
        }

        private decimal GetDecimalProperty(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property))
            {
                if (property.ValueKind == JsonValueKind.Number)
                {
                    return property.GetDecimal();
                }
            }
            return 0;
        }

        private DateTime GetDateTimeProperty(JsonElement element, string propertyName)
        {
            try
            {
                if (element.TryGetProperty(propertyName, out JsonElement property))
                {
                    // Check if it's a string date format
                    if (property.ValueKind == JsonValueKind.String)
                    {
                        if (DateTime.TryParse(property.GetString(), out DateTime result))
                        {
                            return result;
                        }
                    }
                    // Check if it's a date expressed as "/Date(timestamp)/"
                    else if (property.ValueKind == JsonValueKind.String || property.ValueKind == JsonValueKind.Object)
                    {
                        var dateStr = property.ToString();
                        if (dateStr.StartsWith("/Date(") && dateStr.EndsWith(")/"))
                        {
                            var timestamp = dateStr.Substring(6, dateStr.Length - 8);
                            if (long.TryParse(timestamp.Split('+')[0], out long milliseconds))
                            {
                                return DateTimeOffset.FromUnixTimeMilliseconds(milliseconds).DateTime;
                            }
                        }
                    }
                }

                // FIXED: Return a valid default date instead of DateTime.MinValue
                return DateTime.UtcNow;
            }
            catch
            {
                // FIXED: Return a valid default date
                return DateTime.UtcNow;
            }
        }

        // Convert from our internal model to Xero format
        public object MapInvoiceToXeroFormat(Invoice invoice, List<InvoiceLineItem> lineItems, string contactId = null)
        {
            // Check for valid line items
            if (lineItems == null || !lineItems.Any())
            {
                throw new ArgumentException("At least one line item is required for the invoice");
            }

            var xeroLineItems = lineItems.Select(li => new
            {
                LineItemID = !string.IsNullOrEmpty(li.LineId) ? li.LineId : null,
                Description = !string.IsNullOrEmpty(li.Description) ? li.Description : "Item",
                Quantity = li.Quantity > 0 ? li.Quantity : 1,
                UnitAmount = li.Rate > 0 ? li.Rate : 0,
                AccountCode = !string.IsNullOrEmpty(li.AccountCode) ? li.AccountCode : "200", // Use provided or default
                // FIXED: Don't pass ItemCode if it's a GUID - it's probably not a valid Xero item code
                // ItemCode = li.ProductId,
                TaxType = !string.IsNullOrEmpty(li.TaxType) ? li.TaxType : "NONE" // Use provided or default
            }).ToList();

            // Create contact object with proper identification
            var contactObject = new Dictionary<string, object>();

            // If ContactID is provided, use it
            if (!string.IsNullOrEmpty(contactId) || !string.IsNullOrEmpty(invoice.CustomerExternalId))
            {
                contactObject.Add("ContactID", contactId ?? invoice.CustomerExternalId);
            }
            // If ContactName is provided, add it as well (as fallback identification)
            if (!string.IsNullOrEmpty(invoice.CustomerName))
            {
                contactObject.Add("Name", invoice.CustomerName);
            }
            // If neither ID nor Name is available, throw exception
            if (contactObject.Count == 0)
            {
                throw new ArgumentException("Contact ID or Contact Name must be provided");
            }

            // Ensure valid dates are used
            var today = DateTime.UtcNow.Date;
            var invoiceDate = invoice.InvoiceDate != default(DateTime) ? invoice.InvoiceDate.Date : today;
            var dueDate = invoice.DueDate != default(DateTime) ? invoice.DueDate.Date : today.AddDays(30);

            // FIXED: Use DEFAULT_CURRENCY instead of hardcoded "NZD" 
            var currencyCode = DEFAULT_CURRENCY;

            var invoiceObject = new Dictionary<string, object>
            {
                { "Type", !string.IsNullOrEmpty(invoice.Type) ? invoice.Type : "ACCREC" },
                { "Contact", contactObject },
                { "Date", invoiceDate.ToString("yyyy-MM-dd") },
                { "DueDate", dueDate.ToString("yyyy-MM-dd") },
                { "LineAmountTypes", !string.IsNullOrEmpty(invoice.LineAmountTypes) ? invoice.LineAmountTypes : "Exclusive" },
                { "Status", !string.IsNullOrEmpty(invoice.Status) ? invoice.Status : "DRAFT" },
                { "CurrencyCode", currencyCode }, // FIXED: Use organization's currency
                { "LineItems", xeroLineItems }
            };

            // Add ExternalId if available
            if (!string.IsNullOrEmpty(invoice.ExternalId))
            {
                invoiceObject.Add("InvoiceID", invoice.ExternalId);
            }

            // Add invoice number if available
            if (!string.IsNullOrEmpty(invoice.InvoiceNumber))
            {
                invoiceObject.Add("InvoiceNumber", invoice.InvoiceNumber);
            }

            return new { Invoices = new[] { invoiceObject } };
        }
    }
}
