﻿using Data_Access_Layer.Data;
using Data_Access_Layer.Interface;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;
namespace Data_Access_Layer.Services
{
    public class Databasehelper : IDatabase
    {
        private readonly IConfiguration _config;
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<Databasehelper> _logger;

        public Databasehelper(IConfiguration config, HttpClient httpClient, ILogger<Databasehelper> logger, ApplicationDbContext dbContext)
        {
            _config = config;
            _httpClient = httpClient;
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<ApiResponse<List<ChartOfAccount>>> FetchChartOfAccountsFromDbPaginated(
      int page = 1,
      int pageSize = 10,
      string? searchTerm = null)
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    return ApiResponse<List<ChartOfAccount>>.ErrorResponse("No QuickBooks token found.");

                var query = _dbContext.ChartOfAccounts
                    .Where(c => c.QuickBooksUserId == tokenRecord.QuickBooksUserId);

                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    string likeTerm = $"%{searchTerm}%";
                    query = query.Where(c =>
                        EF.Functions.Like(c.Name, likeTerm) ||
                        EF.Functions.Like(c.AccountType, likeTerm) ||
                        (c.AccountSubType != null && EF.Functions.Like(c.AccountSubType, likeTerm)) ||
                        (c.Classification != null && EF.Functions.Like(c.Classification, likeTerm))
                    );
                }

                var totalRecords = await query.CountAsync();

                var pagedData = await query
                    .OrderBy(c => c.Name)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .ToListAsync();

                return ApiResponse<List<ChartOfAccount>>.SuccessResponse(
                    data: pagedData,
                    totalCount: totalRecords,
                    pageNumber: page,
                    pageSize: pageSize,
                    message: "Fetched chart of accounts successfully."
                );
            }
            catch (Exception ex)
            {
                return ApiResponse<List<ChartOfAccount>>.ErrorResponse($"Error fetching paginated accounts: {ex.Message}");
            }
        }

    }
}

