﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Data_Access_Layer.Services
{
    public class AccountMappingService
    {
        // Map QuickBooks Account to our ChartOfAccount model
        public ChartOfAccount MapQuickBooksAccount(JsonElement accountJson, string userId)
        {
            var account = accountJson.GetProperty("Account");

            var chartAccount = new ChartOfAccount
            {
                QuickBooksAccountId = account.GetProperty("Id").GetString(),
                Name = account.GetProperty("Name").GetString(),
                AccountType = account.GetProperty("AccountType").GetString(),
                AccountSubType = account.GetProperty("AccountSubType").GetString(),
                Classification = account.GetProperty("Classification").GetString(),
                CompanySource = "QuickBooks",
                QuickBooksUserId = userId,
                CreatedAt = DateTime.UtcNow,
                Active = account.GetProperty("Active").GetBoolean()
            };

            // Handle CurrentBalance which might be nullable
            if (account.TryGetProperty("CurrentBalance", out JsonElement balanceElement) &&
                balanceElement.ValueKind != JsonValueKind.Null)
            {
                chartAccount.CurrentBalance = balanceElement.GetDecimal();
            }

            // Handle CurrencyRef if present
            if (account.TryGetProperty("CurrencyRef", out JsonElement currencyElement) &&
                currencyElement.ValueKind != JsonValueKind.Null)
            {
                var currencyRef = new CurrencyRef();

                if (currencyElement.TryGetProperty("value", out JsonElement valueElement))
                {
                    currencyRef.Value = valueElement.GetString();
                    chartAccount.CurrencyValue = valueElement.GetString();
                }

                if (currencyElement.TryGetProperty("name", out JsonElement nameElement))
                {
                    currencyRef.Name = nameElement.GetString();
                    chartAccount.CurrencyName = nameElement.GetString();
                }

                chartAccount.CurrencyRef = currencyRef;
            }

            return chartAccount;
        }

        // Map Xero Account to our ChartOfAccount model

        public ChartOfAccount MapXeroAccount(JsonElement accountJson, string userId)
        {
            var chartAccount = new ChartOfAccount
            {
                QuickBooksAccountId = accountJson.GetProperty("AccountID").GetString(),
                Name = accountJson.GetProperty("Name").GetString(),
                AccountType = accountJson.GetProperty("Type").GetString(),
                CompanySource = "Xero",
                QuickBooksUserId = userId,
                CreatedAt = DateTime.UtcNow,
                Active = accountJson.GetProperty("Status").GetString() == "ACTIVE",
                // Provide default values for all required non-nullable fields
                CurrencyValue = "DEFAULT", // Set a default value for CurrencyValue
                CurrencyName = "DEFAULT"   // If this is also non-nullable in DB
            };

            // Handle Classification/Class
            if (accountJson.TryGetProperty("Class", out JsonElement classElement) &&
                classElement.ValueKind != JsonValueKind.Null)
            {
                chartAccount.Classification = classElement.GetString();
            }
            else
            {
                chartAccount.Classification = "DEFAULT"; // Provide default if required
            }

            // For AccountSubType, use ReportingCodeName if available, otherwise use Code
            if (accountJson.TryGetProperty("ReportingCodeName", out JsonElement reportingCodeElement) &&
                reportingCodeElement.ValueKind != JsonValueKind.Null)
            {
                chartAccount.AccountSubType = reportingCodeElement.GetString();
            }
            else if (accountJson.TryGetProperty("Code", out JsonElement codeElement))
            {
                chartAccount.AccountSubType = codeElement.GetString();
            }
            else
            {
                chartAccount.AccountSubType = "DEFAULT"; // Provide default if required
            }

            // Check for currency information in Xero response
            if (accountJson.TryGetProperty("CurrencyCode", out JsonElement currencyElement) &&
                currencyElement.ValueKind != JsonValueKind.Null)
            {
                chartAccount.CurrencyValue = currencyElement.GetString();
            }

            return chartAccount;
        }

        // Process full QuickBooks response
        public List<ChartOfAccount> ProcessQuickBooksResponse(JsonElement response, string userId)
        {
            var accounts = new List<ChartOfAccount>();

            // Check if response is an array
            if (response.ValueKind == JsonValueKind.Array)
            {
                foreach (var account in response.EnumerateArray())
                {
                    accounts.Add(MapQuickBooksAccount(account, userId));
                }
            }
            else if (response.ValueKind == JsonValueKind.Object)
            {
                // Single account object
                accounts.Add(MapQuickBooksAccount(response, userId));
            }

            return accounts;
        }

        // Process full Xero response
        public List<ChartOfAccount> ProcessXeroResponse(JsonElement response, string userId)
        {
            var accounts = new List<ChartOfAccount>();

            // Check for Accounts array in response
            if (response.TryGetProperty("Accounts", out JsonElement accountsArray) &&
                accountsArray.ValueKind == JsonValueKind.Array)
            {
                foreach (var account in accountsArray.EnumerateArray())
                {
                    accounts.Add(MapXeroAccount(account, userId));
                }
            }

            return accounts;
        }
    }
}
