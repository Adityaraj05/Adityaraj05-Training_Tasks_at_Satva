﻿using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
namespace Data_Access_Layer.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<QuickBooksToken> QuickBooksTokens { get; set; }
        public DbSet<ChartOfAccount> ChartOfAccounts { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
        public DbSet<InvoiceLineItem> InvoiceLineItem { get; set; }
        public DbSet<Vendor> Vendors { get; set; }
        public DbSet<Bill> Bills { get; set; }
        public DbSet<BillLineItem> BillLineItems { get; set; }

 
        public DbSet<XeroToken> XeroTokens { get; set; }






        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Ignore<CurrencyRef>();
            modelBuilder.Entity<ChartOfAccount>()
            .Property(c => c.QuickBooksAccountId)
             .HasConversion<string>();
            // Add any customer-specific configurations here
            modelBuilder.Entity<Customer>()
                .HasIndex(c => c.DisplayName);

            modelBuilder.Entity<Customer>()
                .HasIndex(c => c.Email);

        }
    }
}
