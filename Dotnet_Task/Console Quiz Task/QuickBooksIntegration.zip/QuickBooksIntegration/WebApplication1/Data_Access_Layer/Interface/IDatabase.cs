﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Interface
{
    public interface IDatabase
    {

        Task<ApiResponse<List<ChartOfAccount>>> FetchChartOfAccountsFromDbPaginated(int page = 1, int pageSize = 10, string? searchTerm = null);
    }
}
