﻿namespace Data_Access_Layer.Models
{
    public class LineItem
    {
        public decimal Amount { get; set; }
        public string DetailType { get; set; }
        public string Description { get; set; }
        public string AccountId { get; set; }
        public string TaxCodeId { get; set; }
        public string ItemId { get; set; }
        public decimal? Quantity { get; set; }
        public decimal? UnitPrice { get; set; }
        public string CustomerId { get; set; }
        public string BillableStatus { get; set; }
    }
}