﻿// Models/DTO/InvoiceCsvModel.cs
using System;
using System.ComponentModel.DataAnnotations;

namespace Data_Access_Layer.Models.DTO
{
    public class InvoiceCsvModel
    {
        [Required]
        public string InvoiceNumber { get; set; }

        [Required]
        public string CustomerName { get; set; }

        public string CustomerEmail { get; set; }

        [Required]
        public string InvoiceDate { get; set; }

        [Required]
        public string DueDate { get; set; }

        [Required]
        public string ItemName { get; set; }

        public string ItemDescription { get; set; }

        [Required]
        public string Quantity { get; set; }

        [Required]
        public string Rate { get; set; }
    }
}