﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Models.DTO
{
    public class InvoiceDTOs
    {
        public int Id { get; set; }
        public int InvoiceId { get; set; }
        public int CustomerId { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public string Store { get; set; }
        public string BillingAddress { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Total { get; set; }
        public bool SendLater { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public List<InvoiceLineItem> LineItems { get; set; } = new();

    }
    public class InvoiceInputModel
    {
        public string? CustomerId { get; set; }
        public string? CustomerExternalId { get; set; }
        public string? CustomerName { get; set; }
        public DateTime InvoiceDate { get; set; }
        public string? InvoiceNumber { get; set; }
        public DateTime DueDate { get; set; }
        public string? BillingAddress { get; set; }
        public string? Currency { get; set; }
        public string? Status { get; set; }
        public string? Type { get; set; }
        public string? LineAmountTypes { get; set; }
        public string? Store { get; set; }
        public bool SendLater { get; set; }
        public List<InvoiceLineItemInputModel> LineItems { get; set; } = new List<InvoiceLineItemInputModel>();
        public string? CustomerEmail { get; internal set; }
    }
    public class InvoiceLineItemInputModel
    {
        public string? Description { get; set; }
        public int Quantity { get; set; }
        public decimal Rate { get; set; }
        public string? ProductId { get; set; }
        public string? AccountCode { get; set; }
        public string? TaxType { get; set; }
        public int Amount { get; internal set; }
    }
    public class PagedResponse<T>
    {
        public List<T> Items { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
        public PagedResponse(List<T> items, int pageNumber, int pageSize, int totalCount)
        {
            Items = items;
            PageNumber = pageNumber;
            PageSize = pageSize;
            TotalCount = totalCount;
        }
    }
}
