﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Models.DTO
{
    public class PaginatedResponse<T> where T : class
    {
        private List<Invoice> invoices;
        private int page;

        public IEnumerable<T> Items { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages { get; set; }

        public PaginatedResponse(IEnumerable<T> items, int count, int pageSize, PaginationParams paginationParams)
        {
            PageNumber = paginationParams.PageNumber;
            PageSize = paginationParams.PageSize;
            TotalCount = count;
            PageSize = pageSize;
            TotalPages = (count + PageSize - 1) / PageSize;
            Items = items;
        }

        public PaginatedResponse(List<Invoice> invoices, int page, int pageSize, int totalCount)
        {
            this.invoices = invoices;
            this.page = page;
            PageSize = pageSize;
            TotalCount = totalCount;
        }
    }
}
