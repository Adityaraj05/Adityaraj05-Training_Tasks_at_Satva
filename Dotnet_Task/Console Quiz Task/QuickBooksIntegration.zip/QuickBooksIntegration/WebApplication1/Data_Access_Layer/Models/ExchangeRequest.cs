﻿namespace Data_Access_Layer.Models
{
    public class ExchangeRequest
    {
        public string Code { get; set; }
        public string State { get; set; }
        public string RealmId { get; set; }
    }
}
