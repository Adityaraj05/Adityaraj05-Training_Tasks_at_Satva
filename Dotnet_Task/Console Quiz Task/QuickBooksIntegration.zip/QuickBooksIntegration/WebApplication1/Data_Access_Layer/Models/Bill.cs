﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Data_Access_Layer.Models
{
    public class Bill
    {
        [Key]
        public int Id { get; set; }

        // Common ID fields for both QuickBooks and Xero
        public string? QuickBooksBillId { get; set; }
        public string? XeroBillId { get; set; }

        // Company source to identify where the bill is from
        public string CompanySource { get; set; } = "QuickBooks"; // Default value

        // Tenant IDs
        public string? QuickBooksUserId { get; set; }
        public string? XeroTenantId { get; set; }

        // Common fields from both systems
        public string? DocNumber { get; set; } // QuickBooks equivalent
        public string? InvoiceNumber { get; set; } // Xero equivalent
        public string? Reference { get; set; }
        public string SyncToken { get; set; } = "1"; // Default for new records

        // Vendor reference
        public string? VendorId { get; set; } // QuickBooks
        public string? ContactId { get; set; } // Xero
        public string? VendorName { get; set; } // Common

        // AP Account reference
        public string? APAccountId { get; set; }
        public string? APAccountName { get; set; }

        // Date information
        public DateTime? TxnDate { get; set; } // QuickBooks
        public DateTime? Date { get; set; } // Xero
        public DateTime? DueDate { get; set; } // Common

        // Financial info
        public decimal? TotalAmt { get; set; } // QuickBooks
        public decimal? Total { get; set; } // Xero
        public decimal? SubTotal { get; set; }
        public decimal? TotalTax { get; set; }
        public decimal? Balance { get; set; } // QuickBooks
        public decimal? AmountDue { get; set; } // Xero
        public decimal? AmountPaid { get; set; }
        public decimal? AmountCredited { get; set; }

        // Currency info
        public string? CurrencyValue { get; set; } // QuickBooks
        public string? CurrencyCode { get; set; } // Xero
        public string? CurrencyName { get; set; }
        public decimal? CurrencyRate { get; set; } = 1.0m; // Default value

        // Status
        public string? Status { get; set; }
        public bool? Paid { get; set; }
        public bool IsDiscounted { get; set; }
        public bool HasAttachments { get; set; }
        public bool HasErrors { get; set; }

        // Memo/Notes
        public string? PrivateNote { get; set; }
        public string? LineAmountTypes { get; set; } // "Exclusive" or "Inclusive" in Xero

        // Timestamps
        public DateTime? QuickBooksCreateTime { get; set; }
        public DateTime? QuickBooksLastUpdateTime { get; set; }
        public DateTime? XeroUpdateTime { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        [InverseProperty("Bill")]
        public ICollection<BillLineItem> LineItems { get; set; } = new List<BillLineItem>();
    }

    // Update BillLineItem to accommodate Xero-specific fields
    public class BillLineItem
    {
        [Key]
        public int Id { get; set; }

        // IDs for both systems
        public string? LineId { get; set; } // QuickBooks
        public string? XeroLineId { get; set; } // Xero

        public int BillId { get; set; }

        [ForeignKey("BillId")]
        [JsonIgnore]
        public Bill? Bill { get; set; }

        // Line details
        public string? Description { get; set; }
        public string? DetailType { get; set; } // AccountBasedExpenseLineDetail or ItemBasedExpenseLineDetail

        // Account reference (for AccountBasedExpenseLineDetail)
        public string? AccountId { get; set; }
        public string? AccountName { get; set; }

        // Item reference (for ItemBasedExpenseLineDetail)
        public string? ItemId { get; set; }
        public string? ItemName { get; set; }

        // Financial info
        public decimal? Amount { get; set; }
        public decimal? UnitPrice { get; set; }
        public decimal? Quantity { get; set; }

        // Tax info
        public string? TaxCodeId { get; set; }
        public string? TaxType { get; set; } // Xero specific
        public decimal? TaxAmount { get; set; } // Xero specific

        // Customer reference (for billable expenses)
        public string? CustomerId { get; set; }
        public string? CustomerName { get; set; }
        public string? BillableStatus { get; set; } // Billable, NotBillable, HasBeenBilled
    }
}