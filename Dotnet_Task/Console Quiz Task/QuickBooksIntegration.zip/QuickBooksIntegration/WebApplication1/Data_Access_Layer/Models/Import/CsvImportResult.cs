﻿
using System.Collections.Generic;

namespace Data_Access_Layer.Models.Import
{
    public class CsvImportResult
    {
        public bool Success { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
        public int TotalRows { get; set; }
        public int ProcessedRows { get; set; }
        public int CreatedCustomers { get; set; }
        public int CreatedItems { get; set; }
        public int CreatedInvoices { get; set; }
        public int UpdatedInvoices { get; set; }
    }

    public class ValidationError
    {
        public int RowNumber { get; set; }
        public string Message { get; set; }
    }
}