﻿// Models/QuickBooksResponse.cs
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Data_Access_Layer.Models
{
    public class QBInvoiceResponse
    {
        public QueryResponse QueryResponse { get; set; }
    }

    public class QueryResponse
    {
        public List<QBInvoice> Invoice { get; set; }
    }

    public class QBInvoice
    {
        public string Id { get; set; }
        public string SyncToken { get; set; }
        public string DocNumber { get; set; }
        public string TxnDate { get; set; }
        public CustomerRef CustomerRef { get; set; }
        public BillAddr BillAddr { get; set; }
        public BillEmail BillEmail { get; set; }
        public string DueDate { get; set; }
        public string TotalAmt { get; set; }
        public List<QBInvoiceLine> Line { get; set; }
    }

    public class CustomerRef
    {
        public string value { get; set; }
        public string name { get; set; }
    }

    public class BillAddr
    {
        public string Id { get; set; }
        public string Line1 { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string CountrySubDivisionCode { get; set; }
        public string PostalCode { get; set; }
    }

    public class BillEmail
    {
        public string Address { get; set; }
    }

    public class QBInvoiceLine
    {
        public string Id { get; set; }
        public int? LineNum { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public string DetailType { get; set; }
        public SalesItemLineDetail SalesItemLineDetail { get; set; }
    }

    public class SalesItemLineDetail
    {
        public ItemRef ItemRef { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Qty { get; set; }
    }

    public class ItemRef
    {
        public string value { get; set; }
        public string name { get; set; }
    }

    public class QBInvoiceCreateResponse
    {
        public QBInvoice Invoice { get; set; }
    }
}