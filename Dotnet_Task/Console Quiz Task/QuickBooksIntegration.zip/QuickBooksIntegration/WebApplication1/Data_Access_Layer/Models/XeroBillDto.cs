﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Data_Access_Layer.Models
{
    public class XeroBillDto
    {
        [JsonPropertyName("Id")]
        public string? Id { get; set; }

        [JsonPropertyName("InvoiceID")]
        public string? InvoiceID { get; set; }

        [JsonPropertyName("InvoiceNumber")]
        public string? InvoiceNumber { get; set; }

        [JsonPropertyName("Reference")]
        public string? Reference { get; set; }

        [JsonPropertyName("Contact")]
        public XeroContactDto Contact { get; set; } = new XeroContactDto();

        [JsonPropertyName("Date")]
        public DateTime Date { get; set; }

        [JsonPropertyName("DueDate")]
        public DateTime DueDate { get; set; }

        [JsonPropertyName("Status")]
        public string Status { get; set; } = "AUTHORISED";

        [JsonPropertyName("LineAmountTypes")]
        public string LineAmountTypes { get; set; } = "Exclusive";

        [JsonPropertyName("CurrencyCode")]
        public string? CurrencyCode { get; set; } = "INR";

        [JsonPropertyName("Type")]
        public string Type { get; set; } = "ACCPAY";

        [JsonPropertyName("LineItems")]
        public List<XeroBillLineItemDto> LineItems { get; set; } = new List<XeroBillLineItemDto>();
    }
    public class XeroContactDto
    {
        [JsonPropertyName("ContactID")]
        public string ContactID { get; set; } = string.Empty;
    }
    public class XeroBillLineItemDto
    {
        [JsonPropertyName("Description")]
        public string? Description { get; set; }

        [JsonPropertyName("Quantity")]
        public decimal Quantity { get; set; } = 1;

        [JsonPropertyName("UnitAmount")]
        public decimal UnitAmount { get; set; }

        [JsonPropertyName("AccountCode")]
        public string? AccountCode { get; set; }

        [JsonPropertyName("ItemCode")]
        public string? ItemCode { get; set; }

        [JsonPropertyName("TaxType")]
        public string? TaxType { get; set; }

        [JsonPropertyName("TaxAmount")]
        public decimal? TaxAmount { get; set; }

        [JsonPropertyName("LineAmount")]
        public decimal LineAmount { get; set; }
    }

    // For pagination and filtering
    public class BillQueryParameters
    {
        public string? TenantId { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string? SearchTerm { get; set; }
        public string? Status { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string? SortBy { get; set; } = "Date";
        public bool SortAscending { get; set; } = false;
    }

    // For Xero API response mapping
    public class XeroResponse<T>
    {
        public List<T> Items { get; set; } = new List<T>();
    }
}
