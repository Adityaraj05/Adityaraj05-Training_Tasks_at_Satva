﻿namespace Data_Access_Layer.Models
{
    public class Product
    {
        // Common / Local Fields
        public int Id { get; set; } 
        public string? Name { get; set; }
        public string? Description { get; set; }
        public decimal? UnitPrice { get; set; }

        public string? IncomeAccountId { get; set; }
        public string? IncomeAccountName { get; set; }

        public string? ExpenseAccountId { get; set; }
        public string? ExpenseAccountName { get; set; }

        public string? AssetAccountId { get; set; }
        public string? AssetAccountName { get; set; }

        public int? QuantityOnHand { get; set; }
        public DateTime? InventoryStartDate { get; set; }

        public bool IsTrackedAsInventory { get; set; } // Xero only
        public bool IsSold { get; set; } // Xero only
        public bool IsPurchased { get; set; } // Xero only

        public bool Taxable { get; set; } // QuickBooks
        public bool Active { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        // Source Tracking
        public string? SourceSystem { get; set; } 


        public string? QuickBooksItemId { get; set; }
        public string? QuickBooksUserId { get; set; }
        public string? SyncToken { get; set; }
        public string? Type { get; set; } 

        public string? XeroItemId { get; set; }
        public string? Code { get; set; }

        public DateTime? UpdatedDateUTC { get; set; }

        public string? PurchaseDescription { get; set; }

        public double? TotalCostPool { get; set; } 
        public string? InventoryAssetAccountCode { get; set; } 

        // Flattened PurchaseDetails (Xero)
        public double? XeroPurchaseUnitPrice { get; set; }
        public string? XeroPurchaseAccountCode { get; set; }
        public string? XeroPurchaseTaxType { get; set; }
        public string? XeroCOGSAccountCode { get; set; }

  
        public double? XeroSalesUnitPrice { get; set; }
        public string? XeroSalesAccountCode { get; set; }
        public string? XeroSalesTaxType { get; set; }
    }
}
