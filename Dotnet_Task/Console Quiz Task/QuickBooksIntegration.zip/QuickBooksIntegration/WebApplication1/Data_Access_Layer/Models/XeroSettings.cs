﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.Models
{
    public class XeroSettings
    {
  
  
        public string ApiBaseUrl { get; set; }
        public string TokenUrl { get; set; }
        public string AuthUrl { get; set; }       
        public string ConnectionsUrl { get; set; }
    }

}
