﻿
using System.ComponentModel.DataAnnotations;

namespace Data_Access_Layer.Models
{

    public class XeroToken
    {
        [Key]
        public int Id { get; set; }
        public string? XeroUserId { get; set; }
        public string TenantId { get; set; }
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public string? IdToken { get; set; }
        public string? TokenType { get; set; } = "Bearer";
        public int ExpiresIn { get; set; }
        public int? RefreshTokenExpiresIn { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAt { get; set; }
    }

    public class XeroRefreshTokenRequest
    {
        public string RefreshToken { get; set; }
    }

    public class XeroExchangeRequest
    {
        public string Code { get; set; }
        public string State { get; set; }
    }
}
