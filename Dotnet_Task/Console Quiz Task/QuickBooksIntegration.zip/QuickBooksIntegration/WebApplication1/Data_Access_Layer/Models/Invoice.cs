﻿using System.Text.Json.Serialization;

namespace Data_Access_Layer.Models
{
    // Models/Invoice.cs
    public class Invoice
    {
        public int Id { get; set; } // Primary Key
        public int? CustomerId { get; set; }
        public string? CustomerName { get; set; } // Added for Xero Contact.Name
        public string? CustomerExternalId { get; set; } // Added for Xero Contact.ContactID
        public DateTime InvoiceDate { get; set; }
        public string? InvoiceNumber { get; set; } // Added for Xero InvoiceNumber
        public DateTime DueDate { get; set; }
        public string? Store { get; set; }
        public string? BillingAddress { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Total { get; set; }
        public decimal? TotalTax { get; set; } // Added for Xero TotalTax
        public string? Currency { get; set; } // Added for Xero CurrencyCode
        public decimal? AmountDue { get; set; } // Added for Xero AmountDue
        public decimal? AmountPaid { get; set; } // Added for Xero AmountPaid
        public string? Status { get; set; } 
        public bool SendLater { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string SourceCompany { get; set; } = "QuickBook";
        public string? ExternalId { get; set; } // Xero InvoiceID
        public string? XeroTenantId { get; set; }
        public string? Type { get; set; } // Added for Xero Type (ACCREC, etc.)
        public string? LineAmountTypes { get; set; } // Added for Xero LineAmountTypes

        // Navigation property for line items

        [JsonIgnore]
        public virtual ICollection<InvoiceLineItem>? LineItems { get; set; }
        public int InvoiceId { get; set; }
 
    }

    // Models/InvoiceLineItem.cs
    public class InvoiceLineItem
    {
        public int Id { get; set; }
        public string LineId { get; set; } // Xero LineItemID
        public int InvoiceId { get; set; } // Foreign key to Invoice
        public string? ProductId { get; set; } // Xero ItemCode
        public string? Description { get; set; }
        public int Quantity { get; set; }
        public decimal Rate { get; set; } // Xero UnitAmount
        public decimal Amount { get; set; } // Xero LineAmount
        public string? TaxType { get; set; } // Added for Xero TaxType
        public decimal? TaxAmount { get; set; } // Added for Xero TaxAmount
        public string? AccountCode { get; set; } // Added for Xero AccountCode
        public string? AccountId { get; set; } // Added for Xero AccountID
        public string? ItemId { get; set; } // Added for Xero Item.ItemID
        public string? ItemName { get; set; } // Added for Xero Item.Name

   
        [JsonIgnore]
        public virtual Invoice? Invoice { get; set; }
    }
}