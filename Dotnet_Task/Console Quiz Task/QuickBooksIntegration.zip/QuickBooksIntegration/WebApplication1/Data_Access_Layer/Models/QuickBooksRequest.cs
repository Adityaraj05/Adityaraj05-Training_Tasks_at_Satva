﻿namespace Data_Access_Layer.Models
{
    public class QuickBooksRequest
    {
        public string AccessToken { get; set; }
        public string RealmId { get; set; }
    }
}
