﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IAuthService
    {
        string GetLoginUrl();
        Task<(bool Success, string Message, int? TokenId)> ExchangeCodeAsync(ExchangeRequest request);
        Task<(bool Success, string Message)> LogoutAsync();
    }
}
