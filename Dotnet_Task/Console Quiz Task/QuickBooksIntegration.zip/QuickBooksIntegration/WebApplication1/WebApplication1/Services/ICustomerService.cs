﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface ICustomerService
    {
        Task<object> FetchCustomersFromDbPaginated(int page, int pageSize, string searchTerm);
        Task<List<Customer>> FetchCustomersFromQuickBooks();
        Task<Customer> AddCustomer(CustomerDto customerDto);
        Task<Customer> UpdateCustomer(int id, CustomerDto customerDto);
        Task<bool> DeleteCustomer(string id);
    }
}