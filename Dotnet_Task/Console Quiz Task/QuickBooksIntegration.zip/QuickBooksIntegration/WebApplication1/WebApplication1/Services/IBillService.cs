﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IBillService
    {
        Task<List<Bill>> FetchBillsFromQuickBooksAsync();
        Task<object> FetchBillsFromDbPaginated(int page, int pageSize, string searchTerm);
        Task<Bill> CreateBillInQuickBooksAsync(Bill bill);
        Task<object> GetAllVendorDetailsAsync();
        Task<object> GetChartOfAccountIdAndNamesAsync();
        Task<object> GetAllProductDetailsAsync();
        Task<object> GetAllCustomerDetailsAsync();
    }
}
