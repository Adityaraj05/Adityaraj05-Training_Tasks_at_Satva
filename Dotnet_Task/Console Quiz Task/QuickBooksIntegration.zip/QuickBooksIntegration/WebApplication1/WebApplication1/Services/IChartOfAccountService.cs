﻿using static WebApplication1.Services.ChartOfAccountService;

namespace WebApplication1.Services
{
    public interface IChartOfAccountService
    {
        Task<object> FetchChartOfAccountsFromDbPaginated(int page, int pageSize, string? searchTerm);
        Task<(bool Success, object? Result, string? ErrorMessage)> FetchChartOfAccountsFromQuickBooks();
        Task<ProductAccountOptionsDto> GetProductAccountOptionsAsync(string quickBooksUserId, int? productId);

    }
}
