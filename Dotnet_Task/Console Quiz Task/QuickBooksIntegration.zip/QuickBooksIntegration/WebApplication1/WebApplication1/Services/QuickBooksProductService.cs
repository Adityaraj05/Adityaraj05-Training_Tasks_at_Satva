﻿using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using System.Text.Json;
using System.Text;
using System.Text.Json.Serialization;
using System.Globalization;

namespace WebApplication1.Services
{
    public class QuickBooksProductService : IQuickBooksProductService
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<QuickBooksProductService> _logger;

        public QuickBooksProductService(HttpClient httpClient, ApplicationDbContext dbContext, ILogger<QuickBooksProductService> logger)
        {
            _httpClient = httpClient;
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<object> FetchProductsFromDbPaginated(int page, int pageSize, string? searchTerm)
        {
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                return new { Error = "No QuickBooks token found." };

            var query = _dbContext.Products
                .Where(p => p.Active); // Only show active ones

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                string likeTerm = $"%{searchTerm}%";
                query = query.Where(p =>
                    EF.Functions.Like(p.Name, likeTerm) ||
                    EF.Functions.Like(p.Type, likeTerm) ||
                    EF.Functions.Like(p.IncomeAccountName, likeTerm) ||
                    (p.ExpenseAccountName != null && EF.Functions.Like(p.ExpenseAccountName, likeTerm)) ||
                    (p.AssetAccountName != null && EF.Functions.Like(p.AssetAccountName, likeTerm))
                );
            }

            var totalRecords = await query.CountAsync();
            var pagedData = await query
                .OrderBy(p => p.Name)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return new
            {
                TotalRecords = totalRecords,
                TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize),
                CurrentPage = page,
                PageSize = pageSize,
                Data = pagedData
            };
        }

        public async Task<List<Product>> SyncProductsFromQuickBooksAsync()
        {
            var token = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
                throw new Exception("QuickBooks token not found.");

            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{token.RealmId}/query?query=SELECT * FROM Item";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(request);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"QuickBooks API Error: {response.StatusCode} - {json}");

            var items = ParseItemsFromJson(json); // Returns List<Product>

            using var transaction = await _dbContext.Database.BeginTransactionAsync();

            try
            {
                var quickBooksItemIds = items.Select(i => i.QuickBooksItemId).ToList();

                // Update or Insert
                foreach (var item in items)
                {
                    var existing = await _dbContext.Products
                        .FirstOrDefaultAsync(p => p.QuickBooksItemId == item.QuickBooksItemId);

                    if (existing != null)
                    {
                        // Update
                        existing.Name = item.Name;
                        existing.Type = item.Type;
                        existing.UnitPrice = item.UnitPrice;
                        existing.IncomeAccountId = item.IncomeAccountId;
                        existing.IncomeAccountName = item.IncomeAccountName;
                        existing.ExpenseAccountId = item.ExpenseAccountId;
                        existing.ExpenseAccountName = item.ExpenseAccountName;
                        existing.AssetAccountId = item.AssetAccountId;
                        existing.AssetAccountName = item.AssetAccountName;
                        existing.QuantityOnHand = item.QuantityOnHand;
                        existing.InventoryStartDate = item.InventoryStartDate;
                        existing.Taxable = item.Taxable;
                        existing.Active = item.Active;
                        existing.SyncToken = item.SyncToken;
                        existing.UpdatedAt = DateTime.UtcNow;
                    }
                    else
                    {
                        // Insert
                        item.CreatedAt = DateTime.UtcNow;
                        item.UpdatedAt = DateTime.UtcNow;
                        await _dbContext.Products.AddAsync(item);
                    }
                }

                // Mark missing products as inactive
                var productsInDb = await _dbContext.Products.ToListAsync();
                foreach (var dbProduct in productsInDb)
                {
                    if (!quickBooksItemIds.Contains(dbProduct.QuickBooksItemId))
                    {
                        dbProduct.Active = false;
                        dbProduct.UpdatedAt = DateTime.UtcNow;
                    }
                }

                await _dbContext.SaveChangesAsync();
                await transaction.CommitAsync();

                return items;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Failed syncing QuickBooks items");
                throw;
            }
        }

        private List<Product> ParseItemsFromJson(string json)
        {
            var result = new List<Product>();

            var root = JObject.Parse(json);
            var items = root["QueryResponse"]?["Item"];

            if (items == null) return result;

            foreach (var item in items)
            {
                var type = item["Type"]?.ToString();
                if (type != "Inventory" && type != "Service")
                    continue;

                var product = new Product
                {
                    QuickBooksItemId = item["Id"]?.ToString(),
                    Name = item["Name"]?.ToString(),
                    Type = type,
                    UnitPrice = item["UnitPrice"]?.Value<decimal>() ?? 0,

                    IncomeAccountId = item["IncomeAccountRef"]?["value"]?.ToString(),
                    IncomeAccountName = item["IncomeAccountRef"]?["name"]?.ToString(),

                    ExpenseAccountId = item["ExpenseAccountRef"]?["value"]?.ToString(),
                    ExpenseAccountName = item["ExpenseAccountRef"]?["name"]?.ToString(),

                    AssetAccountId = item["AssetAccountRef"]?["value"]?.ToString(),
                    AssetAccountName = item["AssetAccountRef"]?["name"]?.ToString(),

                    QuantityOnHand = item["QtyOnHand"]?.Value<int?>(),
                    InventoryStartDate = item["InvStartDate"]?.Value<DateTime?>(),

                    Taxable = item["Taxable"]?.Value<bool>() ?? false,
                    Active = item["Active"]?.Value<bool>() ?? true,
                    SyncToken = item["SyncToken"]?.ToString()
                };

                result.Add(product);
            }

            return result;
        }

        public async Task<Product> AddProductAsync(Product product)
        {
            var token = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
                throw new Exception("No QuickBooks token found");

            var realmId = token.RealmId;
            var accessToken = token.AccessToken;

            product.Type = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(product.Type.ToLower());

            // Get account names from DB but only if IDs are provided
            if (product.IncomeAccountId != null)
            {
                product.IncomeAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.IncomeAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync();
            }

            if (product.ExpenseAccountId != null)
            {
                product.ExpenseAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.ExpenseAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync();
            }

            if (product.Type == "Inventory")
            {
                product.AssetAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.AssetAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync();
            }

            //Console.WriteLine($"Income Account → ID: {product.IncomeAccountId}, Name: {product.IncomeAccountName}");
            //Console.WriteLine($"Expense Account → ID: {product.ExpenseAccountId}, Name: {product.ExpenseAccountName}");
            //Console.WriteLine($"Asset Account → ID: {product.AssetAccountId}, Name: {product.AssetAccountName}");

            // Validate according to QuickBooks requirements
            if (product.Type == "Service" && product.IncomeAccountId == null && product.ExpenseAccountId == null)
            {
                throw new Exception("For Service products, at least one of Income Account or Expense Account must be provided");
            }

            // ✅ Construct QuickBooks payload with both ID and name
            var itemDto = new QuickBooksItemDto
            {
                Name = product.Name,
                Type = product.Type,
                UnitPrice = product.UnitPrice,
                Taxable = product.Taxable
            };

            // Only add IncomeAccountRef if we have an income account
            if (product.IncomeAccountId != null)
            {
                itemDto.IncomeAccountRef = new AccountRef
                {
                    value = product.IncomeAccountId,
                    name = product.IncomeAccountName
                };
            }

            // Only add ExpenseAccountRef for a Service if ExpenseAccountId is provided
            if (product.Type == "Service" && product.ExpenseAccountId != null)
            {
                itemDto.ExpenseAccountRef = new AccountRef
                {
                    value = product.ExpenseAccountId,
                    name = product.ExpenseAccountName
                };
            }

            if (product.Type == "Inventory")
            {
                itemDto.TrackQtyOnHand = true;
                itemDto.QtyOnHand = product.QuantityOnHand;
                itemDto.InvStartDate = product.InventoryStartDate?.ToString("yyyy-MM-dd");

                // For Inventory, ExpenseAccountRef is required
                itemDto.ExpenseAccountRef = new AccountRef
                {
                    value = product.ExpenseAccountId,
                    name = product.ExpenseAccountName
                };

                itemDto.AssetAccountRef = new AccountRef
                {
                    value = product.AssetAccountId,
                    name = product.AssetAccountName
                };
            }

            var jsonOptions = new JsonSerializerOptions
            {
                PropertyNamingPolicy = null,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
            };

            var jsonContent = JsonSerializer.Serialize(itemDto, jsonOptions);

            // 👇 Add this line to debug what you're sending to QuickBooks
            //Console.WriteLine("Sending JSON to QuickBooks:");
            //Console.WriteLine(jsonContent);

            // 📤 Send to QuickBooks
            var request = new HttpRequestMessage(HttpMethod.Post, $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item")
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");

            // 🧠 Store relevant info returned from QuickBooks
            var itemJson = JsonDocument.Parse(responseBody).RootElement.GetProperty("Item");

            product.QuickBooksItemId = itemJson.GetProperty("Id").GetString();
            product.SyncToken = itemJson.GetProperty("SyncToken").GetString();
            product.CreatedAt = DateTime.UtcNow;
            product.UpdatedAt = DateTime.UtcNow;

            _dbContext.Products.Add(product);
            await _dbContext.SaveChangesAsync();

            return product;
        }

        public async Task<Product> UpdateProductAsync(Product product)
        {
            var token = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();
            if (token == null)
                throw new Exception("No QuickBooks token found");

            var realmId = token.RealmId;
            var accessToken = token.AccessToken;

            // First update our database record
            product.Type = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(product.Type.ToLower());

            // Ensure account names are set correctly, but only if IDs are provided
            if (product.IncomeAccountId != null)
            {
                product.IncomeAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.IncomeAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync() ?? product.IncomeAccountName;
            }
            else
            {
                // If ID is null, name should be null too
                product.IncomeAccountName = null;
            }

            if (product.ExpenseAccountId != null)
            {
                product.ExpenseAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.ExpenseAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync() ?? product.ExpenseAccountName;
            }
            else
            {
                // If ID is null, name should be null too
                product.ExpenseAccountName = null;
            }

            if (product.Type == "Inventory" && product.AssetAccountId != null)
            {
                product.AssetAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.AssetAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync() ?? product.AssetAccountName;
            }

            // Validate according to QuickBooks requirements
            if (product.Type == "Service" && product.IncomeAccountId == null && product.ExpenseAccountId == null)
            {
                throw new Exception("For Service products, at least one of Income Account or Expense Account must be provided");
            }

            //Console.WriteLine("Product data pre-processing:");
            //Console.WriteLine($"ID: {product.Id}");
            //Console.WriteLine($"QuickBooksItemId: {product.QuickBooksItemId}");
            //Console.WriteLine($"Name: {product.Name}");
            //Console.WriteLine($"Type: {product.Type}");
            //Console.WriteLine($"Income Account ID: {product.IncomeAccountId}");
            //Console.WriteLine($"Income Account Name: {product.IncomeAccountName}");
            //Console.WriteLine($"Expense Account ID: {product.ExpenseAccountId}");
            //Console.WriteLine($"Expense Account Name: {product.ExpenseAccountName}");

            // Create a base DTO with common fields
            var baseDto = new
            {
                Id = product.QuickBooksItemId,
                SyncToken = product.SyncToken,
                Name = product.Name,
                Type = product.Type,
                UnitPrice = product.UnitPrice,
                Taxable = product.Taxable
            };

            // Create the final DTO based on product type and account availability
            object finalDto;

            if (product.Type == "Inventory")
            {
                // Inventory products need both income and expense accounts
                finalDto = new
                {
                    Id = product.QuickBooksItemId,
                    SyncToken = product.SyncToken,
                    Name = product.Name,
                    Type = product.Type,
                    UnitPrice = product.UnitPrice,
                    Taxable = product.Taxable,
                    IncomeAccountRef = new
                    {
                        value = product.IncomeAccountId,
                        name = product.IncomeAccountName
                    },
                    TrackQtyOnHand = true,
                    QtyOnHand = product.QuantityOnHand,
                    InvStartDate = product.InventoryStartDate?.ToString("yyyy-MM-dd"),
                    ExpenseAccountRef = new
                    {
                        value = product.ExpenseAccountId,
                        name = product.ExpenseAccountName
                    },
                    AssetAccountRef = new
                    {
                        value = product.AssetAccountId,
                        name = product.AssetAccountName
                    }
                };
            }
            else
            {
                // For Service type, conditionally include account references
                var dtoDict = new Dictionary<string, object>
                    {
                        { "Id", product.QuickBooksItemId },
                        { "SyncToken", product.SyncToken },
                        { "Name", product.Name },
                        { "Type", product.Type },
                        { "UnitPrice", product.UnitPrice },
                        { "Taxable", product.Taxable }
                    };

                // Only add IncomeAccountRef if the ID is provided
                if (product.IncomeAccountId != null)
                {
                    dtoDict["IncomeAccountRef"] = new
                    {
                        value = product.IncomeAccountId,
                        name = product.IncomeAccountName
                    };
                }

                // Only add ExpenseAccountRef if the ID is provided
                if (product.ExpenseAccountId != null)
                {
                    dtoDict["ExpenseAccountRef"] = new
                    {
                        value = product.ExpenseAccountId,
                        name = product.ExpenseAccountName
                    };
                }

                finalDto = dtoDict;
            }

            var jsonOptions = new JsonSerializerOptions
            {
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                WriteIndented = true // For clearer logging
            };

            var jsonContent = JsonSerializer.Serialize(finalDto, jsonOptions);
            Console.WriteLine("Sending JSON to QuickBooks for update:");
            Console.WriteLine(jsonContent);

            // Make the API request to QuickBooks
            var request = new HttpRequestMessage(HttpMethod.Post, $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item")
            {
                Headers =
                {
                    Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                    Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
                },
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                Console.WriteLine($"Error response from QuickBooks API: {responseBody}");
                throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");
            }

            var itemJson = JsonDocument.Parse(responseBody).RootElement.GetProperty("Item");
            product.SyncToken = itemJson.GetProperty("SyncToken").GetString();
            product.UpdatedAt = DateTime.UtcNow;

            _dbContext.Products.Update(product);
            await _dbContext.SaveChangesAsync();

            return product;
        }
        
        public async Task<Product> SoftDeleteProductAsync(int id)
        {
            var product = await _dbContext.Products.FirstOrDefaultAsync(p => p.Id == id);
            if (product == null)
                throw new Exception("Product not found");

            var token = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (token == null)
                throw new Exception("No QuickBooks token found");

            var realmId = token.RealmId;
            var accessToken = token.AccessToken;

            product.Type = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(product.Type.ToLower());
            product.Active = false;

            // Load related account names
            product.IncomeAccountName = await _dbContext.ChartOfAccounts
                .Where(a => a.QuickBooksAccountId == product.IncomeAccountId)
                .Select(a => a.Name)
                .FirstOrDefaultAsync() ?? product.IncomeAccountName;

            if (product.Type == "Inventory")
            {
                product.ExpenseAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.ExpenseAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync() ?? product.ExpenseAccountName;

                product.AssetAccountName = await _dbContext.ChartOfAccounts
                    .Where(a => a.QuickBooksAccountId == product.AssetAccountId)
                    .Select(a => a.Name)
                    .FirstOrDefaultAsync() ?? product.AssetAccountName;
            }

            // Build QuickBooks payload
            dynamic quickBooksDto;

            if (product.Type == "Inventory")
            {
                quickBooksDto = new
                {
                    Id = product.QuickBooksItemId,
                    SyncToken = product.SyncToken,
                    Name = product.Name,
                    Type = product.Type,
                    UnitPrice = product.UnitPrice,
                    Taxable = product.Taxable,
                    Active = false,
                    IncomeAccountRef = new
                    {
                        value = product.IncomeAccountId,
                        name = product.IncomeAccountName
                    },
                    ExpenseAccountRef = new
                    {
                        value = product.ExpenseAccountId,
                        name = product.ExpenseAccountName
                    },
                    AssetAccountRef = new
                    {
                        value = product.AssetAccountId,
                        name = product.AssetAccountName
                    },
                    TrackQtyOnHand = true,
                    QtyOnHand = product.QuantityOnHand,
                    InvStartDate = product.InventoryStartDate?.ToString("yyyy-MM-dd")
                };
            }
            else
            {
                var dto = new Dictionary<string, object>
                {
                    { "Id", product.QuickBooksItemId },
                    { "SyncToken", product.SyncToken },
                    { "Name", product.Name },
                    { "Type", product.Type },
                    { "UnitPrice", product.UnitPrice },
                    { "Taxable", product.Taxable },
                    { "Active", false }
                };

                if (!string.IsNullOrWhiteSpace(product.IncomeAccountId))
                {
                    dto["IncomeAccountRef"] = new
                    {
                        value = product.IncomeAccountId,
                        name = product.IncomeAccountName
                    };
                }
                else if (!string.IsNullOrWhiteSpace(product.ExpenseAccountId))
                {
                    dto["ExpenseAccountRef"] = new
                    {
                        value = product.ExpenseAccountId,
                        name = product.ExpenseAccountName
                    };
                }

                quickBooksDto = dto;
            }

            // Serialize
            var jsonOptions = new JsonSerializerOptions
            {
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                WriteIndented = true
            };

            var jsonContent = JsonSerializer.Serialize(quickBooksDto, jsonOptions);

            // Send to QuickBooks
            var request = new HttpRequestMessage(HttpMethod.Post, $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item")
            {
                Headers =
                {
                    Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                    Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
                },
                Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
            };

            var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");
            }

            // Update local SyncToken and set inactive in DB
            var itemJson = JsonDocument.Parse(responseBody).RootElement.GetProperty("Item");
            product.SyncToken = itemJson.GetProperty("SyncToken").GetString();
            product.Active = false;
            product.UpdatedAt = DateTime.UtcNow;

            _dbContext.Products.Update(product);
            await _dbContext.SaveChangesAsync();

            return product;
        }

    }
}
