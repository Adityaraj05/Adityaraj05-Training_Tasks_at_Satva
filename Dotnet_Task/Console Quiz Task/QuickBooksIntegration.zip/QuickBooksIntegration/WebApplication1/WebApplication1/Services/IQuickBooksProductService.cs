﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IQuickBooksProductService
    {
        Task<object> FetchProductsFromDbPaginated(int page, int pageSize, string? searchTerm);

        Task<List<Product>> SyncProductsFromQuickBooksAsync();

        Task<Product> AddProductAsync(Product product);
        Task<Product> UpdateProductAsync(Product product);
        Task<Product> SoftDeleteProductAsync(int id);

    }
}
