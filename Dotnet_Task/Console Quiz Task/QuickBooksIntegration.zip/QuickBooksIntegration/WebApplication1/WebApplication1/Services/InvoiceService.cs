﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Models; 
using WebApplication1.Data; 
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text.Json;
using System.Text;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Services
{
    public class InvoiceService : IInvoiceService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<InvoiceService> _logger;

        public InvoiceService(ApplicationDbContext dbContext, IHttpClientFactory httpClientFactory, ILogger<InvoiceService> logger)
        {
            _dbContext = dbContext;
            _httpClientFactory = httpClientFactory;
            _logger = logger;
        }

        public async Task<(List<InvoiceListItem> Invoices, int TotalCount)> FetchInvoicesFromDbPaginated(int page, int pageSize, string? searchTerm)
        {
            var today = DateTime.UtcNow.Date;

            var baseQuery = from invoice in _dbContext.Invoices
                            join customer in _dbContext.Customers
                                on invoice.QuickBooksCustomerId equals customer.QuickBooksCustomerId
                            select new
                            {
                                Invoice = invoice,
                                CustomerName = customer.DisplayName
                            };

            if (!string.IsNullOrEmpty(searchTerm))
            {
                baseQuery = baseQuery.Where(x =>
                    x.CustomerName.Contains(searchTerm) ||
                    x.Invoice.Store.Contains(searchTerm) ||
                    x.Invoice.QuickBooksInvoiceId.Contains(searchTerm)
                );
            }

            var totalCount = await baseQuery.CountAsync();

            var invoices = await baseQuery
                .OrderByDescending(x => x.Invoice.InvoiceDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new InvoiceListItem
                {
                    Date = x.Invoice.InvoiceDate.ToString("yyyy-MM-dd"),
                    No = x.Invoice.QuickBooksInvoiceId,
                    Customer = x.CustomerName,
                    Amount = x.Invoice.Total,
                    Status = x.Invoice.DueDate < today
                        ? $"Overdue {(today - x.Invoice.DueDate.Date).Days} days"
                        : "Not Due",
                    Id = x.Invoice.QuickBooksInvoiceId
                })
                .ToListAsync();

            return (Invoices: invoices, TotalCount: totalCount);
        }
        public async Task<(bool Success, List<Invoice> Result, string ErrorMessage)> FetchInvoicesFromQuickBooks()
        {
            try
            {
                var token = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync()
                    .ConfigureAwait(false);

                if (token == null)
                {
                    _logger.LogError("QuickBooks token not found.");
                    return (false, null, "QuickBooks token not found.");
                }

                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{token.RealmId}/query?query=SELECT * FROM Invoice";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var client = _httpClientFactory.CreateClient();
                var response = await client.SendAsync(request).ConfigureAwait(false);
                var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                _logger.LogInformation("QuickBooks Response JSON:\n" + json);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"QuickBooks API Error: {response.StatusCode} - {json}");
                    return (false, null, $"QuickBooks API Error: {response.StatusCode} - {json}");
                }

                if (string.IsNullOrWhiteSpace(json) || !json.Contains("Invoice"))
                {
                    _logger.LogWarning("No invoices found in the response.");
                    return (false, null, "No invoices found in the response.");
                }

                var invoices = ParseInvoicesFromJson(json, token.RealmId);
                _logger.LogInformation($"Fetched {invoices.Count} invoices from QuickBooks.");

                int updatedCount = 0;
                int insertedCount = 0;

                foreach (var invoice in invoices)
                {
                    var existingInvoice = await _dbContext.Invoices
                        .FirstOrDefaultAsync(i => i.QuickBooksInvoiceId == invoice.QuickBooksInvoiceId
                                               && i.RealmId == invoice.RealmId);

                    if (existingInvoice != null)
                    {
                        // Update existing invoice
                        existingInvoice.SyncToken = invoice.SyncToken;
                        existingInvoice.LastSyncedAt = DateTime.UtcNow;   
                        existingInvoice.InvoiceDate = invoice.InvoiceDate;    
                        existingInvoice.DueDate = invoice.DueDate;
                        existingInvoice.Total = invoice.Total;
                        existingInvoice.Subtotal = invoice.Subtotal;
                        existingInvoice.BillingAddress = invoice.BillingAddress;
                        existingInvoice.UpdatedAt = DateTime.UtcNow;
                        existingInvoice.QuickBooksCustomerId = invoice.QuickBooksCustomerId;

                        // Remove existing line items
                        var existingLineItems = await _dbContext.InvoiceLineItems
                            .Where(li => li.InvoiceId == existingInvoice.Id)
                            .ToListAsync();

                        if (existingLineItems.Any())
                        {
                            _dbContext.InvoiceLineItems.RemoveRange(existingLineItems);
                        }

                        // Add new line items
                        if (invoice.InvoiceLineItems != null)
                        {
                            foreach (var lineItem in invoice.InvoiceLineItems)
                            {
                                lineItem.Id = 0; // 💥 Prevent IDENTITY_INSERT error
                                lineItem.InvoiceId = existingInvoice.Id;
                                lineItem.QuickBooksInvoiceId = invoice.QuickBooksInvoiceId;
                                lineItem.CreatedAt = DateTime.UtcNow;
                                lineItem.UpdatedAt = DateTime.UtcNow;
                                _dbContext.InvoiceLineItems.Add(lineItem);
                            }
                        }

                        updatedCount++;
                    }
                    else
                    {
                        // Insert new invoice
                        invoice.CreatedAt = DateTime.UtcNow;
                        invoice.UpdatedAt = DateTime.UtcNow;
                        await _dbContext.Invoices.AddAsync(invoice);
                        await _dbContext.SaveChangesAsync(); // ✅ Required to get generated Id

                        if (invoice.InvoiceLineItems != null)
                        {
                            foreach (var lineItem in invoice.InvoiceLineItems)
                            {
                                lineItem.Id = 0; // 💥 Prevent IDENTITY_INSERT error
                                lineItem.InvoiceId = invoice.Id;
                                lineItem.QuickBooksInvoiceId = invoice.QuickBooksInvoiceId;
                                lineItem.CreatedAt = DateTime.UtcNow;
                                lineItem.UpdatedAt = DateTime.UtcNow;
                                _dbContext.InvoiceLineItems.Add(lineItem);
                            }
                        }

                        insertedCount++;
                    }
                }

                await _dbContext.SaveChangesAsync();

                _logger.LogInformation($"Successfully processed invoices from QuickBooks. Updated: {updatedCount}, Inserted: {insertedCount}");
                return (true, invoices, null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching invoices from QuickBooks.");
                return (false, null, $"Error fetching invoices from QuickBooks: {ex.Message}");
            }
        }
        public async Task<Invoice> CreateInvoiceInQuickBooksAsync(InvoiceRequestDto invoiceRequest)
        {
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                throw new Exception("No QuickBooks token found.");

            var accessToken = tokenRecord.AccessToken;
            var realmId = tokenRecord.RealmId;

            if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                throw new Exception("Missing access token or realm ID.");

            var quickBooksCustomerId = await _dbContext.Customers
                .Where(c => c.QuickBooksCustomerId == invoiceRequest.CustomerId)
                .Select(c => c.QuickBooksCustomerId)
                .FirstOrDefaultAsync();

            if (string.IsNullOrEmpty(quickBooksCustomerId))
                throw new Exception("QuickBooksCustomerId not found for the provided CustomerId.");

            var payload = new
            {
                Line = invoiceRequest.Line.Select(line => new
                {
                    DetailType = "SalesItemLineDetail",
                    Amount = line.Amount,
                    SalesItemLineDetail = new
                    {
                        ItemRef = new { name = line.ProductName, value = line.QuickBooksItemId },
                        Qty = line.Qty,
                        UnitPrice = line.Rate
                    },
                    Description = line.Description
                }).ToList(),
                CustomerRef = new { value = quickBooksCustomerId }
            };

            var jsonPayload = System.Text.Json.JsonSerializer.Serialize(payload);
            var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice";

            var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
            };

            var client = _httpClientFactory.CreateClient();
            var response = await client.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");
            }

            using var document = JsonDocument.Parse(responseBody);
            var invoiceJson = document.RootElement.GetProperty("Invoice");

            var quickBooksInvoiceId = invoiceJson.GetProperty("Id").GetString();
            var syncToken = invoiceJson.GetProperty("SyncToken").GetString();

            var invoice = new Invoice
            {
                QuickBooksInvoiceId = quickBooksInvoiceId,
                QuickBooksCustomerId = quickBooksCustomerId,
                InvoiceDate = invoiceRequest.InvoiceDate,
                DueDate = (DateTime)invoiceRequest.DueDate,
                Store = invoiceRequest.Store,
                BillingAddress = invoiceRequest.BillingAddress,
                Subtotal = invoiceRequest.Subtotal,
                Total = invoiceRequest.Total,
                RealmId = realmId,
                SyncToken = syncToken,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                LastSyncedAt = DateTime.UtcNow
            };

            _dbContext.Invoices.Add(invoice);
            await _dbContext.SaveChangesAsync();

            foreach (var line in invoiceRequest.Line)
            {
                var lineItem = new InvoiceLineItem
                {
                    InvoiceId = invoice.Id,
                    QuickBooksInvoiceId = quickBooksInvoiceId,
                    QuickBooksItemId = line.QuickBooksItemId,
                    Description = line.Description,
                    Qty = line.Qty,
                    Rate = line.Rate,
                    Amount = line.Amount,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _dbContext.InvoiceLineItems.Add(lineItem);
            }

            await _dbContext.SaveChangesAsync(); 

            return invoice;
        }
        public async Task<List<object>> GetCustomerDropdownAsync()
        {
            // Retrieve the most recent token from the QuickBooksTokens table
            var token = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.Id)
                .FirstOrDefaultAsync();

            if (token == null)
                throw new Exception("Token not found");

            // Retrieve customers along with the realmId from the token
            return await _dbContext.Customers
                .Select(c => new
                {
                    c.QuickBooksCustomerId,
                    c.DisplayName,
                    token.RealmId // Include realmId from the token
                })
                .ToListAsync<object>();
        }

        public async Task<object> GetCustomerDetailsAsync(string quickBooksCustomerId)
        {
            var customerDetails = await _dbContext.Customers
                .Where(c => c.QuickBooksCustomerId == quickBooksCustomerId)
                .GroupJoin(
                    _dbContext.Invoices,
                    c => c.QuickBooksCustomerId,
                    i => i.QuickBooksCustomerId.ToString(),
                    (c, invoices) => new
                    {
                        c.Email,
                        BillingAddress = invoices.Any() ? invoices.First().BillingAddress + " " + c.BillingLine1 : c.BillingLine1,
                        c.DisplayName,
                    })
                .Where(result => result.Email != null && result.DisplayName != null)
                .FirstOrDefaultAsync();

            if (customerDetails == null)
            {
                _logger.LogWarning($"Customer not found for QuickBooksCustomerId: {quickBooksCustomerId}");
                return new { Message = "Customer details not found." };
            }

            return customerDetails;
        }

        public async Task<Invoice> UpdateInvoiceInQuickBooksAsync(InvoiceRequestDto invoiceRequest)
        {
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                throw new Exception("No QuickBooks token found.");

            var accessToken = tokenRecord.AccessToken;
            var realmId = tokenRecord.RealmId;

            if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                throw new Exception("Missing access token or realm ID.");

            var invoice = await _dbContext.Invoices
                .FirstOrDefaultAsync(i => i.QuickBooksInvoiceId == invoiceRequest.QuickBooksInvoiceId);

            if (invoice == null)
                throw new Exception("Invoice not found in the local database.");

            var payload = new
            {
                Id = invoiceRequest.QuickBooksInvoiceId, // Pass the QuickBooksInvoiceId
                SyncToken = invoice.SyncToken,  // Include the SyncToken for version control
                Line = invoiceRequest.Line.Select(line => new
                {
                    DetailType = "SalesItemLineDetail",
                    Amount = line.Amount,
                    Description = line.Description,
                    SalesItemLineDetail = new
                    {
                        ItemRef = new { name = line.ProductName, value = line.QuickBooksItemId },
                        Qty = line.Qty
                    }
                }).ToList(),
                CustomerRef = new { value = invoiceRequest.CustomerId } // Use QuickBooksCustomerId here
            };

            var jsonPayload = System.Text.Json.JsonSerializer.Serialize(payload);
            var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice";
            var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
            };

            var client = _httpClientFactory.CreateClient();
            var response = await client.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");
            }

            using var document = JsonDocument.Parse(responseBody);
            var invoiceJson = document.RootElement.GetProperty("Invoice");

            var syncToken = invoiceJson.GetProperty("SyncToken").GetString(); // Get the updated SyncToken

            // Update the local database record
            invoice.SyncToken = syncToken; // Update the SyncToken in the database
            invoice.InvoiceDate = invoiceRequest.InvoiceDate;
            invoice.DueDate = (DateTime)invoiceRequest.DueDate;
            invoice.Store = invoiceRequest.Store;
            invoice.BillingAddress = invoiceRequest.BillingAddress;
            invoice.Subtotal = invoiceRequest.Subtotal;
            invoice.Total = invoiceRequest.Total;
            invoice.UpdatedAt = DateTime.UtcNow;

            _dbContext.Invoices.Update(invoice);
            await _dbContext.SaveChangesAsync();

            // Now update the line items in the local database
            foreach (var line in invoiceRequest.Line)
            {
                var existingLineItem = await _dbContext.InvoiceLineItems
                    .FirstOrDefaultAsync(li => li.QuickBooksInvoiceId == invoiceRequest.QuickBooksInvoiceId && li.QuickBooksItemId == line.QuickBooksItemId);

                if (existingLineItem != null)
                {
                    existingLineItem.Qty = line.Qty;
                    existingLineItem.Rate = line.Rate;
                    existingLineItem.Amount = line.Amount;
                    existingLineItem.Description = line.Description;
                    existingLineItem.UpdatedAt = DateTime.UtcNow;

                    _dbContext.InvoiceLineItems.Update(existingLineItem);
                }
                else
                {
                    // If the line item doesn't exist, create a new one
                    var lineItem = new InvoiceLineItem
                    {
                        InvoiceId = invoice.Id,
                        QuickBooksInvoiceId = invoice.QuickBooksInvoiceId,
                        QuickBooksItemId = line.QuickBooksItemId,  // Store QuickBooksItemId as string
                        Description = line.Description,
                        Qty = line.Qty,
                        Rate = line.Rate,
                        Amount = line.Amount,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                    _dbContext.InvoiceLineItems.Add(lineItem);
                }
            }

            await _dbContext.SaveChangesAsync(); // Save line items

            return invoice; // Return the updated invoice
        }

        public async Task<bool> DeleteInvoiceFromQuickBooksAsync(string quickBooksInvoiceId)
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    throw new Exception("No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    throw new Exception("Missing access token or realm ID.");

                // Get the invoice from the database to retrieve the SyncToken
                var invoice = await _dbContext.Invoices
                    .FirstOrDefaultAsync(i => i.QuickBooksInvoiceId == quickBooksInvoiceId);

                if (invoice == null)
                    throw new Exception("Invoice not found in the local database.");

                // Prepare the payload as per the documentation
                var payload = new
                {
                    SyncToken = invoice.SyncToken,  // The SyncToken for this invoice
                    Id = quickBooksInvoiceId        // The QuickBooks Invoice ID
                };

                var jsonPayload = System.Text.Json.JsonSerializer.Serialize(payload);
                var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice?operation=delete";

                var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
                {
                    Headers =
            {
                Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
            },
                    Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
                };

                var client = _httpClientFactory.CreateClient();
                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();

                Console.WriteLine($"QuickBooks API Delete Response: {responseBody}");

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");
                }

                // If deletion was successful, delete from the local database
                var lineItems = await _dbContext.InvoiceLineItems
                    .Where(li => li.QuickBooksInvoiceId == quickBooksInvoiceId)
                    .ToListAsync();

                _dbContext.InvoiceLineItems.RemoveRange(lineItems);
                _dbContext.Invoices.Remove(invoice);
                await _dbContext.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting invoice: {ex.Message}");
                throw;
            }
        }
        public async Task<List<object>> GetActiveProductsAsync()
        {
            return await _dbContext.Products
                .Where(p => p.Active == true)
                .Select(p => new
                {
                    p.Id,
                    p.QuickBooksItemId,
                    p.Name
                })
                .Cast<object>() 
                .ToListAsync();
        }
        private List<Invoice> ParseInvoicesFromJson(string json, string realmId)
        {
            try
            {
                var parsedResponse = JsonConvert.DeserializeObject<QuickBooksQueryResponse>(json);

                if (parsedResponse?.QueryResponse?.Invoices == null)
                {
                    _logger.LogWarning("No invoices found in the parsed JSON response.");
                    return new List<Invoice>();
                }

                return parsedResponse.QueryResponse.Invoices.Select(invoice =>
                {
                    try
                    {
                        return new Invoice
                        {
                            QuickBooksInvoiceId = invoice.Id,
                            SyncToken = invoice.SyncToken,
                            RealmId = realmId,
                            LastSyncedAt = DateTime.UtcNow,

                            InvoiceDate = DateTime.TryParse(invoice.TxnDate, out var invoiceDate) ? invoiceDate : DateTime.MinValue,
                            DueDate = DateTime.TryParse(invoice.DueDate, out var dueDate) ? dueDate : DateTime.MinValue,
                            Total = invoice.TotalAmt,
                            Subtotal = invoice.Line?.Sum(l => (l.Amount as decimal?) ?? 0.0m) ?? 0.0m,
                            Store = "QuickBooks",
                            BillingAddress = invoice.BillAddr != null
                                ? $"{invoice.BillAddr.Line1}, {invoice.BillAddr.City}, {invoice.BillAddr.Country}"
                                : null,
                            QuickBooksCustomerId = invoice.CustomerRef?.Value ?? string.Empty,
                            InvoiceLineItems = invoice.Line?
                            .Where(l => l.DetailType == "SalesItemLineDetail" && l.SalesItemLineDetail != null)
                            .Select(line => new InvoiceLineItem
                            {
                                Description = line.Description ?? "No Desc Provided",
                                Amount = (line.Amount as decimal?) ?? 0.0m,
                                Qty = (line.SalesItemLineDetail.Qty as decimal?) ?? 0.0m,
                                Rate = (line.SalesItemLineDetail.UnitPrice as decimal?) ?? 0.0m,
                                QuickBooksItemId = line.SalesItemLineDetail.ItemRef?.Value, // Use QuickBooksItemId directly
                                QuickBooksInvoiceId = invoice.Id,
                                CreatedAt = DateTime.UtcNow,
                                UpdatedAt = DateTime.UtcNow,
                            }).ToList()
                        };
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error parsing individual invoice: {JsonConvert.SerializeObject(invoice)}");
                        return null; // or you could choose to throw, or skip
                    }
                })
                .Where(i => i != null)
                .ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error parsing invoice JSON response");
                return new List<Invoice>();
            }
        }

        public async Task<InvoiceEditFormDto> GetInvoiceByIdAsync(string id)
        {
            var invoice = await _dbContext.Invoices
                .Include(i => i.InvoiceLineItems)
                .FirstOrDefaultAsync(i => i.QuickBooksInvoiceId == id);

            if (invoice == null) return null;

            var customer = await _dbContext.Customers
                .FirstOrDefaultAsync(c => c.QuickBooksCustomerId == invoice.QuickBooksCustomerId);

            return new InvoiceEditFormDto
            {
                QuickBooksInvoiceId = invoice.QuickBooksInvoiceId,
                QuickBooksCustomerId = customer?.QuickBooksCustomerId,
                CustomerName = customer?.DisplayName, // ✅ Use DisplayName here
                CustomerEmail = customer?.Email,
                BillingAddress = invoice.BillingAddress,
                InvoiceDate = invoice.InvoiceDate,
                DueDate = invoice.DueDate,
                LineItems = invoice.InvoiceLineItems.Select(item => new InvoiceEditLineDto
                {
                    QuickBooksItemId = item.QuickBooksItemId,
                    ProductName = GetProductNameByItemId(item.QuickBooksItemId),
                    Description = item.Description,
                    Qty = item.Qty,
                    Rate = item.Rate,
                    Amount = item.Amount
                }).ToList()
            };
        }

        private string GetProductNameByItemId(string itemId)
        {
            return _dbContext.Products
                .Where(p => p.QuickBooksItemId == itemId)
                .Select(p => p.Name)
                .FirstOrDefault() ?? "Unknown Item";
        }

        public class QuickBooksQueryResponse
        {
            [JsonProperty("QueryResponse")]
            public InvoiceQueryResponse QueryResponse { get; set; }
        }

        public class InvoiceQueryResponse
        {
            [JsonProperty("Invoice")]
            public List<InvoiceApi> Invoices { get; set; }
        }

        public class InvoiceApi
        {
            public string TxnDate { get; set; }
            public string DueDate { get; set; }
            public decimal TotalAmt { get; set; }
            public CustomerRef CustomerRef { get; set; }
            public string Id { get; set; }  // QuickBooks internal ID
            public string DocNumber { get; set; }
            public string SyncToken { get; set; } // ✅ Add this
            public BillAddr BillAddr { get; set; }
            public List<InvoiceLineApi> Line { get; set; }
        }

        public class BillAddr
        {
            public string Line1 { get; set; }
            public string City { get; set; }
            public string Country { get; set; }
        }

        public class CustomerRef
        {
            public string Value { get; set; }
        }

        public class InvoiceLineApi
        {
            public string DetailType { get; set; } 
            public string Description { get; set; }
            public decimal Amount { get; set; }
            public SalesItemLineDetail SalesItemLineDetail { get; set; }
        }

        public class SalesItemLineDetail
        {
            public ItemRef ItemRef { get; set; }
            public decimal Qty { get; set; }
            public decimal UnitPrice { get; set; }
        }

        public class ItemRef
        {
            public string Value { get; set; }
        }

    }
}
