﻿using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class QuickBooksVendorService : IQuickBooksVendorService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<QuickBooksVendorService> _logger;
        private readonly ApplicationDbContext _dbContext;

        public QuickBooksVendorService(HttpClient httpClient, ILogger<QuickBooksVendorService> logger, ApplicationDbContext dbContext)
        {
            _httpClient = httpClient;
            _logger = logger;
            _dbContext = dbContext;
        }
        public async Task<object> FetchVendorsFromDbPaginated(int page = 1, int pageSize = 10, string searchTerm = null)
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    throw new Exception("No QuickBooks token found.");

                var query = _dbContext.Vendors
                    .Where(v => v.Active); 

                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    string likeTerm = $"%{searchTerm}%";
                    query = query.Where(v =>
                        EF.Functions.Like(v.DisplayName, likeTerm) ||
                        EF.Functions.Like(v.PrimaryPhone, likeTerm));
                }

                var totalRecords = await query.CountAsync();

                var pagedData = await query
                    .OrderBy(v => v.DisplayName)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(v => new
                    {
                        Id = v.Id,
                        DisplayName = v.DisplayName ?? "",
                        PrimaryPhone = v.PrimaryPhone ?? "",
                        PrimaryEmailAddr = v.PrimaryEmailAddr ?? "",
                        AcctNum = v.AcctNum ?? "",
                        Balance = v.Balance ?? 0.0m,
                        BillAddr_Line1 = v.BillAddr_Line1 ?? "",
                        BillAddr_City = v.BillAddr_City ?? "",
                        BillAddr_CountrySubDivisionCode = v.BillAddr_CountrySubDivisionCode ?? "",
                        BillAddr_PostalCode = v.BillAddr_PostalCode ?? ""
                    })
                    .ToListAsync();

                var response = new
                {
                    TotalRecords = totalRecords,
                    TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize),
                    CurrentPage = page,
                    PageSize = pageSize,
                    Data = pagedData
                };

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching vendors: {ex.Message}", ex);
            }
        }

        public async Task<List<Vendor>> FetchVendorsFromQuickBooks()
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    throw new Exception("No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    throw new Exception("Missing access token or realm ID.");

                _logger.LogInformation("Fetching vendor data from QuickBooks API.");

                var query = Uri.EscapeDataString("SELECT * FROM Vendor");
                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query={query}";

                var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(httpRequest);
                var json = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                    throw new Exception($"QuickBooks API error: {response.StatusCode} - {json}");

                var parsedVendors = ParseVendorData(json);

                using var transaction = await _dbContext.Database.BeginTransactionAsync();

                try
                {
                    foreach (var vendor in parsedVendors)
                    {
                        var existingVendor = await _dbContext.Vendors
                            .FirstOrDefaultAsync(v => v.Id == vendor.Id);

                        if (existingVendor != null)
                        {
                            UpdateVendorValues(existingVendor, vendor);
                        }
                        else
                        {
                            vendor.Active = true;  
                            await _dbContext.Vendors.AddAsync(vendor);
                        }
                    }

                    await _dbContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    return parsedVendors;
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    throw new Exception($"Error processing QuickBooks vendor data: {ex.Message}", ex);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching vendors from QuickBooks: {ex.Message}", ex);
            }
        }

        public async Task<Vendor> AddVendorToQuickBooks(Vendor vendor)
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    throw new Exception("No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    throw new Exception("Missing access token or realm ID.");

                if (string.IsNullOrWhiteSpace(vendor.DisplayName) ||
                    string.IsNullOrWhiteSpace(vendor.AcctNum) ||
                    string.IsNullOrWhiteSpace(vendor.PrimaryPhone))
                {
                    throw new Exception("DisplayName, AcctNum, and PrimaryPhone are required fields.");
                }

                var payload = new
                {
                    DisplayName = vendor.DisplayName,
                    AcctNum = vendor.AcctNum,
                    PrimaryPhone = new { FreeFormNumber = vendor.PrimaryPhone },
                    PrimaryEmailAddr = string.IsNullOrWhiteSpace(vendor.PrimaryEmailAddr) ? null : new { Address = vendor.PrimaryEmailAddr },
                    BillAddr = new
                    {
                        Line1 = vendor.BillAddr_Line1,
                        City = vendor.BillAddr_City,
                        CountrySubDivisionCode = vendor.BillAddr_CountrySubDivisionCode,
                        PostalCode = vendor.BillAddr_PostalCode,
                        Country = "U.S.A"
                    }
                };

                var jsonPayload = JsonSerializer.Serialize(payload);
                var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/vendor";

                var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
                {
                    Headers =
            {
                Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
            },
                    Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
                };

                var response = await _httpClient.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");
                }

                using var document = JsonDocument.Parse(responseBody);
                var vendorJson = document.RootElement.GetProperty("Vendor");

                vendor.Id = int.Parse(vendorJson.GetProperty("Id").GetString());
                vendor.SyncToken = vendorJson.GetProperty("SyncToken").GetString();

                vendor.Active = true;

                _dbContext.Vendors.Add(vendor);
                await _dbContext.SaveChangesAsync();

                return vendor;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error adding vendor: {ex.Message}", ex);
            }
        }

        private List<Vendor> ParseVendorData(string json)
        {
            var vendors = new List<Vendor>();

            try
            {
                var parsed = JsonDocument.Parse(json);

                if (parsed.RootElement.TryGetProperty("QueryResponse", out var queryResponse) &&
                    queryResponse.TryGetProperty("Vendor", out var vendorArray))
                {
                    foreach (var item in vendorArray.EnumerateArray())
                    {
                        var vendor = ParseSingleVendor(item);
                        if (vendor != null)
                        {
                            vendors.Add(vendor);
                        }
                    }
                }
                else if (parsed.RootElement.TryGetProperty("Vendor", out var vendorElement))
                {
                    var vendor = ParseSingleVendor(vendorElement);
                    if (vendor != null)
                    {
                        vendors.Add(vendor);
                    }
                }
                else
                {
                    _logger.LogWarning("No vendor data found in QuickBooks response.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error parsing QuickBooks vendor data: {ex.Message}");
                throw new Exception("Error parsing QuickBooks vendor data.", ex);
            }

            return vendors;
        }

        private Vendor ParseSingleVendor(JsonElement element)
        {
            try
            {
                var vendor = new Vendor
                {
                    Id = int.TryParse(element.GetProperty("Id").GetString(), out var idVal) ? idVal : null,
                    SyncToken = element.TryGetProperty("SyncToken", out var syncToken) ? syncToken.GetString() : null,
                    DisplayName = element.GetProperty("DisplayName").GetString()
                };

                if (element.TryGetProperty("AcctNum", out var acctNum))
                {
                    vendor.AcctNum = acctNum.GetString();
                }

                if (element.TryGetProperty("PrimaryEmailAddr", out var email) &&
                    email.TryGetProperty("Address", out var address))
                {
                    vendor.PrimaryEmailAddr = address.GetString();
                }

                if (element.TryGetProperty("PrimaryPhone", out var phone) &&
                    phone.TryGetProperty("FreeFormNumber", out var freeForm))
                {
                    vendor.PrimaryPhone = freeForm.GetString();
                }
                if (element.TryGetProperty("Balance", out var balanceProp) && balanceProp.TryGetDecimal(out var balance))
                {
                    vendor.Balance = balance;
                }


                if (element.TryGetProperty("BillAddr", out var addr))
                {
                    if (addr.TryGetProperty("Line1", out var line1))
                    {
                        vendor.BillAddr_Line1 = line1.GetString();
                    }

                    if (addr.TryGetProperty("City", out var city))
                    {
                        vendor.BillAddr_City = city.GetString();
                    }

                    if (addr.TryGetProperty("PostalCode", out var postal))
                    {
                        vendor.BillAddr_PostalCode = postal.GetString();
                    }

                    if (addr.TryGetProperty("CountrySubDivisionCode", out var region))
                    {
                        vendor.BillAddr_CountrySubDivisionCode = region.GetString();
                    }
                }

                // Set the Active status (if available)
                if (element.TryGetProperty("Active", out var active))
                {
                    vendor.Active = active.GetBoolean();  // Ensure the Active status is parsed
                }

                return vendor;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error parsing individual vendor: {ex.Message}");
                return null;
            }
        }

        private void UpdateVendorValues(Vendor existing, Vendor updated)
        {
            existing.SyncToken = updated.SyncToken;
            existing.DisplayName = updated.DisplayName;
            existing.AcctNum = updated.AcctNum;
            existing.PrimaryEmailAddr = updated.PrimaryEmailAddr;
            existing.PrimaryPhone = updated.PrimaryPhone;
            existing.BillAddr_Line1 = updated.BillAddr_Line1;
            existing.BillAddr_City = updated.BillAddr_City;
            existing.BillAddr_PostalCode = updated.BillAddr_PostalCode;
            existing.BillAddr_CountrySubDivisionCode = updated.BillAddr_CountrySubDivisionCode;
            existing.Active = updated.Active;
        }

        public async Task<bool> DeleteVendor(string id)
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    throw new Exception("No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    throw new Exception("Missing access token or realm ID.");

                if (!int.TryParse(id, out int parsedId))
                {
                    throw new Exception("Invalid vendor ID format.");
                }

                var vendor = await _dbContext.Vendors
                    .FirstOrDefaultAsync(v => v.Id == parsedId);

                if (vendor == null)
                    throw new Exception("Vendor not found in local DB.");

                string quickBooksVendorId = vendor.Id?.ToString();

                var getVendorUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/vendor/{quickBooksVendorId}";
                var getRequest = new HttpRequestMessage(HttpMethod.Get, getVendorUrl);
                getRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                getRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var getResponse = await _httpClient.SendAsync(getRequest);
                var getContent = await getResponse.Content.ReadAsStringAsync();

                if (!getResponse.IsSuccessStatusCode)
                {
                    vendor.Active = false;
                    _dbContext.Vendors.Update(vendor);
                    await _dbContext.SaveChangesAsync();
                    return true;
                }

                using var document = JsonDocument.Parse(getContent);
                var syncToken = document.RootElement.GetProperty("Vendor").GetProperty("SyncToken").GetString();

                var deletePayload = new
                {
                    Id = quickBooksVendorId,
                    SyncToken = syncToken,
                    Active = false,  
                    DisplayName = vendor.DisplayName,
                    AcctNum = vendor.AcctNum
                };

                var deleteUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/vendor?operation=update";
                var deleteRequest = new HttpRequestMessage(HttpMethod.Post, deleteUrl)
                {
                    Headers =
                    {
                        Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                        Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
                    },
                    Content = new StringContent(JsonSerializer.Serialize(deletePayload), Encoding.UTF8, "application/json")
                };

                var deleteResponse = await _httpClient.SendAsync(deleteRequest);
                var deleteContent = await deleteResponse.Content.ReadAsStringAsync();

                if (!deleteResponse.IsSuccessStatusCode)
                {
                    if (deleteContent.Contains("Object Not Found") || deleteContent.Contains("made inactive"))
                    {
                        vendor.Active = false;
                        _dbContext.Vendors.Update(vendor);
                        await _dbContext.SaveChangesAsync();
                        return true;
                    }

                    throw new Exception($"QuickBooks API error: {deleteResponse.StatusCode} - {deleteContent}");
                }

                vendor.Active = false;
                _dbContext.Vendors.Update(vendor);
                await _dbContext.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deleting vendor: {ex.Message}", ex);
            }
        }

    }

}
