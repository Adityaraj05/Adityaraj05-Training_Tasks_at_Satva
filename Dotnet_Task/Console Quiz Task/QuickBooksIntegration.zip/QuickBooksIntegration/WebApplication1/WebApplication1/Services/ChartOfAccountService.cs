﻿using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Services
{

    public class ChartOfAccountService : IChartOfAccountService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<ChartOfAccountService> _logger;
        private readonly HttpClient _httpClient;

        public ChartOfAccountService(ApplicationDbContext dbContext, ILogger<ChartOfAccountService> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
            _httpClient = new HttpClient();
        }

        public async Task<object> FetchChartOfAccountsFromDbPaginated(int page, int pageSize, string? searchTerm)
        {
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                return new { Error = "No QuickBooks token found." };

            var query = _dbContext.ChartOfAccounts
                .Where(c => c.QuickBooksUserId == tokenRecord.QuickBooksUserId);

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                string likeTerm = $"%{searchTerm}%";
                query = query.Where(c =>
                    EF.Functions.Like(c.Name, likeTerm) ||
                    EF.Functions.Like(c.AccountType, likeTerm) ||
                    (c.AccountSubType != null && EF.Functions.Like(c.AccountSubType, likeTerm)) ||
                    (c.Classification != null && EF.Functions.Like(c.Classification, likeTerm)));
            }

            var totalRecords = await query.CountAsync();
            var pagedData = await query
                .OrderBy(c => c.Name)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return new
            {
                TotalRecords = totalRecords,
                TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize),
                CurrentPage = page,
                PageSize = pageSize,
                Data = pagedData
            };
        }

        public async Task<(bool Success, object? Result, string? ErrorMessage)> FetchChartOfAccountsFromQuickBooks()
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    return (false, null, "No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    return (false, null, "Missing access token or realm ID.");

                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query=SELECT * FROM Account";
                var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(httpRequest);
                var json = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                    return (false, null, json);

                var parsedAccounts = ParseAccountData(json, tokenRecord.QuickBooksUserId);

                using var transaction = await _dbContext.Database.BeginTransactionAsync();
                try
                {
                    foreach (var account in parsedAccounts)
                    {
                        var existingAccount = await _dbContext.ChartOfAccounts
                            .FirstOrDefaultAsync(c => c.QuickBooksAccountId == account.QuickBooksAccountId);

                        if (existingAccount != null)
                        {
                            UpdateAccountValues(existingAccount, account);
                        }
                        else
                        {
                            account.CreatedAt = DateTime.UtcNow;
                            account.UpdatedAt = DateTime.UtcNow;
                            await _dbContext.ChartOfAccounts.AddAsync(account);
                        }
                    }

                    await _dbContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    return (true, parsedAccounts, null);
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    return (false, null, $"Error processing QuickBooks data: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching accounts from QuickBooks");
                return (false, null, ex.Message);
            }
        }

        private List<ChartOfAccount> ParseAccountData(string json, string quickBooksUserId)
        {
            var result = new List<ChartOfAccount>();

            using (JsonDocument document = JsonDocument.Parse(json))
            {
                var root = document.RootElement;
                if (root.TryGetProperty("QueryResponse", out JsonElement queryResponse) &&
                    queryResponse.TryGetProperty("Account", out JsonElement accounts))
                {
                    foreach (JsonElement acc in accounts.EnumerateArray())
                    {
                        var account = new ChartOfAccount
                        {
                            QuickBooksAccountId = GetJsonPropertyValue(acc, "Id"),
                            Name = GetJsonPropertyValue(acc, "Name"),
                            AccountType = GetJsonPropertyValue(acc, "AccountType"),
                            AccountSubType = GetJsonPropertyValue(acc, "AccountSubType"),
                            Classification = GetJsonPropertyValue(acc, "Classification"),
                            QuickBooksUserId = quickBooksUserId,
                            CreatedAt = DateTime.UtcNow
                        };

                        if (acc.TryGetProperty("CurrentBalance", out JsonElement balanceElement) &&
                            balanceElement.ValueKind != JsonValueKind.Null)
                        {
                            account.CurrentBalance = balanceElement.GetDecimal();
                        }

                        if (acc.TryGetProperty("CurrencyRef", out JsonElement currencyRef))
                        {
                            account.CurrencyRef = new CurrencyRef
                            {
                                Value = GetJsonPropertyValue(currencyRef, "value"),
                                Name = GetJsonPropertyValue(currencyRef, "name")
                            };
                            account.UpdateCurrencyRefProperties();
                        }

                        result.Add(account);
                    }
                }
            }

            return result;
        }

        private string GetJsonPropertyValue(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property) &&
                property.ValueKind != JsonValueKind.Null)
            {
                return property.GetString();
            }
            return null;
        }

        private void UpdateAccountValues(ChartOfAccount existing, ChartOfAccount updated)
        {
            existing.QuickBooksAccountId = updated.QuickBooksAccountId;
            existing.Name = updated.Name;
            existing.AccountType = updated.AccountType;
            existing.AccountSubType = updated.AccountSubType;
            existing.CurrentBalance = updated.CurrentBalance;
            existing.Classification = updated.Classification;
            existing.CurrencyRef = updated.CurrencyRef;
            existing.UpdateCurrencyRefProperties();
            existing.QuickBooksUserId = updated.QuickBooksUserId;
            existing.UpdatedAt = DateTime.UtcNow;
        }

        public class ProductAccountOptionsDto
        {
            public List<AccountDto> InventoryAssetAccounts { get; set; } = new List<AccountDto>();
            public List<AccountDto> IncomeAccounts { get; set; } = new List<AccountDto>();
            public List<AccountDto> ExpenseAccounts { get; set; } = new List<AccountDto>();
        }

        public class AccountDto
        {
            public string QuickBooksAccountId { get; set; }
            public string Name { get; set; }
        }

        public async Task<ProductAccountOptionsDto> GetProductAccountOptionsAsync(string quickBooksUserId, int? productId = null)
        {
            var accounts = await _dbContext.ChartOfAccounts
                .Where(a => a.QuickBooksUserId == quickBooksUserId)
                .ToListAsync();

            Console.WriteLine($"🔍 Found {accounts.Count} accounts for user {quickBooksUserId}");

            var inventoryAssetAccounts = accounts
                .Where(a => a.AccountType == "Other Current Asset" &&
                            (a.AccountSubType ?? "").Trim().Equals("Inventory", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var incomeAccounts = accounts
                .Where(a => a.AccountType == "Income" &&
                            (a.AccountSubType ?? "").Trim().Equals("SalesOfProductIncome", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var expenseAccounts = accounts
                .Where(a => a.AccountType == "Cost of Goods Sold" &&
                            (a.AccountSubType ?? "").Trim().Equals("SuppliesMaterialsCogs", StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (productId.HasValue)
            {
                var product = await _dbContext.Products.FindAsync(productId.Value);
                if (product != null)
                {
                    void AddIfMissing(List<ChartOfAccount> list, string? accountId)
                    {
                        if (!string.IsNullOrEmpty(accountId) && !list.Any(a => a.QuickBooksAccountId == accountId))
                        {
                            var match = accounts.FirstOrDefault(a => a.QuickBooksAccountId == accountId);
                            if (match != null)
                                list.Add(match);
                        }
                    }

                    AddIfMissing(inventoryAssetAccounts, product.AssetAccountId);
                    AddIfMissing(incomeAccounts, product.IncomeAccountId);
                    AddIfMissing(expenseAccounts, product.ExpenseAccountId);
                }
            }

            return new ProductAccountOptionsDto
            {
                InventoryAssetAccounts = inventoryAssetAccounts
                    .Select(a => new AccountDto
                    {
                        QuickBooksAccountId = a.QuickBooksAccountId,
                        Name = a.Name
                    }).ToList(),

                IncomeAccounts = incomeAccounts
                    .Select(a => new AccountDto
                    {
                        QuickBooksAccountId = a.QuickBooksAccountId,
                        Name = a.Name
                    }).ToList(),

                ExpenseAccounts = expenseAccounts
                    .Select(a => new AccountDto
                    {
                        QuickBooksAccountId = a.QuickBooksAccountId,
                        Name = a.Name
                    }).ToList()
            };
        }

    }
}
