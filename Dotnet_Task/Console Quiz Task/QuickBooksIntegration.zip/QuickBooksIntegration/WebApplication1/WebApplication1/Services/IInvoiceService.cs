﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication1.Models; // Assuming you have models for Invoice and InvoiceLineItem

namespace WebApplication1.Services
{
    public interface IInvoiceService
    {
        Task<(List<InvoiceListItem> Invoices, int TotalCount)> FetchInvoicesFromDbPaginated(int page, int pageSize, string? searchTerm);
        Task<(bool Success, List<Invoice> Result, string ErrorMessage)> FetchInvoicesFromQuickBooks();
        Task<List<object>> GetCustomerDropdownAsync();
        Task<object> GetCustomerDetailsAsync(string quickBooksCustomerId);
        Task<List<object>> GetActiveProductsAsync();
        Task<Invoice> CreateInvoiceInQuickBooksAsync(InvoiceRequestDto invoiceRequest);
        Task<Invoice> UpdateInvoiceInQuickBooksAsync(InvoiceRequestDto invoiceRequest);
        Task<bool> DeleteInvoiceFromQuickBooksAsync(string quickBooksInvoiceId);
        Task<InvoiceEditFormDto> GetInvoiceByIdAsync(string id);

    }
}
