﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text;
using WebApplication1.Data;
using WebApplication1.Models;
using static WebApplication1.Services.InvoiceService;

namespace WebApplication1.Services
{
    public class BillService : IBillService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<BillService> _logger;
        private readonly IConfiguration _configuration;
        private readonly ApplicationDbContext _dbContext;

        public BillService(HttpClient httpClient, ILogger<BillService> logger, IConfiguration configuration, ApplicationDbContext dbContext)
        {
            _httpClient = httpClient;
            _logger = logger;
            _configuration = configuration;
            _dbContext = dbContext;
        }

        public async Task<List<Bill>> FetchBillsFromQuickBooksAsync()
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    throw new Exception("No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    throw new Exception("Missing access token or realm ID.");

                _logger.LogInformation("Fetching bill data from QuickBooks API.");

                var query = Uri.EscapeDataString("SELECT * FROM Bill");
                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query={query}";

                var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(httpRequest);
                var json = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                    throw new Exception($"QuickBooks API error: {response.StatusCode} - {json}");

                var parsedBills = ParseBillData(json);

                using var transaction = await _dbContext.Database.BeginTransactionAsync();

                try
                {
                    foreach (var bill in parsedBills)
                    {
                        var existingBill = await _dbContext.Bills
                            .FirstOrDefaultAsync(b => b.QuickBooksBillId == bill.QuickBooksBillId);

                        if (existingBill != null)
                        {
                            _dbContext.Bills.Remove(existingBill);

                            var existingLines = _dbContext.BillLines
                                .Where(l => l.QuickBooksBillId == bill.QuickBooksBillId);
                            _dbContext.BillLines.RemoveRange(existingLines);

                            await _dbContext.SaveChangesAsync();
                        }

                        await _dbContext.Bills.AddAsync(bill);

                        if (bill.Lines != null && bill.Lines.Any())
                        {
                            await _dbContext.BillLines.AddRangeAsync(bill.Lines);
                        }
                    }

                    await _dbContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    return parsedBills;
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    throw new Exception($"Error processing QuickBooks bill data: {ex.Message}", ex);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error fetching bills from QuickBooks: {ex.Message}", ex);
            }
        }
        public List<Bill> ParseBillData(string json)
        {
            var result = new List<Bill>();

            var root = JObject.Parse(json);
            var billsArray = root["QueryResponse"]?["Bill"] as JArray;

            if (billsArray == null)
                return result;

            foreach (var b in billsArray)
            {
                var billId = (string)b["Id"];
                var bill = new Bill
                {
                    QuickBooksBillId = billId,
                    SyncToken = (string)b["SyncToken"],
                    TxnDate = ((DateTime?)b["TxnDate"]).GetValueOrDefault(),
                    DueDate = (DateTime?)b["DueDate"],
                    VendorId = (string)b["VendorRef"]?["value"],
                    VendorName = (string)b["VendorRef"]?["name"],
                    VendorAddrLine1 = (string)b["VendorAddr"]?["Line1"],
                    VendorAddrCity = (string)b["VendorAddr"]?["City"],
                    VendorAddrState = (string)b["VendorAddr"]?["CountrySubDivisionCode"],
                    VendorAddrPostalCode = (string)b["VendorAddr"]?["PostalCode"],
                    VendorAddrLat = (string)b["VendorAddr"]?["Lat"],
                    VendorAddrLong = (string)b["VendorAddr"]?["Long"],
                    APAccountId = (string)b["APAccountRef"]?["value"],
                    APAccountName = (string)b["APAccountRef"]?["name"],
                    CurrencyValue = (string)b["CurrencyRef"]?["value"],
                    CurrencyName = (string)b["CurrencyRef"]?["name"],
                    TotalAmt = (decimal?)b["TotalAmt"] ?? 0,
                    Balance = (decimal?)b["Balance"] ?? 0,
                    CreatedAt = (DateTime?)b["MetaData"]?["CreateTime"] ?? DateTime.UtcNow,
                    UpdatedAt = (DateTime?)b["MetaData"]?["LastUpdatedTime"] ?? DateTime.UtcNow,
                    LastModifiedBy = (string)b["MetaData"]?["LastModifiedByRef"]?["value"],
                };

                var lines = new List<BillLine>();
                var lineArray = b["Line"] as JArray;

                if (lineArray != null)
                {
                    foreach (var l in lineArray)
                    {
                        BillLine line = new BillLine
                        {
                            QuickBooksBillId = billId,
                            QuickBooksLineId = (string)l["Id"],
                            LineNum = (int?)l["LineNum"] ?? 0,
                            Description = (string)l["Description"],
                            Amount = (decimal?)l["Amount"] ?? 0
                        };

                        if (l["ItemBasedExpenseLineDetail"] != null)
                        {
                            var detail = l["ItemBasedExpenseLineDetail"];
                            line.ItemId = (string)detail["ItemRef"]?["value"];
                            line.ItemName = (string)detail["ItemRef"]?["name"];
                            line.UnitPrice = (decimal?)detail["UnitPrice"] ?? 0;
                            line.Qty = (decimal?)detail["Qty"] ?? 0;
                            line.BillableStatus = (string)detail["BillableStatus"];
                            line.TaxCodeRef = (string)detail["TaxCodeRef"]?["value"];
                            line.DetailType = "Item";
                        }
                        else if (l["AccountBasedExpenseLineDetail"] != null)
                        {
                            var detail = l["AccountBasedExpenseLineDetail"];
                            line.ItemId = (string)detail["AccountRef"]?["value"];
                            line.ItemName = (string)detail["AccountRef"]?["name"];
                            line.BillableStatus = (string)detail["BillableStatus"];
                            line.TaxCodeRef = (string)detail["TaxCodeRef"]?["value"];
                            line.DetailType = "Account";
                        }

                        lines.Add(line);
                    }
                }

                bill.Lines = lines;
                result.Add(bill);
            }

            return result;
        }

        public async Task<object> FetchBillsFromDbPaginated(int page = 1, int pageSize = 10, string searchTerm = null)
        {
            var query = _dbContext.Bills.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                query = query.Where(b => b.VendorName.Contains(searchTerm));
            }

            var totalCount = await query.CountAsync();

            var bills = await query
                .OrderByDescending(b => b.TxnDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return new
            {
                data = bills,
                currentPage = page,
                pageSize = pageSize,
                totalCount = totalCount,
                totalPages = (int)Math.Ceiling((double)totalCount / pageSize)
            };
        }

        public async Task<Bill> CreateBillInQuickBooksAsync(Bill bill)
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    throw new Exception("No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    throw new Exception("Missing access token or realm ID.");

                var qbPayload = new
                {
                    VendorRef = new { value = bill.VendorId },
                    // Ensure this has a value - required field
                    TxnDate = bill.TxnDate?.ToString("yyyy-MM-dd") ?? DateTime.Now.ToString("yyyy-MM-dd"),
                    DueDate = bill.DueDate?.ToString("yyyy-MM-dd"),
                    Line = bill.Lines.Select(line =>
                    {
                        var baseLine = new Dictionary<string, object>
                            {
                                { "DetailType", line.DetailType == "Item" ? "ItemBasedExpenseLineDetail" : "AccountBasedExpenseLineDetail" },
                                { "Amount", line.Amount },
                                { "Description", line.Description ?? "" }
                            };

                        if (line.DetailType == "Item")
                        {
                            baseLine["ItemBasedExpenseLineDetail"] = new
                            {
                                ItemRef = new { value = line.ItemId },
                                Qty = line.Qty,
                                UnitPrice = line.UnitPrice,
                                // Only include if it has a valid value
                                BillableStatus = string.IsNullOrWhiteSpace(line.BillableStatus) ? "NotBillable" : line.BillableStatus,
                                TaxCodeRef = string.IsNullOrWhiteSpace(line.TaxCodeRef) ? null : new { value = line.TaxCodeRef }
                            };
                        }
                        else
                        {
                            baseLine["AccountBasedExpenseLineDetail"] = new
                            {
                                AccountRef = new { value = line.ItemId },
                                // Only include if it has a valid value
                                BillableStatus = string.IsNullOrWhiteSpace(line.BillableStatus) ? "NotBillable" : line.BillableStatus,
                                TaxCodeRef = string.IsNullOrWhiteSpace(line.TaxCodeRef) ? null : new { value = line.TaxCodeRef }
                            };
                        }

                        return baseLine;
                    }).ToArray()
                };
                var jsonPayload = System.Text.Json.JsonSerializer.Serialize(qbPayload);
                _logger.LogInformation($"QuickBooks API Request Payload: {jsonPayload}");

                var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/bill";

                var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
                {
                    Headers =
                    {
                        Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                        Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
                    },
                    Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
                };

                var response = await _httpClient.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"QuickBooks API error: {response.StatusCode} - {responseBody}");
                }

                using var document = JsonDocument.Parse(responseBody);
                var billJson = document.RootElement.GetProperty("Bill");

                var createdBill = new Bill
                {
                    QuickBooksBillId = billJson.GetProperty("Id").GetString(),
                    SyncToken = billJson.GetProperty("SyncToken").GetString(),
                    TxnDate = billJson.GetProperty("TxnDate").GetDateTime(),
                    DueDate = billJson.TryGetProperty("DueDate", out var dueDate) ? dueDate.GetDateTime() : (DateTime?)null,
                    VendorId = bill.VendorId,
                    VendorName = bill.VendorName,
                    TotalAmt = billJson.GetProperty("TotalAmt").GetDecimal(),
                    Balance = billJson.GetProperty("Balance").GetDecimal(),
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow,
                    LastModifiedBy = "system",
                    Lines = bill.Lines.Select((line, index) => new BillLine
                    {
                        QuickBooksBillId = billJson.GetProperty("Id").GetString(),
                        QuickBooksLineId = line.QuickBooksLineId,
                        LineNum = index + 1,
                        Description = line.Description,
                        Amount = line.Amount,
                        ItemId = line.ItemId,
                        ItemName = line.ItemName,
                        UnitPrice = line.UnitPrice,
                        Qty = line.Qty,
                        BillableStatus = line.BillableStatus,
                        TaxCodeRef = line.TaxCodeRef
                    }).ToList()
                };

                _dbContext.Bills.Add(createdBill);

                foreach (var billLine in createdBill.Lines)
                {
                    _dbContext.BillLines.Add(billLine);
                }

                await _dbContext.SaveChangesAsync();

                return createdBill;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error creating bill: {ex.Message}", ex);
            }
        }

        public async Task<object> GetAllVendorDetailsAsync()
        {
            var vendorDetails = await _dbContext.Vendors
                .Where(v => v.DisplayName != null && v.PrimaryEmailAddr != null)
                .Select(v => new
                {
                    v.Id,
                    v.DisplayName,
                    v.PrimaryEmailAddr
                })
                .ToListAsync();

            if (!vendorDetails.Any())
            {
                _logger.LogWarning("No vendors with DisplayName and PrimaryEmailAddr found.");
                return new { Message = "No vendor details found." };
            }

            return vendorDetails;
        }

        public async Task<object> GetChartOfAccountIdAndNamesAsync()
        {
            var accounts = await _dbContext.ChartOfAccounts
                .Where(a => a.Name != null)
                .Select(a => new
                {
                    a.QuickBooksAccountId,
                    a.Name
                })
                .ToListAsync();

            if (accounts == null || !accounts.Any())
            {
                _logger.LogWarning("No Chart of Accounts found.");
                return new { Message = "No Chart of Accounts found." };
            }

            return accounts;
        }
        public async Task<object> GetAllProductDetailsAsync()
        {
            var productDetails = await _dbContext.Products
                .Where(p => p.QuickBooksItemId != null && p.Name != null)
                .Select(p => new
                {
                    p.QuickBooksItemId,
                    p.Name,
                    p.UnitPrice
                })
                .ToListAsync();

            if (!productDetails.Any())
            {
                _logger.LogWarning("No products with QuickBooksItemId and Name found.");
                return new { Message = "No product details found." };
            }

            return productDetails;
        }
        public async Task<object> GetAllCustomerDetailsAsync()
        {
            var customerDetails = await _dbContext.Customers
                .Where(c => c.QuickBooksCustomerId != null && c.DisplayName != null)
                .Select(c => new
                {
                    c.QuickBooksCustomerId,
                    c.DisplayName,
                   
                })
                .ToListAsync();

            if (!customerDetails.Any())
            {
                _logger.LogWarning("No customers with QuickBooksCustomerId and Name found.");
                return new { Message = "No customer details found." };
            }

            return customerDetails;
        }

    }
}
