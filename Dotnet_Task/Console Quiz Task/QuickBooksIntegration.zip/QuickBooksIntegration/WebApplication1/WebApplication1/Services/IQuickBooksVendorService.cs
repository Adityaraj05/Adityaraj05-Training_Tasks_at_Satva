﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IQuickBooksVendorService
    {
        Task<object> FetchVendorsFromDbPaginated(int page, int pageSize, string searchTerm);
        Task<List<Vendor>> FetchVendorsFromQuickBooks();
        Task<Vendor> AddVendorToQuickBooks(Vendor vendor);
        Task<bool> DeleteVendor(string id);
    }

}
