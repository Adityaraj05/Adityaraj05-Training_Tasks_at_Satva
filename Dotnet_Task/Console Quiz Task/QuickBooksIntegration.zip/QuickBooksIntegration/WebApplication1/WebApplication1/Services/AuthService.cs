﻿using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Web;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class AuthService : IAuthService
    {
        private readonly IConfiguration _config;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<AuthService> _logger;
        private readonly HttpClient _httpClient;

        public AuthService(IConfiguration config, ApplicationDbContext dbContext, ILogger<AuthService> logger, HttpClient httpClient)
        {
            _config = config;
            _dbContext = dbContext;
            _logger = logger;
            _httpClient = httpClient;
        }

        public string GetLoginUrl()
        {
            var clientId = _config["QuickBooks:ClientId"];
            var redirectUri = _config["QuickBooks:RedirectUri"];
            var scope = "com.intuit.quickbooks.accounting openid profile email phone address";

            var query = HttpUtility.ParseQueryString(string.Empty);
            query["client_id"] = clientId;
            query["redirect_uri"] = redirectUri;
            query["response_type"] = "code";
            query["scope"] = scope;
            query["state"] = Guid.NewGuid().ToString();

            return $"https://appcenter.intuit.com/connect/oauth2?{query}";
        }

        public async Task<(bool Success, string Message, int? TokenId)> ExchangeCodeAsync(ExchangeRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Code) || string.IsNullOrWhiteSpace(request.RealmId))
                return (false, "Code or RealmId is missing.", null);

            try
            {
                var clientId = _config["QuickBooks:ClientId"];
                var clientSecret = _config["QuickBooks:ClientSecret"];
                var redirectUri = _config["QuickBooks:RedirectUri"];

                var authHeader = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{clientId}:{clientSecret}"));

                var postData = new Dictionary<string, string>
                {
                    { "grant_type", "authorization_code" },
                    { "code", request.Code },
                    { "redirect_uri", redirectUri }
                };

                var httpRequest = new HttpRequestMessage(HttpMethod.Post, "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer")
                {
                    Headers = { { "Authorization", $"Basic {authHeader}" } },
                    Content = new FormUrlEncodedContent(postData)
                };

                var httpClient = new HttpClient();
                var response = await httpClient.SendAsync(httpRequest);
                var content = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                    return (false, "Token exchange failed: " + content, null);

                var tokenData = JsonSerializer.Deserialize<TokenResponse>(content);
                if (tokenData == null)
                    return (false, "Token data could not be parsed.", null);

                var quickBooksUserId = ExtractSubClaimFromIdToken(tokenData.IdToken);

                var token = new QuickBooksToken
                {
                    QuickBooksUserId = quickBooksUserId,
                    RealmId = request.RealmId,
                    AccessToken = tokenData.AccessToken,
                    RefreshToken = tokenData.RefreshToken,
                    IdToken = tokenData.IdToken,
                    TokenType = tokenData.TokenType,
                    ExpiresIn = tokenData.ExpiresIn,
                    XRefreshTokenExpiresIn = tokenData.XRefreshTokenExpiresIn,
                    CreatedAt = DateTime.UtcNow,
                };

                _dbContext.QuickBooksTokens.Add(token);
                await _dbContext.SaveChangesAsync();

                return (true, "Token saved successfully", token.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during token exchange. Inner exception: {0}", ex.InnerException?.Message);
                return (false, "Internal server error: " + ex.Message, null);
            }

        }

        public async Task<(bool Success, string Message)> LogoutAsync()
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    return (false, "No QuickBooks token found.");

                _dbContext.QuickBooksTokens.Remove(tokenRecord);

                await _dbContext.SaveChangesAsync();

                return (true, "Token and associated data deleted successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during logout and deletion");
                return (false, $"Error during logout and deletion: {ex.Message}");
            }
        }

        private string ExtractSubClaimFromIdToken(string idToken)
        {
            if (string.IsNullOrWhiteSpace(idToken) || idToken.Split('.').Length < 2)
                return null;

            try
            {
                var payload = idToken.Split('.')[1];
                var padded = payload.PadRight(payload.Length + (4 - payload.Length % 4) % 4, '=');
                var jsonBytes = Convert.FromBase64String(padded);
                var json = Encoding.UTF8.GetString(jsonBytes);

                using var doc = JsonDocument.Parse(json);
                return doc.RootElement.TryGetProperty("sub", out var sub) ? sub.GetString() : null;
            }
            catch
            {
                return null;
            }
        }

    }
}
