﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<QuickBooksToken> QuickBooksTokens { get; set; }
        public DbSet<ChartOfAccount> ChartOfAccounts { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Product> Products { get; set; }

        public DbSet<Invoice> Invoices { get; set; }
        public DbSet<InvoiceLineItem> InvoiceLineItems { get; set; }
        public DbSet<Vendor> Vendors { get; set; }

        public DbSet<Bill> Bills { get; set; }
        public DbSet<BillLine> BillLines { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Invoice>()
                .HasKey(i => i.Id);

            modelBuilder.Entity<Invoice>()
                .Property(i => i.Subtotal)
                .HasColumnType("decimal(18, 4)");

            modelBuilder.Entity<Invoice>()
                .Property(i => i.Total)
                .HasColumnType("decimal(18, 4)");

            modelBuilder.Entity<Invoice>()
                .HasMany(i => i.InvoiceLineItems)
                .WithOne(il => il.Invoice)
                .HasForeignKey(il => il.InvoiceId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<InvoiceLineItem>()
                .HasKey(il => il.Id);

            modelBuilder.Entity<InvoiceLineItem>()
                .Property(il => il.Rate)
                .HasColumnType("decimal(18, 4)");

            modelBuilder.Entity<InvoiceLineItem>()
                .Property(il => il.Amount)
                .HasColumnType("decimal(18, 4)");

            modelBuilder.Entity<Product>()
                .Property(p => p.UnitPrice)
                .HasColumnType("decimal(18, 4)");

            modelBuilder.Entity<Customer>()
                .Property(c => c.Balance)
                .HasColumnType("decimal(18, 4)");

            modelBuilder.Entity<ChartOfAccount>()
                .Property(ca => ca.CurrentBalance)
                .HasColumnType("decimal(18, 4)");
            modelBuilder.Entity<Bill>()
        .HasKey(b => b.QuickBooksBillId);  // Set QuickBooksBillId as the primary key

            modelBuilder.Entity<Bill>()
                .Property(b => b.TotalAmt)
                .HasColumnType("decimal(18, 2)");  // Configure decimal type for TotalAmt

            modelBuilder.Entity<Bill>()
                .Property(b => b.Balance)
                .HasColumnType("decimal(18, 2)");  // Configure decimal type for Balance

            // Configure the 'BillLine' entity
            modelBuilder.Entity<BillLine>()
                .HasKey(bl => bl.Id);  // Set Id as the primary key for BillLine

            modelBuilder.Entity<BillLine>()
                .Property(bl => bl.Amount)
                .HasColumnType("decimal(18, 2)");  // Configure decimal type for Amount

            modelBuilder.Entity<BillLine>()
                .Property(bl => bl.UnitPrice)
                .HasColumnType("decimal(18, 2)");  // Configure decimal type for UnitPrice

            modelBuilder.Entity<BillLine>()
                .Property(bl => bl.Qty)
                .HasColumnType("decimal(18, 2)");  // Configure decimal type for Qty

            modelBuilder.Entity<BillLine>()
                .Property(bl => bl.TaxCodeRef)
                .HasMaxLength(50);  // Set max length for TaxCodeRef

            // Configure the foreign key relationship between 'BillLine' and 'Bill'
            modelBuilder.Entity<BillLine>()
                .HasOne<Bill>()  // 'BillLine' has one 'Bill'
                .WithMany(b => b.Lines)  // 'Bill' has many 'BillLine'
                .HasForeignKey(bl => bl.QuickBooksBillId)  // Foreign key is QuickBooksBillId in BillLine
                .HasConstraintName("FK_BillLines_Bills_QuickBooksBillId")  // Set explicit constraint name
                .OnDelete(DeleteBehavior.Cascade);  // Define delete behavior (cascade delete) 
        }
    }
}
