﻿using Microsoft.EntityFrameworkCore;



using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using QuickBooks.Interface;
using QuickBooks.Services;
using Data_Access_Layer.Interface;
using Data_Access_Layer.Services;
using QuickBooks.Helpher;
using Xero.Interface;
using Xero.Services;
using Middlelayer.Interface;
using Middlelayer.Services;


var builder = WebApplication.CreateBuilder(args);

// Database configuration
builder.Services.AddDbContext<ApplicationDbContext>(options =>
options.UseSqlServer(
builder.Configuration.GetConnectionString("DefaultConnection"),
sqlOptions => sqlOptions.MigrationsAssembly("WebApplication1")
)
.EnableSensitiveDataLogging()
.LogTo(Console.WriteLine, LogLevel.Information)
);

//Date--3/05/25
builder.Services.AddScoped<IAuthService,AuthService>();

// Register services for dependency injection
builder.Services.AddScoped<QbHelpher>();


builder.Services.AddScoped<ICustomerService, CustomerService>();
builder.Services.AddScoped<IProductQbService, ProductQbService>();
//builder.Services.AddScoped<CSVHelper>();
builder.Services.AddScoped<AccountMappingService>();
builder.Services.AddScoped<IXeroAuthService, XeroAuthService>();
builder.Services.AddScoped<IXeroAccountService, XeroAccountService>();
builder.Services.AddScoped<ICsvImportService, CsvImportService>();
builder.Services.AddScoped<TokenRefreshService>();
builder.Services.AddHttpClient<IXeroContactService, XeroContactService>();
builder.Services.AddScoped<ContactMappingService>();
builder.Services.Configure<XeroSettings>(builder.Configuration.GetSection("Xero"));
builder.Services.AddScoped<IXeroProductService, XeroProductService>();
builder.Services.AddScoped<IDatabase, Databasehelper>();
builder.Services.AddScoped<IChart, ChartService>();

builder.Services.AddScoped<IXeroInvoiceService, XeroInvoiceService>();
builder.Services.AddScoped<InvoiceMappingService>();
builder.Services.AddScoped<IXeroBillService, XeroBillService>();
builder.Services.AddScoped<ICustomerCommonService, CustomerCommonService>();




// Add services to the container
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:5173") // Frontend origin
              .AllowAnyHeader()
              .AllowAnyMethod()

              .AllowCredentials(); // optional if you are using cookies/auth headers
    });
});


builder.Services.AddHttpClient();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();



// Add CORS before Authorization
app.UseCors("AllowFrontend");

app.UseAuthorization();

app.MapControllers();

app.Run();