﻿namespace WebApplication1.Models
{
    public class QuickBooksRequest
    {
        public string AccessToken { get; set; }
        public string RealmId { get; set; }
    }
}
