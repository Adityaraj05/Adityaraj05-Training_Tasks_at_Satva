﻿namespace WebApplication1.Models
{
    public class InvoiceListItem
    {
        public string Date { get; set; }
        public string No { get; set; }
        public string Customer { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }
        public string Id { get; set; }
    }

}
