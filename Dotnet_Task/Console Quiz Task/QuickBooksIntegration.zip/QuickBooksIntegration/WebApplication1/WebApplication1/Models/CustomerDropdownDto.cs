﻿namespace WebApplication1.Models
{
    public class CustomerDropdownDto
    {
        public int Id { get; set; }
        public string DisplayName { get; set; }
    }

}
