﻿namespace WebApplication1.Models
{
    public class AddProductDto
    {
        public string Name { get; set; }
        public string Type { get; set; } // "Inventory" or "Service"
        public decimal UnitPrice { get; set; }
        public bool Taxable { get; set; }

        public string IncomeAccountId { get; set; }
        public string? ExpenseAccountId { get; set; } // Only for Inventory
        public string? AssetAccountId { get; set; }   // Only for Inventory

        public int? QuantityOnHand { get; set; } // Only for Inventory
        public DateTime? InventoryStartDate { get; set; } // Only for Inventory
    }

}
