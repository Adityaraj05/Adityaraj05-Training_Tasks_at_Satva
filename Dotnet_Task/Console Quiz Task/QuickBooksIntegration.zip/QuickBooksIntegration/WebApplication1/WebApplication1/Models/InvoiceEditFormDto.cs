﻿namespace WebApplication1.Models
{
    public class InvoiceEditFormDto
    {
        public string QuickBooksInvoiceId { get; set; }
        public string QuickBooksCustomerId { get; set; }
        public string CustomerName { get; set; }  // Display Name
        public string CustomerEmail { get; set; }
        public string BillingAddress { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime? DueDate { get; set; }
        public List<InvoiceEditLineDto> LineItems { get; set; }
    }

    public class InvoiceEditLineDto
    {
        public string QuickBooksItemId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Qty { get; set; }
        public decimal Rate { get; set; }
        public decimal Amount { get; set; }
    }

}
