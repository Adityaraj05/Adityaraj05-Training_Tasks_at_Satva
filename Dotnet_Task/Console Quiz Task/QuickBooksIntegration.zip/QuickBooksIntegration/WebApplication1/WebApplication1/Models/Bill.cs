﻿using System.ComponentModel.DataAnnotations;


public class Bill
{
    [Key]
    public string? QuickBooksBillId { get; set; } 
    public string? SyncToken { get; set; }
    public DateTime? TxnDate { get; set; }
    public DateTime? DueDate { get; set; }

    public string? VendorId { get; set; }
    public string? VendorName { get; set; }

    public string? VendorAddrLine1 { get; set; }
    public string? VendorAddrCity { get; set; }
    public string? VendorAddrState { get; set; }
    public string? VendorAddrPostalCode { get; set; }
    public string? VendorAddrLat { get; set; }
    public string? VendorAddrLong { get; set; }

    public string? APAccountId { get; set; }
    public string? APAccountName { get; set; }

    public string? CurrencyValue { get; set; }
    public string? CurrencyName { get; set; }

    public decimal? TotalAmt { get; set; }
    public decimal? Balance { get; set; }

    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? LastModifiedBy { get; set; }

    public List<BillLine>? Lines { get; set; }
}
public class BillLine
{
    public int Id { get; set; } 
    public string? QuickBooksBillId { get; set; } 

    public int LineNum { get; set; }
    public string QuickBooksLineId { get; set; }

    public string? Description { get; set; }
    public decimal? Amount { get; set; }

    public string? ItemId { get; set; }
    public string? ItemName { get; set; }

    public decimal? UnitPrice { get; set; }
    public decimal? Qty { get; set; }

    public string? BillableStatus { get; set; }
    public string? TaxCodeRef { get; set; }
    public string? DetailType { get; set; } 

}
