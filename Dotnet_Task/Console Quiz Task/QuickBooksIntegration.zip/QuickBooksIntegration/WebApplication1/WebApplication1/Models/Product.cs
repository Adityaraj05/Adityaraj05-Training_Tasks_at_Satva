﻿using System.Text.Json.Serialization;

namespace WebApplication1.Models
{
    public class Product
    {
        public int Id { get; set; } // Local DB ID

        public string QuickBooksItemId { get; set; } // QBO ID
        public string Name { get; set; }
        public string Type { get; set; } // "Inventory" or "Service"

        public string SyncToken { get; set; }

        public decimal UnitPrice { get; set; }

        public string? IncomeAccountId { get; set; }
        public string? IncomeAccountName { get; set; }

        public string? ExpenseAccountId { get; set; } // Only for Inventory
        public string? ExpenseAccountName { get; set; }

        public string? AssetAccountId { get; set; } // Only for Inventory
        public string? AssetAccountName { get; set; }

        public int? QuantityOnHand { get; set; } // Only for Inventory
        public DateTime? InventoryStartDate { get; set; } // Only for Inventory

        public bool Taxable { get; set; }
        public bool Active { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

}
