﻿namespace WebApplication1.Models
{
    public class ExchangeRequest
    {
        public string Code { get; set; }
        public string State { get; set; }
        public string RealmId { get; set; }
    }
}
