﻿using System;
using System.Text.Json.Serialization;

namespace WebApplication1.Models
{
    public class InvoiceLineItem
    {
        public int Id { get; set; }  // Primary key

        public int InvoiceId { get; set; }  // Foreign Key to Invoices table

        [JsonIgnore]
        public Invoice Invoice { get; set; }  // Navigation property for Invoice

        public string QuickBooksItemId { get; set; }  // To directly match QuickBooks if needed

        public string QuickBooksInvoiceId { get; set; }
        public string? Description { get; set; }  // Description of the line item
        public decimal Qty { get; set; }  // Quantity of the product
        public decimal Rate { get; set; }  // Rate of the product
        public decimal Amount { get; set; }  // Amount (calculated as Quantity * Rate)

        public DateTime CreatedAt { get; set; }  // Timestamp when the line item was created
        public DateTime UpdatedAt { get; set; }  // Timestamp when the line item was last updated
    }
}
