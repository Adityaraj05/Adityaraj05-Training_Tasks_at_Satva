﻿namespace WebApplication1.Models
{
    public class Vendor
    {
        public int? Id { get; set; }                    
        public string? SyncToken { get; set; }           
        public string DisplayName { get; set; }         
        public string? AcctNum { get; set; }            

        // Contact Info
        public string? PrimaryEmailAddr { get; set; }
        public string? PrimaryPhone { get; set; }

        // Billing Address
        public string? BillAddr_Line1 { get; set; }
        public string? BillAddr_City { get; set; }
        public string? BillAddr_PostalCode { get; set; }
        public string? BillAddr_CountrySubDivisionCode { get; set; }
        public bool Active { get; set; } = true;// 0 = inactive, 1 = active
        public decimal? Balance { get; set; }


    }

}
