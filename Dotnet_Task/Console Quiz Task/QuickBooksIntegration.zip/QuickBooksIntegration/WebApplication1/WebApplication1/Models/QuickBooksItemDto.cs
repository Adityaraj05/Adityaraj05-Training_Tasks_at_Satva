﻿namespace WebApplication1.Models
{
    public class QuickBooksItemDto
    {
        public string Id { get; set; }                     
        public string SyncToken { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public decimal UnitPrice { get; set; }
        public bool Taxable { get; set; }
        public bool Active { get; set; } = true;

        public AccountRef IncomeAccountRef { get; set; }
        public AccountRef ExpenseAccountRef { get; set; }
        public AccountRef AssetAccountRef { get; set; }

        public bool? TrackQtyOnHand { get; set; }
        public decimal? QtyOnHand { get; set; }
        public string InvStartDate { get; set; }
    }

    public class AccountRef
    {
        public string value { get; set; }
        public string name { get; set; }
    }



}
