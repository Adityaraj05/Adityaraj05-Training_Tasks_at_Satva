﻿namespace WebApplication1.Models
{
    public class InvoiceRequestDto
    {
        public string? QuickBooksInvoiceId { get; set; }

        public string? CustomerId { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime? DueDate { get; set; }
        public string Store { get; set; }
        public string BillingAddress { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Total { get; set; }
        public string RealmId { get; set; }
        public List<InvoiceLineDto> Line { get; set; }
    }

    public class InvoiceLineDto
    {
        public string QuickBooksItemId { get; set; } 
        public string ProductName { get; set; }
        public decimal Rate { get; set; }
        public string Description { get; set; }
        public decimal Qty { get; set; }
        public decimal Amount { get; set; }
    }
}
