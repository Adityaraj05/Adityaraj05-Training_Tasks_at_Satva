﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Data_Access_Layer.Models.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Xero.Interface;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class XeroInvoicesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<XeroInvoicesController> _logger;
        private readonly IXeroInvoiceService _xeroService;

        public XeroInvoicesController(
            ApplicationDbContext context,
            ILogger<XeroInvoicesController> logger,
            IXeroInvoiceService xeroService)
        {
            _context = context;
            _logger = logger;
            _xeroService = xeroService;
        }

        // GET: api/XeroInvoices
        [HttpGet]
        public async Task<ActionResult<ApiResponse<List<Invoice>>>> GetInvoices(
            [FromQuery] string tenantId,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string filter = null,
            [FromQuery] string sortBy = null,
            [FromQuery] string sortOrder = "asc")
        {
            try
            {
                _logger.LogInformation($"Getting Xero invoices for tenant {tenantId}, page {page}, pageSize {pageSize}");

                var result = await _xeroService.GetInvoicesAsync(
                    tenantId, page, pageSize, filter, sortBy, sortOrder);

                if (!result.Success)
                {
                    return BadRequest(result);
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving invoices");
                return StatusCode(500, ApiResponse<List<Invoice>>.ErrorResponse(
                    "An error occurred while retrieving invoices"));
            }
        }

        // GET: api/XeroInvoices/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<ApiResponse<Invoice>>> GetInvoice(string id, [FromQuery] string tenantId)
        {
            try
            {
                _logger.LogInformation($"Getting Xero invoice with ID {id} for tenant {tenantId}");

                var result = await _xeroService.GetInvoiceByIdAsync(tenantId, id);

                if (!result.Success)
                {
                    return NotFound(result);
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving invoice with ID {id}");
                return StatusCode(500, ApiResponse<Invoice>.ErrorResponse(
                    "An error occurred while retrieving the invoice"));
            }
        }

        // POST: api/XeroInvoices
        [HttpPost]
        public async Task<ActionResult<ApiResponse<Invoice>>> CreateInvoice([FromBody] InvoiceWrapper wrapper, [FromQuery] string tenantId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (wrapper?.InvoiceInput == null)
                {
                    return BadRequest(ApiResponse<Invoice>.ErrorResponse("Invoice data is required"));
                }

                _logger.LogInformation($"Creating new Xero invoice for tenant {tenantId}");

                var result = await _xeroService.CreateInvoiceAsync(tenantId, wrapper.InvoiceInput);

                if (!result.Success)
                {
                    return BadRequest(result);
                }

                // Return 201 Created with the location header
                return CreatedAtAction(
                    nameof(GetInvoice),
                    new { id = result.Data.ExternalId, tenantId },
                    result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating invoice");
                return StatusCode(500, ApiResponse<Invoice>.ErrorResponse(
                    "An error occurred while creating the invoice"));
            }
        }

        // PUT: api/XeroInvoices/{id}
        [HttpPut("{id}")]
        public async Task<ActionResult<ApiResponse<Invoice>>> UpdateInvoice(string id, [FromBody] InvoiceWrapper wrapper, [FromQuery] string tenantId)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (wrapper?.InvoiceInput == null)
                {
                    return BadRequest(ApiResponse<Invoice>.ErrorResponse("Invoice data is required"));
                }

                _logger.LogInformation($"Updating Xero invoice with ID {id} for tenant {tenantId}");

                var result = await _xeroService.UpdateInvoiceAsync(tenantId, id, wrapper.InvoiceInput);

                if (!result.Success)
                {
                    if (result.Message.Contains("not found"))
                    {
                        return NotFound(result);
                    }
                    return BadRequest(result);
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating invoice with ID {id}");
                return StatusCode(500, ApiResponse<Invoice>.ErrorResponse(
                    "An error occurred while updating the invoice"));
            }
        }

        // DELETE: api/XeroInvoices/{id}
        [HttpDelete("{id}")]
        public async Task<ActionResult<ApiResponse<bool>>> DeleteInvoice(string id, [FromQuery] string tenantId)
        {
            try
            {
                _logger.LogInformation($"Deleting Xero invoice with ID {id} for tenant {tenantId}");

                var result = await _xeroService.DeleteInvoiceAsync(tenantId, id);

                if (!result.Success)
                {
                    return BadRequest(result);
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting invoice with ID {id}");
                return StatusCode(500, ApiResponse<bool>.ErrorResponse(
                    "An error occurred while deleting the invoice"));
            }
        }

        // POST: api/XeroInvoices/sync
        [HttpPost("sync")]
        public async Task<ActionResult<ApiResponse<bool>>> SyncInvoices([FromQuery] string tenantId)
        {
            try
            {
                _logger.LogInformation($"Syncing invoices from Xero for tenant {tenantId}");

                var result = await _xeroService.SyncInvoicesFromXeroAsync(tenantId);

                if (!result.Success)
                {
                    return BadRequest(result);
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing invoices from Xero");
                return StatusCode(500, ApiResponse<bool>.ErrorResponse(
                    "An error occurred while syncing invoices"));
            }
        }
    }

    // Add this wrapper class to handle the frontend's data structure
    public class InvoiceWrapper
    {
        public InvoiceInputModel InvoiceInput { get; set; }
    }
}