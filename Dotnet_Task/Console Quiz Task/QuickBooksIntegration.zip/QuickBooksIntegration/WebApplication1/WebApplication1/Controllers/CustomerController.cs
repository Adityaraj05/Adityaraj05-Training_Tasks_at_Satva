﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerService _customerService;
        private readonly ILogger<CustomerController> _logger;

        public CustomerController(ICustomerService customerService, ILogger<CustomerController> logger)
        {
            _customerService = customerService;
            _logger = logger;
        }

        [HttpGet("fetch-customer-from-db-paginated")]
        public async Task<IActionResult> FetchCustomersFromDbPaginated(
            int page = 1,
            int pageSize = 10,
            string? searchTerm = null)
        {
            try
            {
                var response = await _customerService.FetchCustomersFromDbPaginated(page, pageSize, searchTerm);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching customers: {ex.Message}");
            }
        }

        [HttpGet("fetch-customers-from-quickbooks")]
        public async Task<IActionResult> FetchCustomersFromQuickBooks()
        {
            try
            {
                var customers = await _customerService.FetchCustomersFromQuickBooks();
                return Ok(customers);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching customers from QuickBooks: {ex.Message}");
            }
        }

        [HttpPost("add-customer")]
        public async Task<IActionResult> AddCustomer([FromBody] CustomerDto customerDto)
        {
            try
            {
                var newCustomer = await _customerService.AddCustomer(customerDto);

                return StatusCode(201, new
                {
                    Message = "Customer added successfully to QuickBooks and saved locally.",
                    CustomerId = newCustomer.Id,
                    QuickBooksCustomerId = newCustomer.QuickBooksCustomerId,
                    Customer = new
                    {
                        newCustomer.Id,
                        newCustomer.DisplayName,
                        newCustomer.CompanyName,
                        newCustomer.Phone
                    }
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error adding customer: {ex.Message}");
            }
        }

        [HttpPut("update-customer/{id}")]
        public async Task<IActionResult> UpdateCustomer(int id, [FromBody] CustomerDto customerDto)
        {
            try
            {
                var updatedCustomer = await _customerService.UpdateCustomer(id, customerDto);

                return Ok(new
                {
                    Message = "Customer updated successfully in both QuickBooks and local database.",
                    CustomerId = updatedCustomer.Id,
                    QuickBooksCustomerId = updatedCustomer.QuickBooksCustomerId
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error updating customer: {ex.Message}");
            }
        }

        [HttpDelete("delete-customer/{id}")]
        public async Task<IActionResult> DeleteCustomer(string id)
        {
            try
            {
                var result = await _customerService.DeleteCustomer(id);

                return Ok("Customer marked as inactive in QuickBooks and local DB.");
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Balance must be 0"))
                {
                    return BadRequest("Customer cannot be deleted. Balance must be 0.");
                }
                else if (ex.Message.Contains("Customer not found"))
                {
                    return NotFound("Customer not found in local DB.");
                }
                else if (ex.Message.Contains("Invalid customer ID format"))
                {
                    return BadRequest("Invalid customer ID format.");
                }

                return StatusCode(500, $"Error deleting customer: {ex.Message}");
            }
        }
    }
}