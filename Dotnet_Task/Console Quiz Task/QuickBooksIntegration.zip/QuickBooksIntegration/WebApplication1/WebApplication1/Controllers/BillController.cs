﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BillController : ControllerBase
    {
        private readonly IBillService _billService;

        public BillController(IBillService billService)
        {
            _billService = billService;
        }

        [HttpGet("fetch-bills-from-quickbooks")]
        public async Task<IActionResult> SyncBills()
        {
            try
            {
                var bills = await _billService.FetchBillsFromQuickBooksAsync();
                return Ok(bills);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error syncing bills: {ex.Message}");
            }
        }

        [HttpGet("fetch-bills-from-db")]
        public async Task<IActionResult> FetchBills(int page = 1, int pageSize = 10, string searchTerm = null)
        {
            try
            {
                var result = await _billService.FetchBillsFromDbPaginated(page, pageSize, searchTerm);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
        [HttpPost("create-bill")]
        public async Task<IActionResult> CreateBill([FromBody] Bill bill)
        {
            try
            {
                var createdBill = await _billService.CreateBillInQuickBooksAsync(bill);
                return Ok(createdBill);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error creating bill: {ex.Message}");
            }
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllVendors()
        {
            var result = await _billService.GetAllVendorDetailsAsync();

            if (result is null || result.GetType().GetProperty("Message") != null)
            {
                return NotFound(result);
            }

            return Ok(result);
        }

        [HttpGet("chartofaccounts/id-names")]
        public async Task<IActionResult> GetChartOfAccountIdAndNames()
        {
            var result = await _billService.GetChartOfAccountIdAndNamesAsync();
            return Ok(result);
        }
        [HttpGet("productsDetails")]
        public async Task<IActionResult> GetAllProductDetails()
        {
            var result = await _billService.GetAllProductDetailsAsync();
            return Ok(result);
        }
        [HttpGet("get-all-customers")]
        public async Task<IActionResult> GetAllCustomerDetails()
        {
            var result = await _billService.GetAllCustomerDetailsAsync();

            if (result == null)
            {
                return NotFound(new { Message = "No customer details found." });
            }

            return Ok(result);
        }
    }
}
