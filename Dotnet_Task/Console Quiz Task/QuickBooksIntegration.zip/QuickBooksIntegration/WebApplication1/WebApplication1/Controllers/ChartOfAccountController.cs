﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChartOfAccountController : ControllerBase
    {
        private readonly IChartOfAccountService _chartOfAccountService;

        public ChartOfAccountController(IChartOfAccountService chartOfAccountService)
        {
            _chartOfAccountService = chartOfAccountService;
        }

        [HttpGet("fetch-from-db-paginated")]
        public async Task<IActionResult> FetchChartOfAccountsFromDbPaginated(
            int page = 1,
            int pageSize = 10,
            string? searchTerm = null)
        {
            try
            {
                var result = await _chartOfAccountService.FetchChartOfAccountsFromDbPaginated(page, pageSize, searchTerm);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching paginated accounts: {ex.Message}");
            }
        }

        [HttpGet("fetch-from-quickbooks")]
        public async Task<IActionResult> FetchChartOfAccountsFromQuickBooks()
        {
            try
            {
                var result = await _chartOfAccountService.FetchChartOfAccountsFromQuickBooks();

                if (!result.Success)
                    return StatusCode(500, result.ErrorMessage);

                return Ok(result.Result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching accounts from QuickBooks: {ex.Message}");
            }
        }

        [HttpGet("product-accounts")]
        public async Task<IActionResult> GetProductAccounts([FromQuery] int? productId)
        {
            var quickBooksUserId = "0e2fca6f-006a-3c93-87cc-7fee4a35109d"; 

            var result = await _chartOfAccountService.GetProductAccountOptionsAsync(quickBooksUserId, productId);
            return Ok(result);
        }

    }
}
