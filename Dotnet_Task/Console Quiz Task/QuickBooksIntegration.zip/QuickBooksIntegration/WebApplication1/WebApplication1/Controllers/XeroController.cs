﻿using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

using Xero.Interface;


namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class XeroController : ControllerBase
    {
        private readonly IXeroAuthService _xeroAuthService;
        private readonly ILogger<XeroController> _logger;

        public XeroController(IXeroAuthService xeroAuthService, ILogger<XeroController> logger)
        {
            _xeroAuthService = xeroAuthService;
            _logger = logger;
        }

        [HttpGet("auth")]
        public IActionResult Auth()
        {
            _logger.LogInformation("Starting Xero authentication flow...");
            var authUrl = _xeroAuthService.GetAuthorizationUrl();
            return Redirect(authUrl);
        }

        [HttpPost("exchange")]
        public async Task<IActionResult> ExchangeCode([FromBody] XeroExchangeRequest request)
        {
            _logger.LogInformation("Controller handling exchange code request...");

            if (string.IsNullOrWhiteSpace(request.Code))
            {
                _logger.LogWarning("Missing authorization code.");
                return BadRequest("Code is missing.");
            }

            try
            {
                var response = await _xeroAuthService.ExchangeCodeForTokensAsync(request.Code);
                return Ok(response);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during token exchange");
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

        [HttpPost("refresh")]
        public async Task<IActionResult> RefreshToken([FromBody] XeroRefreshTokenRequest request)
        {
            _logger.LogInformation("Controller handling refresh token request...");

            if (string.IsNullOrWhiteSpace(request.RefreshToken))
            {
                _logger.LogWarning("Missing refresh token.");
                return BadRequest("RefreshToken is missing.");
            }

            try
            {
                var response = await _xeroAuthService.RefreshTokenAsync(request.RefreshToken);
                return Ok(response);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during token refresh");
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

        [HttpGet("callback")]
        public IActionResult Callback([FromQuery] string code, [FromQuery] string state)
        {
            if (string.IsNullOrEmpty(code))
            {
                _logger.LogWarning("No code received in Xero callback");
                return BadRequest("No authorization code received from Xero");
            }

            _logger.LogInformation("Received Xero callback with code. Redirecting to frontend...");

            var redirectUrl = _xeroAuthService.BuildFrontendRedirectUrl(code, state);
            return Redirect(redirectUrl);
        }
    }
}