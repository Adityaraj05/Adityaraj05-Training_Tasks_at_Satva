﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Xero.Interface;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class XeroBillsController : ControllerBase
    {
        private readonly IXeroBillService _xeroBillService;
        private readonly ILogger<XeroBillsController> _logger;

        public XeroBillsController(
            IXeroBillService xeroBillService,
            ILogger<XeroBillsController> logger)
        {
            _xeroBillService = xeroBillService;
            _logger = logger;
        }

        [HttpPost("sync")]

        public async Task<ActionResult<List<Bill>>> SyncXeroBills()
        {
            try
            {
                _logger.LogInformation("Starting Xero bills synchronization");
                var bills = await _xeroBillService.FetchBillsFromXeroAsync();
                _logger.LogInformation($"Successfully synchronized {bills.Count} bills from Xero");
                return Ok(bills);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error synchronizing Xero bills");
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = $"Failed to sync Xero bills: {ex.Message}" });
            }
        }

        [HttpGet]
        public async Task<ActionResult<PagedResult<Bill>>> GetBills([FromQuery] BillQueryParameters parameters)
        {
            try
            {
                if (string.IsNullOrEmpty(parameters.TenantId))
                {
                    return BadRequest("Tenant ID is required");
                }

                var (bills, totalCount) = await _xeroBillService.GetBillsFromDatabaseAsync(parameters);

                var result = new PagedResult<Bill>
                {
                    Items = bills,
                    TotalCount = totalCount,
                    PageNumber = parameters.PageNumber,
                    PageSize = parameters.PageSize
                };

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving Xero bills");
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = $"Failed to retrieve Xero bills: {ex.Message}" });
            }
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Bill>> GetBillById(string id)
        {
            try
            {
                var bill = await _xeroBillService.GetBillByIdAsync(id);
                return Ok(bill);
            }
            catch (ApplicationException ex) when (ex.Message.Contains("not found"))
            {
                _logger.LogWarning($"Xero bill with ID {id} not found");
                return NotFound(new { message = $"Xero bill with ID {id} not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving Xero bill with ID {id}");
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = $"Failed to retrieve Xero bill: {ex.Message}" });
            }
        }


        [HttpPost]
        public async Task<ActionResult<Bill>> CreateBill([FromBody] XeroBillDto billDto)
        {
            try
            {
                // Validate the request
                if (billDto.Contact == null || string.IsNullOrEmpty(billDto.Contact.ContactID))
                {
                    return BadRequest("Contact ID is required");
                }

                if (!billDto.LineItems.Any())
                {
                    return BadRequest("At least one line item is required");
                }

                var createdBill = await _xeroBillService.CreateBillAsync(billDto);

                return CreatedAtAction(
                    nameof(GetBillById),
                    new { id = createdBill.XeroBillId },
                    createdBill);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating Xero bill");
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = $"Failed to create Xero bill: {ex.Message}" });
            }
        }


        [HttpPut("{id}")]
        public async Task<ActionResult<Bill>> UpdateBill(string id, [FromBody] XeroBillDto billDto)
        {
            try
            {
                // Validate the request
                if (billDto.Contact == null || string.IsNullOrEmpty(billDto.Contact.ContactID))
                {
                    return BadRequest("Contact ID is required");
                }

                var updatedBill = await _xeroBillService.UpdateBillAsync(id, billDto);
                return Ok(updatedBill);
            }
            catch (ApplicationException ex) when (ex.Message.Contains("not found"))
            {
                _logger.LogWarning($"Xero bill with ID {id} not found");
                return NotFound(new { message = $"Xero bill with ID {id} not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating Xero bill with ID {id}");
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = $"Failed to update Xero bill: {ex.Message}" });
            }
        }

    
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteBill(string id)
        {
            try
            {
                await _xeroBillService.DeleteBillAsync(id);
                return NoContent();
            }
            catch (ApplicationException ex) when (ex.Message.Contains("not found"))
            {
                _logger.LogWarning($"Xero bill with ID {id} not found");
                return NotFound(new { message = $"Xero bill with ID {id} not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting Xero bill with ID {id}");
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = $"Failed to delete Xero bill: {ex.Message}" });
            }
        }
    }

 
    public class PagedResult<T>
    {
        public List<T> Items { get; set; } = new List<T>();
        public int TotalCount { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
        public bool HasPreviousPage => PageNumber > 1;
        public bool HasNextPage => PageNumber < TotalPages;
    }
}