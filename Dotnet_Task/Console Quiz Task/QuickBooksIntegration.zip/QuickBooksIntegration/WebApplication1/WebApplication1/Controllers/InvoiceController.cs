﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services; // Assuming you have a service to interact with QuickBooks
using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;
using WebApplication1.Data;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InvoiceController : ControllerBase
    {
        private readonly IInvoiceService _invoiceService;
        private readonly ApplicationDbContext _context;

        public InvoiceController(IInvoiceService invoiceService, ApplicationDbContext context)
        {
            _invoiceService = invoiceService;
            _context = context;
        }

        // Fetch invoices from the local database with pagination
        [HttpGet("fetch-from-db-paginated")]
        public async Task<IActionResult> FetchInvoicesFromDbPaginated(
        int page = 1,
        int pageSize = 10,
        string? searchTerm = null)
        {
            try
            {
                var result = await _invoiceService.FetchInvoicesFromDbPaginated(page, pageSize, searchTerm);
                return Ok(new
                {
                    items = result.Invoices,
                    totalCount = result.TotalCount
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching paginated invoices: {ex.Message}");
            }
        }


        [HttpGet("fetch-from-quickbooks")]
        public async Task<IActionResult> FetchInvoicesFromQuickBooks()
        {
            try
            {
                var result = await _invoiceService.FetchInvoicesFromQuickBooks();

                if (!result.Success)
                    return StatusCode(500, result.ErrorMessage);

                return Ok(result.Result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching invoices from QuickBooks: {ex.Message}");
            }
        }

        [HttpGet("customer-dropdown")]
        public async Task<IActionResult> GetCustomerDropdown()
        {
            var customers = await _invoiceService.GetCustomerDropdownAsync();

            if (customers == null || !customers.Any())
                return Unauthorized("QuickBooks token is missing or expired.");

            return Ok(customers);
        }
        
        [HttpGet("customer-details/{quickBooksCustomerId}")]
        public async Task<IActionResult> GetCustomerDetails(string quickBooksCustomerId)
        {
            var customerDetails = await _invoiceService.GetCustomerDetailsAsync(quickBooksCustomerId);

            if (customerDetails == null)
            {
                return NotFound(new { message = "Customer details not found." });
            }

            return Ok(customerDetails);
        }
        [HttpGet("active-products")]
        public async Task<IActionResult> GetActiveProducts()
       {
            var products = await _invoiceService.GetActiveProductsAsync();
            return Ok(products);
        }

        [HttpPost("create-invoice")]
        public async Task<IActionResult> CreateInvoiceAsync([FromBody] InvoiceRequestDto invoiceRequest)
        {
            try
            {
                var createdInvoice = await _invoiceService.CreateInvoiceInQuickBooksAsync(invoiceRequest);
                return Ok(createdInvoice); 
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("update-invoice")]
        public async Task<IActionResult> UpdateInvoice([FromBody] InvoiceRequestDto invoiceRequest)
        {
            if (invoiceRequest == null)
                return BadRequest(new { message = "Invalid invoice data." });

            try
            {
                var updatedInvoice = await _invoiceService.UpdateInvoiceInQuickBooksAsync(invoiceRequest);
                return Ok(new { message = "Invoice updated successfully.", invoice = updatedInvoice });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error updating invoice.", error = ex.Message });
            }
        }

        [HttpDelete("delete-invoice/{quickBooksInvoiceId}")]
        public async Task<IActionResult> DeleteInvoice(string quickBooksInvoiceId)
        {
            try
            {
                var result = await _invoiceService.DeleteInvoiceFromQuickBooksAsync(quickBooksInvoiceId);
                return Ok(new { success = true, message = "Invoice deleted successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error deleting invoice.", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetInvoiceById(string id)
        {
            var result = await _invoiceService.GetInvoiceByIdAsync(id);

            if (result == null)
                return NotFound(new { message = "Invoice not found." });

            return Ok(result);
        }
    }
}
 