﻿using System.Threading.Tasks;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Xero.Interface;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/products")]
    public class XeroProductController : ControllerBase
    {
        private readonly IXeroProductService _xeroProductService;
        private readonly ILogger<XeroProductController> _logger;

        public XeroProductController(
            IXeroProductService xeroProductService,
            ILogger<XeroProductController> logger)
        {
            _xeroProductService = xeroProductService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetProducts(
            [FromQuery] string tenantId,
            [FromQuery] string type = null,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string search = null)
        {
            if (string.IsNullOrEmpty(tenantId))
            {
                return BadRequest(ApiResponse<string>.ErrorResponse("TenantId is required"));
            }

            _logger.LogInformation($"Getting products. TenantId: {tenantId}, Type: {type}, Page: {page}, PageSize: {pageSize}, Search: {search}");

            var response = await _xeroProductService.GetProductsAsync(tenantId, type, page, pageSize, search);

            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(string id, [FromQuery] string tenantId)
        {
            if (string.IsNullOrEmpty(tenantId))
            {
                return BadRequest(ApiResponse<string>.ErrorResponse("TenantId is required"));
            }

            _logger.LogInformation($"Getting product by ID: {id}, TenantId: {tenantId}");

            var response = await _xeroProductService.GetProductByIdAsync(tenantId, id);

            if (!response.Success)
            {
                return NotFound(response);
            }

            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromQuery] string tenantId, [FromBody] Product product)
        {
            if (string.IsNullOrEmpty(tenantId))
            {
                return BadRequest(ApiResponse<string>.ErrorResponse("TenantId is required"));
            }

            if (product == null)
            {
                return BadRequest(ApiResponse<string>.ErrorResponse("Product data is required"));
            }

            _logger.LogInformation($"Creating product. TenantId: {tenantId}, Name: {product.Name}, Type: {product.Type}");

            var response = await _xeroProductService.CreateProductAsync(tenantId, product);

            if (!response.Success)
            {
                return BadRequest(response);
            }

            return CreatedAtAction(nameof(GetProductById), new { id = response.Data.XeroItemId, tenantId }, response);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(string id, [FromQuery] string tenantId, [FromBody] Product product)
        {
            if (string.IsNullOrEmpty(tenantId))
            {
                return BadRequest(ApiResponse<string>.ErrorResponse("TenantId is required"));
            }

            if (product == null)
            {
                return BadRequest(ApiResponse<string>.ErrorResponse("Product data is required"));
            }

            _logger.LogInformation($"Updating product. ID: {id}, TenantId: {tenantId}, Name: {product.Name}");

            var response = await _xeroProductService.UpdateProductAsync(tenantId, id, product);

            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(string id, [FromQuery] string tenantId)
        {
            if (string.IsNullOrEmpty(tenantId))
            {
                return BadRequest(ApiResponse<string>.ErrorResponse("TenantId is required"));
            }

            _logger.LogInformation($"Deleting product. ID: {id}, TenantId: {tenantId}");

            var response = await _xeroProductService.DeleteProductAsync(tenantId, id);

            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }
    }
}