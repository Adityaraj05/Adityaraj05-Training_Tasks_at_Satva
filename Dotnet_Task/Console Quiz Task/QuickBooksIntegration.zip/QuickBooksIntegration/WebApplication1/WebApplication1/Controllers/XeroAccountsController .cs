﻿using Data_Access_Layer.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;


using Xero.Interface;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class XeroAccountsController : ControllerBase
    {
        private readonly IXeroAccountService _xeroAccountService;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<XeroAccountsController> _logger;

        public XeroAccountsController(
            IXeroAccountService xeroAccountService,
            ApplicationDbContext dbContext,
            ILogger<XeroAccountsController> logger)
        {
            _xeroAccountService = xeroAccountService;
            _dbContext = dbContext;
            _logger = logger;
        }

        [HttpGet("fetch-from-xero")]
        public async Task<IActionResult> FetchAccountsFromXero()
        {
            try
            {
                _logger.LogInformation("Starting fetch accounts from Xero process...");
                var accounts = await _xeroAccountService.FetchAccountsFromXeroAsync();
                return Ok(accounts);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching accounts from Xero");
                return StatusCode(500, $"Error fetching accounts from Xero: {ex.Message}");
            }
        }

        [HttpGet("fetch-from-db-paginated")]
        public async Task<IActionResult> FetchAccountsFromDbPaginated(
            int page = 1,
            int pageSize = 10,
            string searchTerm = null)
        {
            try
            {
                _logger.LogInformation("Fetching paginated Xero accounts from database...");

                // Get the latest token to identify the user/tenant
                var tokenRecord = await _dbContext.XeroTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                {
                    return NotFound("No Xero token found.");
                }

                var query = _dbContext.ChartOfAccounts
                    .Where(c => c.QuickBooksUserId == tokenRecord.TenantId && c.CompanySource == "Xero");

                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    string likeTerm = $"%{searchTerm}%";
                    query = query.Where(c =>
                        EF.Functions.Like(c.Name, likeTerm) ||
                        EF.Functions.Like(c.AccountType, likeTerm) ||
                        (c.AccountSubType != null && EF.Functions.Like(c.AccountSubType, likeTerm)) ||
                        (c.Classification != null && EF.Functions.Like(c.Classification, likeTerm))
                    );
                }

                var totalRecords = await query.CountAsync();

                var accounts = await query
                    .OrderBy(c => c.Name)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .ToListAsync();

                var response = new
                {
                    TotalRecords = totalRecords,
                    TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize),
                    CurrentPage = page,
                    PageSize = pageSize,
                    Data = accounts
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching paginated Xero accounts");
                return StatusCode(500, $"Error fetching paginated Xero accounts: {ex.Message}");
            }
        }
    }
}