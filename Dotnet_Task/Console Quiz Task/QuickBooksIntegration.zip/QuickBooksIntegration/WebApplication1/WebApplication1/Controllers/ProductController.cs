﻿using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Mvc;
using QuickBooks.DTOs;
using QuickBooks.Interface;



namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductQbService _productQbService;

        private readonly ILogger<ProductController> _logger;

        public ProductController(IProductQbService productQbService, ILogger<ProductController> logger)
        {
            _productQbService = productQbService;
            _logger = logger;
        }

        [HttpGet("fetch-products-from-quickbooks")]
        public async Task<IActionResult> FetchProductsFromQuickBooks()
        {
           var result = await _productQbService.FetchProductsFromQuickBooks();
            if (result == null)
            {
                return NotFound("No data found.");
            }
            return Ok(result);
        }

        [HttpPost("send-to-quickbooks/{id}")]
        public async Task<IActionResult> SendProductToQuickBooks(int id)
        {
          var result = await _productQbService.SendProductToQuickBooks(id);
            if (result == null)
            {
                return NotFound("No data found.");
            }
            return Ok(result);
        }

        [HttpGet("get-all")]
        public async Task<IActionResult> GetAllProducts(
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? search = null,
               [FromQuery] string? source = null,
            [FromQuery] bool includeInactive = false)
        {
           var result = await _productQbService.GetAllProducts(pageNumber, pageSize, search, source, includeInactive);
            if (result == null)
            {
                return NotFound("No data found.");
            }
            return Ok(result);
        }


        [HttpPost("create")]
        public async Task<IActionResult> CreateProduct([FromBody] Product product)
        {
            var result = await _productQbService.CreateProduct(product);

            if (result == null)
                return StatusCode(500, new ApiResponse { Status = 500, Message = "Unexpected error occurred." });

            if (result.Status == 201)
                return StatusCode(201, result);

            if (result.Status == 400)
                return BadRequest(result);

            if (result.Status == 404)
                return NotFound(result);

            // Fallback
            return StatusCode(result.Status ?? 500, result);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
           var result = await _productQbService.GetProduct(id);
            if (result == null)
            {
                return NotFound("No data found.");
            }
            return Ok(result);
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product productUpdate)
        {
            var result = await _productQbService.UpdateProduct(id, productUpdate);

            if (result == null)
            {
                return StatusCode(500, new ApiResponse
                {
                    Status = 500,
                    Message = "Unexpected error occurred"
                });
            }

            return StatusCode(result.Status ?? 200, result);
        }


        [HttpPut("update-in-quickbooks/{id}")]
        public async Task<IActionResult> UpdateProductInQuickBooks(int id)
        {
            var result = await _productQbService.UpdateProductInQuickBooks(id);

            if (result == null)
            {
                return StatusCode(500, new ApiResponse
                {
                    Status = 500,
                    Message = "Unexpected error occurred"
                });
            }

            return Ok(new ApiResponse
            {
                Status = 200,
                Message = "Product successfully updated in QuickBooks",
                Data = result
            });
        }


        [HttpPut("deactivate/{id}")]
        public async Task<IActionResult> DeactivateProduct(int id)
        {
           var result = await _productQbService.DeactivateProduct(id);
            if (result == null)
            {
                return StatusCode(500, new ApiResponse
                {
                    Status = 500,
                    Message = "Unexpected error occurred"
                });
            }
            return Ok(new ApiResponse
            {
                Status = 200,
                Message = "Product successfully deactivated",
                Data = result
            });
        }

        [HttpPut("make-product-inactive/{quickBooksItemId}")]
        public async Task<IActionResult> MakeProductInactive(string quickBooksItemId)
        {
            var result = await _productQbService.MakeProductInactive(quickBooksItemId);

            // Default to 500 if result.Status is null
            if (result.Status != 200)
            {
                return StatusCode(result.Status ?? 500, new ApiResponse
                {
                    Status = result.Status ?? 500,
                    Message = result.Message
                });
            }

            return Ok(new ApiResponse
            {
                Status = 200,
                Message = result.Message,
                Data = result.Data
            });
        }



        [HttpGet("get-accounts")]
        public async Task<IActionResult> GetAccounts([FromQuery] string accountType)
        {
           var result = await _productQbService.GetAccountsByType(accountType);
            if (result == null)
            {
                return NotFound("No data found.");
            }
            return Ok(result);
        }
    }

}