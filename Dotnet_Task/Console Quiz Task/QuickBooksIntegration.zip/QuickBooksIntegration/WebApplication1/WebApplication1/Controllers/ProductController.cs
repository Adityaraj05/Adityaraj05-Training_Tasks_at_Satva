﻿using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IQuickBooksProductService _productService;

        public ProductController(IQuickBooksProductService productService)
        {
            _productService = productService;
        }

        [HttpGet("fetch-product-from-db-paginated")]
        public async Task<IActionResult> FetchProductsFromDbPaginated(
        int page = 1,
        int pageSize = 10,
        string? searchTerm = null)
        {
            try
            {
                var result = await _productService.FetchProductsFromDbPaginated(page, pageSize, searchTerm);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching paginated products: {ex.Message}");
            }
        }


        [HttpGet("fetch-product-from-quickbooks")]
        public async Task<IActionResult> SyncProducts()
        {
            var products = await _productService.SyncProductsFromQuickBooksAsync();
            return Ok(products.Where(p => p.Active)); 
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddProduct([FromBody] AddProductDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var product = new Product
            {
                Name = dto.Name,
                Type = dto.Type,
                UnitPrice = dto.UnitPrice,
                IncomeAccountId = dto.IncomeAccountId,
                ExpenseAccountId = dto.ExpenseAccountId,
                AssetAccountId = dto.AssetAccountId,
                QuantityOnHand = dto.QuantityOnHand,
                InventoryStartDate = dto.InventoryStartDate,
                Taxable = dto.Taxable,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                Active = true
            };

            var createdProduct = await _productService.AddProductAsync(product);
            return Ok(createdProduct);
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product updatedProduct)
        {
            try
            {
                Console.WriteLine($"Received update request for product ID: {id}");
                Console.WriteLine($"Data received from client: {JsonSerializer.Serialize(updatedProduct, new JsonSerializerOptions { WriteIndented = true })}");

                if (id != updatedProduct.Id)
                {
                    Console.WriteLine("Product ID mismatch error");
                    return BadRequest("Product ID mismatch.");
                }

                var result = await _productService.UpdateProductAsync(updatedProduct);
                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in UpdateProduct: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                return StatusCode(500, new { Error = ex.Message });
            }
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> SoftDeleteProduct(int id)
        {
            try
            {
                var updatedProduct = await _productService.SoftDeleteProductAsync(id);
                return Ok(updatedProduct);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

    }

}
