﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using QuickBooks.Interface;
using System;
using System.Threading.Tasks;



namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CsvImportController : ControllerBase
    {
        private readonly ICsvImportService _csvImportService;
        private readonly ILogger<CsvImportController> _logger;

        public CsvImportController(ICsvImportService csvImportService, ILogger<CsvImportController> logger)
        {
            _csvImportService = csvImportService;
            _logger = logger;
        }

        [HttpPost("validate")]
        public async Task<IActionResult> ValidateCsvFile(IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("No file uploaded");
                }

                var validationErrors = await _csvImportService.ValidateCsvFile(file);
                if (validationErrors.Count > 0)
                {
                    return Ok(new
                    {
                        IsValid = false,
                        Errors = validationErrors
                    });
                }

                return Ok(new { IsValid = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating CSV file");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error validating CSV file");
            }
        }

        [HttpPost("import")]
        public async Task<IActionResult> ImportCsvFile(IFormFile file, [FromQuery] string accessToken, [FromQuery] string realmId)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("No file uploaded");
                }

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                {
                    return BadRequest("QuickBooks access token and realm ID are required");
                }

                var result = await _csvImportService.ProcessCsvFile(file);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error importing CSV file");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error importing CSV file");
            }
        }
    }
}