﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VendorController : ControllerBase
    {
        private readonly IQuickBooksVendorService _vendorService;

        public VendorController(IQuickBooksVendorService vendorService)
        {
            _vendorService = vendorService;
        }
        [HttpGet("fetch-vendors-from-db")]
        public async Task<IActionResult> FetchVendors(int page = 1, int pageSize = 10, string searchTerm = null)
        {
            try
            {
                var result = await _vendorService.FetchVendorsFromDbPaginated(page, pageSize, searchTerm);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
        [HttpGet("fetch-vendors-from-quickbooks")]
        public async Task<IActionResult> SyncVendors()
        {
            try
            {
                var vendors = await _vendorService.FetchVendorsFromQuickBooks();
                return Ok(vendors);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        [HttpPost("add-vendor")]
        public async Task<IActionResult> AddVendor([FromBody] Vendor vendor)
        {
            try
            {
                var result = await _vendorService.AddVendorToQuickBooks(vendor);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVendor(string id)
        {
            try
            {
                var result = await _vendorService.DeleteVendor(id);

                if (result)
                {
                    return Ok(new { message = "Vendor deleted successfully." });
                }

                return NotFound(new { message = "Vendor not found." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error: {ex.Message}" });
            }
        }
    }

}
