﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Middlelayer.Interface;
using Xero.Interface;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class XeroContactsController : ControllerBase
    {
        private readonly IXeroContactService _contactService;
        private readonly ICustomerCommonService _customerCommonService;
        private readonly ILogger<XeroContactsController> _logger;

        public XeroContactsController(
            IXeroContactService contactService,
            ILogger<XeroContactsController> logger, ICustomerCommonService customerCommonService)
        {
            _contactService = contactService;
            _logger = logger;
            _customerCommonService = customerCommonService;
        }

        [HttpGet("fetch")]
        public async Task<IActionResult> FetchContacts()
        {
            try
            {
                _logger.LogInformation("Starting fetch of Xero contacts");
                var contacts = await _customerCommonService.SyncCustomers("Xero");
                return Ok(new { success = true, message = $"Successfully fetched {contacts.Count} contacts from Xero", data = contacts });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching Xero contacts");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetContacts([FromQuery] string tenantId,[FromQuery] int page = 1,[FromQuery] int pageSize = 10,
            [FromQuery] string search = null)
        {
            try
            {
                _logger.LogInformation($"Getting Xero contacts for tenant {tenantId}, page {page}, pageSize {pageSize}");
                var contacts = await _contactService.GetContactsFromDatabaseAsync(tenantId, page, pageSize, search);
                return Ok(new { success = true, data = contacts });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting Xero contacts from database");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("{contactId}")]
        public async Task<IActionResult> GetContact(string contactId)
        {
            try
            {
                _logger.LogInformation($"Getting Xero contact with ID {contactId}");
                var contact = await _contactService.GetContactByIdAsync(contactId);
                return Ok(new { success = true, data = contact });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting Xero contact by ID");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateContact([FromBody] Customer customer)
        {
            try
            {
                _logger.LogInformation("Creating new Xero contact");
                var createdContact = await _contactService.CreateContactAsync(customer);
                return CreatedAtAction(nameof(GetContact), new { contactId = createdContact.XeroContactId },
                    new { success = true, message = "Contact created successfully", data = createdContact });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating Xero contact");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPut("{contactId}")]
        public async Task<IActionResult> UpdateContact(string contactId, [FromBody] Customer customer)
        {
            try
            {
                _logger.LogInformation($"Updating Xero contact with ID {contactId}");
                // Ensure the contactId from the URL is set in the customer object
                if (string.IsNullOrEmpty(customer.XeroContactId) || customer.XeroContactId != contactId)
                {
                    _logger.LogInformation($"Setting XeroContactId from URL parameter: {contactId}");
                    customer.XeroContactId = contactId;
                }

                // Log the customer object to verify it has the correct XeroContactId
                _logger.LogDebug($"Customer object to update: XeroContactId={customer.XeroContactId}, DisplayName={customer.DisplayName}");

                var updatedContact = await _contactService.UpdateContactAsync(customer);

                return Ok(new
                {
                    success = true,
                    message = "Contact updated successfully",
                    data = updatedContact
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating Xero contact with ID {contactId}");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpDelete("{contactId}")]
        public async Task<IActionResult> DeleteContact(string contactId)
        {
            try
            {
                _logger.LogInformation($"Deleting Xero contact with ID {contactId}");
                await _contactService.DeleteContactAsync(contactId);
                return Ok(new { success = true, message = "Contact deleted successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting Xero contact");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }
    }
}