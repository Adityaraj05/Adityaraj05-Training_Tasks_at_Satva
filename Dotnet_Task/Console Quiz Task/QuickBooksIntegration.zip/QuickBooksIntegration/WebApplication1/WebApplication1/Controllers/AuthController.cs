﻿
using Data_Access_Layer.Data;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Mvc;

using QuickBooks.Interface;


namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AuthController> _logger;
        private readonly ApplicationDbContext _dbContext;
        private readonly IAuthService _authService;


        public AuthController(IConfiguration config, ApplicationDbContext context, ILogger<AuthController> logger, ApplicationDbContext dbContext, IAuthService authService)
        {
            _config = config;
            _context = context;
            _logger = logger;
            _dbContext = dbContext;
            _authService = authService;
        }

        [HttpGet("login")]
        public IActionResult Login()
        {
            var authUrl = _authService.GetLoginUrl();
            if(string.IsNullOrEmpty(authUrl))
            {
                _logger.LogError("Failed to generate QuickBooks login URL.");
                return BadRequest("Failed to generate login URL.");
            }
            return Redirect(authUrl);
        }

        [HttpPost("exchange")]
        public async Task<IActionResult> ExchangeCode([FromBody] ExchangeRequest request)
        {
            var result = await _authService.ExchangeCode(request);
            if (result == null)
            {
                return BadRequest("Failed to exchange code for token.");
            }
            return Ok(result);
        }

        [HttpPost("refresh")]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenRequest request)
        {
            
              var result = await _authService.RefreshToken(request);
              if (result == null)
            {
                return BadRequest("Failed to refresh token.");
            }
            return Ok(result);

        }

        [HttpGet("current")]
        public async Task<IActionResult> GetCurrentToken(string realmId)
        {
              
           var result = await _authService.GetCurrentToken(realmId);
            if (result == null)
            {
                return NotFound("No token found for the specified realm ID.");
            }
            return Ok(result);
        }


        [HttpDelete("logout")]
        public async Task<IActionResult> Logout()
        {
           var result = await _authService.Logout();
            if (result == null)
            {
                return BadRequest("Failed to logout.");
            }
            return Ok(result);

        }
    }
}