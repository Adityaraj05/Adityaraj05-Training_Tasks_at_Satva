﻿using System.Text;
using System.Text.Json;
using System.Web;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpGet("login")]
        public IActionResult Login()
        {
            var authUrl = _authService.GetLoginUrl();
            return Redirect(authUrl);
        }

        [HttpPost("exchange")]
        public async Task<IActionResult> ExchangeCode([FromBody] ExchangeRequest request)
        {
            var result = await _authService.ExchangeCodeAsync(request);

            if (!result.Success)
                return BadRequest(result.Message);

            return Ok(new { message = result.Message, result.TokenId });
        }


        [HttpDelete("logout")]
        public async Task<IActionResult> Logout()
        {
            var result = await _authService.LogoutAsync();

            if (!result.Success)
                return StatusCode(500, result.Message);

            return Ok(result.Message);
        }

    }
}
