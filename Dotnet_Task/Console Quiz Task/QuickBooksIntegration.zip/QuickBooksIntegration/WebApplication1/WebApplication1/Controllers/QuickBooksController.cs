﻿using System.Net.Http.Headers;
using System.Text.Json;
using Data_Access_Layer.Data;
using Data_Access_Layer.Interface;
using Data_Access_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using QuickBooks.Interface;



namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class QuickBooksController : ControllerBase
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<AuthController> _logger;
        private readonly IDatabase _databasehelperService;
        private readonly IChart _chartService;

        public QuickBooksController(ApplicationDbContext dbContext, IDatabase databasehelperService, ILogger<AuthController> logger, IChart chartService)
        {
            _httpClient = new HttpClient();
            _dbContext = dbContext;
            _logger = logger;
            _databasehelperService = databasehelperService;
            _chartService = chartService;
        }

        [HttpGet("fetch-from-db-paginated")]
        public async Task<IActionResult> FetchChartOfAccountsFromDbPaginated(
        int page = 1,
        int pageSize = 10,
        string? searchTerm = null)
        {
         
            var result = await _databasehelperService.FetchChartOfAccountsFromDbPaginated(page, pageSize, searchTerm);
            if (result == null)
            {
                return NotFound("No data found.");
            }
            return Ok(result);

        }


        [HttpGet("fetch-from-quickbooks")]
        public async Task<IActionResult> FetchChartOfAccountsFromQuickBooks()
        {
            var result = await _chartService.FetchChartOfAccountsFromQuickBooks();
            if (result == null)
            {
                return NotFound("No data found.");
            }
            return Ok(result);

        }


    }

}
