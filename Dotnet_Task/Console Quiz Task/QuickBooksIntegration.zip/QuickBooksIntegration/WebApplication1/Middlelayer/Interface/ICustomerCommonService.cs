﻿using Data_Access_Layer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Middlelayer.Interface
{
    public interface ICustomerCommonService
    {
        Task<List<Customer>> SyncCustomers(string platform);

        //Task<Customer> AddCustomers(string platform, Object input);
    }


}
