﻿using Data_Access_Layer.Models;
using Middlelayer.Interface;
using Newtonsoft.Json;
using QuickBooks.Helpher;
using QuickBooks.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xero.Interface;

namespace Middlelayer.Services
{
    public class CustomerCommonService : ICustomerCommonService
    {
        private readonly ICustomerService _customerService;
        private readonly QbHelpher _helper;
        private readonly IXeroContactService _xeroContactService;

        public CustomerCommonService(ICustomerService customerService, QbHelpher helper, IXeroContactService xeroContactService)
        {
            _customerService = customerService;
            _helper = helper;
            _xeroContactService = xeroContactService;
        }

        public async Task<List<Customer>> SyncCustomers(string platform)
        {
            try
            {
                object response;

                if (platform.ToLower() == "quickbooks")
                {
                    response = await _customerService.FetchCustomersFromQuickBooks();
                }
                else
                {
                    response = await _xeroContactService.FetchContactsFromXeroAsync();
                }

                // Handle null response
                if (response == null)
                {
                    return new List<Customer>();
                }

                // Try to cast to List<Customer>
                var customers = response as List<Customer>;
                if (customers == null)
                {
                    // Optionally log or throw a specific exception
                    throw new InvalidCastException("The response could not be cast to List<Customer>.");
                }

                return customers;
            }
            catch (Exception ex)
            {
                // Log the exception or rethrow
                Console.WriteLine($"Error syncing customers: {ex.Message}");
                return new List<Customer>(); // Return empty list on error
            }
        }



        public async Task<Customer> AddCustomers(string platform, Object input)
        {
            try
            {
                if (platform.ToLower() == "quickbooks")
                {
                    var payload = JsonConvert.DeserializeObject<CustomerDto>(input.ToString());
                    var customer = await _customerService.AddCustomer(payload);
                    return customer;
                }
                else
                {
                    // Assuming Xero returns multiple customers — adjust if needed
                    var contacts = await _xeroContactService.FetchContactsFromXeroAsync();
                    // Handle accordingly, but for consistency, return one customer (or throw)
                    throw new NotSupportedException("Xero integration is not supported in this method.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error syncing customer: {ex.Message}");
                return null!;
            }
            //}


        }
    }
}
    