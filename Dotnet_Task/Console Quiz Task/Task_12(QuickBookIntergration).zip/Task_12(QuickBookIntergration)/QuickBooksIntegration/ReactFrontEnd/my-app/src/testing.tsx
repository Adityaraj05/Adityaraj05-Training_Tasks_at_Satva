{/* <Drawer
title={
  <Typography.Title level={4} style={{ margin: 0 }}>
    {editingCustomer ? 'Edit Customer' : 'Add Customer'}
  </Typography.Title>
}
placement="right"
onClose={handleDrawerClose}
open={drawerVisible}
width={600}
className="customer-drawer"
bodyStyle={{ padding: '24px' }}
headerStyle={{ padding: '16px 24px', borderBottom: '1px solid #f0f0f0' }}
footer={
  <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', padding: '12px 0' }}>
    <Button onClick={handleDrawerClose}>
      Cancel
    </Button>
    <Button 
      type="primary" 
      onClick={handleSubmit}
      loading={submitting}
    >
      {editingCustomer ? 'Update Customer' : 'Add Customer'}
    </Button>
  </div>
}
>
<Form
  form={form}
  layout="vertical"
  initialValues={editingCustomer || {}}
  requiredMark="optional"
>
  <Typography.Title level={5} style={{ marginTop: 0, marginBottom: 16 }}>
    Customer Information
  </Typography.Title>
  
  <Row gutter={16}>
    <Col span={12}>
      <Form.Item 
        label="Display Name" 
        name="displayName"
        rules={[{ required: true, message: 'Please enter display name' }]}
      >
        <Input placeholder="Enter display name" />
      </Form.Item>
    </Col>
    <Col span={12}>
      <Form.Item 
        label="Company Name" 
        name="companyName"
        rules={[{ required: true, message: 'Please enter company name' }]}
      >
        <Input placeholder="Enter company name" />
      </Form.Item>
    </Col>
  </Row>
  
  <Row gutter={16}>
    <Col span={12}>
      <Form.Item 
        label="Phone" 
        name="phone"
        rules={[
          { required: true, message: 'Please enter phone number' },
          { pattern: /^[0-9+-]+$/, message: 'Please enter a valid phone number' }
        ]}
      >
        <Input prefix={<PhoneOutlined style={{ color: '#bfbfbf' }} />} placeholder="Enter phone number" />
      </Form.Item>
    </Col>
    <Col span={12}>
      <Form.Item 
        label="Email" 
        name="email"
        rules={[
          { type: 'email', message: 'Please enter a valid email' }
        ]}
      >
        <Input prefix={<MailOutlined style={{ color: '#bfbfbf' }} />} placeholder="Enter email" />
      </Form.Item>
    </Col>
  </Row>

  <Typography.Title level={5} style={{ marginTop: 24, marginBottom: 16 }}>
    Billing Address
  </Typography.Title>
  
  <Form.Item 
    label="Street Address 1" 
    name="billingStreet1"
  >
    <Input placeholder="Enter street address 1" />
  </Form.Item>
  
  <Form.Item 
    label="Street Address 2" 
    name="billingStreet2"
  >
    <Input placeholder="Enter street address 2" />
  </Form.Item>
  
  <Row gutter={16}>
    <Col span={12}>
      <Form.Item 
        label="City" 
        name="city"
      >
        <Input placeholder="Enter city" />
      </Form.Item>
    </Col>
    <Col span={12}>
      <Form.Item 
        label="State" 
        name="state"
      >
        <Input placeholder="Enter state" />
      </Form.Item>
    </Col>
  </Row>
  
  <Row gutter={16}>
    <Col span={12}>
      <Form.Item 
        label="ZIP Code" 
        name="zipCode"
      >
        <Input placeholder="Enter ZIP code" />
      </Form.Item>
    </Col>
    <Col span={12}>
      <Form.Item 
        label="Country" 
        name="country"
      >
        <Select
          placeholder="Select country"
          showSearch
          optionFilterProp="children"
          defaultValue="United States"
        >
          <Select.Option value="United States">United States</Select.Option>
          <Select.Option value="Canada">Canada</Select.Option>
          <Select.Option value="United Kingdom">United Kingdom</Select.Option>
          <Select.Option value="Australia">Australia</Select.Option>
          {/* Add more countries as needed */}
        </Select>
      </Form.Item>
    </Col>
  </Row>
</Form>
</Drawer> */}