import React, { useState } from 'react';
import { Spin, Typography, Card, Space, Divider } from 'antd';
import { CloudSyncOutlined, CheckCircleOutlined } from '@ant-design/icons';
import './QuickBooksLogin.css';
import './index.css';
import connectButtonImg from './assets/qb-connect-button.png'; // ✅ Import your image

const { Title, Paragraph, Text } = Typography;

const App: React.FC = () => {
  const [loading, setLoading] = useState(false);

  const handleConnect = () => {
    setLoading(true);
    window.location.href = `${import.meta.env.VITE_API_BASE_URL}/api/auth/login`;
  };

  return (
    <div className="qb-page-container">
      <Card 
        className="qb-login-card"
        bordered={false}
        cover={
          <div className="qb-card-cover">
            <CloudSyncOutlined className="qb-header-icon" />
          </div>
        }
      >
        <Typography>
          <Title level={2} className="qb-login-title">
            QuickBooks Integration
          </Title>
          <Divider />
          
          <Space direction="vertical" size="large" className="qb-content-container">
            {loading ? (
              <div className="qb-loading-container">
                <Spin size="large" />
                <Paragraph className="qb-loading-text">
                  Redirecting to QuickBooks...
                </Paragraph>
              </div>
            ) : (
              <>
                <div className="qb-features">
                  <Paragraph>
                    <Text strong>Connect your QuickBooks account to:</Text>
                  </Paragraph>
                  <ul className="qb-feature-list">
                    <li><CheckCircleOutlined className="qb-check-icon" /> Sync your financial data automatically</li>
                    <li><CheckCircleOutlined className="qb-check-icon" /> Import invoices and transactions</li>
                    <li><CheckCircleOutlined className="qb-check-icon" /> Streamline your accounting workflow</li>
                  </ul>
                </div>
                
                <div className="qb-connect-button-container">
                  <img
                    src={connectButtonImg}
                    alt="Connect to QuickBooks"
                    className="qb-custom-button"
                    onClick={handleConnect}
                  />
                  <Paragraph type="secondary" className="qb-helper-text">
                    Securely connect your account with one click
                  </Paragraph>
                </div>
              </>
            )}
          </Space>
        </Typography>
      </Card>
    </div>
  );
};

export default App;
