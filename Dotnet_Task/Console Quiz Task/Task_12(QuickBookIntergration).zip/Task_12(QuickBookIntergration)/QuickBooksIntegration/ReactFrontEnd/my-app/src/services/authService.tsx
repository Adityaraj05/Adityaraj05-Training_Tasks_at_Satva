import axios, { AxiosError, AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

// Token management
export const isTokenExpired = (): boolean => {
  const expiryTime = localStorage.getItem('qb_token_expiry');
  if (!expiryTime) return true;
  
  const now = new Date().getTime();
  return now >= parseInt(expiryTime);
};

export const getTokens = () => {
  return {
    accessToken: localStorage.getItem('qb_access_token'),
    refreshToken: localStorage.getItem('qb_refresh_token'),
    realmId: localStorage.getItem('qb_realm_id')
  };
};

export const clearTokens = () => {
  localStorage.removeItem('qb_access_token');
  localStorage.removeItem('qb_refresh_token');
  localStorage.removeItem('qb_token_expiry');
  localStorage.removeItem('qb_token_id');
  localStorage.removeItem('qb_realm_id');
};

// Save new tokens and expiry
export const saveTokens = (data: { accessToken: string, refreshToken: string, expiresIn: number }) => {
  localStorage.setItem('qb_access_token', data.accessToken);
  localStorage.setItem('qb_refresh_token', data.refreshToken);
  
  // Calculate and store expiration time
  const now = new Date();
  const expiryTime = now.getTime() + (data.expiresIn * 1000);
  localStorage.setItem('qb_token_expiry', expiryTime.toString());
};

// Refresh token implementation
export const refreshToken = async (): Promise<boolean> => {
  const { refreshToken, realmId } = getTokens();
  
  if (!refreshToken || !realmId) {
    console.error('Missing refresh token or realm ID');
    return false;
  }
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken, realmId })
    });
    
    if (!response.ok) {
      throw new Error('Failed to refresh token');
    }
    
    const data = await response.json();
    saveTokens(data);
    
    console.log('Token refreshed successfully');
    return true;
  } catch (error) {
    console.error('Failed to refresh token:', error);
    return false;
  }
};

// Get a valid access token (refresh if needed)
export const getValidAccessToken = async (): Promise<string | null> => {
  if (isTokenExpired()) {
    const success = await refreshToken();
    if (!success) {
      return null;
    }
  }
  
  return localStorage.getItem('qb_access_token');
};

// Create an axios instance with interceptors for automatic token refresh
export const createAuthenticatedAxios = (): AxiosInstance => {
  const axiosInstance = axios.create({
    baseURL: API_BASE_URL
  });
  
  // Track if we're currently refreshing to prevent multiple refresh calls
  let isRefreshing = false;
  // Store pending requests to retry after refresh
  let failedQueue: Array<{
    resolve: (value?: unknown) => void;
    reject: (reason?: any) => void;
    config: AxiosRequestConfig;
  }> = [];
  
  // Process the failed queue
  const processQueue = (error: Error | null, token: string | null = null) => {
    failedQueue.forEach(request => {
      if (error) {
        request.reject(error);
      } else if (token) {
        request.config.headers = {
          ...request.config.headers,
          Authorization: `Bearer ${token}`
        };
        request.resolve(axiosInstance(request.config));
      }
    });
    
    failedQueue = [];
  };
  
  // Request interceptor - adds auth token to requests
  axiosInstance.interceptors.request.use(
    async (config) => {
      // Don't add auth header for refresh token endpoint
      if (config.url?.includes('/api/auth/refresh')) {
        return config;
      }
      
      const token = await getValidAccessToken();
      if (token) {
        config.headers = {
          ...config.headers,
          Authorization: `Bearer ${token}`
        };
      }
      return config;
    },
    error => Promise.reject(error)
  );
  
  // Response interceptor - handles token refresh on 401
  axiosInstance.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
      const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean };
      
      // If error is 401 and not from refresh token endpoint and not already retrying
      if (
        error.response?.status === 401 &&
        !originalRequest._retry &&
        !originalRequest.url?.includes('/api/auth/refresh')
      ) {
        if (isRefreshing) {
          // If already refreshing, queue this request to retry later
          return new Promise((resolve, reject) => {
            failedQueue.push({ resolve, reject, config: originalRequest });
          });
        }
        
        originalRequest._retry = true;
        isRefreshing = true;
        
        try {
          const refreshSuccess = await refreshToken();
          isRefreshing = false;
          
          if (refreshSuccess) {
            const newToken = localStorage.getItem('qb_access_token');
            processQueue(null, newToken);
            
            // Retry original request with new token
            if (originalRequest.headers) {
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
            }
            return axiosInstance(originalRequest);
          } else {
            processQueue(new Error('Failed to refresh token'));
            clearTokens();
            // Redirect to login or handle auth failure
            window.location.href = '/login'; // Or use your navigation method
            return Promise.reject(new Error('Authentication failed'));
          }
        } catch (refreshError) {
          isRefreshing = false;
          processQueue(refreshError as Error);
          clearTokens();
          window.location.href = '/login'; // Or use your navigation method
          return Promise.reject(refreshError);
        }
      }
      
      return Promise.reject(error);
    }
  );
  
  return axiosInstance;
};

// Create a singleton authenticated axios instance
const api = createAuthenticatedAxios();
export default api;

// For backward compatibility - authenticated fetch
export const authFetch = async (
  url: string,
  options: RequestInit = {}
): Promise<Response> => {
  const token = await getValidAccessToken();
  
  if (!token) {
    throw new Error('No valid authentication token');
  }
  
  return fetch(url, {
    ...options,
    headers: {
      ...(options.headers || {}),
      'Authorization': `Bearer ${token}`
    }
  });
};