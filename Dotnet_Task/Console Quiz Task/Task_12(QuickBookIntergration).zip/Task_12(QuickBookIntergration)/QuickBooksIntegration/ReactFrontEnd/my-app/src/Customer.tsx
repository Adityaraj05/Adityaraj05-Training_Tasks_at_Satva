import React, { useEffect, useState } from 'react';
import { Table, message, Spin, Button, Empty, Drawer, Form, Input, Divider, Popconfirm,Space } from 'antd';
import { DownloadOutlined, PlusOutlined, EditOutlined, DeleteOutlined,ReloadOutlined } from '@ant-design/icons';
import SearchBar from './SearchBar';
import './ChartOfAccount.css';

interface CustomerData {
    id: string;
    displayName: string;
    companyName: string;
    phone: string;
    balance: number;
    email?: string;
    billingStreet1?: string;
    city?: string;
    state?: string;
    zipCode?: string;   
    country?: string;
}

interface CustomerFormData extends Omit<CustomerData, 'id' | 'balance'> {
    id?: string;
}

const Customers = () => {
    const [pagedData, setPagedData] = useState<CustomerData[]>([]);
    const [loading, setLoading] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [isDataFetched, setIsDataFetched] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0
    });
    const [drawerVisible, setDrawerVisible] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState<CustomerData | null>(null);
    const [form] = Form.useForm();

    const fetchCustomersFromDb = async (page = 1, pageSize = 10, search = searchTerm) => {
        setLoading(true);
        try {
            const res = await fetch(
                `${import.meta.env.VITE_API_BASE_URL}/api/customer/fetch-customer-from-db-paginated?page=${page}&pageSize=${pageSize}&searchTerm=${encodeURIComponent(search)}`
            );

            const text = await res.text();
            let result;
            try {
                result = JSON.parse(text);
            } catch (e) {
                throw new Error(text);
            }
            console.log('Customers data received:', result);
            if (!res.ok) throw new Error(result.message || 'Failed to fetch data');

            setPagedData(result.data);
            setPagination({
                current: result.currentPage,
                pageSize: result.pageSize,
                total: result.totalRecords,
            });
            setIsDataFetched(true);
        } catch (err) {
            message.error('Failed to fetch customer data.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const fetchCustomersFromQuickBooks = async () => {
        console.log("Setting loading to true");
        setLoading(true);
        console.log("Loading set to true");

        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/customer/fetch-customers-from-quickbooks`, {
                method: 'GET',
            });

            const text = await res.text();
            let result;

            try {
                result = JSON.parse(text);
            } catch (e) {
                console.error("❌ Invalid JSON from QuickBooks download:", text);
                throw new Error(text);
            }

            if (!res.ok) {
                console.error("❌ Error response from QuickBooks download:", result);
                throw new Error(result.message || 'Failed to download accounts from QuickBooks');
            }

            if (result && result.length > 0) {
                setPagedData(result);
                setIsDataFetched(true);
                message.success('Chart of accounts downloaded successfully from QuickBooks.');
            } else {
                message.warning('No new accounts were downloaded from QuickBooks.');
            }
        } catch (err) {
            message.error('Failed to download chart of accounts from QuickBooks.');
            console.error(err);
        } finally {
            console.log("Setting loading to false");
            setLoading(false);
            console.log("Loading set to false");
        }
    };


    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setSearchTerm(value);
        fetchCustomersFromDb(1, pagination.pageSize, value);
    };

    const handleTableChange = (paginationInfo: any) => {
        const { current, pageSize } = paginationInfo;
        setPagination(prev => ({
            ...prev,
            current,
            pageSize
        }));
        fetchCustomersFromDb(current, pageSize, searchTerm);
    };

    const handleDownload = async () => {
        try {
            setIsDataFetched(false);
            await fetchCustomersFromQuickBooks();
            await fetchCustomersFromDb();
            setIsDataFetched(true);
        } catch (error) {
            console.error("Error during download:", error);
            message.error("Failed to fetch data from QuickBooks.");
        }
    };


    const handleAddCustomer = () => {
        setEditingCustomer(null);
        form.resetFields();
        setDrawerVisible(true);
    };

    const handleEditCustomer = (customer: CustomerData) => {
        console.log('Editing customer with ID:', customer.id);
        console.log('Full customer object:', customer);
        setEditingCustomer(customer);
        form.setFieldsValue(customer);
        setDrawerVisible(true);
    };

    const handleDeleteCustomer = async (customerId: string) => {
        console.log("deleting", customerId);
        setLoading(true);
    
        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/customer/delete-customer/${customerId}`, {
                method: 'DELETE',
            });
    
            const responseText = await res.text();
    
            if (!res.ok) {
                // message.error(responseText || 'Failed to delete customer');
                throw new Error(responseText);
            }
    
            message.success('Customer deleted successfully from QuickBooks and local database.');
            fetchCustomersFromDb(pagination.current, pagination.pageSize, searchTerm);
        } catch (err: any) {
            if (err.message.includes("Balance must be 0")) {
                message.warning("Cannot delete customer: balance must be 0.");
            } else {
                message.error(err.message || 'Failed to delete customer.');
            }
            console.error('Delete Error:', err.message || err);
        } finally {
            setLoading(false);
        }
    };
    

    const handleDrawerClose = () => {
        setDrawerVisible(false);
        form.resetFields();
    };

    const handleSubmit = async () => {
        try {
            const values = await form.validateFields();
            const mappedValues = {
                displayName: values.displayName,
                companyName: values.companyName,
                phone: values.phone,
                email: values.email,
                billingLine1: values.billingStreet1,
                billingCity: values.city,
                billingState: values.state,
                billingPostalCode: values.zipCode,
                billingCountry: values.country,
            };

            setSubmitting(true);

            const isEditing = !!editingCustomer;
            const apiEndpoint = isEditing
                ? `${import.meta.env.VITE_API_BASE_URL}/api/customer/update-customer/${editingCustomer?.id}`
                : `${import.meta.env.VITE_API_BASE_URL}/api/customer/add-customer`;

            const method = isEditing ? 'PUT' : 'POST';
            console.log('🧾 Form values before submit:', mappedValues);

            const response = await fetch(apiEndpoint, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(mappedValues),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to save customer');
            }

            message.success(`Customer ${isEditing ? 'updated' : 'added'} successfully!`);
            setDrawerVisible(false);
            form.resetFields();
            fetchCustomersFromDb(pagination.current, pagination.pageSize, searchTerm);
        } catch (error) {
            if (error instanceof Error) {
                message.error(error.message);
            } else {
                message.error('An error occurred while saving the customer');
            }
            console.error('Submit error:', error);
        } finally {
            setSubmitting(false);
        }
    };

    useEffect(() => {
        fetchCustomersFromDb();
    }, []);

    const columns = [
        {
            title: 'Display Name',
            dataIndex: 'displayName',
            key: 'displayName',
            sorter: (a: CustomerData, b: CustomerData) => a.displayName.localeCompare(b.displayName),
        },
        {
            title: 'Company Name',
            dataIndex: 'companyName',
            key: 'companyName',
        },
        {
            title: 'Phone',
            dataIndex: 'phone',
            key: 'phone',
        },
        {
            title: 'Balance',
            dataIndex: 'balance',
            key: 'balance',
            render: (value: number) => {
                if (value === undefined || value === null) return '-';
                const isNegative = value < 0;
                const absValue = Math.abs(value);
                return isNegative
                    ? `-$${absValue.toFixed(2)}`
                    : `$${value.toFixed(2)}`;
            },
            sorter: (a: CustomerData, b: CustomerData) => a.balance - b.balance,
        },
        {
            title: 'Actions',
            key: 'actions',
            render: (_: any, record: CustomerData) => (
                <div className="action-buttons ">
                    <Space>
  <Button
    type="primary"
    icon={<EditOutlined />}
    onClick={() => handleEditCustomer(record)}
  >
    Edit
  </Button>

  <Popconfirm
    title="Are you sure you want to delete this customer?"
    onConfirm={() => handleDeleteCustomer(record.id)}
    okText="Yes"
    cancelText="No"
  >
    <Button danger icon={<DeleteOutlined />}>
      Delete
    </Button>
  </Popconfirm>
</Space>
                </div>
            ),
        },
    ];

    return (
        <div className="chart-accounts-container">
            <div className="chart-accounts-header">
                <div className="chart-accounts-title">Customers</div>
                <div className="chart-accounts-actions d-flex">
                    <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />
                    <Button
                        type="primary"
                        icon={<PlusOutlined />}
                        onClick={handleAddCustomer}
                        className="action-button"
                    >
                        Add Customer
                    </Button>
                    <Button
    type="primary"
    onClick={handleDownload}
    icon={<ReloadOutlined />}
    className="action-button"
>
    Refresh
</Button>
                </div>
            </div>

            <div className="scrollable-table-container">
                {loading ? (
                    <div className="loading-container">
                        <Spin size="large" />
                        <p>Loading Customers...</p>
                    </div>
                ) : pagedData.length > 0 ? (
                    <Table
                        dataSource={pagedData}
                        columns={columns}
                        rowKey={(record) => record.id}
                        pagination={{
                            current: pagination.current,
                            pageSize: pagination.pageSize,
                            total: pagination.total,
                            showSizeChanger: true,
                        }}
                        onChange={handleTableChange}
                        scroll={{ x: 'max-content' }}
                        bordered
                        className="accounts-table"
                    />
                ) : (
                    <div className="empty-data-container">
                        <Empty
                            description='No customer data available. Click "Download" to load from QuickBooks.'
                            image={Empty.PRESENTED_IMAGE_SIMPLE}
                        />
                        <Button
                            type="primary"
                            onClick={handleDownload}
                            icon={<DownloadOutlined />}
                            className="empty-download-button"
                        >
                            Download
                        </Button>
                    </div>
                )}
            </div>

            <Drawer
                title={editingCustomer ? 'Edit Customer' : 'Add Customer'}
                placement="right"
                onClose={handleDrawerClose}
                open={drawerVisible}
                width={500}
                className="customer-drawer"
                footer={
                    <div className="drawer-footer">
                        <Button onClick={handleDrawerClose} className="cancel-button">
                            Cancel
                        </Button>
                        <Button
                            type="primary"
                            onClick={handleSubmit}
                            loading={submitting}
                            className="submit-button"
                        >
                            {editingCustomer ? 'Update Customer' : 'Add Customer'}
                        </Button>
                    </div>
                }
            >
                <Form
                    form={form}
                    layout="vertical"
                    initialValues={editingCustomer || {}}
                    className="customer-form"
                >
                    <Divider orientation="left">Customer Information</Divider>

                    {/* Display Name and Company Name in same row */}
                    <div className="form-row" style={{ display: 'flex', gap: '16px' }}>
                        <Form.Item
                            label="Display Name"
                            name="displayName"
                            rules={[{ required: true, message: 'Please enter display name' }]}
                            style={{ flex: 1 }}
                        >
                            <Input placeholder="Enter display name" />
                        </Form.Item>
                        <Form.Item
                            label="Company Name"
                            name="companyName"
                            rules={[{ required: true, message: 'Please enter company name' }]}
                            style={{ flex: 1 }}
                        >
                            <Input placeholder="Enter company name" />
                        </Form.Item>
                    </div>

                    {/* Phone and Email in same row */}
                    <div className="form-row" style={{ display: 'flex', gap: '16px' }}>
                        <Form.Item
                            label="Phone"
                            name="phone"
                            rules={[
                                { required: true, message: 'Please enter phone number' },
                                { pattern: /^[0-9+-]+$/, message: 'Please enter a valid phone number' }
                            ]}
                            style={{ flex: 1 }}
                        >
                            <Input placeholder="Enter phone number" />
                        </Form.Item>
                        <Form.Item
                            label="Email"
                            name="email"
                            rules={[
                                { required: true, message: 'Please enter email' },
                                { type: 'email', message: 'Please enter a valid email' }
                            ]}
                            style={{ flex: 1 }}
                        >
                            <Input placeholder="Enter email" />
                        </Form.Item>
                    </div>

                    <Divider orientation="left">Billing Address</Divider>

                    {/* Billing fields taking full width */}
                    <div className="billing-section" style={{ border: '1px solid #e8e8e8', borderRadius: '8px', padding: '16px', marginBottom: '16px' }}>
                        <Form.Item
                            label="Street Address 1"
                            name="billingStreet1"
                            rules={[{ required: true, message: 'Please enter street address' }]}
                        >
                            <Input placeholder="Enter street address 1" />
                        </Form.Item>

                        <Form.Item
                            label="City"
                            name="city"
                            rules={[{ required: true, message: 'Please enter city' }]}
                        >
                            <Input placeholder="Enter city" />
                        </Form.Item>

                        <Form.Item
                            label="State"
                            name="state"
                            rules={[{ required: true, message: 'Please enter state' }]}
                        >
                            <Input placeholder="Enter state" />
                        </Form.Item>

                        <Form.Item
                            label="ZIP Code"
                            name="zipCode"
                            rules={[
                                { required: true, message: 'Please enter ZIP code' },
                                { pattern: /^\d{5}(-\d{4})?$/, message: 'Please enter a valid ZIP code' }
                            ]}
                        >
                            <Input placeholder="Enter ZIP code" />
                        </Form.Item>

                        <Form.Item
                            label="Country"
                            name="country"
                            rules={[{ required: true, message: 'Please enter country' }]}
                        >
                            <Input placeholder="Enter country" />
                        </Form.Item>
                    </div>
                </Form>
            </Drawer>
        </div>
    );
};

export default Customers;