import React, { useState, useEffect } from 'react';
import { Table, Input, Button, Space, DatePicker, Select, message, Tag, Spin } from 'antd';
import { SearchOutlined, SyncOutlined, PlusOutlined } from '@ant-design/icons';
import type { TablePaginationConfig } from 'antd/es/table';
import type { FilterValue } from 'antd/es/table/interface';
import moment from 'moment';
import BillDrawer from './BillDrawer';

const { RangePicker } = DatePicker;
const { Option } = Select;

interface Bill {
  id: number;
  docNumber: string;
  vendorName: string;
  txnDate: string;
  dueDate: string;
  totalAmt: number;
  balance: number;
  paid: boolean;
  currencyName: string;
  privateNote: string;
}

interface BillTableParams {
  pagination: TablePaginationConfig;
  sortField?: string;
  sortOrder?: string;
  filters?: Record<string, FilterValue>;
  search?: string;
  startDate?: string;
  endDate?: string;
  vendorId?: string;
  isPaid?: boolean | null;
}

const Bill: React.FC = () => {
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [search, setSearch] = useState<string>('');
  const [drawerVisible, setDrawerVisible] = useState<boolean>(false);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [tableParams, setTableParams] = useState<BillTableParams>({
    pagination: {
      current: 1,
      pageSize: 10,
      showSizeChanger: true,
      pageSizeOptions: ['10', '20', '50'],
    },
    sortField: 'createdAt',
    sortOrder: 'descend',
    search: '',
    startDate: undefined,
    endDate: undefined,
    vendorId: undefined,
    isPaid: null,
  });

  // Use a dependency array with proper dependencies instead of stringifying the object
  useEffect(() => {
    fetchBills();
  }, [
    tableParams.pagination.current,
    tableParams.pagination.pageSize,
    tableParams.sortField,
    tableParams.sortOrder,
    tableParams.search,
    tableParams.startDate,
    tableParams.endDate,
    tableParams.vendorId,
    tableParams.isPaid
  ]);

  const getAuthCredentials = () => {
    const token = localStorage.getItem('qb_access_token');
    const realmId = localStorage.getItem('qb_realm_id');
    
    if (!token || !realmId) {
      message.error('Authentication credentials not found');
      return null;
    }
    
    return { token, realmId };
  };

  const fetchBills = async () => {
    const auth = getAuthCredentials();
    if (!auth) return;

    setLoading(true);
    
    try {
      const { pagination, sortField, sortOrder, search, startDate, endDate, vendorId, isPaid } = tableParams;
      
      const params = new URLSearchParams({
        page: String(pagination.current || 1),
        pageSize: String(pagination.pageSize || 10),
        search: search || '',
        sortBy: sortField || 'createdAt',
        descending: sortOrder === 'descend' ? 'true' : 'false',
      });
      
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      if (vendorId) params.append('vendorId', vendorId);
      if (isPaid !== null) params.append('isPaid', String(isPaid));
      
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/Bill/Pagination?${params.toString()}`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${auth.token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch bills');
      }
      
      const data = await response.json();
      
      setBills(data.bills || []);
      
      // Directly update the tableParams with the returned pagination data
      setTableParams(prev => ({
        ...prev,
        pagination: {
          ...prev.pagination,
          total: data.totalCount,
          current: data.currentPage || pagination.current,
          pageSize: data.pageSize || pagination.pageSize,
        }
      }));
    } catch (error) {
      console.error('Error fetching bills:', error);
      message.error('Failed to load bills');
    } finally {
      setLoading(false);
    }
  };

  const handleTableChange = (
    newPagination: TablePaginationConfig,
    filters: Record<string, FilterValue>,
    sorter: any
  ) => {
    // Update tableParams with the new pagination, filters, and sorting
    setTableParams({
      ...tableParams,
      pagination: {
        ...newPagination,
        // Make sure we keep the total value when changing page or pageSize
        total: tableParams.pagination.total
      },
      filters,
      sortField: sorter.field,
      sortOrder: sorter.order,
    });
  };

  const handleSearch = () => {
    // Reset to first page when performing a new search
    setTableParams({
      ...tableParams,
      search,
      pagination: {
        ...tableParams.pagination,
        current: 1,
      },
    });
  };

  const handleSyncBills = async () => {
    const auth = getAuthCredentials();
    if (!auth) return;

    setLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/Bill/Sync`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${auth.token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to sync bills');
      }

      const result = await response.json();
      message.success(`Successfully synced: Created ${result.created}, Updated ${result.updated}, Total ${result.total} bills`);
      
      // Reset pagination to first page after sync
      setTableParams({
        ...tableParams,
        pagination: {
          ...tableParams.pagination,
          current: 1,
        },
      });
    } catch (error) {
      console.error('Error syncing bills:', error);
      message.error('Failed to sync bills from QuickBooks');
    } finally {
      setLoading(false);
    }
  };

  const handleAddBill = () => {
    setSelectedBill(null);
    setDrawerVisible(true);
  };

  const handleEditBill = (record: Bill) => {
    setSelectedBill(record);
    setDrawerVisible(true);
  };

  const handleDrawerClose = (refreshList: boolean = false) => {
    setDrawerVisible(false);
    if (refreshList) {
      fetchBills();
    }
  };

  const columns = [
    {
      title: 'Vendor',
      dataIndex: 'vendorName',
      key: 'vendorName',
      sorter: true,
    },
    {
      title: 'Date',
      dataIndex: 'txnDate',
      key: 'txnDate',
      sorter: true,
      render: (date: string) => date ? moment(date).format('MM/DD/YYYY') : '-'
    },
    {
      title: 'Due Date',
      dataIndex: 'dueDate',
      key: 'dueDate',
      sorter: true,
      render: (date: string) => date ? moment(date).format('MM/DD/YYYY') : '-'
    },
    {
      title: 'Amount',
      dataIndex: 'totalAmt',
      key: 'totalAmt',
      sorter: true,
      render: (amount: number, record: Bill) => (
        <span>{record.currencyName || '$'} {amount?.toFixed(2) || '0.00'}</span>
      ),
    },
    {
      title: 'Balance',
      dataIndex: 'balance',
      key: 'balance',
      sorter: true,
      render: (balance: number, record: Bill) => (
        <span>{record.currencyName || '$'} {balance?.toFixed(2) || '0.00'}</span>
      ),
    },
    {
      title: 'Status',
      dataIndex: 'paid',
      key: 'paid',
      render: (paid: boolean) => (
        <Tag color={paid ? 'green' : 'orange'}>
          {paid ? 'Paid' : 'Unpaid'}
        </Tag>
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Bill) => (
        <Space>
          <Button type="link" onClick={() => handleEditBill(record)}>Edit</Button>
        </Space>
      ),
    },
  ];

  return (
    <div className="bill-container">
      <div className="bill-header" style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
        <Space>
          <Input 
            placeholder="Search bills..." 
            value={search}
            onChange={e => setSearch(e.target.value)}
            onPressEnter={handleSearch}
            style={{ width: 250 }}
            prefix={<SearchOutlined />} 
          />
          <Button type="primary" onClick={handleSearch}>Search</Button>
        </Space>
        <Space>
          <Button 
            icon={<SyncOutlined />} 
            onClick={handleSyncBills}
            loading={loading}
          >
            Sync with QuickBooks
          </Button>
          <Button 
            type="primary" 
            icon={<PlusOutlined />} 
            onClick={handleAddBill}
          >
            Add Bill
          </Button>
        </Space>
      </div>

      <Table
        columns={columns}
        rowKey={record => record.id.toString()}
        dataSource={bills}
        pagination={tableParams.pagination}
        loading={loading}
        onChange={handleTableChange}
        scroll={{ x: 'max-content', y: 'calc(100vh - 290px)' }}
        style={{ flex: 1 }}
      />

      {drawerVisible && (
        <BillDrawer
          visible={drawerVisible}
          onClose={handleDrawerClose}
          bill={selectedBill}
        />
      )}
    </div>
  );
};

export default Bill;