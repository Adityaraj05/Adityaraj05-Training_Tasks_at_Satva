import React, { useState, useEffect } from 'react';
import { Table, Button, Input, Card, Space, message, Popconfirm } from 'antd';
import { SearchOutlined, SyncOutlined, PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import VendorDrawer from './VendorDrawer';

interface Vendor {
  id: number;
  displayName: string;
  companyName: string;
  email: string;
  phone: string;
  webAddr: string;
  billingLine1?: string;
  billingCity?: string;
  billingState?: string;
  billingPostalCode?: string;
  billingCountry?: string;
  active: boolean;
  vendor1099: boolean;
  balance: number;
  currencyValue: string;
  currencyName: string;
}

interface VendorResponse {
  vendors: Vendor[];
  totalCount: number;
  totalPages: number;
  currentPage: number;
}

const Vendors: React.FC = () => {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [syncLoading, setSyncLoading] = useState<boolean>(false);
  const [searchText, setSearchText] = useState<string>('');
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [drawerVisible, setDrawerVisible] = useState<boolean>(false);
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);

  // Get authentication credentials
  const getAuthCredentials = () => {
    const token = localStorage.getItem('qb_access_token');
    const realmId = localStorage.getItem('qb_realm_id');
    
    if (!token || !realmId) {
      message.error('QuickBooks authentication required');
      return null;
    }
    
    return { token, realmId };
  };

  // Fetch vendors
  const fetchVendors = async (page = 1, pageSize = 10, search = '') => {
    const auth = getAuthCredentials();
    if (!auth) return;
    
    setLoading(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/Vendor?page=${page}&pageSize=${pageSize}&search=${encodeURIComponent(search)}&realmId=${auth.realmId}`,
        {
          headers: {
            'Authorization': `Bearer ${auth.token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch vendors');
      }
      
      const data: VendorResponse = await response.json();
      
      setVendors(data.vendors);
      setPagination({
        current: data.currentPage,
        pageSize,
        total: data.totalCount,
      });
    } catch (error) {
      console.error('Error fetching vendors:', error);
      message.error('Failed to load vendors');
    } finally {
      setLoading(false);
    }
  };

  // Sync vendors with QuickBooks
  const syncVendors = async () => {
    const auth = getAuthCredentials();
    if (!auth) return;
    
    setSyncLoading(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/Vendor/Sync?realmId=${auth.realmId}`, 
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${auth.token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to sync vendors');
      }
      
      const result = await response.json();
      message.success(result.message || 'Vendors synchronized successfully');
      
      // Refresh the vendor list
      fetchVendors(pagination.current, pagination.pageSize, searchText);
    } catch (error) {
      console.error('Error syncing vendors:', error);
      message.error('Failed to sync vendors with QuickBooks');
    } finally {
      setSyncLoading(false);
    }
  };

  // Delete/deactivate vendor
  const deactivateVendor = async (id: number) => {
    const auth = getAuthCredentials();
    if (!auth) return;
    
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/Vendor/${id}?realmId=${auth.realmId}`, 
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${auth.token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to deactivate vendor');
      }
      
      message.success('Vendor successfully deactivated');
      
      // Refresh the vendor list
      fetchVendors(pagination.current, pagination.pageSize, searchText);
    } catch (error) {
      console.error('Error deactivating vendor:', error);
      message.error('Failed to deactivate vendor');
    }
  };

  // Handle search
  const handleSearch = (value: string) => {
    setSearchText(value);
    fetchVendors(1, pagination.pageSize, value);
  };

  // Handle table change (pagination)
  const handleTableChange = (pagination: any) => {
    fetchVendors(pagination.current, pagination.pageSize, searchText);
  };

  // Open drawer for creating/editing vendor
  const openDrawer = (vendor: Vendor | null = null) => {
    setSelectedVendor(vendor);
    setDrawerVisible(true);
  };

  // Handle drawer close
  const handleDrawerClose = (refreshData: boolean = false) => {
    setDrawerVisible(false);
    setSelectedVendor(null);
    
    if (refreshData) {
      fetchVendors(pagination.current, pagination.pageSize, searchText);
    }
  };

  // Load vendors on component mount
  useEffect(() => {
    fetchVendors();
  }, []);

  // Table columns
  const columns = [
    {
      title: 'Name',
      dataIndex: 'displayName',
      key: 'displayName',
      sorter: (a: Vendor, b: Vendor) => a.displayName.localeCompare(b.displayName),
    },
    {
      title: 'Company',
      dataIndex: 'companyName',
      key: 'companyName',
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
    },
    // {
    //   title: 'Phone',
    //   dataIndex: 'phone',
    //   key: 'phone',
    // },
    {
      title: 'Status',
      dataIndex: 'active',
      key: 'active',
      render: (active: boolean) => (
        <span style={{ color: active ? 'green' : 'red' }}>
          {active ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      title: 'Balance',
      dataIndex: 'balance',
      key: 'balance',
      render: (balance: number, record: Vendor) => (
        <span>
          {record.currencyValue} {balance.toFixed(2)}
        </span>
      ),
    },
    
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Vendor) => (
        <Space>
          <Button 
            icon={<EditOutlined />} 
            onClick={() => openDrawer(record)}
            type="primary"
            size="small"
          />
          <Popconfirm
            title="Are you sure you want to deactivate this vendor?"
            onConfirm={() => deactivateVendor(record.id)}
            okText="Yes"
            cancelText="No"
          >
            <Button 
              icon={<DeleteOutlined />} 
              danger 
              size="small"
              disabled={!record.active}
            />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <Card title="Vendor" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
        <Space>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => openDrawer()}
          >
            Add Vendor
          </Button>
          <Button
            type="default"
            icon={<SyncOutlined spin={syncLoading} />}
            onClick={syncVendors}
            loading={syncLoading}
          >
            Sync with QuickBooks
          </Button>
        </Space>
        <Input.Search
          placeholder="Search vendors..."
          allowClear
          enterButton={<SearchOutlined />}
          onSearch={handleSearch}
          style={{ width: 300 }}
        />
      </div>
      
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Table
          columns={columns}
          dataSource={vendors}
          rowKey="id"
          pagination={{
            ...pagination,
            showSizeChanger: true,
            showTotal: (total) => `Total ${total} vendors`,
            position: ['bottomRight']
          }}
          loading={loading}
          onChange={handleTableChange}
          scroll={{ x: 'max-content', y: 'calc(100vh - 365px)' }}
          style={{ flex: 1 }}
        />
      </div>
      
      <VendorDrawer
        visible={drawerVisible}
        vendor={selectedVendor}
        onClose={handleDrawerClose}
      />
    </Card>
  );
};

export default Vendors;