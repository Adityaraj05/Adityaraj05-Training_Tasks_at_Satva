import React, { useState, useEffect } from 'react';
import { Drawer, Form, Input, Select, DatePicker, Button, Space, Table, InputNumber, message, Spin, Row, Col, Typography } from 'antd';
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons';
import moment from 'moment';

const { Option } = Select;
const { TextArea } = Input;
const { Title } = Typography;

interface BillDrawerProps {
  visible: boolean;
  onClose: (refreshList?: boolean) => void;
  bill: any | null;
}

interface Vendor {
  id: number;
  displayName: string;
  companyName?: string;
  email?: string;
  phone?: string;
  billAddr?: {
    line1?: string;
    line2?: string;
    city?: string;
    country?: string;
    postalCode?: string;
  };
}

interface Account {
  id: number;
  name: string;
  accountType: string;
  accountSubType: string;
}

interface Product {
  id: number;
  name: string;
  description?: string;
  unitPrice: number;
  type: string;
}

interface Customer {
  value: string | number;
  label: string;
  email?: string;
  billingAddress?: string;
}

const BillDrawer: React.FC<BillDrawerProps> = ({ visible, onClose, bill }) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingCustomers, setLoadingCustomers] = useState<boolean>(false);
  const [loadingProducts, setLoadingProducts] = useState<boolean>(false);
  const [loadingAccounts, setLoadingAccounts] = useState<boolean>(false);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [apAccounts, setApAccounts] = useState<Account[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [categoryLines, setCategoryLines] = useState<any[]>([{ key: 1, category: '', description: '', amount: 0, billable: false, taxable: false, customer: '' }]);
  const [itemLines, setItemLines] = useState<any[]>([]);
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
  const [currencies, setCurrencies] = useState<{value: string, label: string}[]>([
    { value: 'USD', label: 'US Dollar (USD)' },
    { value: 'CAD', label: 'Canadian Dollar (CAD)' },
    { value: 'EUR', label: 'Euro (EUR)' },
    { value: 'GBP', label: 'British Pound (GBP)' }
  ]);

  useEffect(() => {
    if (visible) {
      fetchVendors();
      fetchAccounts();
      fetchProducts();
      fetchCustomers();
      
      if (bill) {
        populateForm(bill);
      } else {
        resetForm();
      }
    }
  }, [visible, bill]);

  const getAuthCredentials = () => {
    const token = localStorage.getItem('qb_access_token');
    const realmId = localStorage.getItem('qb_realm_id');
    
    if (!token || !realmId) {
      message.error('Authentication credentials not found');
      return null;
    }
    
    return { token, realmId };
  };

  const fetchVendors = async () => {
    const auth = getAuthCredentials();
    if (!auth) return;
    
    setLoading(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/Vendor?pageSize=100&realmId=${auth.realmId}`,
        {
          headers: {
            'Authorization': `Bearer ${auth.token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch vendors');
      }
      
      const data = await response.json();
      setVendors(data.vendors);
    } catch (error) {
      console.error('Error fetching vendors:', error);
      message.error('Failed to load vendors');
    } finally {
      setLoading(false);
    }
  };

  const fetchAccounts = async () => {
    setLoadingAccounts(true);
    try {
      const realmId = localStorage.getItem('qb_realm_id');
      if (!realmId) {
        message.error('QuickBooks RealmID is required');
        return;
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/Account/get-accounts`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch chart of accounts');
      }
      
      const data = await response.json();
      setAccounts(data.data || []);
      
      // Filter accounts to get AP accounts
      const apAccountsList = (data.data || []).filter((account: Account) => 
        account.accountType === 'Accounts Payable' || 
        account.accountSubType === 'AccountsPayable'
      );
      setApAccounts(apAccountsList);
    } catch (error) {
      console.error('Error fetching accounts:', error);
      message.error('Failed to load chart of accounts');
    } finally {
      setLoadingAccounts(false);
    }
  };

  const fetchProducts = async () => {
    setLoadingProducts(true);
    try {
      const realmId = localStorage.getItem('qb_realm_id');
      if (!realmId) {
        message.error('QuickBooks RealmID is required');
        return;
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/get-all?pageNumber=1&pageSize=100`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'realmId': realmId
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch products');
      }
      
      const data = await response.json();
      
      // Transform the data to format required by Select component
      const productOptions = data.data ? data.data.map((product: any) => ({
        value: product.id,
        label: product.name,
        price: product.unitPrice || 0,
        description: product.description || ''
      })) : [];
      
      setProducts(productOptions);
    } catch (error) {
      console.error('Error fetching products:', error);
      message.error('Failed to load products');
    } finally {
      setLoadingProducts(false);
    }
  };

  const fetchCustomers = async () => {
    setLoadingCustomers(true);
    try {
      const realmId = localStorage.getItem('qb_realm_id');
      if (!realmId) {
        message.error('QuickBooks RealmID is required');
        return;
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/customer/fetch-customer-from-db-paginated?page=1&pageSize=100`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'realmId': realmId
          }
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Transform the data to format required by Select component
      const customerOptions = data.data ? data.data.map((customer: any) => ({
        value: customer.id,
        label: customer.displayName || customer.companyName,
        email: customer.email || '',
        billingAddress: `${customer.billingStreet1 || ''}\n${customer.city || ''}, ${customer.state || ''} ${customer.zipCode || ''}\n${customer.country || ''}`.trim()
      })) : [];
      
      setCustomers(customerOptions);
    } catch (error) {
      console.error('Error fetching customers:', error);
      message.error('Failed to load customers');
    } finally {
      setLoadingCustomers(false);
    }
  };

  const populateForm = (billData: any) => {
    form.setFieldsValue({
      vendorId: billData.vendorId,
      docNumber: billData.docNumber || '',
      billDate: moment(billData.txnDate),
      dueDate: moment(billData.dueDate),
      mailingAddress: billData.mailingAddress || '',
      terms: billData.terms || '3', // Default to Net 30
      privateNote: billData.privateNote || '',
      apAccountId: billData.apAccountId || '',
      currencyValue: billData.currencyValue || 'USD', // Default to USD
    });

    // If the bill has line items, populate them
    if (billData.lineItems && billData.lineItems.length > 0) {
      // Process category and item lines separately
      const categoryItems = billData.lineItems.filter((item: any) => item.detailType === 'AccountBasedExpenseLineDetail');
      const productItems = billData.lineItems.filter((item: any) => item.detailType === 'ItemBasedExpenseLineDetail');
      
      if (categoryItems.length > 0) {
        setCategoryLines(categoryItems.map((item: any, index: number) => ({
          key: index + 1,
          category: item.accountId,
          description: item.description || '',
          amount: item.amount || 0,
          billable: item.billable || false,
          taxable: item.taxable || false,
          customer: item.customerId || ''
        })));
      }
      
      if (productItems.length > 0) {
        setItemLines(productItems.map((item: any, index: number) => ({
          key: index + 1,
          product: item.itemId,
          description: item.description || '',
          qty: item.quantity || 1,
          rate: item.unitPrice || 0,
          amount: item.amount || 0,
          billable: item.billable || false,
          taxable: item.taxable || false,
          customer: item.customerId || ''
        })));
      }
    }

    // Find and set selected vendor
    const vendor = vendors.find(v => v.id === billData.vendorId);
    setSelectedVendor(vendor || null);
  };

  const resetForm = () => {
    form.resetFields();
    setCategoryLines([{ key: 1, category: '', description: '', amount: 0, billable: false, taxable: false, customer: '' }]);
    setItemLines([]);
    setSelectedVendor(null);
    
    // Set default values
    form.setFieldsValue({
      billDate: moment(),
      dueDate: moment(),
      terms: '3', // Default to Net 30
      currencyValue: 'USD' // Default to USD
    });
  };

  const handleVendorChange = (value: number) => {
    const vendor = vendors.find(v => v.id === value);
    setSelectedVendor(vendor || null);
    
    if (vendor && vendor.billAddr) {
      form.setFieldsValue({
        mailingAddress: `${vendor.billAddr.line1 || ''}\n${vendor.billAddr.line2 || ''}\n${vendor.billAddr.city || ''}, ${vendor.billAddr.country || ''} ${vendor.billAddr.postalCode || ''}`
      });
    } else {
      form.setFieldsValue({ mailingAddress: '' });
    }
  };

  const handleAddCategoryLine = () => {
    const newKey = categoryLines.length > 0 ? Math.max(...categoryLines.map(item => item.key)) + 1 : 1;
    setCategoryLines([...categoryLines, { key: newKey, category: '', description: '', amount: 0, billable: false, taxable: false, customer: '' }]);
  };

  const handleRemoveCategoryLine = (key: number) => {
    if (categoryLines.length > 1) {
      setCategoryLines(categoryLines.filter(item => item.key !== key));
    }
  };

  const handleCategoryLineChange = (key: number, field: string, value: any) => {
    setCategoryLines(
      categoryLines.map(item => 
        item.key === key ? { ...item, [field]: value } : item
      )
    );
  };

  const handleAddItemLine = () => {
    const newKey = itemLines.length > 0 ? Math.max(...itemLines.map(item => item.key)) + 1 : 1;
    setItemLines([...itemLines, { key: newKey, product: '', description: '', qty: 1, rate: 0, amount: 0, billable: false, taxable: false, customer: '' }]);
  };

  const handleRemoveItemLine = (key: number) => {
    if (itemLines.length > 0) {
      setItemLines(itemLines.filter(item => item.key !== key));
    }
  };

  const handleItemLineChange = (key: number, field: string, value: any) => {
    setItemLines(
      itemLines.map(item => {
        if (item.key === key) {
          const updatedItem = { ...item, [field]: value };
          
          // If product changed, update description and rate
          if (field === 'product') {
            const product = products.find(p => p.value === value);
            if (product) {
              updatedItem.description = product.description || '';
              updatedItem.rate = product.price;
              updatedItem.amount = updatedItem.qty * product.price;
            }
          }
          
          // If qty or rate changed, update amount
          if (field === 'qty' || field === 'rate') {
            updatedItem.amount = updatedItem.qty * updatedItem.rate;
          }
          
          return updatedItem;
        }
        return item;
      })
    );
  };

  const calculateTotalAmount = () => {
    const categoryTotal = categoryLines.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    const itemTotal = itemLines.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    return (categoryTotal + itemTotal).toFixed(2);
  };

  // Validate line items before submission
  const validateLineItems = () => {
    // Validate at least one line item is present
    if (categoryLines.length === 0 && itemLines.length === 0) {
      message.error('At least one expense line is required');
      return false;
    }
    
    // Validate category lines
    for (let i = 0; i < categoryLines.length; i++) {
      const line = categoryLines[i];
      if (!line.category) {
        message.error(`Category is required for expense line ${i + 1}`);
        return false;
      }
      if (!(line.amount > 0)) {
        message.error(`Amount must be greater than zero for expense line ${i + 1}`);
        return false;
      }
      if (line.billable && !line.customer) {
        message.error(`Customer is required for billable expense line ${i + 1}`);
        return false;
      }
    }
    
    // Validate item lines
    for (let i = 0; i < itemLines.length; i++) {
      const line = itemLines[i];
      if (!line.product) {
        message.error(`Product/Service is required for item line ${i + 1}`);
        return false;
      }
      if (!(line.qty > 0)) {
        message.error(`Quantity must be greater than zero for item line ${i + 1}`);
        return false;
      }
      if (!(line.rate > 0)) {
        message.error(`Rate must be greater than zero for item line ${i + 1}`);
        return false;
      }
      if (line.billable && !line.customer) {
        message.error(`Customer is required for billable item line ${i + 1}`);
        return false;
      }
    }
    
    return true;
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      
      // Validate line items
      if (!validateLineItems()) {
        return;
      }
      
      setLoading(true);
      
      const auth = getAuthCredentials();
      if (!auth) return;
      
      // Format the line items to match the backend DTO
      const lineItems = [
        ...categoryLines.map(line => ({
          Description: line.description || '',
          DetailType: 'AccountBasedExpenseLineDetail',
          AccountId: line.category.toString(),
          Amount: parseFloat(line.amount) || 0,
          TaxCodeId: line.taxable ? 'TAX' : 'NON',
          CustomerId: line.customer ? line.customer.toString() : '',
          BillableStatus: line.billable ? 'Billable' : 'NotBillable',
          Quantity: 1,
          UnitPrice: 0,
          ItemId: ''
        })),
        ...itemLines.map(line => ({
          Description: line.description || '',
          DetailType: 'ItemBasedExpenseLineDetail',
          ItemId: line.product.toString(),
          UnitPrice: parseFloat(line.rate) || 0,
          Quantity: parseFloat(line.qty) || 0,
          Amount: parseFloat(line.amount) || 0,
          TaxCodeId: line.taxable ? 'TAX' : 'NON',
          CustomerId: line.customer ? line.customer.toString() : '',
          BillableStatus: line.billable ? 'Billable' : 'NotBillable',
          AccountId: ''
        }))
      ];
      
      // Format the bill data to match the backend DTO structure exactly as expected
      const billDto = {
        VendorId: values.vendorId.toString(),
        DocNumber: values.docNumber || `BILL-${Date.now()}`,
        TxnDate: values.billDate.format('YYYY-MM-DD'),
        DueDate: values.dueDate.format('YYYY-MM-DD'),
        MailingAddress: values.mailingAddress || '',
        Terms: values.terms || '3', // Default to Net 30
        PrivateNote: values.privateNote || '',
        APAccountId: values.apAccountId?.toString() || '', 
        CurrencyValue: values.currencyValue || 'USD',
        TotalAmt: parseFloat(calculateTotalAmount()),
        LineItems: lineItems
      };
      
      // If we're updating an existing bill, include the ID
      if (bill?.id) {
        billDto.Id = bill.id;
      }
      
      // Use 'Create' endpoint for new bills, 'Update' for existing ones
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/Bill/${bill ? 'Update' : 'Create'}`;
      const method = bill ? 'PUT' : 'POST';
      
      console.log('Sending bill DTO:', billDto);
      
      const response = await fetch(url, {
        method,
        headers: {
          'Authorization': `Bearer ${auth.token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(billDto) // Send the properly formatted billDto
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`Failed to ${bill ? 'update' : 'create'} bill: ${errorData}`);
      }
      
      message.success(`Bill ${bill ? 'updated' : 'created'} successfully`);
      onClose(true);
    } catch (error) {
      console.error(`Error ${bill ? 'updating' : 'creating'} bill:`, error);
      message.error(`Failed to ${bill ? 'update' : 'create'} bill: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  const categoryColumns = [
    {
      title: '#',
      dataIndex: 'key',
      key: 'key',
      width: 50,
      render: (text: string, record: any, index: number) => index + 1
    },
    {
      title: 'Category',
      dataIndex: 'category',
      key: 'category',
      render: (text: string, record: any) => (
        <Select
          placeholder="Select category"
          value={text || undefined}
          onChange={(value) => handleCategoryLineChange(record.key, 'category', value)}
          style={{ width: '100%' }}
          loading={loading}
        >
          {accounts.map(account => (
            <Option key={account.id} value={account.id}>
              {account.name}
            </Option>
          ))}
        </Select>
      )
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
      render: (text: string, record: any) => (
        <Input 
          placeholder="Description" 
          value={text} 
          onChange={(e) => handleCategoryLineChange(record.key, 'description', e.target.value)} 
        />
      )
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (text: string, record: any) => (
        <InputNumber
          min={0}
          style={{ width: '100%' }}
          value={text}
          onChange={(value) => handleCategoryLineChange(record.key, 'amount', value)}
          formatter={value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
          parser={value => value!.replace(/\$\s?|(,*)/g, '')}
        />
      )
    },
    {
      title: 'Billable',
      dataIndex: 'billable',
      key: 'billable',
      render: (checked: boolean, record: any) => (
        <input 
          type="checkbox" 
          checked={checked} 
          onChange={(e) => handleCategoryLineChange(record.key, 'billable', e.target.checked)} 
        />
      )
    },
    {
      title: 'Tax',
      dataIndex: 'taxable',
      key: 'taxable',
      render: (checked: boolean, record: any) => (
        <input 
          type="checkbox" 
          checked={checked} 
          onChange={(e) => handleCategoryLineChange(record.key, 'taxable', e.target.checked)} 
        />
      )
    },
    {
      title: 'Customer',
      dataIndex: 'customer',
      key: 'customer',
      render: (text: string, record: any) => (
        <Select
          placeholder="Select customer"
          allowClear
          value={text || undefined}
          onChange={(value) => handleCategoryLineChange(record.key, 'customer', value)}
          style={{ width: '100%' }}
          loading={loadingCustomers}
          showSearch
          optionFilterProp="children"
        >
          {customers.map(customer => (
            <Option key={customer.value} value={customer.value}>
              {customer.label}
            </Option>
          ))}
        </Select>
      )
    },
    {
      title: '',
      key: 'action',
      width: 50,
      render: (text: string, record: any) => (
        <Button 
          icon={<DeleteOutlined />} 
          onClick={() => handleRemoveCategoryLine(record.key)}
          type="text"
          danger
        />
      )
    }
  ];

  const itemColumns = [
    {
      title: '#',
      dataIndex: 'key',
      key: 'key',
      width: 50,
      render: (text: string, record: any, index: number) => index + 1
    },
    {
      title: 'Product/Service',
      dataIndex: 'product',
      key: 'product',
      render: (text: string, record: any) => (
        <Select
          placeholder="Select product"
          value={text || undefined}
          onChange={(value) => handleItemLineChange(record.key, 'product', value)}
          style={{ width: '100%' }}
          loading={loadingProducts}
          showSearch
          optionFilterProp="children"
        >
          {products.map(product => (
            <Option key={product.value} value={product.value}>{product.label}</Option>
          ))}
        </Select>
      )
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
      render: (text: string, record: any) => (
        <Input 
          placeholder="Description" 
          value={text} 
          onChange={(e) => handleItemLineChange(record.key, 'description', e.target.value)} 
        />
      )
    },
    {
      title: 'Qty',
      dataIndex: 'qty',
      key: 'qty',
      render: (text: string, record: any) => (
        <InputNumber
          min={0}
          style={{ width: '100%' }}
          value={text}
          onChange={(value) => handleItemLineChange(record.key, 'qty', value)}
        />
      )
    },
    {
      title: 'Rate',
      dataIndex: 'rate',
      key: 'rate',
      render: (text: string, record: any) => (
        <InputNumber
          min={0}
          style={{ width: '100%' }}
          value={text}
          onChange={(value) => handleItemLineChange(record.key, 'rate', value)}
          formatter={value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
          parser={value => value!.replace(/\$\s?|(,*)/g, '')}
        />
      )
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (text: number) => `$ ${text.toFixed(2)}`
    },
    {
      title: 'Billable',
      dataIndex: 'billable',
      key: 'billable',
      render: (checked: boolean, record: any) => (
        <input 
          type="checkbox" 
          checked={checked} 
          onChange={(e) => handleItemLineChange(record.key, 'billable', e.target.checked)} 
        />
      )
    },
    {
      title: 'Tax',
      dataIndex: 'taxable',
      key: 'taxable',
      render: (checked: boolean, record: any) => (
        <input 
          type="checkbox" 
          checked={checked} 
          onChange={(e) => handleItemLineChange(record.key, 'taxable', e.target.checked)} 
        />
      )
    },
    {
      title: 'Customer',
      dataIndex: 'customer',
      key: 'customer',
      render: (text: string, record: any) => (
        <Select
          placeholder="Select customer"
          allowClear
          value={text || undefined}
          onChange={(value) => handleItemLineChange(record.key, 'customer', value)}
          style={{ width: '100%' }}
          loading={loadingCustomers}
          showSearch
          optionFilterProp="children"
        >
          {customers.map(customer => (
            <Option key={customer.value} value={customer.value}>
              {customer.label}
            </Option>
          ))}
        </Select>
      )
    },
    {
      title: '',
      key: 'action',
      width: 50,
      render: (text: string, record: any) => (
        <Button 
          icon={<DeleteOutlined />} 
          onClick={() => handleRemoveItemLine(record.key)}
          type="text"
          danger
        />
      )
    }
  ];

  return (
    <Drawer
      title={bill ? "Edit Bill" : "Add Bill"}
      placement="top"
      closable={true}
      onClose={() => onClose()}
      visible={visible}
      width="100%"
      height="100%"
      extra={
        <Space>
          <Button onClick={() => onClose()}>Cancel</Button>
          <Button type="primary" onClick={handleSubmit} loading={loading}>
            Save
          </Button>
          <Button type="primary" style={{ backgroundColor: '#52c41a' }}>
            Save and schedule payment
          </Button>
        </Space>
      }
    >
      <Spin spinning={loading}>
        <Form
          form={form}
          layout="vertical"
        >
          <Row gutter={24}>
            <Col span={16}>
              <Row gutter={24}>
                <Col span={16}>
                  <Form.Item
                    name="vendorId"
                    label="Vendor"
                    rules={[{ required: true, message: 'Please select a vendor' }]}
                  >
                    <Select
                      placeholder="Choose a vendor"
                      onChange={handleVendorChange}
                      showSearch
                      optionFilterProp="children"
                    >
                      {vendors.map(vendor => (
                        <Option key={vendor.id} value={vendor.id}>
                          {vendor.displayName}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    name="apAccountId"
                    label="AP Account"
                    // rules={[{ required: true, message: 'Please select AP account' }]}
                  >
                    <Select
                      placeholder="Select AP account"
                      loading={loadingAccounts}
                    >
                      {apAccounts.map(account => (
                        <Option key={account.id} value={account.id}>
                          {account.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Col>
              </Row>
              
              <Row gutter={24}>
                <Col span={12}>
                  <Form.Item
                    name="mailingAddress"
                    label="Mailing address"
                    rules={[{ required: true, message: 'Please enter mailing address' }]}
                  >
                    <TextArea rows={4} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name="terms"
                    label="Terms"
                    rules={[{ required: true, message: 'Please select terms' }]}
                  >
                    <Select placeholder="Select terms">
                      <Option value="1">Net 10</Option>
                      <Option value="2">Net 15</Option>
                      <Option value="3">Net 30</Option>
                      <Option value="4">Net 60</Option>
                    
                      <Option value="5">Due on receipt</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name="billDate"
                    label="Bill date"
                    rules={[{ required: true, message: 'Please select bill date' }]}
                  >
                    <DatePicker style={{ width: '100%' }} format="MM/DD/YYYY" />
                  </Form.Item>
                </Col>
              </Row>
              
              <Row gutter={24}>
                <Col span={12}></Col>
                <Col span={6}>
                  <Form.Item
                    name="dueDate"
                    label="Due date"
                    rules={[{ required: true, message: 'Please select due date' }]}
                  >
                    <DatePicker style={{ width: '100%' }} format="MM/DD/YYYY" />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item
                    name="docNumber"
                    label="Bill no."
                  >
                    <Input placeholder="Bill number" />
                  </Form.Item>
                </Col>
              </Row>
              
              <Row gutter={24}>
                <Col span={24}>
                  <Form.Item
                    name="privateNote"
                    label="Notes"
                  >
                    <TextArea rows={3} placeholder="Enter any notes about this bill" />
                  </Form.Item>
                </Col>
              </Row>
            </Col>
            <Col span={8} style={{ textAlign: 'right' }}>
              <div className="balance-due">
                <Typography.Text style={{ display: 'block', marginBottom: '8px' }}>BALANCE DUE</Typography.Text>
                <Typography.Title level={2} style={{ margin: 0 }}>
                  ${calculateTotalAmount()}
                </Typography.Title>
              </div>
            </Col>
          </Row>
          
          <div style={{ marginTop: 20 }}>
            <Typography.Title level={5}>Category details</Typography.Title>
            <Table
              dataSource={categoryLines}
              columns={categoryColumns}
              pagination={false}
              rowKey="key"
              size="small"
              scroll={{ x: true }}
            />
            <Button
              type="dashed"
              onClick={handleAddCategoryLine}
              style={{ marginTop: 16, marginBottom: 24 }}
              icon={<PlusOutlined />}
            >
              Add lines
            </Button>
          </div>
          
          <div style={{ marginTop: 20 }}>
            <Typography.Title level={5}>Item details</Typography.Title>
            <Table
              dataSource={itemLines}
              columns={itemColumns}
              pagination={false}
              rowKey="key"
              size="small"
              scroll={{ x: true }}
            />
            <Button
              type="dashed"
              onClick={handleAddItemLine}
              style={{ marginTop: 16 }}
              icon={<PlusOutlined />}
            >
              Add lines
            </Button>
          </div>
        </Form>
      </Spin>
    </Drawer>
  );
};

export default BillDrawer;