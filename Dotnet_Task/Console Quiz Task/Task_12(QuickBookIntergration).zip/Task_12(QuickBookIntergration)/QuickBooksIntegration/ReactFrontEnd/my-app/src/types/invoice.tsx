// Define TypeScript interfaces for Invoice data models

export interface InvoiceLineItem {
    id?: number;
    lineId: string;
    invoiceId: number;
    productId: string;
    description: string;
    quantity: number;
    rate: number;
    amount: number;
  }
  
  export interface InvoiceDto {
    id: number;
    invoiceId: number;
    customerId: number;
    invoiceDate: string;
    dueDate: string;
    store: string;
    billingAddress: string;
    subtotal: number;
    total: number;
    sendLater: boolean;
    createdAt: string;
    updatedAt: string;
    lineItems: InvoiceLineItem[];
  }
  
  export interface InvoiceLineItemInputModel {
    productId: number;
    description: string;
    quantity: number;
    rate: number;
  }
  
  export interface InvoiceInputModel {
    customerId: number;
    customerEmail: string;
    invoiceDate: string;
    dueDate: string;
    store: string;
    billingAddress: string;
    sendLater: boolean;
    lineItems: InvoiceLineItemInputModel[];
  }
  
  export interface PagedResponse<T> {
    data: T[];
    page: number;
    pageSize: number;
    totalRecords: number;
    totalPages: number;
  }