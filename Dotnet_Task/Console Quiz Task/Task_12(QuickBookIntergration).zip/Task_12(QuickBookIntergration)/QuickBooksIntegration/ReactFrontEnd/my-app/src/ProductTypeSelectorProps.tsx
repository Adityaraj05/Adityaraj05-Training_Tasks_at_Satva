// import React from 'react';
// import { Modal, List, Avatar } from 'antd';
// import { TagOutlined, BoxPlotOutlined, ShoppingOutlined, AppstoreAddOutlined } from '@ant-design/icons';

// interface ProductTypeSelectorProps {
//   visible: boolean;
//   onClose: () => void;
//   onSelectType: (type: string) => void;
// }

// const ProductTypeSelector: React.FC<ProductTypeSelectorProps> = ({
//   visible,
//   onClose,
//   onSelectType
// }) => {
//   const productTypes = [
//     {
//       title: 'Inventory',
//       icon: <BoxPlotOutlined style={{ fontSize: 24, color: '#1890ff' }} />,
//       description: 'Products you buy and/or sell and that you track quantities of.',
//       value: 'Inventory'
//     },
//     {
//       title: 'Non-inventory',
//       icon: <ShoppingOutlined style={{ fontSize: 24, color: '#1890ff' }} />,
//       description: 'Products you buy and/or sell but don\'t need to (or can\'t) track quantities of.',
//       value: 'NonInventory'
//     },
//     {
//       title: 'Service',
//       icon: <TagOutlined style={{ fontSize: 24, color: '#1890ff' }} />,
//       description: 'Services that you provide to customers, for example, landscaping or tax preparation services.',
//       value: 'Service'
//     },
//     {
//       title: 'Bundle',
//       icon: <AppstoreAddOutlined style={{ fontSize: 24, color: '#1890ff' }} />,
//       description: 'A collection of products and/or services that you sell together.',
//       value: 'Bundle'
//     }
//   ];

//   const handleSelect = (type: string) => {
//     onSelectType(type);
//     onClose();
//   };

//   return (
//     <Modal
//       title="Select Product Type"
//       open={visible}
//       onCancel={onClose}
//       footer={null}
//       width={600}
//     >
//       <List
//         itemLayout="horizontal"
//         dataSource={productTypes}
//         renderItem={item => (
//           <List.Item 
//             onClick={() => handleSelect(item.value)}
//             style={{ cursor: 'pointer', padding: '12px', borderRadius: '8px' }}
//             className="hover:bg-gray-100"
//           >
//             <List.Item.Meta
//               avatar={<Avatar icon={item.icon} shape="circle" size={48} />}
//               title={<div style={{ fontSize: '16px', fontWeight: 'bold' }}>{item.title}</div>}
//               description={item.description}
//             />
//           </List.Item>
//         )}
//       />
//     </Modal>
//   );
// };

// export default ProductTypeSelector;