import React, { useEffect, useState } from 'react';
import { Button, Input, Table, message, Space, Popconfirm, Badge, Tooltip } from 'antd';
import { EditOutlined, PoweroffOutlined, PlusOutlined, SyncOutlined, CheckCircleOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import ProductDrawer from './ProductDrawer';

const { Search } = Input;

interface Product {
  id: number;
  name: string;
  type: string;
  syncToken: string;
  unitPrice: number;
  incomeAccountId: string | null;
  incomeAccountName: string | null;
  assetAccountId: string | null;
  assetAccountName: string | null;
  expenseAccountId: string | null;
  expenseAccountName: string | null;
  quantityOnHand: number | null;
  inventoryStartDate: string | null;
  taxable: boolean;
  active: boolean;
  quickBooksItemId: string;
  createdAt: string;
  updatedAt: string;
}

const Product: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0
  });
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    fetchProducts(1, pagination.pageSize, value); // Reset to first page when searching
  };

  const handleTableChange = (tablePagination: any) => {
    const { current, pageSize } = tablePagination;
    fetchProducts(current, pageSize, searchTerm);
  };

  // Fetch products from QuickBooks and store them in the database
  const fetchProductsFromQuickBooks = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/fetch-products-from-quickbooks`
      );

      const text = await res.text();
      let result;

      try {
        result = JSON.parse(text);
      } catch (e) {
        console.error("❌ Invalid QuickBooks response:", text);
        throw new Error('Failed to parse QuickBooks response: ' + text);
      }

      if (!res.ok) {
        console.error("❌ QuickBooks error:", result);
        throw new Error(result.message || 'Failed to fetch from QuickBooks');
      }

      message.success('Products downloaded from QuickBooks!');
      await fetchProducts(1, pagination.pageSize, searchTerm); // Refresh table from first page
    } catch (err) {
      message.error('Error fetching from QuickBooks');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetching the data from the database after fetching from QuickBooks and storing in the backend
  const fetchProducts = async (page = 1, pageSize = 10, search = searchTerm) => {
    setLoading(true);

    try {
      const queryParams = new URLSearchParams({
        pageNumber: page.toString(),
        pageSize: pageSize.toString(),
      });
      if (search) queryParams.append('search', search);

      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/get-all?${queryParams}`
      );

      const text = await res.text();
      
      let result;

      try {
        result = JSON.parse(text);
        console.log(result);
      } catch (e) {
        console.error("❌ Invalid JSON:", text);
        throw new Error('Failed to parse response: ' + text);
      }

      if (!res.ok) {
        console.error("❌ Error response:", result);
        throw new Error(result.message || 'Failed to fetch data');
      }

      console.log("✅ Product fetch successful:", result);
      
      setProducts(result.data || []);
      setPagination({
        current: page,
        pageSize: pageSize,
        total: result.totalCount || 0
      });
    } catch (err) {
      message.error('Error loading products');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = () => {
    setEditingProduct(null);
    setDrawerVisible(true);
  };

  const handleEditProduct = (product: Product) => {
    const mappedProduct = {
      ...product,
      initialQuantity: product.quantityOnHand,
      asOfDate: product.inventoryStartDate,
      reorderPoint: 0, // Adjust if you later add this field
    };
  
    setEditingProduct(mappedProduct);
    setDrawerVisible(true);
  };
  
  // This function now handles both local deactivation and QuickBooks sync
  const handleDeleteProduct = async (productId: number) => {
    setLoading(true);
    try {
      // First deactivate in local database
      const deactivateRes = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/deactivate/${productId}`,
        {
          method: 'PUT',
        }
      );
  
      if (!deactivateRes.ok) {
        const errorText = await deactivateRes.text();
        throw new Error(errorText || 'Failed to deactivate product locally');
      }
      
      // Get the product details to check if it needs QuickBooks sync
      const product = products.find(p => p.id === productId);
      
      // Update local state immediately to mark product as inactive
      setProducts(prevProducts => 
        prevProducts.map(p => p.id === productId ? { ...p, active: false } : p)
      );
      
      // If product exists in QuickBooks, sync the deactivation
      if (product && product.quickBooksItemId) {
        try {
          const syncRes = await fetch(
            `${import.meta.env.VITE_API_BASE_URL}/api/product/make-product-inactive/${product.quickBooksItemId}`,
            {
              method: 'PUT',
            }
          );
          
          if (!syncRes.ok) {
            const syncErrorText = await syncRes.text();
            console.error("QuickBooks sync error:", syncErrorText);
            message.warning("Product deactivated locally but failed to sync with QuickBooks.");
          } else {
            message.success('Product deactivated successfully and synced with QuickBooks.');
          }
        } catch (syncErr) {
          console.error("QuickBooks sync error:", syncErr);
          message.warning("Product deactivated locally but failed to sync with QuickBooks.");
        }
      } else {
        message.success('Product deactivated successfully.');
      }
      
    } catch (err: any) {
      if (err.message.includes("stock must be 0")) {
        message.warning("Cannot deactivate product: stock must be 0.");
      } else if (err.message.includes("not found")) {
        message.error("Product not found.");
      } else {
        message.error(err.message || "Failed to deactivate product.");
      }
      console.error('Deactivate Error:', err.message || err);
    } finally {
      setLoading(false);
    }
  };
  
  const handleSendToQuickBooks = async (productId: number) => {
    setLoading(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/product/send-to-quickbooks/${productId}`,
        {
          method: 'POST',
        }
      );
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || 'Failed to sync product with QuickBooks');
      }
      
      const result = await res.json();
      
      // Update the product in local state with QuickBooks info
      setProducts(prevProducts => 
        prevProducts.map(p => p.id === productId ? {
          ...p,
          quickBooksItemId: result.quickBooksItemId || p.quickBooksItemId,
          syncToken: result.syncToken || p.syncToken
        } : p)
      );
      
      message.success('Product successfully synced with QuickBooks!');
      return result;
    } catch (err: any) {
      message.error(err.message || 'Failed to sync with QuickBooks');
      console.error('QuickBooks Sync Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitProduct = async (values: any, syncToQuickBooks: boolean = false) => {
    setSubmitting(true);
    let localUpdateSuccess = false;
    let qbUpdateSuccess = true; // Start as true, set to false if QB update fails
    
    try {
      // First update locally
      const endpoint = values.id
        ? `${import.meta.env.VITE_API_BASE_URL}/api/product/update/${values.id}`
        : `${import.meta.env.VITE_API_BASE_URL}/api/product/create`;
      
      const method = values.id ? 'PUT' : 'POST';
      
      const res = await fetch(endpoint, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });
      
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || 'Failed to save product');
      }
      
      const savedProduct = await res.json();
      localUpdateSuccess = true;
      
      // Update local state immediately without refetching from server
      if (values.id) {
        // Update existing product in local state
        setProducts(prevProducts => 
          prevProducts.map(p => p.id === savedProduct.id ? savedProduct : p)
        );
      } else {
        // Add new product to local state
        setProducts(prevProducts => [...prevProducts, savedProduct]);
      }
      
      // Close drawer after successful save
      setDrawerVisible(false);
      
      // For new products, sync to QuickBooks if requested
      if (syncToQuickBooks && !values.quickBooksItemId) {
        try {
          const qbResult = await handleSendToQuickBooks(savedProduct.id || values.id);
          // Update the product again with QuickBooks data
          if (qbResult) {
            setProducts(prevProducts => 
              prevProducts.map(p => p.id === savedProduct.id ? {
                ...p,
                quickBooksItemId: qbResult.quickBooksItemId || p.quickBooksItemId,
                syncToken: qbResult.syncToken || p.syncToken
              } : p)
            );
          }
        } catch (syncError) {
          console.error('Error syncing product to QuickBooks:', syncError);
          qbUpdateSuccess = false;
        }
      } 
      // For existing products that are already in QuickBooks, update in QuickBooks too
      else if (values.id && values.quickBooksItemId) {
        try {
          const qbUpdateResult = await handleUpdateInQuickBooks(values.id);
          // Update the product with new sync token if available
          if (qbUpdateResult && qbUpdateResult.NewSyncToken) {
            setProducts(prevProducts => 
              prevProducts.map(p => p.id === values.id ? {
                ...p,
                syncToken: qbUpdateResult.NewSyncToken
              } : p)
            );
          }
        } catch (syncError) {
          console.error('Error updating product in QuickBooks:', syncError);
          qbUpdateSuccess = false;
        }
      }
      
      // Show appropriate message based on results
      if (localUpdateSuccess && qbUpdateSuccess) {
        message.success(`Product ${values.id ? 'updated' : 'created'} successfully in both local database and QuickBooks`);
      } else if (localUpdateSuccess) {
        message.warning(`Product was updated locally but failed to update in QuickBooks`);
      }
      
    } catch (err) {
      message.error(`Error ${values.id ? 'updating' : 'creating'} product`);
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

// Add this new function to handle updating in QuickBooks
const handleUpdateInQuickBooks = async (productId: number) => {
  try {
    const response = await fetch(
      `${import.meta.env.VITE_API_BASE_URL}/api/product/update-in-quickbooks/${productId}`,
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        }
      }
    );
    
    if (!response.ok) {
      const errorData = await response.text();
      console.error('QuickBooks update error:', errorData);
      
      // Provide more specific error messages based on status code
      if (response.status === 401) {
        message.error('QuickBooks authentication error. Please reconnect your QuickBooks account.');
      } else if (response.status === 400) {
        message.error(`QuickBooks error: ${errorData}`);
      } else {
        message.error(`Failed to update product in QuickBooks (${response.status})`);
      }
      
      throw new Error(errorData || 'Failed to update product in QuickBooks');
    }
    
    const result = await response.json();
    
    // Update product's sync token in local state if available
    if (result && result.NewSyncToken) {
      setProducts(prevProducts => 
        prevProducts.map(p => p.id === productId ? {
          ...p,
          syncToken: result.NewSyncToken
        } : p)
      );
    }
    
    message.success('Product updated successfully in QuickBooks');
    return result;
  } catch (error) {
    console.error('Error updating in QuickBooks:', error);
    throw error;
  }
};

  // Initial load
  useEffect(() => {
    fetchProducts(1, pagination.pageSize, searchTerm);
  }, []);  // Empty dependency array to only run on mount

  const columns: ColumnsType<Product> = [
    { 
      title: 'Name', 
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
      width: 180,
    },
    { 
      title: 'Type', 
      dataIndex: 'type',
      key: 'type',
      width: 100,
    },
    { 
      title: 'Unit Price', 
      dataIndex: 'unitPrice',
      key: 'unitPrice',
      width: 100,
      render: (value) => `$${value.toFixed(2)}`
    },
    { 
      title: 'Income Account', 
      dataIndex: 'incomeAccountName',
      key: 'incomeAccountName',
      ellipsis: true,
      width: 160,
    },
    {
      title: 'QuickBooks Sync',
      key: 'quickBooksSync',
      width: 100,
      render: (_, record) => (
        record.quickBooksItemId ? (
          <Tooltip title="Synced with QuickBooks">
            <Badge status="success" text={<CheckCircleOutlined style={{ color: 'green' }} />} />
          </Tooltip>
        ) : (
          <Tooltip title="Sync to QuickBooks">
            <Button 
              icon={<SyncOutlined />}
              onClick={() => handleSendToQuickBooks(record.id)}
              size="small"
              type="link"
            />
          </Tooltip>
        )
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      fixed: 'right',
      width: 120,
      render: (_, record) => (
        <Space>
          <Button 
            icon={<EditOutlined />} 
            onClick={() => handleEditProduct(record)}
            size="large"
          />
          <Popconfirm
  title="Are you sure you want to deactivate this product?"
  onConfirm={() => handleDeleteProduct(record.id)}
  okText="Yes"
  cancelText="No"
>
  <Button 
    icon={<PoweroffOutlined />} 
    danger 
    size="large"
  />
</Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div style={{ 
      padding: 20, 
      display: 'flex', 
      flexDirection: 'column', 
      height: 'calc(100vh - 64px)' // Adjust this value based on your layout header size
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Space>
          <Search
            placeholder="Search by name"
            onSearch={handleSearch}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            enterButton
            allowClear
            style={{ width: 300 }}
          />
          <Button type="primary" icon={<PlusOutlined />} onClick={handleAddProduct}>
            Add Product
          </Button>
        </Space>

        <Button 
          type="primary" 
          onClick={fetchProductsFromQuickBooks} 
          loading={loading}
          icon={<SyncOutlined />}
        >
          Download from QuickBooks
        </Button>
      </div>

      <div style={{ 
        flex: 1, 
        overflow: 'auto', 
        position: 'relative',
        display: 'flex',
        flexDirection: 'column'
      }}>
        <Table
          dataSource={products}
          columns={columns}
          rowKey="id"
          bordered
          loading={loading}
          scroll={{ x: 'max-content' }}
          pagination={{
            current: pagination.current,
            pageSize: pagination.pageSize,
            total: pagination.total,
            showSizeChanger: true,
            pageSizeOptions: ['10', '20', '50', '100'],
            showTotal: (total) => `Total ${total} items`,
            position: ['bottomRight'],
          }}
          onChange={handleTableChange}
          className="products-table"
          sticky={{ offsetHeader: 0 }}
        />
      </div>
      
      <ProductDrawer
        visible={drawerVisible}
        onClose={() => setDrawerVisible(false)}
        onSubmit={handleSubmitProduct}
        editingProduct={editingProduct}
        loading={submitting}
      />
    </div>
  );
};

export default Product;