import api from './authService';

// Function to make authenticated API calls to QuickBooks
export const callQuickBooksApi = async <T>(
  endpoint: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
  data?: any
): Promise<T | null> => {
  try {
    const config = {
      method,
      url: endpoint,
      data: method !== 'GET' ? data : undefined,
      params: method === 'GET' ? data : undefined
    };

    // Use the authenticated axios instance which handles token refreshing automatically
    const response = await api(config);
    return response.data as T;
  } catch (error: any) {
    console.error('API call error:', error.message);
    return null;
  }
};