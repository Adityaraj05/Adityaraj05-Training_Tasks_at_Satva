import React, { useEffect, useState } from 'react';
import { Table, message, Spin, Card, Button, Empty } from 'antd';
import SearchBar from './SearchBar';
import { DownloadOutlined,ReloadOutlined } from '@ant-design/icons';
import './ChartOfAccount.css';
interface AccountData {
    id: string;
    name: string;
    accountType: string;
    accountSubType: string;
    currentBalance: number;
    classification: string;
    active: boolean;
    currencyRef?: {
        value: string;
        name?: string;
    };
}

const ChartOfAccounts = () => {
    const [pagedData, setPagedData] = useState<AccountData[]>([]);
    const [loading, setLoading] = useState(false);
    const [isDataFetched, setIsDataFetched] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0
    });

    const checkDataInDatabase = async (page = 1, pageSize = 10, search = searchTerm) => {
        setLoading(true);
        console.log("➡️ Fetching DB data", { page, pageSize, search });

        try {
            const res = await fetch(
                `${import.meta.env.VITE_API_BASE_URL}/api/quickbooks/fetch-from-db-paginated?page=${page}&pageSize=${pageSize}&searchTerm=${encodeURIComponent(search)}`
            );

            const text = await res.text();
            let result;

            try {
                result = JSON.parse(text);
            } catch (e) {
                console.error("❌ Invalid JSON:", text);
                throw new Error(text);
            }

            if (!res.ok) {
                console.error("❌ Error response:", result);
                throw new Error(result.message || 'Failed to fetch data');
            }

            console.log("✅ DB fetch successful:", result);

            setPagedData(result.data);
            setPagination({
                current: result.currentPage,
                pageSize: result.pageSize,
                total: result.totalRecords,
            });
            setIsDataFetched(true);
        } catch (err) {
            message.error('Failed to fetch chart of accounts.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const fetchAccountsFromQuickBooks = async () => {
        setLoading(true);
        console.log("➡️ Fetching from QuickBooks...");

        try {
            const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/quickbooks/fetch-from-quickbooks`, {
                method: 'GET',
            });

            const result = await res.json();

            if (!res.ok) throw new Error(result);

            if (result && result.length > 0) {
                setPagedData(result);
                setIsDataFetched(true);
                message.success('Chart of accounts loaded successfully from QuickBooks.');
            } else {
                message.warning('No chart of accounts data found in QuickBooks.');
            }
        } catch (err) {
            message.error('Failed to fetch chart of accounts from QuickBooks.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        console.log("🔍 Searching:", value);
        setSearchTerm(value);
        checkDataInDatabase(1, pagination.pageSize, value);
    };

    const handleTableChange = (paginationInfo: any) => {
        console.log("📃 Table pagination change:", paginationInfo);
        const { current, pageSize } = paginationInfo;

        setPagination(prev => ({
            ...prev,
            current,
            pageSize
        }));

        checkDataInDatabase(current, pageSize, searchTerm);
    };

    useEffect(() => {
        checkDataInDatabase();
    }, []);

    const handleDownload = () => {
        console.log("⬇️ Downloading from QuickBooks...");
        setIsDataFetched(false);
        fetchAccountsFromQuickBooks();
    };

    const columns = [
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
            sorter: (a: AccountData, b: AccountData) => a.name.localeCompare(b.name),
        },
        {
            title: 'Account Type',
            dataIndex: 'accountType',
            key: 'accountType',
            filters: Array.from(new Set(pagedData.map(item => item.accountType)))
                .filter(Boolean)
                .map(type => ({ text: type, value: type })),
            onFilter: (value, record: AccountData) => record.accountType === String(value),
        },
        {
            title: 'Detail Type',
            dataIndex: 'accountSubType',
            key: 'accountSubType',
        },
        {
            title: 'Classification',
            dataIndex: 'classification',
            key: 'classification',
        },
        {
            title: 'QuickBooks Balance',
            dataIndex: 'currentBalance',
            key: 'balance',
            render: (value: number) => {
                if (value === undefined || value === null) return '-';
                const isNegative = value < 0;
                const absValue = Math.abs(value);
                return isNegative
                    ? `-$${absValue.toFixed(2)}`
                    : `$${value.toFixed(2)}`;
            },
            sorter: (a: AccountData, b: AccountData) => a.currentBalance - b.currentBalance,
        }
    ];

    return (
        <div className="chart-accounts-container">
            <div className="chart-accounts-header">
                <div className="chart-accounts-title">Chart of Accounts</div>
                <div className="chart-accounts-actions">
                    <SearchBar onSearch={handleSearch} searchTerm={searchTerm} />
                    <Button
                        type="primary"
                        onClick={handleDownload}
                        icon={<ReloadOutlined />}
                    >
                        Refresh
                    </Button>
                </div>
            </div>

            <div className="scrollable-table-container">
                {loading ? (
                    <div className="loading-container">
                        <Spin size="large" />
                        <p>Loading Accounts...</p>
                    </div>
                ) : pagedData.length > 0 ? (
                    <Table
                        dataSource={pagedData}
                        columns={columns}
                        rowKey="id"
                        pagination={{
                            current: pagination.current,
                            pageSize: pagination.pageSize,
                            total: pagination.total,
                            showSizeChanger: true,
                        }}
                        onChange={handleTableChange}
                        scroll={{ x: 'max-content' }}
                        bordered
                        className="accounts-table"
                    />
                ) : (
                    <div className="empty-data-container">
                        <Empty
                            description='No data available. Click "Download" to load chart of accounts.'
                            image={Empty.PRESENTED_IMAGE_SIMPLE}
                        />
                        <Button
                            type="primary"
                            onClick={handleDownload}
                            icon={<DownloadOutlined />}
                            className="empty-download-button"
                        >
                            Download
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ChartOfAccounts;
