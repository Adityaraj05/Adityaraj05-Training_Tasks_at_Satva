import React, { useEffect, useState, useRef } from 'react';
import { Table, Button, Input, Space, Popconfirm, message, Drawer, Pagination, Spin, Empty } from 'antd';
import { SearchOutlined, ReloadOutlined, PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { InvoiceDto, InvoiceInputModel } from './types/invoice';
import InvoiceDrawer from './InvoiceDrawer';
import dayjs from 'dayjs';

const Invoice: React.FC = () => {
  // State hooks
  const [invoices, setInvoices] = useState<InvoiceDto[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchText, setSearchText] = useState<string>('');
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0
  });
  const [drawerVisible, setDrawerVisible] = useState<boolean>(false);
  const [editingInvoice, setEditingInvoice] = useState<InvoiceDto | null>(null);
  const [sortField, setSortField] = useState<string>('CreatedAt');
  const [sortDirection, setSortDirection] = useState<string>('desc');
  const searchTimeout = useRef<NodeJS.Timeout | null>(null);

  // Fetch invoices from backend
 
  const fetchInvoices = async (
    page: number = pagination.current,
    pageSize: number = pagination.pageSize,
    search: string = searchText,
    sortBy: string = sortField,
    sortDir: string = sortDirection
  ) => {
    setLoading(true);
    try {
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!realmId) {
        message.error('QuickBooks RealmID is required');
        return;
      }
      
      const url = `${import.meta.env.VITE_API_BASE_URL}/api/invoice?page=${page}&pageSize=${pageSize}&search=${search}&sortBy=${sortBy}&sortDirection=${sortDir}&realmId=${realmId}`;
      const res = await fetch(url);
      
      if (!res.ok) {
        const errorData = await res.json();
        console.error('Error response:', errorData);
        throw new Error(errorData.title || `HTTP error! status: ${res.status}`);
      }
      
      const data = await res.json();
      setInvoices(data.data);
      setPagination({
        ...pagination,
        current: data.page,
        pageSize: data.pageSize,
        total: data.totalRecords
      });
    } catch (error) {
      console.error('Error fetching invoices:', error);
      message.error('Failed to load invoices');
    } finally {
      setLoading(false);
    }
  };
  // Sync invoices from QuickBooks
  const syncInvoicesFromQuickBooks = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('qb_access_token');
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!token || !realmId) {
        message.error('QuickBooks authentication required');
        return;
      }
  
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/invoice/fetch?realmId=${realmId}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,  // Using proper Authorization header format
          }
        }
      );
  
      if (!res.ok) {
        const errorData = await res.json();
        console.error('Error response:', errorData);
        throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
      }
  
      const data = await res.json();
      message.success(`${data.invoicesAdded} invoices added, ${data.invoicesUpdated} invoices updated!`);
      
      // Refresh the list
      fetchInvoices();
    } catch (error) {
      console.error('Error syncing invoices from QuickBooks:', error);
      message.error(`Failed to sync invoices from QuickBooks: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Delete invoice
  const deleteInvoice = async (invoiceId: number) => {
    try {
      const token = localStorage.getItem('qb_access_token');
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!token || !realmId) {
        message.error('QuickBooks authentication required');
        return;
      }
  
      const res = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/invoice/${invoiceId}?realmId=${realmId}`,
        {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`  // Using proper Authorization header format
          }
        }
      );
  
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
      }
  
      message.success('Invoice deleted successfully');
      fetchInvoices();
    } catch (error) {
      console.error('Error deleting invoice:', error);
      message.error('Failed to delete invoice');
    }
  };

  // Handle search input change with debounce
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchText(value);
    
    if (searchTimeout.current) {
      clearTimeout(searchTimeout.current);
    }
    
    searchTimeout.current = setTimeout(() => {
      fetchInvoices(1, pagination.pageSize, value, sortField, sortDirection);
    }, 500);
  };

  // Handle table sorting
  const handleTableChange = (paginationInfo: any, filters: any, sorter: any) => {
    const { current, pageSize } = paginationInfo;
    
    let sortBy = 'CreatedAt';
    let sortDir = 'desc';
    
    if (sorter.field) {
      sortBy = sorter.field;
      sortDir = sorter.order === 'ascend' ? 'asc' : 'desc';
    }
    
    setSortField(sortBy);
    setSortDirection(sortDir);
    
    setPagination(prev => ({
      ...prev,
      current,
      pageSize
    }));
    
    fetchInvoices(current, pageSize, searchText, sortBy, sortDir);
  };

  // Open drawer for creating new invoice
  const openCreateDrawer = () => {
    setEditingInvoice(null);
    setDrawerVisible(true);
  };

  // Open drawer for editing invoice
  const openEditDrawer = (invoice: InvoiceDto) => {
    setEditingInvoice(invoice);
    setDrawerVisible(true);
  };

  // Handle drawer close
  const handleDrawerClose = () => {
    setDrawerVisible(false);
    setEditingInvoice(null);
  };
// Fetch customers from QuickBooks
const fetchCustomersFromQuickBooks = async () => {
  setLoading(true);
  try {
    const token = localStorage.getItem('qb_access_token');
    const realmId = localStorage.getItem('qb_realm_id');
    
    if (!token || !realmId) {
      message.error('QuickBooks authentication required');
      return;
    }

    const res = await fetch(
      `${import.meta.env.VITE_API_BASE_URL}/api/customer/fetch-customers-from-quickbooks?realmId=${realmId}`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`  // Using proper Authorization header format
        }
      }
    );

    if (!res.ok) {
      const errorData = await res.json();
      console.error('Error response:', errorData);
      throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
    }

    const data = await res.json();
    message.success(`${data.customersAdded || 0} customers added, ${data.customersUpdated || 0} customers updated!`);
    
  } catch (error) {
    console.error('Error syncing customers from QuickBooks:', error);
    message.error(`Failed to sync customers from QuickBooks: ${error.message}`);
  } finally {
    setLoading(false);
  }
};


  // Handle invoice form submission (create/update)
  const handleFormSubmit = async (values: InvoiceInputModel) => {
    try {
      const token = localStorage.getItem('qb_access_token');
      const realmId = localStorage.getItem('qb_realm_id');
      
      if (!token || !realmId) {
        message.error('QuickBooks authentication required');
        return;
      }
  
      const method = editingInvoice ? 'PUT' : 'POST';
      const url = editingInvoice 
        ? `${import.meta.env.VITE_API_BASE_URL}/api/invoice/${editingInvoice.invoiceId}?realmId=${realmId}`
        : `${import.meta.env.VITE_API_BASE_URL}/api/invoice?realmId=${realmId}`;
  
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`  // Using proper Authorization header format
        },
        body: JSON.stringify(values)
      });
  
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || `HTTP error! status: ${res.status}`);
      }
  
      message.success(editingInvoice ? 'Invoice updated successfully' : 'Invoice created successfully');
      handleDrawerClose();
      fetchInvoices();
    } catch (error) {
      console.error('Error saving invoice:', error);
      message.error(`Failed to save invoice: ${error.message}`);
    }
  };
  

  // Initial fetch on component mount
  useEffect(() => {
    fetchInvoices();
  }, []);


  const columns = [
    {
      title: 'Invoice #',
      dataIndex: 'invoiceId',
      key: 'invoiceId',
      sorter: true,
    },
    {
      title: 'Due Date',
      dataIndex: 'dueDate',
      key: 'dueDate',
      render: (text: string) => dayjs(text).format('MM/DD/YYYY'),
      sorter: true,
    },
    {
      title: 'Store',
      dataIndex: 'store',
      key: 'store',
    },
    {
      title: 'Billing Address',
      dataIndex: 'billingAddress',
      key: 'billingAddress',
      render: (text: string) => text || 'N/A',
    },
    
    {
      title: 'Total',
      dataIndex: 'total',
      key: 'total',
      render: (text: number) => `$${text.toFixed(2)}`,
      sorter: true,
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: InvoiceDto) => (
        <Space size="middle">
          <Button 
            icon={<EditOutlined />} 
            type="primary" 
            size="small" 
            onClick={() => openEditDrawer(record)}
          />
          <Popconfirm
            title="Are you sure you want to delete this invoice?"
            onConfirm={() => deleteInvoice(record.invoiceId)}
            okText="Yes"
            cancelText="No"
          >
            <Button icon={<DeleteOutlined />} type="primary" danger size="small" />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div className="invoice-container" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="invoice-header" style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between' }}>
      <div className="invoice-title " style={{ fontWeight: 'bold', marginLeft: '20px', fontSize: '24px' }}>Invoices</div>
        <div className="invoice-actions" style={{ display: 'flex' }}>
          <Input
            placeholder="Search invoices"
            value={searchText}
            onChange={handleSearchChange}
            prefix={<SearchOutlined />}
            style={{ width: 250, marginRight: 16 }}
          />
          <Button 
            type="primary" 
            icon={<ReloadOutlined />} 
            onClick={() => syncInvoicesFromQuickBooks()}
            className="action-button"
            loading={loading}
            style={{ marginRight: 8 }}
          >
            Refresh from QuickBooks
          </Button>
          <Button 
            type="primary" 
            icon={<PlusOutlined />} 
            onClick={openCreateDrawer}
            className="action-button"
          >
            Create Invoice
          </Button>
        </div>
      </div>

      <div className="content-container" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {loading ? (
          <div className="loading-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1 }}>
            <Spin size="large" />
            <p>Loading Invoices...</p>
          </div>
        ) : invoices.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            <div className="table-container" style={{ flex: 1, overflow: 'auto' }}>
              <Table
                columns={columns}
                dataSource={invoices}
                rowKey="invoiceId"
                pagination={false} // Disable table's built-in pagination
                onChange={handleTableChange}
                scroll={{ x: 'max-content' }}
                bordered
                className="invoices-table"
                expandable={{
                  expandedRowRender: (record: InvoiceDto) => (
                    <div style={{ margin: 0 }}>
                      <h4>Line Items:</h4>
                      <Table
                        columns={[
                          { title: 'Product ID', dataIndex: 'productId', key: 'productId' },
                          { title: 'Description', dataIndex: 'description', key: 'description' },
                          { title: 'Quantity', dataIndex: 'quantity', key: 'quantity' },
                          { title: 'Rate', dataIndex: 'rate', key: 'rate', render: (rate: number) => `$${rate.toFixed(2)}` },
                          { title: 'Amount', dataIndex: 'amount', key: 'amount', render: (amount: number) => `$${amount.toFixed(2)}` },
                        ]}
                        dataSource={record.lineItems}
                        pagination={false}
                        rowKey="lineId"
                      />
                    </div>
                  ),
                }}
              />
            </div>
            <div className="pagination-container" style={{ padding: '16px 0', backgroundColor: '#fff', display: 'flex',
    justifyContent: 'flex-end', borderTop: '1px solid #f0f0f0' }}>
              <Pagination
                current={pagination.current}
                pageSize={pagination.pageSize}
                total={pagination.total}
                onChange={(page, pageSize) => fetchInvoices(page, pageSize)}
                showSizeChanger
                showTotal={(total) => `Total ${total} items`}
                style={{ textAlign: 'right' }}
              />
            </div>
          </div>
        ) : (
          <div className="empty-data-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1 }}>
            <Empty
              description='No invoice data available. Click "Refresh from QuickBooks" to load invoices.'
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
            <Button
              type="primary"
              onClick={() => syncInvoicesFromQuickBooks()}
              icon={<ReloadOutlined />}
              className="empty-download-button"
              style={{ marginTop: 16 }}
            >
              Refresh from QuickBooks
            </Button>
          </div>
        )}
      </div>

      <InvoiceDrawer
        visible={drawerVisible}
        onClose={handleDrawerClose}
        onSubmit={handleFormSubmit}
        invoice={editingInvoice}
      />
    </div>
  );
};

export default Invoice;