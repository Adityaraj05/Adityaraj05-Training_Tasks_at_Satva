import React, { useState, useEffect } from 'react';
import {
  Drawer, Form, Input, Button, Select,
  DatePicker, InputNumber, message, Space,
  Switch, Divider, Spin, Checkbox
} from 'antd';
import dayjs from 'dayjs';

const { Option } = Select;

interface ProductDrawerProps {
  visible: boolean;
  onClose: () => void;
  onSubmit: (values: any, syncToQuickBooks: boolean) => Promise<void>;
  editingProduct: any | null;
  loading: boolean;
}

const ProductDrawer: React.FC<ProductDrawerProps> = ({
  visible,
  onClose,
  onSubmit,
  editingProduct,
  loading
}) => {
  const [form] = Form.useForm();
  const [productType, setProductType] = useState<string>('Inventory');
  const [isQuickBooksProduct, setIsQuickBooksProduct] = useState<boolean>(false);
  const [incomeAccounts, setIncomeAccounts] = useState([]);
  const [expenseAccounts, setExpenseAccounts] = useState([]);
  const [assetAccounts, setAssetAccounts] = useState([]);
  const [loadingAccounts, setLoadingAccounts] = useState(false);
  const [syncToQuickBooks, setSyncToQuickBooks] = useState<boolean>(true);

  useEffect(() => {
    if (visible) {
      if (editingProduct) {
        form.setFieldsValue({
          ...editingProduct,
          Type: editingProduct.type,
          Name: editingProduct.name,
          UnitPrice: editingProduct.unitPrice,
          QuantityOnHand: editingProduct.quantityOnHand,
          IncomeAccountId: editingProduct.incomeAccountId,
          ExpenseAccountId: editingProduct.expenseAccountId,
          AssetAccountId: editingProduct.assetAccountId,
          Taxable: editingProduct.taxable,
       
          inventoryStartDate: editingProduct.inventoryStartDate
            ? dayjs(editingProduct.inventoryStartDate)
            : null,
        });
        setProductType(editingProduct.type || 'Inventory');
        setIsQuickBooksProduct(!!editingProduct.quickBooksItemId);
        // If product is already in QuickBooks, no need to sync
        setSyncToQuickBooks(!editingProduct.quickBooksItemId);
      } else {
        form.resetFields();
        setProductType('Inventory');
        setIsQuickBooksProduct(false);
        setSyncToQuickBooks(true);
      }

      // Fetch account data when drawer opens
      fetchAccounts();
    }
  }, [editingProduct, visible]);

  const fetchAccounts = async () => {
    setLoadingAccounts(true);
    try {
      // Fetch income accounts
      const incomeResponse = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/account/get-accounts?accountType=Income`
      );
      if (incomeResponse.ok) {
        const incomeData = await incomeResponse.json();
        setIncomeAccounts(incomeData.data || []);
      }

      // Fetch expense accounts
      const expenseResponse = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/account/get-accounts?accountType=Expense`
      );
      if (expenseResponse.ok) {
        const expenseData = await expenseResponse.json();
        setExpenseAccounts(expenseData.data || []);
      }

      // Fetch asset accounts
      const assetResponse = await fetch(
        `${import.meta.env.VITE_API_BASE_URL}/api/account/get-accounts?accountType=Asset`
      );
      if (assetResponse.ok) {
        const assetData = await assetResponse.json();
        setAssetAccounts(assetData.data || []);
      }
    } catch (error) {
      console.error('Error fetching accounts:', error);
      message.error('Failed to load QuickBooks accounts');
    } finally {
      setLoadingAccounts(false);
    }
  };

  const handleTypeChange = (value: string) => {
    setProductType(value);
    
    // Reset inventory-specific fields when changing to Service
    if (value === 'Service') {
      form.setFieldsValue({
        QuantityOnHand: null,
        inventoryStartDate: null,
        AssetAccountId: null,
        ExpenseAccountId: null
      });
    }
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
  
      // Convert date to ISO string if present
      if (values.inventoryStartDate) {
        values.InventoryStartDate = values.inventoryStartDate.toISOString();
        delete values.inventoryStartDate;
      }
  
      // Get selected income account name if available
      let incomeAccountName = null;
      if (values.IncomeAccountId) {
        const selectedAccount = incomeAccounts.find((acc: any) => acc.id === values.IncomeAccountId);
        incomeAccountName = selectedAccount?.name || null;
      }
  
      // Prepare data for API submission
      const submitData = {
        ...values,
        id: editingProduct?.id || 0,
        quickBooksItemId: editingProduct?.quickBooksItemId || "", // Add empty string instead of null
        syncToken: editingProduct?.syncToken || "0",
        incomeAccountName: editingProduct?.incomeAccountName || incomeAccountName || "", // Add income account name
      };
  
      await onSubmit(submitData, syncToQuickBooks);
      onClose();
    } catch (error) {
      console.error('Validation failed:', error);
    }
  };

  return (
    <Drawer
      title={editingProduct ? 'Edit Product' : 'Add Product'}
      width={520}
      onClose={onClose}
      open={visible}
      bodyStyle={{ paddingBottom: 80 }}
      footer={
        <Space>
          <Button onClick={onClose}>Cancel</Button>
          <Button type="primary" loading={loading} onClick={handleSubmit}>
            {editingProduct ? 'Update' : 'Save'}
          </Button>
        </Space>
      }
    >
      {loadingAccounts ? (
        <div style={{ textAlign: 'center', padding: '30px 0' }}>
          <Spin tip="Loading accounts from QuickBooks..." />
        </div>
      ) : (
        <Form
          form={form}
          layout="vertical"
          initialValues={{
            Type: 'Inventory',
            Active: true,
            Taxable: true,
          }}
        >
          <Form.Item
            name="Type"
            label="Product Type"
            rules={[{ required: true, message: 'Please select a product type' }]}
          >
            <Select onChange={handleTypeChange} disabled={isQuickBooksProduct}>
              <Option value="Inventory">Inventory</Option>
              <Option value="Service">Service</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="Name"
            label="Product Name"
            rules={[{ required: true, message: 'Please enter the product name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            name="UnitPrice"
            label="Unit Price"
            rules={[{ required: true, message: 'Please enter the unit price' }]}
          >
            <InputNumber
              style={{ width: '100%' }}
              formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
              parser={(value) => value!.replace(/\$\s?|(,*)/g, '')}
              min={0}
            />
          </Form.Item>

          <Form.Item
            name="IncomeAccountId"
            label="Income Account"
            rules={[{ required: true, message: 'Please select an income account' }]}
          >
            <Select placeholder="Select income account">
              {incomeAccounts.map((account: any) => (
                <Option key={account.id} value={account.id}>
                  {account.name}
                </Option>
              ))}
            </Select>
          </Form.Item>

          {productType === 'Inventory' && (
            <>
              <Divider>Inventory Settings</Divider>
              
              <Form.Item
                name="QuantityOnHand"
                label="Initial Quantity on Hand"
                rules={[{ required: true, message: 'Please enter initial quantity' }]}
              >
                <InputNumber style={{ width: '100%' }} min={0} />
              </Form.Item>

              <Form.Item
                name="inventoryStartDate"
                label="Inventory Start Date"
                rules={[{ required: true, message: 'Please select a start date' }]}
              >
                <DatePicker style={{ width: '100%' }} format="MM/DD/YYYY" />
              </Form.Item>

              <Form.Item
                name="AssetAccountId"
                label="Inventory Asset Account"
                rules={[{ message: '' }]}
              >
                <Select disabled={isQuickBooksProduct} placeholder="Select asset account">
                  {assetAccounts.map((account: any) => (
                    <Option key={account.id} value={account.id}>
                      {account.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item
                name="ExpenseAccountId"
                label="Expense Account"
                rules={[{  message: 'Please select an expense account' }]}
              >
                <Select  placeholder="Select expense account">
                  {expenseAccounts.map((account: any) => (
                    <Option key={account.id} value={account.id}>
                      {account.name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </>
          )}

          <Divider>Options</Divider>

          <Form.Item
            name="Taxable"
            label="Taxable"
            valuePropName="checked"
          >
            <Switch />
          </Form.Item>

        
          {!isQuickBooksProduct && (
            <Form.Item>
              <Checkbox 
                checked={syncToQuickBooks} 
                onChange={(e) => setSyncToQuickBooks(e.target.checked)}
              >
                Sync to QuickBooks after saving
              </Checkbox>
            </Form.Item>
          )}
        </Form>
      )}
    </Drawer>
  );
};

export default ProductDrawer;