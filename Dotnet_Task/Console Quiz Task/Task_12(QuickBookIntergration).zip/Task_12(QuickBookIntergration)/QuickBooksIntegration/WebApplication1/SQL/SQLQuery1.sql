create database QuickBookDB
use QuickBook

CREATE TABLE QuickBooksTokens (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksUserId NVARCHAR(255) NOT NULL,
    RealmId NVARCHAR(50) NOT NULL,
    AccessToken NVARCHAR(MAX) NOT NULL,
    RefreshToken NVARCHAR(MAX) NOT NULL,
    IdToken NVARCHAR(MAX) NULL,
    TokenType NVARCHAR(20) NOT NULL,
    ExpiresIn INT NOT NULL,
    XRefreshTokenExpiresIn INT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    UpdatedAt DATETIME NULL
);

CREATE TABLE ChartOfAccounts (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksAccountId NVARCHAR(MAX) NOT NULL,
    Name NVARCHAR(MAX) NOT NULL,
    AccountType NVARCHAR(MAX) NOT NULL,
    AccountSubType NVARCHAR(MAX) NOT NULL,
    CurrentBalance DECIMAL(18, 2) NULL,
    CurrencyValue NVARCHAR(MAX) NOT NULL,
    CurrencyName NVARCHAR(MAX) NOT NULL,
    Classification NVARCHAR(MAX) NOT NULL,
    CreatedAt DATETIME2 NOT NULL,
    QuickBooksUserId NVARCHAR(MAX) NOT NULL
);

select @@SERVERNAME



ALTER TABLE ChartOfAccounts
ALTER COLUMN CurrencyValue NVARCHAR(MAX) NULL;

ALTER TABLE ChartOfAccounts
ALTER COLUMN CurrencyName NVARCHAR(MAX) NULL;

truncate table  ChartOfAccounts
truncate table  QuickBooksTokens
truncate table Customers

CREATE TABLE Customers (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksCustomerId VARCHAR(20),
    QuickBooksUserId VARCHAR(50), -- link to token table if needed
    DisplayName NVARCHAR(150),
    CompanyName NVARCHAR(150),
    GivenName NVARCHAR(50),
    MiddleName NVARCHAR(50),
    FamilyName NVARCHAR(50),
    Email NVARCHAR(100),
    Phone NVARCHAR(30),
    
    BillingLine1 NVARCHAR(200),
    BillingCity NVARCHAR(100),
    BillingState NVARCHAR(50),
    BillingPostalCode NVARCHAR(20),
    BillingCountry NVARCHAR(50),

    ShippingLine1 NVARCHAR(200),
    ShippingCity NVARCHAR(100),
    ShippingState NVARCHAR(50),
    ShippingPostalCode NVARCHAR(20),
    ShippingCountry NVARCHAR(50),

    Balance DECIMAL(18,2),
    Taxable BIT,
    Active BIT,
    Notes NVARCHAR(MAX),

    PreferredDeliveryMethod NVARCHAR(20),
    PrintOnCheckName NVARCHAR(150),

    QuickBooksCreateTime DATETIME,
    QuickBooksLastUpdateTime DATETIME,
    
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE()
);


ALTER TABLE Customers
ADD Title NVARCHAR(50),
    Suffix NVARCHAR(50);


CREATE TABLE Products (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    QuickBooksItemId NVARCHAR(50) NOT NULL,
    Name NVARCHAR(100) NOT NULL,
    Type NVARCHAR(50) NOT NULL,
    SyncToken NVARCHAR(50) NOT NULL,
    UnitPrice DECIMAL(18, 2) NOT NULL,
    IncomeAccountId NVARCHAR(50) NOT NULL,
    IncomeAccountName NVARCHAR(100) NOT NULL,
    ExpenseAccountId NVARCHAR(50) NULL,
    ExpenseAccountName NVARCHAR(100) NULL,
    AssetAccountId NVARCHAR(50) NULL,
    AssetAccountName NVARCHAR(100) NULL,
    QuantityOnHand INT NULL,
    InventoryStartDate DATETIME NULL,
    Taxable BIT NOT NULL,
    Active BIT NOT NULL,
    CreatedAt DATETIME NOT NULL,
    UpdatedAt DATETIME NOT NULL
);

ALTER TABLE Products
ALTER COLUMN IncomeAccountName NVARCHAR(255) NULL;

ALTER TABLE Products
ALTER COLUMN IncomeAccountId NVARCHAR(255) NULL;

CREATE TABLE Invoices (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CustomerId INT NOT NULL,
    InvoiceDate DATETIME NOT NULL,
    DueDate DATETIME NOT NULL,
    Store VARCHAR(100),
    BillingAddress TEXT,
    Subtotal DECIMAL(18, 2) NOT NULL,
    Total DECIMAL(18, 2) NOT NULL,
    SendLater BIT NOT NULL DEFAULT 0,
    CreatedAt DATETIME NOT NULL,
    UpdatedAt DATETIME NOT NULL,
    DocNumber VARCHAR(50),
    QuickBooksId VARCHAR(50),
    SyncToken VARCHAR(20),
    EmailAddress VARCHAR(255),
    FOREIGN KEY (CustomerId) REFERENCES Customers(Id)
);

CREATE TABLE InvoiceLineItems (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceId INT NOT NULL,
    ProductId INT NOT NULL,
    Description TEXT,
    Quantity DECIMAL(18, 2) NOT NULL,
    Rate DECIMAL(18, 2) NOT NULL,
    Amount DECIMAL(18, 2) NOT NULL,
    QuickBooksLineId VARCHAR(50),
    LineNum INT,
    FOREIGN KEY (InvoiceId) REFERENCES Invoices(Id) ON DELETE CASCADE,
    FOREIGN KEY (ProductId) REFERENCES Products(Id)
);


DROP TABLE Invoices;


select * from Invoices;
select * from Customers;
select * from Vendors;
select * from Bills;

select * from QuickBooksTokens
select * from ChartOfAccounts

select * from Customers where QuickBooksCustomerId = 62
delete from Customers where QuickBooksCustomerId =0
select * from Customers where Active = 0;
SELECT * FROM QuickBooksTokens;

TRUNCATE TABLE QuickBooksTokens;



