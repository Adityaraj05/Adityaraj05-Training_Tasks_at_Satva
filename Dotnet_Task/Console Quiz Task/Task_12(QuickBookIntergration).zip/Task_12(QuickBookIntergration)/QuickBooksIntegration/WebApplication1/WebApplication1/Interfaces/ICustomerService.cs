﻿using WebApplication1.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Interfaces
{
    public interface ICustomerService
    {
        Task<object> FetchCustomersFromDbPaginated(int page, int pageSize, string searchTerm);
        Task<List<Customer>> FetchCustomersFromQuickBooks();
        Task<Customer> AddCustomer(CustomerDto customerDto);
        Task<Customer> UpdateCustomer(int id, CustomerDto customerDto);
        Task<bool> DeleteCustomer(string id);
    }
}