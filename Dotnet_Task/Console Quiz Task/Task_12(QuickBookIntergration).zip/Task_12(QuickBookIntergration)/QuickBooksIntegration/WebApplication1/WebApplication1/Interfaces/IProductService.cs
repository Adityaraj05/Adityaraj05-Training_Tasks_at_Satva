﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Interfaces
{
    public interface IProductService
    {
        Task<List<Product>> FetchProductsFromQuickBooks();
        Task<Product> CreateProduct(Product product);
        Task<Product> GetProduct(int id);
        Task<Product> UpdateProduct(int id, Product productUpdate);
        Task<object> SendProductToQuickBooks(int id);
        Task<object> UpdateProductInQuickBooks(int id);
        Task<string> DeactivateProduct(int id);
        Task<string> MakeProductInactive(string quickBooksItemId);
        Task<object> GetAllProducts(int pageNumber, int pageSize, string search, bool includeInactive);
    }
}