﻿//using System.Threading.Tasks;
//using WebApplication1.DTOs;
//using WebApplication1.Models;

//namespace WebApplication1.Interfaces
//{
//    public interface IInvoiceService
//    {
//        Task<PaginatedResponse<InvoiceDto>> GetInvoicesAsync(PaginationParams paginationParams);
//        Task<InvoiceDto> GetInvoiceByIdAsync(int id);
//        Task<InvoiceDto> CreateInvoiceAsync(InvoiceDto invoiceDto, string realmId, string accessToken);
//        Task<InvoiceDto> UpdateInvoiceAsync(int id, InvoiceDto invoiceDto, string realmId, string accessToken);
//        Task<bool> DeleteInvoiceAsync(int id, string realmId, string accessToken);
//        Task<byte[]> GetInvoicePdfAsync(int id, string realmId, string accessToken);
//        Task<bool> SendInvoiceByEmailAsync(int id, string emailAddress, string realmId, string accessToken);
//    }
//}