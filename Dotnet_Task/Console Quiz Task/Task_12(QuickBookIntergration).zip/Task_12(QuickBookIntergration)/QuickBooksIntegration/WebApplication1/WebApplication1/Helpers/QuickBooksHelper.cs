﻿using System.Net.Http.Headers;
using System.Numerics;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Helpers
{
    public class QuickBooksHelper
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<QuickBooksHelper> _logger;

        public QuickBooksHelper(HttpClient httpClient, ApplicationDbContext dbContext, ILogger<QuickBooksHelper> logger)
        {
            _httpClient = httpClient;
            _dbContext = dbContext;
            _logger = logger;
        }

        // Renamed to match both implementations
        public async Task<(string AccessToken, string RealmId)> GetQuickBooksCredentials()
        {
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                throw new Exception("No QuickBooks token found.");

            var accessToken = tokenRecord.AccessToken;
            var realmId = tokenRecord.RealmId;

            if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                throw new Exception("Missing access token or realm ID.");

            return (accessToken, realmId);
        }

        // Keeping alias method for backwards compatibility
        public async Task<(string AccessToken, string RealmId)> GetLatestTokens()
        {
            return await GetQuickBooksCredentials();
        }

        public async Task<string> GetQuickBooksUserId()
        {
            var tokenRecord = await _dbContext.QuickBooksTokens
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefaultAsync();

            if (tokenRecord == null)
                throw new Exception("No QuickBooks token found.");

            return tokenRecord.QuickBooksUserId;
        }

        public async Task<string> GetCustomerSyncToken(string accessToken, string realmId, string quickBooksCustomerId)
        {
            var getCustomerUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/customer/{quickBooksCustomerId}";
            var getRequest = new HttpRequestMessage(HttpMethod.Get, getCustomerUrl);
            getRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            getRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var getResponse = await _httpClient.SendAsync(getRequest);
            var getContent = await getResponse.Content.ReadAsStringAsync();

            if (!getResponse.IsSuccessStatusCode)
                throw new Exception($"Error retrieving customer from QuickBooks: {getContent}");

            using var document = JsonDocument.Parse(getContent);
            var customerJson = document.RootElement.GetProperty("Customer");
            return customerJson.GetProperty("SyncToken").GetString();
        }

        public async Task<string> FetchCustomerDataFromQuickBooks(string accessToken, string realmId)
        {
            _logger.LogInformation("Fetching customer data from QuickBooks API.");

            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query=SELECT * FROM Customer";

            var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(httpRequest);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Error from QuickBooks API: {json}");

            return json;
        }

        public List<Customer> ParseCustomerData(string json, string quickBooksUserId)
        {
            var customers = new List<Customer>();
            var jsonResponse = JObject.Parse(json);

            if (jsonResponse["QueryResponse"]?["Customer"] is JArray customerArray)
            {
                foreach (var item in customerArray)
                {
                    var customer = new Customer
                    {
                        QuickBooksCustomerId = item["Id"]?.ToString(),
                        QuickBooksUserId = quickBooksUserId,
                        DisplayName = item["DisplayName"]?.ToString(),
                        CompanyName = string.IsNullOrWhiteSpace(item["CompanyName"]?.ToString())
                        ? item["DisplayName"]?.ToString()
                        : item["CompanyName"]?.ToString(),
                        GivenName = item["GivenName"]?.ToString(),
                        MiddleName = item["MiddleName"]?.ToString(),
                        FamilyName = item["FamilyName"]?.ToString(),
                        Title = item["Title"]?.ToString(),
                        Suffix = item["Suffix"]?.ToString(),
                        Email = item["PrimaryEmailAddr"]?["Address"]?.ToString(),
                        Phone = item["PrimaryPhone"]?["FreeFormNumber"]?.ToString(),
                        Active = item["Active"]?.ToObject<bool>() ?? false,
                        Balance = item["Balance"]?.ToObject<decimal>() ?? 0,
                        Notes = item["Notes"]?.ToString(),
                        PreferredDeliveryMethod = item["PreferredDeliveryMethod"]?.ToString(),
                        PrintOnCheckName = item["PrintOnCheckName"]?.ToString(),
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                    // Billing address
                    if (item["BillAddr"] != null)
                    {
                        customer.BillingLine1 = item["BillAddr"]?["Line1"]?.ToString();
                        customer.BillingCity = item["BillAddr"]?["City"]?.ToString();
                        customer.BillingState = item["BillAddr"]?["CountrySubDivisionCode"]?.ToString();
                        customer.BillingPostalCode = item["BillAddr"]?["PostalCode"]?.ToString();
                        customer.BillingCountry = item["BillAddr"]?["Country"]?.ToString();
                    }

                    // Shipping address
                    if (item["ShipAddr"] != null)
                    {
                        customer.ShippingLine1 = item["ShipAddr"]?["Line1"]?.ToString();
                        customer.ShippingCity = item["ShipAddr"]?["City"]?.ToString();
                        customer.ShippingState = item["ShipAddr"]?["CountrySubDivisionCode"]?.ToString();
                        customer.ShippingPostalCode = item["ShipAddr"]?["PostalCode"]?.ToString();
                        customer.ShippingCountry = item["ShipAddr"]?["Country"]?.ToString();
                    }

                    // Metadata times
                    if (item["MetaData"] != null)
                    {
                        DateTime.TryParse(item["MetaData"]?["CreateTime"]?.ToString(), out DateTime createTime);
                        DateTime.TryParse(item["MetaData"]?["LastUpdatedTime"]?.ToString(), out DateTime updateTime);

                        if (createTime != DateTime.MinValue)
                            customer.QuickBooksCreateTime = createTime;

                        if (updateTime != DateTime.MinValue)
                            customer.QuickBooksLastUpdateTime = updateTime;
                    }

                    customers.Add(customer);
                }
            }

            return customers;
        }

        public async Task<Customer> AddCustomerToQuickBooks(string accessToken, string realmId, CustomerDto customerDto)
        {
            // Prepare payload for QuickBooks API request
            var payload = new
            {
                DisplayName = customerDto.DisplayName,
                CompanyName = customerDto.CompanyName,
                PrimaryPhone = new { FreeFormNumber = customerDto.Phone },
                PrimaryEmailAddr = string.IsNullOrWhiteSpace(customerDto.Email) ? null : new { Address = customerDto.Email },
                BillAddr = new
                {
                    Line1 = customerDto.BillingLine1,
                    City = customerDto.BillingCity,
                    CountrySubDivisionCode = customerDto.BillingState,
                    PostalCode = customerDto.BillingPostalCode,
                    Country = customerDto.BillingCountry
                }
            };

            var jsonPayload = System.Text.Json.JsonSerializer.Serialize(payload);
            var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/customer";

            // Set up HTTP request to QuickBooks API
            var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
            {
                Headers =
                {
                    Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                    Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
                },
                Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
            };

            // Send request to QuickBooks API
            var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Error from QuickBooks API: {responseBody}");
            }

            // Parse the response from QuickBooks API
            using var document = JsonDocument.Parse(responseBody);
            var customerJson = document.RootElement.GetProperty("Customer");

            var quickBooksCustomerId = customerJson.GetProperty("Id").GetString();

            return new Customer
            {
                QuickBooksCustomerId = quickBooksCustomerId,
                DisplayName = customerDto.DisplayName,
                CompanyName = customerDto.CompanyName,
                Phone = customerDto.Phone,
                Email = customerDto.Email,
                BillingLine1 = customerDto.BillingLine1,
                BillingCity = customerDto.BillingCity,
                BillingState = customerDto.BillingState,
                BillingPostalCode = customerDto.BillingPostalCode,
                BillingCountry = customerDto.BillingCountry,
                Active = true,
                Balance = 1000,  // Default balance
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
        }

        public async Task<bool> UpdateCustomerInQuickBooks(string accessToken, string realmId, string quickBooksCustomerId, string syncToken, CustomerDto customerDto)
        {
            var qbPayload = new
            {
                Id = quickBooksCustomerId,
                SyncToken = syncToken,
                DisplayName = customerDto.DisplayName,
                CompanyName = customerDto.CompanyName,
                PrimaryPhone = new { FreeFormNumber = customerDto.Phone },
                PrimaryEmailAddr = string.IsNullOrWhiteSpace(customerDto.Email) ? null : new { Address = customerDto.Email },
                BillAddr = new
                {
                    Line1 = customerDto.BillingLine1,
                    City = customerDto.BillingCity,
                    CountrySubDivisionCode = customerDto.BillingState,
                    PostalCode = customerDto.BillingPostalCode,
                    Country = customerDto.BillingCountry
                }
            };

            var updateUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/customer?operation=update";
            var updateRequest = new HttpRequestMessage(HttpMethod.Post, updateUrl)
            {
                Headers =
                {
                    Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                    Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
                },
                Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(qbPayload), Encoding.UTF8, "application/json")
            };

            var updateResponse = await _httpClient.SendAsync(updateRequest);
            var updateContent = await updateResponse.Content.ReadAsStringAsync();

            if (!updateResponse.IsSuccessStatusCode)
                throw new Exception($"Error updating customer in QuickBooks: {updateContent}");

            return true;
        }

        public async Task<bool> MarkCustomerInactiveInQuickBooks(string accessToken, string realmId, string quickBooksCustomerId, string syncToken, string displayName, string familyName)
        {
            var deletePayload = new
            {
                Id = quickBooksCustomerId,
                SyncToken = syncToken,
                Active = false, // marking as inactive instead of full delete
                DisplayName = displayName,
                FamilyName = familyName
            };

            var deleteUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/customer?operation=update";
            var deleteRequest = new HttpRequestMessage(HttpMethod.Post, deleteUrl)
            {
                Headers =
                {
                    Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
                    Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
                },
                Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(deletePayload), Encoding.UTF8, "application/json")
            };

            var deleteResponse = await _httpClient.SendAsync(deleteRequest);
            var deleteContent = await deleteResponse.Content.ReadAsStringAsync();

            // Handle specific cases
            if (!deleteResponse.IsSuccessStatusCode)
            {
                if (deleteContent.Contains("Object Not Found") || deleteContent.Contains("made inactive"))
                {
                    return true; // Consider this successful for our purposes
                }
                throw new Exception($"Error marking customer inactive in QuickBooks: {deleteContent}");
            }

            return true;
        }

        public async Task<(bool success, string syncToken)> DeactivateInQuickBooks(string quickBooksItemId, string syncToken, string productName)
        {
            // Get the latest QuickBooks token
            var (accessToken, realmId) = await GetQuickBooksCredentials();

            // Prepare request to QuickBooks API
            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/item?minorversion=75";
            var httpRequest = new HttpRequestMessage(HttpMethod.Post, url);
            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Create the sparse update request
            var requestBody = new
            {
                Id = quickBooksItemId,
                sparse = true,
                SyncToken = syncToken,
                Name = productName,
                Active = false
            };

            httpRequest.Content = new StringContent(
                JsonConvert.SerializeObject(requestBody),
                Encoding.UTF8,
                "application/json");

            var response = await _httpClient.SendAsync(httpRequest);
            var responseContent = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"QuickBooks error: {responseContent}");
                throw new Exception($"QuickBooks API error: {responseContent}");
            }

            // Parse the response to get the updated sync token
            var responseObject = JObject.Parse(responseContent);
            var newSyncToken = responseObject["Item"]?["SyncToken"]?.ToString();

            return (true, newSyncToken);
        }



      // vendor helper function

        public async Task<string> FetchVendorDataFromQuickBooks(string accessToken, string realmId)
        {
            _logger.LogInformation("Fetching vendor data from QuickBooks API.");

            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query=SELECT * FROM Vendor";

            var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(httpRequest);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Error from QuickBooks API: {json}");

            return json;
        }

        public List<Vendor> ParseVendorData(string json, string quickBooksUserId)
        {
            var vendors = new List<Vendor>();
            var jsonResponse = JObject.Parse(json);

            if (jsonResponse["QueryResponse"]?["Vendor"] is JArray vendorArray)
            {
                foreach (var item in vendorArray)
                {
                    var vendor = new Vendor
                    {
                        QuickBooksVendorId = item["Id"]?.ToString(),
                        QuickBooksUserId = quickBooksUserId,
                        DisplayName = item["DisplayName"]?.ToString(),
                        CompanyName = item["CompanyName"]?.ToString(),
                        GivenName = item["GivenName"]?.ToString(),
                        FamilyName = item["FamilyName"]?.ToString(),
                        Email = item["PrimaryEmailAddr"]?["Address"]?.ToString(),
                        Phone = item["PrimaryPhone"]?["FreeFormNumber"]?.ToString(),
                        WebAddr = item["WebAddr"]?["URI"]?.ToString(),
                        Active = item["Active"]?.ToObject<bool>() ?? false,
                        Vendor1099 = item["Vendor1099"]?.ToObject<bool>() ?? false,
                        Balance = item["Balance"]?.ToObject<decimal>() ?? 0,
                        CurrencyValue = item["CurrencyRef"]?["value"]?.ToString(),
                        CurrencyName = item["CurrencyRef"]?["name"]?.ToString(),
                        SyncToken = item["SyncToken"]?.ToString(),
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                    // Billing address
                    if (item["BillAddr"] != null)
                    {
                        vendor.BillingLine1 = item["BillAddr"]?["Line1"]?.ToString();
                        vendor.BillingCity = item["BillAddr"]?["City"]?.ToString();
                        vendor.BillingState = item["BillAddr"]?["CountrySubDivisionCode"]?.ToString();
                        vendor.BillingPostalCode = item["BillAddr"]?["PostalCode"]?.ToString();
                        vendor.BillingCountry = item["BillAddr"]?["Country"]?.ToString();
                    }

                    // Metadata times
                    if (item["MetaData"] != null)
                    {
                        DateTime.TryParse(item["MetaData"]?["CreateTime"]?.ToString(), out DateTime createTime);
                        DateTime.TryParse(item["MetaData"]?["LastUpdatedTime"]?.ToString(), out DateTime updateTime);

                        if (createTime != DateTime.MinValue)
                            vendor.QuickBooksCreateTime = createTime;

                        if (updateTime != DateTime.MinValue)
                            vendor.QuickBooksLastUpdateTime = updateTime;
                    }

                    vendors.Add(vendor);
                }
            }

            return vendors;
        }

        public async Task<string> GetVendorSyncToken(string accessToken, string realmId, string quickBooksVendorId)
        {
            var getVendorUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/vendor/{quickBooksVendorId}";
            var getRequest = new HttpRequestMessage(HttpMethod.Get, getVendorUrl);
            getRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            getRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var getResponse = await _httpClient.SendAsync(getRequest);
            var getContent = await getResponse.Content.ReadAsStringAsync();

            if (!getResponse.IsSuccessStatusCode)
                throw new Exception($"Error retrieving vendor from QuickBooks: {getContent}");

            using var document = JsonDocument.Parse(getContent);
            var vendorJson = document.RootElement.GetProperty("Vendor");
            return vendorJson.GetProperty("SyncToken").GetString();
        }

        public async Task<Vendor> AddVendorToQuickBooks(string accessToken, string realmId, VendorDto vendorDto)
        {
            // Prepare payload for QuickBooks API request
            var payload = new
            {
                DisplayName = vendorDto.DisplayName,
                GivenName = vendorDto.GivenName,
                FamilyName = vendorDto.FamilyName,
                CompanyName = vendorDto.CompanyName,
                Vendor1099 = vendorDto.Vendor1099,
                PrimaryPhone = new { FreeFormNumber = vendorDto.Phone },
                PrimaryEmailAddr = string.IsNullOrWhiteSpace(vendorDto.Email) ? null : new { Address = vendorDto.Email },
                WebAddr = string.IsNullOrWhiteSpace(vendorDto.WebAddr) ? null : new { URI = vendorDto.WebAddr },
                BillAddr = new
                {
                    Line1 = vendorDto.BillingLine1,
                    City = vendorDto.BillingCity,
                    CountrySubDivisionCode = vendorDto.BillingState,
                    PostalCode = vendorDto.BillingPostalCode,
                    Country = vendorDto.BillingCountry
                },
                CurrencyRef = !string.IsNullOrWhiteSpace(vendorDto.CurrencyValue)
                    ? new { value = vendorDto.CurrencyValue }
                    : new { value = "USD" }
            };

            var jsonPayload = System.Text.Json.JsonSerializer.Serialize(payload);
            var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/vendor";

            // Set up HTTP request to QuickBooks API
            var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
            };

            // Send request to QuickBooks API
            var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Error from QuickBooks API: {responseBody}");
            }

            // Parse the response from QuickBooks API
            using var document = JsonDocument.Parse(responseBody);
            var vendorJson = document.RootElement.GetProperty("Vendor");

            var quickBooksVendorId = vendorJson.GetProperty("Id").GetString();
            var syncToken = vendorJson.GetProperty("SyncToken").GetString();
            var currencyRefValue = vendorJson.TryGetProperty("CurrencyRef", out var currencyRef)
                ? currencyRef.GetProperty("value").GetString()
                : "USD";
            var currencyRefName = vendorJson.TryGetProperty("CurrencyRef", out var currencyRefWithName)
                ? currencyRefWithName.GetProperty("name").GetString()
                : "United States Dollar";

            return new Vendor
            {
                QuickBooksVendorId = quickBooksVendorId,
                DisplayName = vendorDto.DisplayName,
                GivenName = vendorDto.GivenName,
                FamilyName = vendorDto.FamilyName,
                CompanyName = vendorDto.CompanyName,
                Phone = vendorDto.Phone,
                Email = vendorDto.Email,
                WebAddr = vendorDto.WebAddr,
                BillingLine1 = vendorDto.BillingLine1,
                BillingCity = vendorDto.BillingCity,
                BillingState = vendorDto.BillingState,
                BillingPostalCode = vendorDto.BillingPostalCode,
                BillingCountry = vendorDto.BillingCountry,
                Active = true,
                Vendor1099 = vendorDto.Vendor1099,
                Balance = 0,
                CurrencyValue = currencyRefValue,
                CurrencyName = currencyRefName,
                SyncToken = syncToken,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
        }

        public async Task<bool> UpdateVendorInQuickBooks(string accessToken, string realmId, string quickBooksVendorId, string syncToken, VendorDto vendorDto)
        {
            var qbPayload = new
            {
                Id = quickBooksVendorId,
                SyncToken = syncToken,
                DisplayName = vendorDto.DisplayName,
                GivenName = vendorDto.GivenName,
                FamilyName = vendorDto.FamilyName,
                CompanyName = vendorDto.CompanyName,
                Vendor1099 = vendorDto.Vendor1099,
                PrimaryPhone = new { FreeFormNumber = vendorDto.Phone },
                PrimaryEmailAddr = string.IsNullOrWhiteSpace(vendorDto.Email) ? null : new { Address = vendorDto.Email },
                WebAddr = string.IsNullOrWhiteSpace(vendorDto.WebAddr) ? null : new { URI = vendorDto.WebAddr },
                BillAddr = new
                {
                    Line1 = vendorDto.BillingLine1,
                    City = vendorDto.BillingCity,
                    CountrySubDivisionCode = vendorDto.BillingState,
                    PostalCode = vendorDto.BillingPostalCode,
                    Country = vendorDto.BillingCountry
                },
                CurrencyRef = !string.IsNullOrWhiteSpace(vendorDto.CurrencyValue)
                    ? new { value = vendorDto.CurrencyValue }
                    : new { value = "USD" }
            };

            var updateUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/vendor?operation=update";
            var updateRequest = new HttpRequestMessage(HttpMethod.Post, updateUrl)
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(qbPayload), Encoding.UTF8, "application/json")
            };

            var updateResponse = await _httpClient.SendAsync(updateRequest);
            var updateContent = await updateResponse.Content.ReadAsStringAsync();

            if (!updateResponse.IsSuccessStatusCode)
                throw new Exception($"Error updating vendor in QuickBooks: {updateContent}");

            return true;
        }

        public async Task<bool> MarkVendorInactiveInQuickBooks(string accessToken, string realmId, string quickBooksVendorId, string syncToken, string displayName)
        {
            var deactivatePayload = new
            {
                Id = quickBooksVendorId,
                SyncToken = syncToken,
                Active = false,
                DisplayName = displayName
            };

            var deactivateUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/vendor?operation=update";
            var deactivateRequest = new HttpRequestMessage(HttpMethod.Post, deactivateUrl)
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(deactivatePayload), Encoding.UTF8, "application/json")
            };

            var deactivateResponse = await _httpClient.SendAsync(deactivateRequest);
            var deactivateContent = await deactivateResponse.Content.ReadAsStringAsync();

            if (!deactivateResponse.IsSuccessStatusCode)
            {
                if (deactivateContent.Contains("Object Not Found") || deactivateContent.Contains("made inactive"))
                {
                    return true; // Consider this successful for our purposes
                }
                throw new Exception($"Error marking vendor inactive in QuickBooks: {deactivateContent}");
            }

            return true;
        }


        // this one for bills

        // Update QuickBooksHelper.cs with these new methods

        // Add these methods to the QuickBooksHelper class
        public async Task<string> FetchBillsFromQuickBooks(string accessToken, string realmId)
        {
            _logger.LogInformation("Fetching bills data from QuickBooks API.");

            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query=SELECT * FROM Bill";

            var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(httpRequest);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Error from QuickBooks API: {json}");

            return json;
        }

        public List<Bill> ParseBillData(string json, string quickBooksUserId)
        {
            var bills = new List<Bill>();
            var jsonResponse = JObject.Parse(json);

            if (jsonResponse["QueryResponse"]?["Bill"] is JArray billArray)
            {
                foreach (var item in billArray)
                {
                    var bill = new Bill
                    {
                        QuickBooksBillId = item["Id"]?.ToString(),
                        QuickBooksUserId = quickBooksUserId,
                        DocNumber = item["DocNumber"]?.ToString(),
                        SyncToken = item["SyncToken"]?.ToString(),
                        VendorId = item["VendorRef"]?["value"]?.ToString(),
                        VendorName = item["VendorRef"]?["name"]?.ToString(),
                        APAccountId = item["APAccountRef"]?["value"]?.ToString(),
                        APAccountName = item["APAccountRef"]?["name"]?.ToString(),
                        TotalAmt = item["TotalAmt"]?.ToObject<decimal>() ?? 0,
                        Balance = item["Balance"]?.ToObject<decimal>() ?? 0,
                        CurrencyValue = item["CurrencyRef"]?["value"]?.ToString(),
                        CurrencyName = item["CurrencyRef"]?["name"]?.ToString(),
                        PrivateNote = item["PrivateNote"]?.ToString(),
                        Paid = (item["Balance"]?.ToObject<decimal>() ?? 0) == 0 && (item["TotalAmt"]?.ToObject<decimal>() ?? 0) > 0,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                    // Parse dates
                    if (DateTime.TryParse(item["TxnDate"]?.ToString(), out DateTime txnDate))
                        bill.TxnDate = txnDate;

                    if (DateTime.TryParse(item["DueDate"]?.ToString(), out DateTime dueDate))
                        bill.DueDate = dueDate;

                    // Metadata times
                    if (item["MetaData"] != null)
                    {
                        DateTime.TryParse(item["MetaData"]?["CreateTime"]?.ToString(), out DateTime createTime);
                        DateTime.TryParse(item["MetaData"]?["LastUpdatedTime"]?.ToString(), out DateTime updateTime);

                        if (createTime != DateTime.MinValue)
                            bill.QuickBooksCreateTime = createTime;

                        if (updateTime != DateTime.MinValue)
                            bill.QuickBooksLastUpdateTime = updateTime;
                    }

                    // Parse line items
                    if (item["Line"] is JArray lineItems)
                    {
                        bill.LineItems = new List<BillLineItem>();

                        foreach (var lineItem in lineItems)
                        {
                            var detailType = lineItem["DetailType"]?.ToString();
                            var lineDetail = detailType == "AccountBasedExpenseLineDetail"
                                ? lineItem["AccountBasedExpenseLineDetail"]
                                : lineItem["ItemBasedExpenseLineDetail"];

                            var billLineItem = new BillLineItem
                            {
                                LineId = lineItem["Id"]?.ToString(),
                                Description = lineItem["Description"]?.ToString(),
                                DetailType = detailType,
                                Amount = lineItem["Amount"]?.ToObject<decimal>() ?? 0,
                                TaxCodeId = lineDetail?["TaxCodeRef"]?["value"]?.ToString()
                            };

                            // Add account or item information
                            if (detailType == "AccountBasedExpenseLineDetail")
                            {
                                billLineItem.AccountId = lineDetail?["AccountRef"]?["value"]?.ToString();
                                billLineItem.AccountName = lineDetail?["AccountRef"]?["name"]?.ToString();
                            }
                            else if (detailType == "ItemBasedExpenseLineDetail")
                            {
                                billLineItem.ItemId = lineDetail?["ItemRef"]?["value"]?.ToString();
                                billLineItem.ItemName = lineDetail?["ItemRef"]?["name"]?.ToString();
                                billLineItem.UnitPrice = lineDetail?["UnitPrice"]?.ToObject<decimal>();
                                billLineItem.Quantity = lineDetail?["Qty"]?.ToObject<decimal>();
                            }

                            // Customer reference for billable expenses
                            billLineItem.CustomerId = lineDetail?["CustomerRef"]?["value"]?.ToString();
                            billLineItem.CustomerName = lineDetail?["CustomerRef"]?["name"]?.ToString();
                            billLineItem.BillableStatus = lineDetail?["BillableStatus"]?.ToString();

                            bill.LineItems.Add(billLineItem);
                        }
                    }

                    bills.Add(bill);
                }
            }

            return bills;
        }

        public async Task<string> GetBillSyncToken(string accessToken, string realmId, string quickBooksBillId)
        {
            var getBillUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/bill/{quickBooksBillId}";
            var getRequest = new HttpRequestMessage(HttpMethod.Get, getBillUrl);
            getRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            getRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var getResponse = await _httpClient.SendAsync(getRequest);
            var getContent = await getResponse.Content.ReadAsStringAsync();

            if (!getResponse.IsSuccessStatusCode)
                throw new Exception($"Error retrieving bill from QuickBooks: {getContent}");

            using var document = JsonDocument.Parse(getContent);
            var billJson = document.RootElement.GetProperty("Bill");
            return billJson.GetProperty("SyncToken").GetString();
        }

        //public async Task<Bill> AddBillToQuickBooks(string accessToken, string realmId, BillDto billDto)
        //{
        //    // Prepare line items
        //    var lineItems = new JArray();
        //    foreach (var item in billDto.LineItems)
        //    {
        //        JObject lineDetail = null;

        //        if (item.DetailType == "AccountBasedExpenseLineDetail")
        //        {
        //            lineDetail = new JObject
        //            {
        //                ["AccountRef"] = new JObject { ["value"] = item.AccountId },
        //                ["TaxCodeRef"] = new JObject { ["value"] = item.TaxCodeId ?? "NON" }
        //            };

        //            if (!string.IsNullOrEmpty(item.CustomerId))
        //            {
        //                lineDetail["CustomerRef"] = new JObject { ["value"] = item.CustomerId };
        //                lineDetail["BillableStatus"] = item.BillableStatus ?? "NotBillable";
        //            }
        //        }
        //        else if (item.DetailType == "ItemBasedExpenseLineDetail")
        //        {
        //            lineDetail = new JObject
        //            {
        //                ["ItemRef"] = new JObject { ["value"] = item.ItemId },
        //                ["TaxCodeRef"] = new JObject { ["value"] = item.TaxCodeId ?? "NON" }
        //            };

        //            if (item.UnitPrice.HasValue)
        //                lineDetail["UnitPrice"] = item.UnitPrice.Value;

        //            if (item.Quantity.HasValue)
        //                lineDetail["Qty"] = item.Quantity.Value;

        //            if (!string.IsNullOrEmpty(item.CustomerId))
        //            {
        //                lineDetail["CustomerRef"] = new JObject { ["value"] = item.CustomerId };
        //                lineDetail["BillableStatus"] = item.BillableStatus ?? "NotBillable";
        //            }
        //        }

        //        var lineItem = new JObject
        //        {
        //            ["DetailType"] = item.DetailType,
        //            ["Amount"] = item.Amount,
        //            ["Description"] = item.Description
        //        };

        //        if (lineDetail != null)
        //            lineItem[item.DetailType] = lineDetail;

        //        lineItems.Add(lineItem);
        //    }

        //    // Prepare payload for QuickBooks API request
        //    var payload = new JObject
        //    {
        //        ["VendorRef"] = new JObject { ["value"] = billDto.VendorId },
        //        ["Line"] = lineItems
        //    };

        //    // Add optional fields if provided
        //    if (!string.IsNullOrEmpty(billDto.DocNumber))
        //        payload["DocNumber"] = billDto.DocNumber;

        //    if (!string.IsNullOrEmpty(billDto.APAccountId))
        //        payload["APAccountRef"] = new JObject { ["value"] = billDto.APAccountId };

        //    if (billDto.TxnDate != default)
        //        payload["TxnDate"] = billDto.TxnDate.ToString("yyyy-MM-dd");

        //    if (billDto.DueDate != default)
        //        payload["DueDate"] = billDto.DueDate.ToString("yyyy-MM-dd");

        //    if (!string.IsNullOrEmpty(billDto.PrivateNote))
        //        payload["PrivateNote"] = billDto.PrivateNote;

        //    if (!string.IsNullOrEmpty(billDto.CurrencyValue))
        //        payload["CurrencyRef"] = new JObject { ["value"] = billDto.CurrencyValue };

        //    var jsonPayload = payload.ToString();
        //    var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/bill?minorversion=75";

        //    // Set up HTTP request to QuickBooks API
        //    var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
        //    {
        //        Headers =
        //{
        //    Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
        //    Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        //},
        //        Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
        //    };

        //    // Send request to QuickBooks API
        //    var response = await _httpClient.SendAsync(request);
        //    var responseBody = await response.Content.ReadAsStringAsync();

        //    if (!response.IsSuccessStatusCode)
        //    {
        //        throw new Exception($"Error from QuickBooks API: {responseBody}");
        //    }

        //    // Parse the response from QuickBooks API
        //    var responseJson = JObject.Parse(responseBody);
        //    var billJson = responseJson["Bill"];

        //    var bill = new Bill
        //    {
        //        QuickBooksBillId = billJson["Id"]?.ToString(),
        //        DocNumber = billJson["DocNumber"]?.ToString(),
        //        SyncToken = billJson["SyncToken"]?.ToString(),
        //        VendorId = billJson["VendorRef"]?["value"]?.ToString(),
        //        VendorName = billJson["VendorRef"]?["name"]?.ToString(),
        //        APAccountId = billJson["APAccountRef"]?["value"]?.ToString(),
        //        APAccountName = billJson["APAccountRef"]?["name"]?.ToString(),
        //        TotalAmt = billJson["TotalAmt"]?.ToObject<decimal>() ?? 0,
        //        Balance = billJson["Balance"]?.ToObject<decimal>() ?? 0,
        //        CurrencyValue = billJson["CurrencyRef"]?["value"]?.ToString(),
        //        CurrencyName = billJson["CurrencyRef"]?["name"]?.ToString(),
        //        PrivateNote = billJson["PrivateNote"]?.ToString(),
        //        Paid = false,
        //        CreatedAt = DateTime.UtcNow,
        //        UpdatedAt = DateTime.UtcNow
        //    };

        //    // Parse dates
        //    if (DateTime.TryParse(billJson["TxnDate"]?.ToString(), out DateTime txnDate))
        //        bill.TxnDate = txnDate;

        //    if (DateTime.TryParse(billJson["DueDate"]?.ToString(), out DateTime dueDate))
        //        bill.DueDate = dueDate;

        //    // Metadata times
        //    if (billJson["MetaData"] != null)
        //    {
        //        DateTime.TryParse(billJson["MetaData"]?["CreateTime"]?.ToString(), out DateTime createTime);
        //        DateTime.TryParse(billJson["MetaData"]?["LastUpdatedTime"]?.ToString(), out DateTime updateTime);

        //        if (createTime != DateTime.MinValue)
        //            bill.QuickBooksCreateTime = createTime;

        //        if (updateTime != DateTime.MinValue)
        //            bill.QuickBooksLastUpdateTime = updateTime;
        //    }

        //    // Parse line items
        //    if (billJson["Line"] is JArray lineItemsJson)
        //    {
        //        bill.LineItems = new List<BillLineItem>();

        //        foreach (var lineItem in lineItemsJson)
        //        {
        //            var detailType = lineItem["DetailType"]?.ToString();
        //            var lineDetail = detailType == "AccountBasedExpenseLineDetail"
        //                ? lineItem["AccountBasedExpenseLineDetail"]
        //                : lineItem["ItemBasedExpenseLineDetail"];

        //            var billLineItem = new BillLineItem
        //            {
        //                LineId = lineItem["Id"]?.ToString(),
        //                Description = lineItem["Description"]?.ToString(),
        //                DetailType = detailType,
        //                Amount = lineItem["Amount"]?.ToObject<decimal>() ?? 0,
        //                TaxCodeId = lineDetail?["TaxCodeRef"]?["value"]?.ToString()
        //            };

        //            // Add account or item information
        //            if (detailType == "AccountBasedExpenseLineDetail")
        //            {
        //                billLineItem.AccountId = lineDetail?["AccountRef"]?["value"]?.ToString();
        //                billLineItem.AccountName = lineDetail?["AccountRef"]?["name"]?.ToString();
        //            }
        //            else if (detailType == "ItemBasedExpenseLineDetail")
        //            {
        //                billLineItem.ItemId = lineDetail?["ItemRef"]?["value"]?.ToString();
        //                billLineItem.ItemName = lineDetail?["ItemRef"]?["name"]?.ToString();
        //                billLineItem.UnitPrice = lineDetail?["UnitPrice"]?.ToObject<decimal>();
        //                billLineItem.Quantity = lineDetail?["Qty"]?.ToObject<decimal>();
        //            }

        //            // Customer reference for billable expenses
        //            billLineItem.CustomerId = lineDetail?["CustomerRef"]?["value"]?.ToString();
        //            billLineItem.CustomerName = lineDetail?["CustomerRef"]?["name"]?.ToString();
        //            billLineItem.BillableStatus = lineDetail?["BillableStatus"]?.ToString();

        //            bill.LineItems.Add(billLineItem);
        //        }
        //    }

        //    return bill;
        //}

         

        public async Task<Bill> AddBillToQuickBooks(string accessToken, string realmId, BillDto billDto)
        {
            var lineItems = billDto.LineItems.Select(item => new
            {
                Amount = item.Amount,
                DetailType = item.DetailType,
                Description = item.Description,
                AccountBasedExpenseLineDetail = item.DetailType == "AccountBasedExpenseLineDetail" ? new
                {
                    AccountRef = new { value = item.AccountId },
                    TaxCodeRef = new { value = item.TaxCodeId ?? "NON" },
                    CustomerRef = !string.IsNullOrEmpty(item.CustomerId) ? new { value = item.CustomerId } : null,
                    BillableStatus = item.BillableStatus ?? "NotBillable"
                } : null,
                ItemBasedExpenseLineDetail = item.DetailType == "ItemBasedExpenseLineDetail" ? new
                {
                    ItemRef = new { value = item.ItemId },
                    TaxCodeRef = new { value = item.TaxCodeId ?? "NON" },
                    UnitPrice = item.UnitPrice,
                    Qty = item.Quantity,
                    CustomerRef = !string.IsNullOrEmpty(item.CustomerId) ? new { value = item.CustomerId } : null,
                    BillableStatus = item.BillableStatus ?? "NotBillable"
                } : null
            }).ToList();

            var payload = new
            {
                VendorRef = new { value = billDto.VendorId },
                APAccountRef = !string.IsNullOrEmpty(billDto.APAccountId) ? new { value = billDto.APAccountId } : null,
                TxnDate = billDto.TxnDate != default ? billDto.TxnDate.ToString("yyyy-MM-dd") : null,
                DueDate = billDto.DueDate != default ? billDto.DueDate.ToString("yyyy-MM-dd") : null,
                PrivateNote = billDto.PrivateNote,
                CurrencyRef = !string.IsNullOrEmpty(billDto.CurrencyValue) ? new { value = billDto.CurrencyValue } : null,
                DocNumber = billDto.DocNumber,
                Line = lineItems
            };

            var jsonPayload = JsonConvert.SerializeObject(payload);
            var requestUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/bill?minorversion=75";

            var request = new HttpRequestMessage(HttpMethod.Post, requestUrl)
            {
                Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Error from QuickBooks API: {responseBody}");
            }

            var responseJson = JObject.Parse(responseBody);
            var billJson = responseJson["Bill"];

            var bill = new Bill
            {
                QuickBooksBillId = billJson["Id"]?.ToString(),
                VendorId = billJson["VendorRef"]?["value"]?.ToString(),
                APAccountId = billJson["APAccountRef"]?["value"]?.ToString(),
                TxnDate = billJson["TxnDate"]?.ToObject<DateTime>() ?? DateTime.MinValue,
                DueDate = billJson["DueDate"]?.ToObject<DateTime>() ?? DateTime.MinValue,
                CurrencyValue = billJson["CurrencyRef"]?["value"]?.ToString(),
                PrivateNote = billJson["PrivateNote"]?.ToString(),
                DocNumber = billJson["DocNumber"]?.ToString(),
                LineItems = (ICollection<BillLineItem>)(billJson["Line"]?.Select(lineItem => new LineItem
                {
                    Amount = lineItem["Amount"]?.ToObject<decimal>() ?? 0,
                    DetailType = lineItem["DetailType"]?.ToString(),
                    Description = lineItem["Description"]?.ToString(),
                    AccountId = lineItem["AccountBasedExpenseLineDetail"]?["AccountRef"]?["value"]?.ToString(),
                    TaxCodeId = lineItem["AccountBasedExpenseLineDetail"]?["TaxCodeRef"]?["value"]?.ToString()
                                 ?? lineItem["ItemBasedExpenseLineDetail"]?["TaxCodeRef"]?["value"]?.ToString(),
                    ItemId = lineItem["ItemBasedExpenseLineDetail"]?["ItemRef"]?["value"]?.ToString(),
                    Quantity = lineItem["ItemBasedExpenseLineDetail"]?["Qty"]?.ToObject<decimal>(),
                    UnitPrice = lineItem["ItemBasedExpenseLineDetail"]?["UnitPrice"]?.ToObject<decimal>(),
                    CustomerId = lineItem["AccountBasedExpenseLineDetail"]?["CustomerRef"]?["value"]?.ToString()
                                 ?? lineItem["ItemBasedExpenseLineDetail"]?["CustomerRef"]?["value"]?.ToString(),
                    BillableStatus = lineItem["AccountBasedExpenseLineDetail"]?["BillableStatus"]?.ToString()
                                     ?? lineItem["ItemBasedExpenseLineDetail"]?["BillableStatus"]?.ToString()
                }).ToList())
            };

            return bill;
        }

        public async Task<bool> UpdateBillInQuickBooks(string accessToken, string realmId, string quickBooksBillId, string syncToken, BillDto billDto)
        {
            // Prepare line items
            var lineItems = new JArray();
            foreach (var item in billDto.LineItems)
            {
                JObject lineDetail = null;

                if (item.DetailType == "AccountBasedExpenseLineDetail")
                {
                    lineDetail = new JObject
                    {
                        ["AccountRef"] = new JObject { ["value"] = item.AccountId },
                        ["TaxCodeRef"] = new JObject { ["value"] = item.TaxCodeId ?? "NON" }
                    };

                    if (!string.IsNullOrEmpty(item.CustomerId))
                    {
                        lineDetail["CustomerRef"] = new JObject { ["value"] = item.CustomerId };
                        lineDetail["BillableStatus"] = item.BillableStatus ?? "NotBillable";
                    }
                }
                else if (item.DetailType == "ItemBasedExpenseLineDetail")
                {
                    lineDetail = new JObject
                    {
                        ["ItemRef"] = new JObject { ["value"] = item.ItemId },
                        ["TaxCodeRef"] = new JObject { ["value"] = item.TaxCodeId ?? "NON" }
                    };

                    if (item.UnitPrice.HasValue)
                        lineDetail["UnitPrice"] = item.UnitPrice.Value;

                    if (item.Quantity.HasValue)
                        lineDetail["Qty"] = item.Quantity.Value;

                    if (!string.IsNullOrEmpty(item.CustomerId))
                    {
                        lineDetail["CustomerRef"] = new JObject { ["value"] = item.CustomerId };
                        lineDetail["BillableStatus"] = item.BillableStatus ?? "NotBillable";
                    }
                }

                var lineItem = new JObject
                {
                    ["DetailType"] = item.DetailType,
                    ["Amount"] = item.Amount,
                    ["Description"] = item.Description
                };

                if (lineDetail != null)
                    lineItem[item.DetailType] = lineDetail;

                lineItems.Add(lineItem);
            }

            // Prepare payload for QuickBooks API request
            var payload = new JObject
            {
                ["Id"] = quickBooksBillId,
                ["SyncToken"] = syncToken,
                ["VendorRef"] = new JObject { ["value"] = billDto.VendorId },
                ["Line"] = lineItems
            };

            // Add optional fields if provided
            if (!string.IsNullOrEmpty(billDto.DocNumber))
                payload["DocNumber"] = billDto.DocNumber;

            if (!string.IsNullOrEmpty(billDto.APAccountId))
                payload["APAccountRef"] = new JObject { ["value"] = billDto.APAccountId };

            if (billDto.TxnDate != default)
                payload["TxnDate"] = billDto.TxnDate.ToString("yyyy-MM-dd");

            if (billDto.DueDate != default)
                payload["DueDate"] = billDto.DueDate.ToString("yyyy-MM-dd");

            if (!string.IsNullOrEmpty(billDto.PrivateNote))
                payload["PrivateNote"] = billDto.PrivateNote;

            if (!string.IsNullOrEmpty(billDto.CurrencyValue))
                payload["CurrencyRef"] = new JObject { ["value"] = billDto.CurrencyValue };

            var jsonPayload = payload.ToString();
            var updateUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/bill?operation=update&minorversion=75";

            var updateRequest = new HttpRequestMessage(HttpMethod.Post, updateUrl)
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
            };

            var updateResponse = await _httpClient.SendAsync(updateRequest);
            var updateContent = await updateResponse.Content.ReadAsStringAsync();

            if (!updateResponse.IsSuccessStatusCode)
                throw new Exception($"Error updating bill in QuickBooks: {updateContent}");

            return true;
        }

        public async Task<bool> DeleteBillInQuickBooks(string accessToken, string realmId, string quickBooksBillId, string syncToken)
        {
            var deletePayload = new JObject
            {
                ["Id"] = quickBooksBillId,
                ["SyncToken"] = syncToken
            };

            var deleteUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/bill?operation=delete&minorversion=75";
            var deleteRequest = new HttpRequestMessage(HttpMethod.Post, deleteUrl)
            {
                Headers =
        {
            Authorization = new AuthenticationHeaderValue("Bearer", accessToken),
            Accept = { new MediaTypeWithQualityHeaderValue("application/json") }
        },
                Content = new StringContent(deletePayload.ToString(), Encoding.UTF8, "application/json")
            };

            var deleteResponse = await _httpClient.SendAsync(deleteRequest);
            var deleteContent = await deleteResponse.Content.ReadAsStringAsync();

            if (!deleteResponse.IsSuccessStatusCode)
            {
                if (deleteContent.Contains("Object Not Found") || deleteContent.Contains("deleted"))
                {
                    return true; // Consider this successful for our purposes
                }
                throw new Exception($"Error deleting bill in QuickBooks: {deleteContent}");
            }

            return true;
        }

    }
}