﻿// DTOs/InvoiceDTO.cs
using System;
using System.Collections.Generic;
using WebApplication1.Models;

namespace WebApplication1.DTOs
{
    public class InvoiceDTOs
    {
        public int Id { get; set; }
        public int InvoiceId { get; set; }
        public int CustomerId { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public string Store { get; set; }
        public string BillingAddress { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Total { get; set; }
        public bool SendLater { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public List<InvoiceLineItem> LineItems { get; set; } = new();
    }

    public class InvoiceInputModel
    {
        public int CustomerId { get; set; }
        public string CustomerEmail { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public string Store { get; set; }
        public string BillingAddress { get; set; }
        public bool SendLater { get; set; }
        public List<InvoiceLineItemInputModel> LineItems { get; set; }
    }

    public class InvoiceLineItemInputModel
    {
        public int ProductId { get; set; }
        public string Description { get; set; }
        public decimal Quantity { get; set; }
        public decimal Rate { get; set; }
    }

    public class PagedResponse<T>
    {
        public List<T> Items { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);

        public PagedResponse(List<T> items, int pageNumber, int pageSize, int totalCount)
        {
            Items = items;
            PageNumber = pageNumber;
            PageSize = pageSize;
            TotalCount = totalCount;
        }
    }
}