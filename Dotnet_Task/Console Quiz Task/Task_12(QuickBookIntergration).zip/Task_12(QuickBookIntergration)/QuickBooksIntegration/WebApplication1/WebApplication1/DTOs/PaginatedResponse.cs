﻿using System.Collections.Generic;

namespace WebApplication1.DTOs
{
    public class PaginatedResponse<T> where T : class
    {
        public IEnumerable<T> Items { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages { get; set; }

        public PaginatedResponse(IEnumerable<T> items, int count, PaginationParams paginationParams)
        {
            PageNumber = paginationParams.PageNumber;
            PageSize = paginationParams.PageSize;
            TotalCount = count;
            TotalPages = (count + PageSize - 1) / PageSize;
            Items = items;
        }
    }
}