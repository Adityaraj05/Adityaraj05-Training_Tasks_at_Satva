﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly HttpClient _httpClient;
        private readonly ILogger<AccountController> _logger;

        public AccountController(ApplicationDbContext dbContext, HttpClient httpClient, ILogger<AccountController> logger)
        {
            _dbContext = dbContext;
            _httpClient = httpClient;
            _logger = logger;
        }

        [HttpGet("get-accounts")]
        public async Task<IActionResult> GetAccounts([FromQuery] string accountType = "")
        {
            try
            {
                var tokenRecord = await _dbContext.QuickBooksTokens
                    .OrderByDescending(t => t.CreatedAt)
                    .FirstOrDefaultAsync();

                if (tokenRecord == null)
                    return NotFound("No QuickBooks token found.");

                var accessToken = tokenRecord.AccessToken;
                var realmId = tokenRecord.RealmId;

                if (string.IsNullOrEmpty(accessToken) || string.IsNullOrEmpty(realmId))
                    return BadRequest("Missing access token or realm ID.");

                string query;
                if (!string.IsNullOrEmpty(accountType))
                {
                    query = $"SELECT * FROM Account WHERE AccountType = '{accountType}' AND Active = true";
                }
                else
                {
                    query = "SELECT * FROM Account WHERE Active = true";
                }

                var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query={Uri.EscapeDataString(query)}";

                var httpRequest = new HttpRequestMessage(HttpMethod.Get, url);
                httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await _httpClient.SendAsync(httpRequest);
                var json = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                    return StatusCode((int)response.StatusCode, json);

                var accounts = ParseAccountData(json);

                return Ok(new
                {
                    totalCount = accounts.Count,
                    data = accounts
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching accounts from QuickBooks");
                return StatusCode(500, $"Error fetching accounts: {ex.Message}");
            }
        }

        private List<dynamic> ParseAccountData(string json)
        {
            var accounts = new List<dynamic>();
            var jsonResponse = JObject.Parse(json);

            if (jsonResponse["QueryResponse"]?["Account"] is JArray items)
            {
                foreach (var item in items)
                {
                    accounts.Add(new
                    {
                        id = item["Id"]?.ToString(),
                        name = item["Name"]?.ToString(),
                        type = item["AccountType"]?.ToString(),
                        subType = item["AccountSubType"]?.ToString(),
                        classification = item["Classification"]?.ToString(),
                        fullyQualifiedName = item["FullyQualifiedName"]?.ToString()
                    });
                }
            }

            return accounts;
        }
    }
}