﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Data;
using WebApplication1.Helpers;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BillController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly QuickBooksHelper _quickBooksHelper;
        private readonly ILogger<BillController> _logger;

        public BillController(
            ApplicationDbContext dbContext,
            QuickBooksHelper quickBooksHelper,
            ILogger<BillController> logger)
        {
            _dbContext = dbContext;
            _quickBooksHelper = quickBooksHelper;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetBills([FromQuery] string search = "", [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            var query = _dbContext.Bills
                .Include(b => b.LineItems)
                .AsQueryable();

            // Apply search filter if provided
            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.ToLower();
                query = query.Where(b =>
                    b.DocNumber.ToLower().Contains(search) ||
                    b.VendorName.ToLower().Contains(search) ||
                    b.PrivateNote.ToLower().Contains(search));
            }

            // Calculate total for pagination
            var totalCount = await query.CountAsync();
            var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            // Apply pagination
            var bills = await query
                .OrderByDescending(b => b.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return Ok(new
            {
                Bills = bills,
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page
            });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBill(int id)
        {
            var bill = await _dbContext.Bills
                .Include(b => b.LineItems)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (bill == null)
            {
                return NotFound();
            }

            return Ok(bill);
        }

        [HttpPost("Sync")]
        public async Task<IActionResult> SyncBills()
        {
            try
            {
                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();
                var quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                // Fetch bills from QuickBooks
                var billJson = await _quickBooksHelper.FetchBillsFromQuickBooks(accessToken, realmId);
                var billsFromQB = _quickBooksHelper.ParseBillData(billJson, quickBooksUserId);

                int created = 0;
                int updated = 0;

                foreach (var qbBill in billsFromQB)
                {
                    var existingBill = await _dbContext.Bills
                        .Include(b => b.LineItems)
                        .FirstOrDefaultAsync(b => b.QuickBooksBillId == qbBill.QuickBooksBillId);

                    if (existingBill == null)
                    {
                        // Add new bill
                        _dbContext.Bills.Add(qbBill);
                        created++;
                    }
                    else
                    {
                        // Update existing bill
                        existingBill.DocNumber = qbBill.DocNumber;
                        existingBill.SyncToken = qbBill.SyncToken;
                        existingBill.VendorId = qbBill.VendorId;
                        existingBill.VendorName = qbBill.VendorName;
                        existingBill.APAccountId = qbBill.APAccountId;
                        existingBill.APAccountName = qbBill.APAccountName;
                        existingBill.TxnDate = qbBill.TxnDate;
                        existingBill.DueDate = qbBill.DueDate;
                        existingBill.TotalAmt = qbBill.TotalAmt;
                        existingBill.Balance = qbBill.Balance;
                        existingBill.CurrencyValue = qbBill.CurrencyValue;
                        existingBill.CurrencyName = qbBill.CurrencyName;
                        existingBill.PrivateNote = qbBill.PrivateNote;
                        existingBill.Paid = qbBill.Paid;
                        existingBill.QuickBooksCreateTime = qbBill.QuickBooksCreateTime;
                        existingBill.QuickBooksLastUpdateTime = qbBill.QuickBooksLastUpdateTime;
                        existingBill.UpdatedAt = DateTime.UtcNow;

                        // Update line items
                        _dbContext.BillLineItems.RemoveRange(existingBill.LineItems);
                        foreach (var lineItem in qbBill.LineItems)
                        {
                            lineItem.BillId = existingBill.Id;
                            _dbContext.BillLineItems.Add(lineItem);
                        }

                        updated++;
                    }
                }

                await _dbContext.SaveChangesAsync();

                return Ok(new { Created = created, Updated = updated, Total = billsFromQB.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing bills from QuickBooks");
                return StatusCode(500, new { Message = "Error syncing bills from QuickBooks", Error = ex.Message });
            }
        }

        //[HttpPost]
        //public async Task<IActionResult> CreateBill([FromBody] BillDto billDto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState);
        //        }

        //        var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();
        //        var quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

        //        // Create bill in QuickBooks
        //        var newBill = await _quickBooksHelper.AddBillToQuickBooks(accessToken, realmId, billDto);

        //        // Add the QuickBooks user ID to the bill
        //        newBill.QuickBooksUserId = quickBooksUserId;

        //        // Save to database
        //        _dbContext.Bills.Add(newBill);
        //        await _dbContext.SaveChangesAsync();

        //        return CreatedAtAction(nameof(GetBill), new { id = newBill.Id }, newBill);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, "Error creating bill in QuickBooks");
        //        return StatusCode(500, new { Message = "Error creating bill", Error = ex.Message });
        //    }
        //}
        [HttpPost("Create")]
        public async Task<IActionResult> CreateBill([FromBody] BillDto model)
        {
            try
            {
                if (model == null)
                {
                    return BadRequest(new { Message = "Request body is empty", Error = "The model field is required." });
                }

                // Ensure LineItems is not null before validations
                model.LineItems ??= new List<BillLineItemDto>();

                // Basic validations
                if (string.IsNullOrEmpty(model.VendorId))
                {
                    ModelState.AddModelError("VendorId", "VendorId is required");
                }

                if (!model.LineItems.Any())
                {
                    ModelState.AddModelError("LineItems", "At least one line item is required");
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();
                var quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                var newBill = await _quickBooksHelper.AddBillToQuickBooks(accessToken, realmId, model);
                newBill.QuickBooksUserId = quickBooksUserId;

                _dbContext.Bills.Add(newBill);
                await _dbContext.SaveChangesAsync();

                return CreatedAtAction(nameof(GetBill), new { id = newBill.Id }, newBill);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating bill in QuickBooks");
                return StatusCode(500, new { Message = "Error creating bill", Error = ex.Message });
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBill(int id, [FromBody] BillDto billDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var bill = await _dbContext.Bills.FindAsync(id);
                if (bill == null)
                {
                    return NotFound();
                }

                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();

                // If SyncToken is outdated, fetch the latest one
                string syncToken;
                if (string.IsNullOrEmpty(bill.SyncToken))
                {
                    syncToken = await _quickBooksHelper.GetBillSyncToken(accessToken, realmId, bill.QuickBooksBillId);
                }
                else
                {
                    syncToken = bill.SyncToken;
                }

                // Update bill in QuickBooks
                var success = await _quickBooksHelper.UpdateBillInQuickBooks(
                    accessToken,
                    realmId,
                    bill.QuickBooksBillId,
                    syncToken,
                    billDto);

                if (success)
                {
                    // Re-sync this bill to get updated information from QuickBooks
                    var billJson = await _quickBooksHelper.FetchBillsFromQuickBooks(accessToken, realmId);
                    var bills = _quickBooksHelper.ParseBillData(billJson, bill.QuickBooksUserId);
                    var updatedBill = bills.FirstOrDefault(b => b.QuickBooksBillId == bill.QuickBooksBillId);

                    if (updatedBill != null)
                    {
                        // Update existing bill in our database
                        bill.DocNumber = updatedBill.DocNumber;
                        bill.SyncToken = updatedBill.SyncToken;
                        bill.VendorId = updatedBill.VendorId;
                        bill.VendorName = updatedBill.VendorName;
                        bill.APAccountId = updatedBill.APAccountId;
                        bill.APAccountName = updatedBill.APAccountName;
                        bill.TxnDate = updatedBill.TxnDate;
                        bill.DueDate = updatedBill.DueDate;
                        bill.TotalAmt = updatedBill.TotalAmt;
                        bill.Balance = updatedBill.Balance;
                        bill.CurrencyValue = updatedBill.CurrencyValue;
                        bill.CurrencyName = updatedBill.CurrencyName;
                        bill.PrivateNote = updatedBill.PrivateNote;
                        bill.Paid = updatedBill.Paid;
                        bill.QuickBooksLastUpdateTime = updatedBill.QuickBooksLastUpdateTime;
                        bill.UpdatedAt = DateTime.UtcNow;

                        // Update line items
                        var lineItems = await _dbContext.BillLineItems
                            .Where(li => li.BillId == bill.Id)
                            .ToListAsync();
                        _dbContext.BillLineItems.RemoveRange(lineItems);

                        foreach (var lineItem in updatedBill.LineItems)
                        {
                            lineItem.BillId = bill.Id;
                            _dbContext.BillLineItems.Add(lineItem);
                        }

                        await _dbContext.SaveChangesAsync();
                        return Ok(bill);
                    }
                }

                return StatusCode(500, new { Message = "Failed to update bill" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating bill in QuickBooks");
                return StatusCode(500, new { Message = "Error updating bill", Error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBill(int id)
        {
            try
            {
                var bill = await _dbContext.Bills
                    .Include(b => b.LineItems)
                    .FirstOrDefaultAsync(b => b.Id == id);

                if (bill == null)
                {
                    return NotFound();
                }

                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();

                // If SyncToken is outdated, fetch the latest one
                string syncToken;
                if (string.IsNullOrEmpty(bill.SyncToken))
                {
                    syncToken = await _quickBooksHelper.GetBillSyncToken(accessToken, realmId, bill.QuickBooksBillId);
                }
                else
                {
                    syncToken = bill.SyncToken;
                }

                // Delete bill in QuickBooks
                var success = await _quickBooksHelper.DeleteBillInQuickBooks(
                    accessToken,
                    realmId,
                    bill.QuickBooksBillId,
                    syncToken);

                if (success)
                {
                    // Remove from our database
                    _dbContext.BillLineItems.RemoveRange(bill.LineItems);
                    _dbContext.Bills.Remove(bill);
                    await _dbContext.SaveChangesAsync();
                    return NoContent();
                }

                return StatusCode(500, new { Message = "Failed to delete bill" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting bill in QuickBooks");
                return StatusCode(500, new { Message = "Error deleting bill", Error = ex.Message });
            }
        }

        [HttpGet("Pagination")]
        public async Task<IActionResult> GetBillsWithAdvancedPagination(
            [FromQuery] string search = "",
            [FromQuery] string sortBy = "CreatedAt",
            [FromQuery] bool descending = true,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] DateTime? startDate = null,
            [FromQuery] DateTime? endDate = null,
            [FromQuery] string vendorId = null,
            [FromQuery] bool? isPaid = null)
        {
            var query = _dbContext.Bills
                .Include(b => b.LineItems)
                .AsQueryable();

            // Apply filters
            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.ToLower();
                query = query.Where(b =>
                    b.DocNumber.ToLower().Contains(search) ||
                    b.VendorName.ToLower().Contains(search) ||
                    b.PrivateNote.ToLower().Contains(search));
            }

            if (startDate.HasValue)
            {
                query = query.Where(b => b.TxnDate >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                query = query.Where(b => b.TxnDate <= endDate.Value);
            }

            if (!string.IsNullOrEmpty(vendorId))
            {
                query = query.Where(b => b.VendorId == vendorId);
            }

            if (isPaid.HasValue)
            {
                query = query.Where(b => b.Paid == isPaid.Value);
            }

            // Apply sorting
            switch (sortBy.ToLower())
            {
                case "docnumber":
                    query = descending
                        ? query.OrderByDescending(b => b.DocNumber)
                        : query.OrderBy(b => b.DocNumber);
                    break;
                case "vendorname":
                    query = descending
                        ? query.OrderByDescending(b => b.VendorName)
                        : query.OrderBy(b => b.VendorName);
                    break;
                case "txndate":
                    query = descending
                        ? query.OrderByDescending(b => b.TxnDate)
                        : query.OrderBy(b => b.TxnDate);
                    break;
                case "duedate":
                    query = descending
                        ? query.OrderByDescending(b => b.DueDate)
                        : query.OrderBy(b => b.DueDate);
                    break;
                case "totalamt":
                    query = descending
                        ? query.OrderByDescending(b => b.TotalAmt)
                        : query.OrderBy(b => b.TotalAmt);
                    break;
                case "balance":
                    query = descending
                        ? query.OrderByDescending(b => b.Balance)
                        : query.OrderBy(b => b.Balance);
                    break;
                case "updatedat":
                    query = descending
                        ? query.OrderByDescending(b => b.UpdatedAt)
                        : query.OrderBy(b => b.UpdatedAt);
                    break;
                case "createdat":
                default:
                    query = descending
                        ? query.OrderByDescending(b => b.CreatedAt)
                        : query.OrderBy(b => b.CreatedAt);
                    break;
            }

            // Calculate total for pagination
            var totalCount = await query.CountAsync();
            var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            // Apply pagination
            var bills = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return Ok(new
            {
                Bills = bills,
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page,
                PageSize = pageSize,
                HasPreviousPage = page > 1,
                HasNextPage = page < totalPages
            });
        }
    }
}