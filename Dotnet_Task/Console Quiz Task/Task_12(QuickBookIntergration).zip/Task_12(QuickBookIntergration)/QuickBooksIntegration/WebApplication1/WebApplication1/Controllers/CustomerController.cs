﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Interfaces;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerService _customerService;
        private readonly ILogger<CustomerController> _logger;

        public CustomerController(ICustomerService customerService, ILogger<CustomerController> logger)
        {
            _customerService = customerService;
            _logger = logger;
        }

        [HttpGet("fetch-customer-from-db-paginated")]
        public async Task<IActionResult> FetchCustomersFromDbPaginated(
            int page = 1,
            int pageSize = 10,
            string? searchTerm = null)
        {
            try
            {
                var result = await _customerService.FetchCustomersFromDbPaginated(page, pageSize, searchTerm);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching customers: {ex.Message}");
            }
        }

        [HttpGet("fetch-customers-from-quickbooks")]
        public async Task<IActionResult> FetchCustomersFromQuickBooks()
        {
            try
            {
                var customers = await _customerService.FetchCustomersFromQuickBooks();
                return Ok(customers);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching customers from QuickBooks: {ex.Message}");
            }
        }

        [HttpPost("add-customer")]
        public async Task<IActionResult> AddCustomer([FromBody] CustomerDto customerDto)
        {
            try
            {
                // Validate required fields in customerDto
                if (string.IsNullOrWhiteSpace(customerDto.DisplayName) ||
                    string.IsNullOrWhiteSpace(customerDto.CompanyName) ||
                    string.IsNullOrWhiteSpace(customerDto.Phone))
                {
                    return BadRequest("DisplayName, CompanyName, and Phone are required fields.");
                }

                var newCustomer = await _customerService.AddCustomer(customerDto);

                return StatusCode(201, new
                {
                    Message = "Customer added successfully to QuickBooks and saved locally.",
                    CustomerId = newCustomer.Id,
                    QuickBooksCustomerId = newCustomer.QuickBooksCustomerId,
                    Customer = new
                    {
                        newCustomer.Id,
                        newCustomer.DisplayName,
                        newCustomer.CompanyName,
                        newCustomer.Phone
                    }
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error adding customer: {ex.Message}");
            }
        }

        [HttpPut("update-customer/{id}")]
        public async Task<IActionResult> UpdateCustomer(int id, [FromBody] CustomerDto customerDto)
        {
            try
            {
                var updatedCustomer = await _customerService.UpdateCustomer(id, customerDto);

                return Ok(new
                {
                    Message = "Customer updated successfully in both QuickBooks and local database.",
                    CustomerId = updatedCustomer.Id,
                    QuickBooksCustomerId = updatedCustomer.QuickBooksCustomerId
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error updating customer: {ex.Message}");
            }
        }

        [HttpDelete("delete-customer/{id}")]
        public async Task<IActionResult> DeleteCustomer(string id)
        {
            try
            {
                await _customerService.DeleteCustomer(id);
                return Ok("Customer marked as inactive in QuickBooks and local DB.");
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error deleting customer: {ex.Message}");
            }
        }




    }
}