﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Data;
using WebApplication1.Helpers;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VendorController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly QuickBooksHelper _quickBooksHelper;
        private readonly ILogger<VendorController> _logger;

        public VendorController(
            ApplicationDbContext dbContext,
            QuickBooksHelper quickBooksHelper,
            ILogger<VendorController> logger)
        {
            _dbContext = dbContext;
            _quickBooksHelper = quickBooksHelper;
            _logger = logger;
        }


        [HttpGet]
        public async Task<IActionResult> GetVendors([FromQuery] string search = "", [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            var query = _dbContext.Vendors.AsQueryable();

            // Apply search filter if provided
            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.ToLower();
                query = query.Where(v =>
                    v.DisplayName.ToLower().Contains(search) ||
                    v.Email.ToLower().Contains(search) ||
                    v.CompanyName.ToLower().Contains(search));
            }

            // Calculate total for pagination
            var totalCount = await query.CountAsync();
            var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            // Apply pagination
            var vendors = await query
                .OrderByDescending(v => v.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return Ok(new
            {
                Vendors = vendors,
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = page
            });
        }

    
        [HttpGet("{id}")]
        public async Task<IActionResult> GetVendor(int id)
        {
            var vendor = await _dbContext.Vendors.FindAsync(id);

            if (vendor == null)
            {
                return NotFound();
            }

            return Ok(vendor);
        }

        [HttpPost("Sync")]
        public async Task<IActionResult> SyncVendors()
        {
            try
            {
                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();
                var quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                // Fetch vendors from QuickBooks
                var vendorJson = await _quickBooksHelper.FetchVendorDataFromQuickBooks(accessToken, realmId);
                var vendorsFromQB = _quickBooksHelper.ParseVendorData(vendorJson, quickBooksUserId);

                int created = 0;
                int updated = 0;

                foreach (var qbVendor in vendorsFromQB)
                {
                    var existingVendor = await _dbContext.Vendors
                        .FirstOrDefaultAsync(v => v.QuickBooksVendorId == qbVendor.QuickBooksVendorId);

                    if (existingVendor == null)
                    {
                        // Add new vendor
                        _dbContext.Vendors.Add(qbVendor);
                        created++;
                    }
                    else
                    {
                        // Update existing vendor
                        existingVendor.DisplayName = qbVendor.DisplayName;
                        existingVendor.GivenName = qbVendor.GivenName;
                        existingVendor.FamilyName = qbVendor.FamilyName;
                        existingVendor.CompanyName = qbVendor.CompanyName;
                        existingVendor.Email = qbVendor.Email;
                        existingVendor.Phone = qbVendor.Phone;
                        existingVendor.WebAddr = qbVendor.WebAddr;
                        existingVendor.BillingLine1 = qbVendor.BillingLine1;
                        existingVendor.BillingCity = qbVendor.BillingCity;
                        existingVendor.BillingState = qbVendor.BillingState;
                        existingVendor.BillingPostalCode = qbVendor.BillingPostalCode;
                        existingVendor.BillingCountry = qbVendor.BillingCountry;
                        existingVendor.Active = qbVendor.Active;
                        existingVendor.Vendor1099 = qbVendor.Vendor1099;
                        existingVendor.Balance = qbVendor.Balance;
                        existingVendor.CurrencyValue = qbVendor.CurrencyValue;
                        existingVendor.CurrencyName = qbVendor.CurrencyName;
                        existingVendor.SyncToken = qbVendor.SyncToken;
                        existingVendor.QuickBooksCreateTime = qbVendor.QuickBooksCreateTime;
                        existingVendor.QuickBooksLastUpdateTime = qbVendor.QuickBooksLastUpdateTime;
                        existingVendor.UpdatedAt = DateTime.UtcNow;

                        updated++;
                    }
                }

                await _dbContext.SaveChangesAsync();

                return Ok(new
                {
                    Message = $"Vendor sync completed successfully. Created: {created}, Updated: {updated}",
                    Created = created,
                    Updated = updated
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing vendors from QuickBooks");
                return StatusCode(500, new { Error = ex.Message });
            }
        }


        [HttpPost]
        public async Task<IActionResult> CreateVendor([FromBody] VendorDto vendorDto)
        {
            try
            {
                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();
                var quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                // Create vendor in QuickBooks
                var vendor = await _quickBooksHelper.AddVendorToQuickBooks(accessToken, realmId, vendorDto);

                // Set the QuickBooks user ID
                vendor.QuickBooksUserId = quickBooksUserId;

                // Add to database
                _dbContext.Vendors.Add(vendor);
                await _dbContext.SaveChangesAsync();

                return CreatedAtAction(nameof(GetVendor), new { id = vendor.Id }, vendor);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating vendor in QuickBooks");
                return StatusCode(500, new { Error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateVendor(int id, [FromBody] VendorDto vendorDto)
        {
            try
            {
                var vendor = await _dbContext.Vendors.FindAsync(id);
                if (vendor == null)
                {
                    return NotFound();
                }

                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();

                // Get the latest SyncToken
                var syncToken = await _quickBooksHelper.GetVendorSyncToken(accessToken, realmId, vendor.QuickBooksVendorId);

                // Update vendor in QuickBooks
                await _quickBooksHelper.UpdateVendorInQuickBooks(accessToken, realmId, vendor.QuickBooksVendorId, syncToken, vendorDto);

                // Update local database
                vendor.DisplayName = vendorDto.DisplayName;
                vendor.GivenName = vendorDto.GivenName;
                vendor.FamilyName = vendorDto.FamilyName;
                vendor.CompanyName = vendorDto.CompanyName;
                vendor.Email = vendorDto.Email;
                vendor.Phone = vendorDto.Phone;
                vendor.WebAddr = vendorDto.WebAddr;
                vendor.BillingLine1 = vendorDto.BillingLine1;
                vendor.BillingCity = vendorDto.BillingCity;
                vendor.BillingState = vendorDto.BillingState;
                vendor.BillingPostalCode = vendorDto.BillingPostalCode;
                vendor.BillingCountry = vendorDto.BillingCountry;
                vendor.Vendor1099 = vendorDto.Vendor1099;
                vendor.CurrencyValue = vendorDto.CurrencyValue;
                vendor.UpdatedAt = DateTime.UtcNow;

                await _dbContext.SaveChangesAsync();

                return Ok(vendor);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating vendor in QuickBooks");
                return StatusCode(500, new { Error = ex.Message });
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeactivateVendor(int id)
        {
            try
            {
                var vendor = await _dbContext.Vendors.FindAsync(id);
                if (vendor == null)
                {
                    return NotFound();
                }

                var (accessToken, realmId) = await _quickBooksHelper.GetQuickBooksCredentials();

                // Get the latest SyncToken
                var syncToken = await _quickBooksHelper.GetVendorSyncToken(accessToken, realmId, vendor.QuickBooksVendorId);

                // Mark vendor as inactive in QuickBooks
                await _quickBooksHelper.MarkVendorInactiveInQuickBooks(accessToken, realmId, vendor.QuickBooksVendorId, syncToken, vendor.DisplayName);

                // Update local database
                vendor.Active = false;
                vendor.UpdatedAt = DateTime.UtcNow;

                await _dbContext.SaveChangesAsync();

                return Ok(new { Message = "Vendor successfully deactivated." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deactivating vendor in QuickBooks");
                return StatusCode(500, new { Error = ex.Message });
            }
        }
    }
}