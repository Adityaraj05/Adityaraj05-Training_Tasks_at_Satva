﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using WebApplication1.Data;
using WebApplication1.DTOs;
using WebApplication1.Models;
using WebApplication1.Helpers;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ApplicationDbContext _context;
        private readonly QuickBooksHelper _quickBooksHelper;
        private readonly ILogger<InvoiceController> _logger;

        public InvoiceController(
            IConfiguration configuration,
            ApplicationDbContext context,
            QuickBooksHelper quickBooksHelper,
            ILogger<InvoiceController> logger)
        {
            _configuration = configuration;
            _context = context;
            _quickBooksHelper = quickBooksHelper;
            _logger = logger;
        }

        [HttpGet("fetch")]
        public async Task<IActionResult> GetInvoiceFromQuickBooks()
        {
            try
            {
                // Get access token and realm ID from QuickBooksHelper instead of from request
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();

                string url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query=select * from Invoice&minorversion=75";

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await client.GetAsync(url);
                var json = await response.Content.ReadAsStringAsync();

                dynamic data = JsonConvert.DeserializeObject(json);
                Console.WriteLine(data);
                var invoices = data.QueryResponse?.Invoice;

                if (invoices == null)
                    return BadRequest("No invoices found.");

                var newInvoices = new List<Invoice>();
                var updatedInvoices = new List<Invoice>();
                var newLineItems = new List<InvoiceLineItem>();
                var updatedLineItems = new Dictionary<int, List<InvoiceLineItem>>();

                foreach (var item in invoices)
                {
                    // Accessing dynamic properties safely
                    string qbId = item.Id?.ToString();
                    if (qbId == null) continue; // Skip if InvoiceId is null

                    // Parse the QuickBooks last updated time
                    DateTime qbLastUpdatedTime = DateTime.TryParse((string?)item.MetaData?.LastUpdatedTime, out var uTime)
                        ? uTime
                        : DateTime.MinValue;

                    var existingInvoice = await _context.Invoices.FirstOrDefaultAsync(x => x.InvoiceId == int.Parse(qbId));

                    if (existingInvoice == null)
                    {
                        // This is a new invoice
                        var invoice = new Invoice
                        {
                            InvoiceId = int.Parse(qbId),
                            CustomerId = int.TryParse((string?)item.CustomerRef?.value, out var cid) ? cid : 0,
                            InvoiceDate = DateTime.TryParse((string?)item.MetaData?.CreateTime, out var invDate) ? invDate : DateTime.MinValue,
                            DueDate = DateTime.TryParse((string?)item.DueDate, out var due) ? due : DateTime.MinValue,
                            Store = "Main Store",
                            BillingAddress = string.Join(", ",
                                new[] {
                            item.BillAddr?.Line1,
                            item.BillAddr?.Line2,
                            item.BillAddr?.Line3,
                            item.BillAddr?.Line4
                                }.Where(x => !string.IsNullOrWhiteSpace((string?)x))),
                            Subtotal = item.Line != null && item.Line.Count > 0 ? (decimal?)item.Line[item.Line.Count - 1]?.Amount ?? 0 : 0,
                            Total = (decimal?)item.TotalAmt ?? 0,
                            SendLater = false,
                            CreatedAt = DateTime.TryParse((string?)item.MetaData?.CreateTime, out var cAt) ? cAt : DateTime.Now,
                            UpdatedAt = qbLastUpdatedTime
                        };

                        newInvoices.Add(invoice);

                        // Handle line items for new invoice (will be added after invoice is saved)
                        var lineItems = item.Line;
                        if (lineItems != null)
                        {
                            foreach (var lineItem in lineItems)
                            {
                                string lineId = lineItem.Id;
                                if (lineId == null) continue;

                                var lineItemObj = new InvoiceLineItem
                                {
                                    LineId = lineId,
                                    InvoiceId = int.Parse(qbId),
                                    ProductId = (string?)lineItem.SalesItemLineDetail?.ItemRef?.value ?? "Unknown",
                                    Description = (string?)lineItem.Description ?? "",
                                    Quantity = (int?)lineItem.SalesItemLineDetail?.Qty ?? 0,
                                    Rate = (decimal?)lineItem.SalesItemLineDetail?.UnitPrice ?? 0,
                                    Amount = (decimal?)lineItem.Amount ?? 0
                                };

                                newLineItems.Add(lineItemObj);
                            }
                        }
                    }
                    else
                    {
                        // Check if the invoice has been updated in QuickBooks
                        if (existingInvoice.UpdatedAt != qbLastUpdatedTime)
                        {
                            // Update the existing invoice with QuickBooks data
                            existingInvoice.CustomerId = int.TryParse((string?)item.CustomerRef?.value, out var cid) ? cid : existingInvoice.CustomerId;
                            existingInvoice.InvoiceDate = DateTime.TryParse((string?)item.TxnDate, out var invDate) ? invDate : existingInvoice.InvoiceDate;
                            existingInvoice.DueDate = DateTime.TryParse((string?)item.DueDate, out var due) ? due : existingInvoice.DueDate;
                            existingInvoice.BillingAddress = string.Join(", ",
                                new[] {
                            item.BillAddr?.Line1,
                            item.BillAddr?.Line2,
                            item.BillAddr?.Line3,
                            item.BillAddr?.Line4
                                }.Where(x => !string.IsNullOrWhiteSpace((string?)x))) ?? existingInvoice.BillingAddress;
                            existingInvoice.Subtotal = item.Line != null && item.Line.Count > 0 ? (decimal?)item.Line[item.Line.Count - 1]?.Amount ?? existingInvoice.Subtotal : existingInvoice.Subtotal;
                            existingInvoice.Total = (decimal?)item.TotalAmt ?? existingInvoice.Total;
                            existingInvoice.UpdatedAt = qbLastUpdatedTime;

                            updatedInvoices.Add(existingInvoice);

                            // Get existing line items for this invoice
                            var existingLineItems = await _context.InvoiceLineItem
                                .Where(li => li.InvoiceId == existingInvoice.Id)
                                .ToListAsync();

                            // Prepare a list for updated line items
                            var updatedInvoiceLineItems = new List<InvoiceLineItem>();

                            // Handle line items for updated invoice
                            var lineItems = item.Line;
                            if (lineItems != null)
                            {
                                // Remove all existing line items and replace with current ones from QuickBooks
                                _context.InvoiceLineItem.RemoveRange(existingLineItems);

                                foreach (var lineItem in lineItems)
                                {
                                    string lineId = lineItem.Id;
                                    if (lineId == null) continue;

                                    var lineItemObj = new InvoiceLineItem
                                    {
                                        LineId = lineId,
                                        InvoiceId = existingInvoice.Id, // Use local DB ID
                                        ProductId = (string?)lineItem.SalesItemLineDetail?.ItemRef?.value ?? "Unknown",
                                        Description = (string?)lineItem.Description ?? "",
                                        Quantity = (int?)lineItem.SalesItemLineDetail?.Qty ?? 0,
                                        Rate = (decimal?)lineItem.SalesItemLineDetail?.UnitPrice ?? 0,
                                        Amount = (decimal?)lineItem.Amount ?? 0
                                    };

                                    updatedInvoiceLineItems.Add(lineItemObj);
                                }

                                // Store the updated line items
                                updatedLineItems[existingInvoice.Id] = updatedInvoiceLineItems;
                            }
                        }
                    }
                }

                // Save new invoices first to get their IDs
                if (newInvoices.Any())
                {
                    await _context.Invoices.AddRangeAsync(newInvoices);
                    await _context.SaveChangesAsync();

                    // Update the InvoiceId field in line items with the actual DB ID
                    foreach (var lineItem in newLineItems)
                    {
                        var invoice = newInvoices.FirstOrDefault(i => i.InvoiceId == lineItem.InvoiceId);
                        if (invoice != null)
                        {
                            lineItem.InvoiceId = invoice.Id;
                        }
                    }

                    // Now save the line items
                    await _context.InvoiceLineItem.AddRangeAsync(newLineItems);
                    await _context.SaveChangesAsync();
                }

                // Update existing invoices
                if (updatedInvoices.Any())
                {
                    _context.Invoices.UpdateRange(updatedInvoices);
                    await _context.SaveChangesAsync();

                    // Add updated line items
                    foreach (var kvp in updatedLineItems)
                    {
                        await _context.InvoiceLineItem.AddRangeAsync(kvp.Value);
                    }
                    await _context.SaveChangesAsync();
                }

                return Ok(new
                {
                    message = "Invoices synced successfully from QuickBooks.",
                    invoicesAdded = newInvoices.Count,
                    invoicesUpdated = updatedInvoices.Count,
                    lineItemsSynced = newLineItems.Count + updatedLineItems.Values.Sum(list => list.Count)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing invoices from QuickBooks");
                return StatusCode(500, new
                {
                    message = "Error syncing invoices",
                    error = ex.Message,
                    trace = ex.StackTrace
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetInvoices(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? search = null,
            [FromQuery] string? sortBy = "CreatedAt",
            [FromQuery] string? sortDirection = "desc")
        {
            try
            {
                var query = _context.Invoices.AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(i =>
                        EF.Functions.Like(i.InvoiceId.ToString(), $"%{search}%") ||
                        EF.Functions.Like(i.Store, $"%{search}%") ||
                        EF.Functions.Like(i.BillingAddress, $"%{search}%"));
                }

                query = (sortBy?.ToLower(), sortDirection?.ToLower()) switch
                {
                    ("invoicedate", "asc") => query.OrderBy(i => i.InvoiceDate),
                    ("invoicedate", "desc") => query.OrderByDescending(i => i.InvoiceDate),
                    ("duedate", "asc") => query.OrderBy(i => i.DueDate),
                    ("duedate", "desc") => query.OrderByDescending(i => i.DueDate),
                    ("total", "asc") => query.OrderBy(i => i.Total),
                    ("total", "desc") => query.OrderByDescending(i => i.Total),
                    ("createdat", "asc") => query.OrderBy(i => i.CreatedAt),
                    _ => query.OrderByDescending(i => i.CreatedAt),
                };

                var totalRecords = await query.CountAsync();
                var invoices = await query
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .ToListAsync();

                var invoiceIds = invoices.Select(i => i.Id).ToList();
                // Fetch related line items
                var lineItems = await (from li in _context.InvoiceLineItem
                                       where invoiceIds.Contains(li.InvoiceId) // Filter by invoice IDs
                                       select li)
                          .ToListAsync();
                var invoiceDtos = invoices.Select(i => new InvoiceDTOs
                {
                    Id = i.Id,
                    InvoiceId = i.InvoiceId,
                    CustomerId = i.CustomerId,
                    InvoiceDate = i.InvoiceDate,
                    DueDate = i.DueDate,
                    Store = i.Store,
                    BillingAddress = i.BillingAddress,
                    Subtotal = i.Subtotal,
                    Total = i.Total,
                    SendLater = i.SendLater,
                    CreatedAt = i.CreatedAt,
                    UpdatedAt = i.UpdatedAt,
                    LineItems = lineItems.Where(li => li.InvoiceId == i.Id).ToList()
                }).ToList();

                var pagedResponse = new Models.PagedResponse<InvoiceDTOs>(invoiceDtos, page, pageSize, totalRecords);
                return Ok(pagedResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching invoices");
                return StatusCode(500, new
                {
                    message = "Error fetching invoices",
                    error = ex.Message,
                    trace = ex.StackTrace
                });
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateInvoice([FromBody] InvoiceInputModel model)
        {
            try
            {
                // Get access token and realm ID from QuickBooksHelper
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();

                var qbInvoicePayload = new
                {
                    CustomerRef = new { value = model.CustomerId.ToString() },
                    TxnDate = model.InvoiceDate.ToString("yyyy-MM-dd"),
                    DueDate = model.DueDate.ToString("yyyy-MM-dd"),
                    BillAddr = new { Line1 = model.BillingAddress },
                    PrivateNote = model.Store,
                    Line = model.LineItems.Select(li => new
                    {
                        DetailType = "SalesItemLineDetail",
                        Amount = li.Quantity * li.Rate,
                        Description = li.Description,
                        SalesItemLineDetail = new
                        {
                            ItemRef = new { value = li.ProductId.ToString() },
                            Qty = li.Quantity,
                            UnitPrice = li.Rate
                        }
                    }).ToList()
                };

                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var content = new StringContent(JsonConvert.SerializeObject(qbInvoicePayload), Encoding.UTF8, "application/json");
                var response = await httpClient.PostAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice", content);

                if (!response.IsSuccessStatusCode)
                {
                    var errorBody = await response.Content.ReadAsStringAsync();
                    return StatusCode((int)response.StatusCode, $"QuickBooks error: {errorBody}");
                }

                var responseBody = await response.Content.ReadAsStringAsync();
                var jsonResponse = JObject.Parse(responseBody);
                var qbInvoiceId = jsonResponse["Invoice"]?["Id"]?.ToString();
                var qbTotalAmount = jsonResponse["Invoice"]?["TotalAmt"]?.ToObject<decimal>();
                var invoice = new Invoice
                {
                    InvoiceId = int.Parse(qbInvoiceId),
                    CustomerId = model.CustomerId,
                    InvoiceDate = model.InvoiceDate,
                    DueDate = model.DueDate,
                    Store = model.Store,
                    BillingAddress = model.BillingAddress,
                    Subtotal = model.LineItems.Sum(li => li.Quantity * li.Rate),
                    Total = qbTotalAmount ?? 0,
                    SendLater = model.SendLater,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };
                _context.Invoices.Add(invoice);
                await _context.SaveChangesAsync();

                // Save line items
                foreach (var line in model.LineItems)
                {
                    var localLineItem = new InvoiceLineItem
                    {
                        LineId = Guid.NewGuid().ToString(),
                        InvoiceId = invoice.Id,
                        ProductId = line.ProductId.ToString(),
                        Description = line.Description,
                        Quantity = (int)line.Quantity,
                        Rate = line.Rate,
                        Amount = line.Quantity * line.Rate
                    };
                    _context.InvoiceLineItem.Add(localLineItem);
                }

                await _context.SaveChangesAsync();

                return Ok(new { message = "Invoice created successfully", invoiceId = invoice.InvoiceId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating invoice");
                return StatusCode(500, new
                {
                    message = "Failed to create invoice",
                    error = ex.Message,
                    trace = ex.StackTrace
                });
            }
        }

        [HttpPut("{invoiceId}")]
        public async Task<IActionResult> UpdateInvoice(int invoiceId, [FromBody] InvoiceInputModel model)
        {
            try
            {
                // Get access token and realm ID from QuickBooksHelper
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();

                var existingInvoice = await _context.Invoices.FirstOrDefaultAsync(i => i.InvoiceId == invoiceId);
                if (existingInvoice == null)
                    return NotFound("Invoice not found in local DB.");

                // Set up HTTP client for QuickBooks API
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Fetch current invoice data from QuickBooks
                var fetchResponse = await httpClient.GetAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice/{invoiceId}");
                Console.WriteLine(fetchResponse);
                if (!fetchResponse.IsSuccessStatusCode)
                {
                    var fetchError = await fetchResponse.Content.ReadAsStringAsync();
                    return StatusCode((int)fetchResponse.StatusCode, $"QuickBooks fetch error: {fetchError}");
                }

                var fetchBody = await fetchResponse.Content.ReadAsStringAsync();
                Console.WriteLine(fetchBody);
                var jsonInvoice = JObject.Parse(fetchBody)["Invoice"];
                var syncToken = jsonInvoice?["SyncToken"]?.ToString();

                // Synchronize the local DB with QuickBooks data first
                await SynchronizeWithQuickBooksData(existingInvoice, jsonInvoice);

                // Now apply the new changes from the model
                // Prepare updated payload for QuickBooks
                var qbUpdatePayload = new
                {
                    Id = invoiceId.ToString(),
                    SyncToken = syncToken,
                    CustomerRef = new { value = model.CustomerId.ToString() },
                    TxnDate = model.InvoiceDate.ToString("yyyy-MM-dd"),
                    DueDate = model.DueDate.ToString("yyyy-MM-dd"),
                    BillAddr = new { Line1 = model.BillingAddress },
                    PrivateNote = model.Store,
                    Line = model.LineItems.Select(li => new
                    {
                        DetailType = "SalesItemLineDetail",
                        Amount = li.Quantity * li.Rate,
                        Description = li.Description,
                        SalesItemLineDetail = new
                        {
                            ItemRef = new { value = li.ProductId.ToString() },
                            Qty = li.Quantity,
                            UnitPrice = li.Rate
                        }
                    }).ToList()
                };

                // Send update to QuickBooks
                var content = new StringContent(JsonConvert.SerializeObject(qbUpdatePayload), Encoding.UTF8, "application/json");
                var updateResponse = await httpClient.PostAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice?operation=update", content);

                if (!updateResponse.IsSuccessStatusCode)
                {
                    var updateError = await updateResponse.Content.ReadAsStringAsync();
                    return StatusCode((int)updateResponse.StatusCode, $"QuickBooks update error: {updateError}");
                }

                // Update local DB with the new model data
                existingInvoice.CustomerId = model.CustomerId;
                existingInvoice.InvoiceDate = model.InvoiceDate;
                existingInvoice.DueDate = model.DueDate;
                existingInvoice.Store = model.Store;
                existingInvoice.BillingAddress = model.BillingAddress;
                existingInvoice.Subtotal = model.LineItems.Sum(li => li.Quantity * li.Rate);
                existingInvoice.Total = model.LineItems.Sum(li => li.Quantity * li.Rate);
                existingInvoice.SendLater = model.SendLater;
                existingInvoice.UpdatedAt = DateTime.UtcNow;

                // Remove old line items
                var oldLineItems = _context.InvoiceLineItem.Where(li => li.InvoiceId == existingInvoice.Id);
                _context.InvoiceLineItem.RemoveRange(oldLineItems);

                // Add new line items
                foreach (var line in model.LineItems)
                {
                    _context.InvoiceLineItem.Add(new InvoiceLineItem
                    {
                        LineId = Guid.NewGuid().ToString(),
                        InvoiceId = existingInvoice.Id,
                        ProductId = line.ProductId.ToString(),
                        Description = line.Description,
                        Quantity = (int)line.Quantity,
                        Rate = line.Rate,
                        Amount = line.Quantity * line.Rate
                    });
                }

                await _context.SaveChangesAsync();
                return Ok(new { message = "Invoice updated successfully", invoiceId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating invoice");
                return StatusCode(500, new { message = "Update failed", error = ex.Message, trace = ex.StackTrace });
            }
        }

        // Helper method to synchronize local DB with QuickBooks data
        private async Task SynchronizeWithQuickBooksData(Invoice localInvoice, JToken qbInvoice)
        {
            if (qbInvoice == null || localInvoice == null)
                return;

            // Update basic invoice properties from QuickBooks
            if (qbInvoice["CustomerRef"] != null && qbInvoice["CustomerRef"]["value"] != null)
            {
                var customerId = qbInvoice["CustomerRef"]["value"].ToString();
                if (int.TryParse(customerId, out int parsedCustomerId))
                {
                    localInvoice.CustomerId = parsedCustomerId;
                }
            }

            if (qbInvoice["TxnDate"] != null && DateTime.TryParse(qbInvoice["TxnDate"].ToString(), out DateTime txnDate))
            {
                localInvoice.InvoiceDate = txnDate;
            }

            if (qbInvoice["DueDate"] != null && DateTime.TryParse(qbInvoice["DueDate"].ToString(), out DateTime dueDate))
            {
                localInvoice.DueDate = dueDate;
            }

            if (qbInvoice["PrivateNote"] != null)
            {
                localInvoice.Store = qbInvoice["PrivateNote"].ToString();
            }

            if (qbInvoice["BillAddr"] != null && qbInvoice["BillAddr"]["Line1"] != null)
            {
                localInvoice.BillingAddress = qbInvoice["BillAddr"]["Line1"].ToString();
            }

            if (qbInvoice["TotalAmt"] != null && decimal.TryParse(qbInvoice["TotalAmt"].ToString(), out decimal totalAmt))
            {
                localInvoice.Total = totalAmt;
            }

            if (qbInvoice["TxnTaxDetail"] != null && qbInvoice["TxnTaxDetail"]["TotalTax"] != null &&
                decimal.TryParse(qbInvoice["TxnTaxDetail"]["TotalTax"].ToString(), out decimal totalTax))
            {
                localInvoice.Subtotal = localInvoice.Total - totalTax;
            }

            // Handle line items
            if (qbInvoice["Line"] != null && qbInvoice["Line"].Type == JTokenType.Array)
            {
                // Remove existing line items
                var oldLineItems = _context.InvoiceLineItem.Where(li => li.InvoiceId == localInvoice.Id);
                _context.InvoiceLineItem.RemoveRange(oldLineItems);

                // Add line items from QuickBooks
                foreach (var line in qbInvoice["Line"])
                {
                    if (line["DetailType"]?.ToString() == "SalesItemLineDetail")
                    {
                        var salesItemDetail = line["SalesItemLineDetail"];
                        if (salesItemDetail != null)
                        {
                            string productId = salesItemDetail["ItemRef"]?["value"]?.ToString() ?? "";
                            decimal quantity = decimal.TryParse(salesItemDetail["Qty"]?.ToString(), out decimal qty) ? qty : 0;
                            decimal rate = decimal.TryParse(salesItemDetail["UnitPrice"]?.ToString(), out decimal unitPrice) ? unitPrice : 0;

                            _context.InvoiceLineItem.Add(new InvoiceLineItem
                            {
                                LineId = Guid.NewGuid().ToString(),
                                InvoiceId = localInvoice.Id,
                                ProductId = productId,
                                Description = line["Description"]?.ToString() ?? "",
                                Quantity = (int)quantity,
                                Rate = rate,
                                Amount = quantity * rate
                            });
                        }
                    }
                }
            }

            // Save the synchronized data
            await _context.SaveChangesAsync();
        }

        [HttpDelete("{invoiceId}")]
        public async Task<IActionResult> DeleteInvoice(int invoiceId)
        {
            try
            {
                // Get access token and realm ID from QuickBooksHelper
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();

                var existingInvoice = await _context.Invoices.FirstOrDefaultAsync(i => i.InvoiceId == invoiceId);
                if (existingInvoice == null)
                    return NotFound("Invoice not found in local DB.");

                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var fetchResponse = await httpClient.GetAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice/{invoiceId}");
                if (!fetchResponse.IsSuccessStatusCode)
                {
                    var fetchError = await fetchResponse.Content.ReadAsStringAsync();
                    return StatusCode((int)fetchResponse.StatusCode, $"QuickBooks fetch error: {fetchError}");
                }

                var fetchBody = await fetchResponse.Content.ReadAsStringAsync();
                var jsonInvoice = JObject.Parse(fetchBody)["Invoice"];
                var syncToken = jsonInvoice?["SyncToken"]?.ToString();

                var qbDeletePayload = new
                {
                    Id = invoiceId.ToString(),
                    SyncToken = syncToken
                };

                var deleteContent = new StringContent(JsonConvert.SerializeObject(qbDeletePayload), Encoding.UTF8, "application/json");
                var deleteResponse = await httpClient.PostAsync($"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice?operation=delete", deleteContent);

                if (!deleteResponse.IsSuccessStatusCode)
                {
                    var deleteError = await deleteResponse.Content.ReadAsStringAsync();
                    return StatusCode((int)deleteResponse.StatusCode, $"QuickBooks delete error: {deleteError}");
                }

                var lineItems = _context.InvoiceLineItem.Where(li => li.InvoiceId == existingInvoice.Id);
                _context.InvoiceLineItem.RemoveRange(lineItems);
                _context.Invoices.Remove(existingInvoice);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Invoice deleted successfully", invoiceId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting invoice");
                return StatusCode(500, new { message = "Delete failed", error = ex.Message, trace = ex.StackTrace });
            }
        }
    }
}