﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Interfaces;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;
        private readonly ILogger<ProductController> _logger;

        public ProductController(IProductService productService, ILogger<ProductController> logger)
        {
            _productService = productService;
            _logger = logger;
        }

        [HttpGet("fetch-products-from-quickbooks")]
        public async Task<IActionResult> FetchProductsFromQuickBooks()
        {
            try
            {
                var products = await _productService.FetchProductsFromQuickBooks();
                return Ok(products);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching products from QuickBooks");
                return StatusCode(500, $"Error fetching products: {ex.Message}");
            }
        }

        [HttpPost("send-to-quickbooks/{id}")]
        public async Task<IActionResult> SendProductToQuickBooks(int id)
        {
            try
            {
                var result = await _productService.SendProductToQuickBooks(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending product to QuickBooks");
                return StatusCode(500, $"Error sending product to QuickBooks: {ex.Message}");
            }
        }

        [HttpGet("get-all")]
        public async Task<IActionResult> GetAllProducts(
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? search = null,
            [FromQuery] bool includeInactive = false)
        {
            try
            {
                var result = await _productService.GetAllProducts(pageNumber, pageSize, search, includeInactive);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving products");
                return StatusCode(500, $"Error retrieving products: {ex.Message}");
            }
        }

        [HttpPost("create")]
        public async Task<IActionResult> CreateProduct([FromBody] Product product)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var createdProduct = await _productService.CreateProduct(product);
                return CreatedAtAction(nameof(GetProduct), new { id = createdProduct.Id }, createdProduct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating product");
                return StatusCode(500, $"Error creating product: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            try
            {
                var product = await _productService.GetProduct(id);
                return Ok(product);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving product with ID {id}");
                return NotFound($"Product with ID {id} not found");
            }
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product productUpdate)
        {
            if (id != productUpdate.Id)
                return BadRequest("Product ID mismatch");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var updatedProduct = await _productService.UpdateProduct(id, productUpdate);
                return Ok(updatedProduct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating product");
                return StatusCode(500, $"Error updating product: {ex.Message}");
            }
        }

        [HttpPut("update-in-quickbooks/{id}")]
        public async Task<IActionResult> UpdateProductInQuickBooks(int id)
        {
            try
            {
                var result = await _productService.UpdateProductInQuickBooks(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating product in QuickBooks");
                return StatusCode(500, $"Error updating product in QuickBooks: {ex.Message}");
            }
        }

        [HttpPut("deactivate/{id}")]
        public async Task<IActionResult> DeactivateProduct(int id)
        {
            try
            {
                var result = await _productService.DeactivateProduct(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deactivating product");
                return StatusCode(500, $"Error deactivating product: {ex.Message}");
            }
        }

        [HttpPut("make-product-inactive/{quickBooksItemId}")]
        public async Task<IActionResult> MakeProductInactive(string quickBooksItemId)
        {
            try
            {
                var result = await _productService.MakeProductInactive(quickBooksItemId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error making product inactive in QuickBooks");
                return StatusCode(500, $"Error making product inactive in QuickBooks: {ex.Message}");
            }
        }
    }
}