﻿//namespace WebApplication1.Models
//{
//    public class ProductUpdateRequest
//    {
//        public Product Product { get; set; }
//        public bool SyncToQuickBooks { get; set; }
//    }
//}
