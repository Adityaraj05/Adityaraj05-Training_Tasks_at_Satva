﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace WebApplication1.Models
{
    public class Bill
    {
        [Key]
        public int Id { get; set; }
        public string QuickBooksBillId { get; set; }
        public string QuickBooksUserId { get; set; }
        public string? DocNumber { get; set; }
        public string SyncToken { get; set; }
        // Vendor reference
        public string VendorId { get; set; }
        public string? VendorName { get; set; }
        // AP Account reference
        public string? APAccountId { get; set; }
        public string? APAccountName { get; set; }
        // Date information
        public DateTime? TxnDate { get; set; }
        public DateTime? DueDate { get; set; }
        // Financial info
        public decimal? TotalAmt { get; set; }
        public decimal? Balance { get; set; }
        // Currency info
        public string? CurrencyValue { get; set; }
        public string? CurrencyName { get; set; }
        // Memo/Notes
        public string? PrivateNote { get; set; }
        // Status
        public bool? Paid { get; set; }
        // Timestamps
        public DateTime? QuickBooksCreateTime { get; set; }
        public DateTime? QuickBooksLastUpdateTime { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        [InverseProperty("Bill")]
        public ICollection<BillLineItem> LineItems { get; set; }
    }
    public class BillLineItem
    {
        [Key]
        public int Id { get; set; }
        // QuickBooks ID for this line item
        public string? LineId { get; set; }
        public int BillId { get; set; }
        [ForeignKey("BillId")]
        [JsonIgnore]
        public Bill? Bill { get; set; }
        // Line details
        public string? Description { get; set; }
        public string? DetailType { get; set; } // AccountBasedExpenseLineDetail or ItemBasedExpenseLineDetail
        // Account reference (for AccountBasedExpenseLineDetail)
        public string? AccountId { get; set; }
        public string? AccountName { get; set; }
        // Item reference (for ItemBasedExpenseLineDetail)
        public string? ItemId { get; set; }
        public string? ItemName { get; set; }
        // Financial info
        public decimal? Amount { get; set; }
        public decimal? UnitPrice { get; set; }
        public decimal? Quantity { get; set; }
        // Tax info
        public string? TaxCodeId { get; set; }
        // Customer reference (for billable expenses)
        public string? CustomerId { get; set; }
        public string? CustomerName { get; set; }
        public string? BillableStatus { get; set; } // Billable, NotBillable, HasBeenBilled
    }
}