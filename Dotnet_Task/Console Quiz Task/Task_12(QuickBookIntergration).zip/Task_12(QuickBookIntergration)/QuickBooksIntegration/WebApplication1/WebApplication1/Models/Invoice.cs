﻿namespace WebApplication1.Models
{
    // Models/Invoice.cs
    public class Invoice
    {
        public int Id { get; set; } // Primary Key
        public int CustomerId { get; set; }
        public DateTime InvoiceDate { get; set; }
        public int InvoiceId { get; set; }
        public DateTime DueDate { get; set; }
        public string Store { get; set; }
        public string BillingAddress { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Total { get; set; }
        public bool SendLater { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    // Models/InvoiceLineItem.cs
    public class InvoiceLineItem
    {
        public int Id { get; set; }
        public string LineId { get; set; }
        public int InvoiceId { get; set; }
        public string ProductId { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal Rate { get; set; }
        public decimal Amount { get; set; }
    }

}
