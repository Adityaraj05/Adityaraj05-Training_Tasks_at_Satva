﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApplication1.Models
{
    public class BillDto
    {
        // Added [Required] annotation to prevent model validation errors
        [JsonPropertyName("Id")]
        public string? Id { get; set; }

        [JsonPropertyName("DocNumber")]
        public string? DocNumber { get; set; }

        [JsonPropertyName("VendorId")]
        public string VendorId { get; set; } = string.Empty;

        [JsonPropertyName("TxnDate")]
        public DateTime TxnDate { get; set; }

        [JsonPropertyName("DueDate")]
        public DateTime DueDate { get; set; }

        [JsonPropertyName("APAccountId")]
        public string? APAccountId { get; set; }

        [JsonPropertyName("PrivateNote")]
        public string? PrivateNote { get; set; }

        [JsonPropertyName("CurrencyValue")]
        public string? CurrencyValue { get; set; }

        [JsonPropertyName("TotalAmt")]
        public decimal? TotalAmt { get; set; }

        [JsonPropertyName("MailingAddress")]
        public string? MailingAddress { get; set; }

        [JsonPropertyName("Terms")]
        public string? Terms { get; set; }

        [JsonPropertyName("LineItems")]
        public List<BillLineItemDto> LineItems { get; set; } = new List<BillLineItemDto>();
    }

    public class BillLineItemDto
    {
        [JsonPropertyName("Description")]
        public string? Description { get; set; }

        [JsonPropertyName("DetailType")]
        public string DetailType { get; set; } = string.Empty; // AccountBasedExpenseLineDetail or ItemBasedExpenseLineDetail

        // For AccountBasedExpenseLineDetail
        [JsonPropertyName("AccountId")]
        public string? AccountId { get; set; }

        // For ItemBasedExpenseLineDetail
        [JsonPropertyName("ItemId")]
        public string? ItemId { get; set; }

        [JsonPropertyName("UnitPrice")]
        public decimal? UnitPrice { get; set; }

        [JsonPropertyName("Quantity")]
        public decimal? Quantity { get; set; }

        // Common fields
        [JsonPropertyName("Amount")]
        public decimal Amount { get; set; }

        [JsonPropertyName("TaxCodeId")]
        public string? TaxCodeId { get; set; }

        [JsonPropertyName("CustomerId")]
        public string? CustomerId { get; set; }

        [JsonPropertyName("Billable")]
        public bool Billable { get; set; }

        [JsonPropertyName("Taxable")]
        public bool Taxable { get; set; }

        [JsonIgnore]
        public string BillableStatus => Billable ? "Billable" : "NotBillable";
    }
}