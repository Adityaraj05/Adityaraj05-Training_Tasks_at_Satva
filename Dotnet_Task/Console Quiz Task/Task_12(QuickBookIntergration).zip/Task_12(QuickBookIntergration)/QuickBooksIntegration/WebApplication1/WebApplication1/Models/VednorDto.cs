﻿// Models/VendorDto.cs
namespace WebApplication1.Models
{
    public class VendorDto
    {
        public string DisplayName { get; set; }
        public string GivenName { get; set; }
        public string FamilyName { get; set; }
        public string CompanyName { get; set; }
        public bool Vendor1099 { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string WebAddr { get; set; }
        public string BillingLine1 { get; set; }
        public string BillingCity { get; set; }
        public string BillingState { get; set; }
        public string BillingPostalCode { get; set; }
        public string BillingCountry { get; set; }
        public string CurrencyValue { get; set; }
    }
}