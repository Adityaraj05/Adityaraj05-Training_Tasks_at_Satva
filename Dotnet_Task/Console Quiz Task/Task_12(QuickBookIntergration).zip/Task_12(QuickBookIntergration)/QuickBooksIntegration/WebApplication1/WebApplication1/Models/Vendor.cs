﻿// Models/Vendor.cs
using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Vendor
    {
        [Key]
        public int Id { get; set; }
        public string QuickBooksVendorId { get; set; }
        public string QuickBooksUserId { get; set; }
        public string? DisplayName { get; set; }
        public string? GivenName { get; set; }
        public string? FamilyName { get; set; }
        public string? CompanyName { get; set; }
        public bool Active { get; set; }
        public bool?  Vendor1099 { get; set; }
        public decimal?  Balance { get; set; }
        public string? CurrencyValue { get; set; }
        public string? CurrencyName { get; set; }

        // Contact information
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? WebAddr { get; set; }

        // Billing Address
        public string? BillingLine1 { get; set; }
        public string? BillingCity { get; set; }
        public string? BillingState { get; set; }
        public string? BillingPostalCode { get; set; }
        public string? BillingCountry { get; set; }

        // Sync data
        public string SyncToken { get; set; }
        public DateTime? QuickBooksCreateTime { get; set; }
        public DateTime? QuickBooksLastUpdateTime { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}