﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Helpers;
using WebApplication1.Interfaces;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly QuickBooksHelper _quickBooksHelper;
        private readonly ILogger<CustomerService> _logger;

        public CustomerService(
            ApplicationDbContext dbContext,
            QuickBooksHelper quickBooksHelper,
            ILogger<CustomerService> logger)
        {
            _dbContext = dbContext;
            _quickBooksHelper = quickBooksHelper;
            _logger = logger;
        }

        public async Task<object> FetchCustomersFromDbPaginated(int page = 1, int pageSize = 10, string searchTerm = null)
        {
            try
            {
                // Get QuickBooksUserId
                string quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                // Base query filtered by QuickBooksUserId
                var query = _dbContext.Customers
                    .Where(c => c.QuickBooksUserId == quickBooksUserId);

                // Apply search if needed
                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    string likeTerm = $"%{searchTerm}%";
                    query = query.Where(c =>
                        EF.Functions.Like(c.DisplayName, likeTerm) ||
                        EF.Functions.Like(c.CompanyName, likeTerm) ||
                        EF.Functions.Like(c.Phone, likeTerm));
                }

                // Count total records
                var totalRecords = await query.Where(c => c.Active).CountAsync();

                // Get paginated data
                var pagedData = await query
                    .Where(c => c.Active)
                    .OrderBy(c => c.DisplayName)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(c => new
                    {
                        Id = c.Id,
                        DisplayName = c.DisplayName ?? "",
                        CompanyName = c.CompanyName ?? "",
                        Phone = c.Phone ?? "",
                        Balance = c.Balance,
                        Email = c.Email ?? "",
                        BillingStreet1 = c.BillingLine1 ?? "",
                        City = c.BillingCity ?? "",
                        State = c.BillingState ?? "",
                        ZipCode = c.BillingPostalCode ?? "",
                        Country = c.BillingCountry ?? ""
                    })
                    .ToListAsync();

                // Construct response
                var response = new
                {
                    TotalRecords = totalRecords,
                    TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize),
                    CurrentPage = page,
                    PageSize = pageSize,
                    Data = pagedData
                };

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching paginated customers");
                throw;
            }
        }

        public async Task<List<Customer>> FetchCustomersFromQuickBooks()
        {
            try
            {
                // Get access token and realm ID
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();
                string quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                // Fetch customer data from QuickBooks
                var json = await _quickBooksHelper.FetchCustomerDataFromQuickBooks(accessToken, realmId);

                // Parse customer data
                var parsedCustomers = _quickBooksHelper.ParseCustomerData(json, quickBooksUserId);

                using var transaction = await _dbContext.Database.BeginTransactionAsync();

                try
                {
                    foreach (var customer in parsedCustomers)
                    {
                        var existingCustomer = await _dbContext.Customers
                            .FirstOrDefaultAsync(c => c.QuickBooksCustomerId == customer.QuickBooksCustomerId);

                        if (existingCustomer != null)
                        {
                            UpdateCustomerValues(existingCustomer, customer);
                        }
                        else
                        {
                            customer.CreatedAt = DateTime.UtcNow;
                            customer.UpdatedAt = DateTime.UtcNow;
                            await _dbContext.Customers.AddAsync(customer);
                        }
                    }

                    await _dbContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    return parsedCustomers;
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError(ex, "Error processing QuickBooks customer data");
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching customers from QuickBooks");
                throw;
            }
        }

        public async Task<Customer> AddCustomer(CustomerDto customerDto)
        {
            try
            {
                // Get access token and realm ID
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();
                string quickBooksUserId = await _quickBooksHelper.GetQuickBooksUserId();

                // Validate required fields
                if (string.IsNullOrWhiteSpace(customerDto.DisplayName) ||
                    string.IsNullOrWhiteSpace(customerDto.CompanyName) ||
                    string.IsNullOrWhiteSpace(customerDto.Phone))
                {
                    throw new ArgumentException("DisplayName, CompanyName, and Phone are required fields.");
                }

                // Add customer to QuickBooks
                var newCustomerFromQB = await _quickBooksHelper.AddCustomerToQuickBooks(accessToken, realmId, customerDto);

                // Save to local database
                var newCustomer = new Customer
                {
                    QuickBooksUserId = quickBooksUserId,
                    QuickBooksCustomerId = newCustomerFromQB.QuickBooksCustomerId,
                    DisplayName = customerDto.DisplayName,
                    CompanyName = customerDto.CompanyName,
                    Phone = customerDto.Phone,
                    Email = customerDto.Email,
                    BillingLine1 = customerDto.BillingLine1,
                    BillingCity = customerDto.BillingCity,
                    BillingState = customerDto.BillingState,
                    BillingPostalCode = customerDto.BillingPostalCode,
                    BillingCountry = customerDto.BillingCountry,
                    Active = true,
                    Balance = 1000,  // Default balance for new customers
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _dbContext.Customers.Add(newCustomer);
                await _dbContext.SaveChangesAsync();

                return newCustomer;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding customer");
                throw;
            }
        }

        public async Task<Customer> UpdateCustomer(int id, CustomerDto customerDto)
        {
            try
            {
                // Get access token and realm ID
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();

                // Get existing customer from DB
                var existingCustomer = await _dbContext.Customers.FirstOrDefaultAsync(c => c.Id == id);
                if (existingCustomer == null)
                    throw new KeyNotFoundException("Customer not found.");

                // Get SyncToken from QuickBooks
                var syncToken = await _quickBooksHelper.GetCustomerSyncToken(
                    accessToken,
                    realmId,
                    existingCustomer.QuickBooksCustomerId);

                // Update customer in QuickBooks
                await _quickBooksHelper.UpdateCustomerInQuickBooks(
                    accessToken,
                    realmId,
                    existingCustomer.QuickBooksCustomerId,
                    syncToken,
                    customerDto);

                // Update local DB
                existingCustomer.DisplayName = customerDto.DisplayName;
                existingCustomer.CompanyName = customerDto.CompanyName;
                existingCustomer.Phone = customerDto.Phone;
                existingCustomer.Email = customerDto.Email;
                existingCustomer.BillingLine1 = customerDto.BillingLine1;
                existingCustomer.BillingCity = customerDto.BillingCity;
                existingCustomer.BillingState = customerDto.BillingState;
                existingCustomer.BillingPostalCode = customerDto.BillingPostalCode;
                existingCustomer.BillingCountry = customerDto.BillingCountry;
                existingCustomer.UpdatedAt = DateTime.UtcNow;

                await _dbContext.SaveChangesAsync();

                return existingCustomer;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating customer");
                throw;
            }
        }

        public async Task<bool> DeleteCustomer(string id)
        {
            try
            {
                // Get access token and realm ID
                var (accessToken, realmId) = await _quickBooksHelper.GetLatestTokens();

                // Parse local DB ID
                if (!int.TryParse(id, out int parsedId))
                {
                    throw new ArgumentException("Invalid customer ID format.");
                }

                // Get customer from local DB
                var customer = await _dbContext.Customers
                    .FirstOrDefaultAsync(c => c.Id == parsedId);

                if (customer == null)
                    throw new KeyNotFoundException("Customer not found in local DB.");

                // Balance Check
                if (customer.Balance > 0)
                    throw new InvalidOperationException("Cannot delete customer with balance greater than 0.");

                string quickBooksCustomerId = customer.QuickBooksCustomerId;

                try
                {
                    // Get SyncToken
                    var syncToken = await _quickBooksHelper.GetCustomerSyncToken(
                        accessToken,
                        realmId,
                        quickBooksCustomerId);

                    // Mark inactive in QuickBooks
                    await _quickBooksHelper.MarkCustomerInactiveInQuickBooks(
                        accessToken,
                        realmId,
                        quickBooksCustomerId,
                        syncToken,
                        customer.DisplayName,
                        customer.FamilyName);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error during QuickBooks customer delete - continuing with local delete");
                    // If we catch specific errors like "not found", we could handle them here
                }

                // Soft Delete from local DB
                customer.Active = false; // Mark as inactive instead of deleting
                _dbContext.Customers.Update(customer);
                await _dbContext.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting customer");
                throw;
            }
        }

        private void UpdateCustomerValues(Customer existing, Customer source)
        {
            // DO NOT update: Id, QuickBooksCustomerId (acts as foreign key or identifier)

            existing.QuickBooksUserId = source.QuickBooksUserId;
            existing.DisplayName = source.DisplayName;
            existing.CompanyName = source.CompanyName;
            existing.GivenName = source.GivenName;
            existing.MiddleName = source.MiddleName;
            existing.FamilyName = source.FamilyName;
            existing.Title = source.Title;
            existing.Suffix = source.Suffix;
            existing.Email = source.Email;
            existing.Phone = source.Phone;

            existing.BillingLine1 = source.BillingLine1;
            existing.BillingCity = source.BillingCity;
            existing.BillingState = source.BillingState;
            existing.BillingPostalCode = source.BillingPostalCode;
            existing.BillingCountry = source.BillingCountry;

            existing.ShippingLine1 = source.ShippingLine1;
            existing.ShippingCity = source.ShippingCity;
            existing.ShippingState = source.ShippingState;
            existing.ShippingPostalCode = source.ShippingPostalCode;
            existing.ShippingCountry = source.ShippingCountry;

            existing.PreferredDeliveryMethod = source.PreferredDeliveryMethod;
            existing.PrintOnCheckName = source.PrintOnCheckName;
            existing.Active = source.Active;
            existing.Balance = source.Balance;
            existing.Notes = source.Notes;

            existing.QuickBooksCreateTime = source.QuickBooksCreateTime;
            existing.QuickBooksLastUpdateTime = source.QuickBooksLastUpdateTime;
            existing.UpdatedAt = DateTime.UtcNow;
        }
    }
}