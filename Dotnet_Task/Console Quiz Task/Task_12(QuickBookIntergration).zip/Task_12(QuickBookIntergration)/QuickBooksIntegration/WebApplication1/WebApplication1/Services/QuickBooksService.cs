﻿namespace WebApplication1.Services
{
    internal class QuickBooksService
    {
        private object configuration;

        public QuickBooksService(object configuration)
        {
            this.configuration = configuration;
        }
    }
}