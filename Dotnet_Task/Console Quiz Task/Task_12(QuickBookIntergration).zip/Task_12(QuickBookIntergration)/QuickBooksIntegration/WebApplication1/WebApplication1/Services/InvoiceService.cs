﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net.Http;
//using System.Net.Http.Headers;
//using System.Net.Http.Json;
//using System.Text;
//using System.Text.Json;
//using System.Threading.Tasks;
//using Microsoft.EntityFrameworkCore;
//using WebApplication1.Data;
//using WebApplication1.DTOs;
//using WebApplication1.Helpers;
//using WebApplication1.Interfaces;
//using WebApplication1.Models;

//namespace WebApplication1.Services
//{
//    public class InvoiceService : IInvoiceService
//    {
//        private readonly ApplicationDbContext _context;
//        private readonly HttpClient _httpClient;
//        private readonly QuickBooksHelper _quickBooksHelper;

//        public InvoiceService(ApplicationDbContext context, HttpClient httpClient, QuickBooksHelper quickBooksHelper)
//        {
//            _context = context;
//            _httpClient = httpClient;
//            _quickBooksHelper = quickBooksHelper;
//        }

//        public async Task<PaginatedResponse<InvoiceDto>> GetInvoicesAsync(PaginationParams paginationParams)
//        {
//            // Check if headers are available in the current context
//            string realmId = null;
//            string accessToken = null;

//            // If we have HttpContext access, get headers
//            var httpContext = new HttpContextAccessor().HttpContext;
//            if (httpContext != null)
//            {
//                if (httpContext.Request.Headers.TryGetValue("X-QuickBooks-RealmId", out var realmIdValue))
//                    realmId = realmIdValue;

//                if (httpContext.Request.Headers.TryGetValue("Authorization", out var authHeader))
//                {
//                    if (authHeader.ToString().StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
//                    {
//                        accessToken = authHeader.ToString().Substring(7);
//                    }
//                }
//            }

//            List<InvoiceDto> invoiceDtos = new List<InvoiceDto>();
//            int totalCount = 0;

//            // If we have QuickBooks credentials, fetch from API
//            if (!string.IsNullOrEmpty(realmId) && !string.IsNullOrEmpty(accessToken))
//            {
//                try
//                {
//                    // Build query with filters
//                    string query = "SELECT * FROM Invoices";

//                    // Add WHERE clauses if needed
//                    if (!string.IsNullOrEmpty(paginationParams.SearchTerm) || paginationParams.CustomerId.HasValue)
//                    {
//                        query += " WHERE ";
//                        List<string> conditions = new List<string>();

//                        if (!string.IsNullOrEmpty(paginationParams.SearchTerm))
//                        {
//                            conditions.Add($"DocNumber LIKE '%{paginationParams.SearchTerm}%'");
//                        }

//                        if (paginationParams.CustomerId.HasValue)
//                        {
//                            // Get customer's QuickBooks ID
//                            var customer = await _context.Customers.FindAsync(paginationParams.CustomerId.Value);
//                            if (customer != null && !string.IsNullOrEmpty(customer.QuickBooksCustomerId))
//                            {
//                                conditions.Add($"CustomerRef = '{customer.QuickBooksCustomerId}'");
//                            }
//                        }

//                        query += string.Join(" AND ", conditions);
//                    }

//                    // Add ORDER BY clause
//                    string orderByField = "Id";
//                    switch (paginationParams.SortBy?.ToLower())
//                    {
//                        case "invoicedate":
//                            orderByField = "TxnDate";
//                            break;
//                        case "duedate":
//                            orderByField = "DueDate";
//                            break;
//                        case "total":
//                            orderByField = "TotalAmt";
//                            break;
//                        default:
//                            orderByField = "Id";
//                            break;
//                    }

//                    string sortDirection = paginationParams.SortDesc ? "DESC" : "ASC";
//                    query += $" ORDER BY {orderByField} {sortDirection}";

//                    // Add pagination (note: QuickBooks has STARTPOSITION and MAXRESULTS)
//                    int startPosition = (paginationParams.PageNumber - 1) * paginationParams.PageSize + 1;
//                    query += $" STARTPOSITION {startPosition} MAXRESULTS {paginationParams.PageSize}";

//                    // Execute query
//                    var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/query?query={Uri.EscapeDataString(query)}&minorversion=75";

//                    _httpClient.DefaultRequestHeaders.Clear();
//                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
//                    _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//                    var response = await _httpClient.GetAsync(url);
//                    if (response.IsSuccessStatusCode)
//                    {
//                        var content = await response.Content.ReadAsStringAsync();
//                        var jsonDoc = JsonDocument.Parse(content);

//                        // Get total count from QueryResponse
//                        if (jsonDoc.RootElement.TryGetProperty("QueryResponse", out var queryResponse) &&
//                            queryResponse.TryGetProperty("totalCount", out var totalCountElement))
//                        {
//                            totalCount = totalCountElement.GetInt32();
//                        }

//                        // Process invoices
//                        if (jsonDoc.RootElement.TryGetProperty("QueryResponse", out var qr) &&
//                            qr.TryGetProperty("Invoice", out var invoicesElement))
//                        {
//                            foreach (var invoiceElement in invoicesElement.EnumerateArray())
//                            {
//                                // Parse QuickBooks invoice data
//                                var quickBooksInvoiceId = invoiceElement.GetProperty("Id").GetString();

//                                // Check if we already have this invoice in our database
//                                var existingInvoice = await _context.Invoices
//                                    .Include(i => i.Customer)
//                                    .Include(i => i.LineItems)
//                                    .ThenInclude(li => li.Product)
//                                    .FirstOrDefaultAsync(i => i.QuickBooksInvoiceId == quickBooksInvoiceId);

//                                if (existingInvoice != null)
//                                {
//                                    // Use existing invoice data from our database
//                                    invoiceDtos.Add(MapToInvoiceDto(existingInvoice));
//                                }
//                                else
//                                {
//                                    // Create DTO directly from QuickBooks data
//                                    var invoiceDto = new InvoiceDto
//                                    {
//                                        QuickBooksInvoiceId = quickBooksInvoiceId,
//                                        InvoiceDate = DateTime.Parse(invoiceElement.GetProperty("TxnDate").GetString()),
//                                        Total = invoiceElement.GetProperty("TotalAmt").GetDecimal()
//                                    };

//                                    // Get customer info if available
//                                    if (invoiceElement.TryGetProperty("CustomerRef", out var customerRef))
//                                    {
//                                        var quickbooksCustomerId = customerRef.GetProperty("value").GetString();
//                                        var customer = await _context.Customers
//                                            .FirstOrDefaultAsync(c => c.QuickBooksCustomerId == quickbooksCustomerId);

//                                        if (customer != null)
//                                        {
//                                            invoiceDto.CustomerId = customer.Id;
//                                            invoiceDto.CustomerName = customer.DisplayName;
//                                            invoiceDto.CustomerEmail = customer.Email;
//                                        }
//                                        else
//                                        {
//                                            // Use name from QuickBooks if we don't have the customer in our DB
//                                            invoiceDto.CustomerName = customerRef.TryGetProperty("name", out var customerName)
//                                                ? customerName.GetString()
//                                                : "Unknown Customer";
//                                        }
//                                    }

//                                    // Get Due Date if available
//                                    if (invoiceElement.TryGetProperty("DueDate", out var dueDate))
//                                    {
//                                        invoiceDto.DueDate = DateTime.Parse(dueDate.GetString());
//                                    }

//                                    // Add line items if available
//                                    if (invoiceElement.TryGetProperty("Line", out var lineItems))
//                                    {
//                                        var lineItemDtos = new List<InvoiceLineItemDto>();

//                                        foreach (var lineItem in lineItems.EnumerateArray())
//                                        {
//                                            if (lineItem.TryGetProperty("DetailType", out var detailType) &&
//                                                detailType.GetString() == "SalesItemLineDetail")
//                                            {
//                                                var lineItemDto = new InvoiceLineItemDto();

//                                                if (lineItem.TryGetProperty("Description", out var description))
//                                                    lineItemDto.Description = description.GetString();

//                                                if (lineItem.TryGetProperty("Amount", out var amount))
//                                                    lineItemDto.Amount = amount.GetDecimal();

//                                                if (lineItem.TryGetProperty("SalesItemLineDetail", out var detail))
//                                                {
//                                                    if (detail.TryGetProperty("Qty", out var qty))
//                                                        lineItemDto.Quantity = qty.GetDecimal();

//                                                    if (detail.TryGetProperty("UnitPrice", out var unitPrice))
//                                                        lineItemDto.Rate = unitPrice.GetDecimal();

//                                                    if (detail.TryGetProperty("ItemRef", out var itemRef))
//                                                    {
//                                                        var itemId = itemRef.GetProperty("value").GetString();
//                                                        var product = await _context.Products
//                                                            .FirstOrDefaultAsync(p => p.QuickBooksItemId == itemId);

//                                                        if (product != null)
//                                                        {
//                                                            lineItemDto.ProductId = product.Id;
//                                                            lineItemDto.ProductName = product.Name;
//                                                        }
//                                                        else if (itemRef.TryGetProperty("name", out var itemName))
//                                                        {
//                                                            lineItemDto.ProductName = itemName.GetString();
//                                                        }
//                                                    }
//                                                }

//                                                lineItemDtos.Add(lineItemDto);
//                                            }
//                                        }

//                                        invoiceDto.LineItems = lineItemDtos;
//                                    }

//                                    invoiceDtos.Add(invoiceDto);
//                                }
//                            }
//                        }
//                    }
//                    else
//                    {
//                        var errorContent = await response.Content.ReadAsStringAsync();
//                        throw new Exception($"Failed to fetch invoices from QuickBooks: {errorContent}");
//                    }
//                }
//                catch (Exception ex)
//                {
//                    // If QuickBooks API fails, fall back to local database
//                    Console.WriteLine($"Error fetching from QuickBooks: {ex.Message}");
//                }
//            }

//            // If we couldn't get data from QuickBooks or don't have credentials, fall back to database
//            if (invoiceDtos.Count == 0)
//            {
//                var query = _context.Invoices
//                    .Include(i => i.Customer)
//                    .Include(i => i.LineItems)
//                    .ThenInclude(li => li.Product)
//                    .AsQueryable();

//                // Apply filtering
//                if (!string.IsNullOrEmpty(paginationParams.SearchTerm))
//                {
//                    var searchTerm = paginationParams.SearchTerm.ToLower();
//                    query = query.Where(i =>
//                        i.Customer.DisplayName.ToLower().Contains(searchTerm) ||
//                        i.Customer.CompanyName.ToLower().Contains(searchTerm) ||
//                        i.QuickBooksInvoiceId.ToLower().Contains(searchTerm)
//                    );
//                }

//                if (paginationParams.CustomerId.HasValue)
//                {
//                    query = query.Where(i => i.CustomerId == paginationParams.CustomerId.Value);
//                }

//                // Apply sorting
//                switch (paginationParams.SortBy?.ToLower())
//                {
//                    case "customer":
//                        query = paginationParams.SortDesc
//                            ? query.OrderByDescending(i => i.Customer.DisplayName)
//                            : query.OrderBy(i => i.Customer.DisplayName);
//                        break;
//                    case "invoicedate":
//                        query = paginationParams.SortDesc
//                            ? query.OrderByDescending(i => i.InvoiceDate)
//                            : query.OrderBy(i => i.InvoiceDate);
//                        break;
//                    case "duedate":
//                        query = paginationParams.SortDesc
//                            ? query.OrderByDescending(i => i.DueDate)
//                            : query.OrderBy(i => i.DueDate);
//                        break;
//                    case "total":
//                        query = paginationParams.SortDesc
//                            ? query.OrderByDescending(i => i.Total)
//                            : query.OrderBy(i => i.Total);
//                        break;
//                    default:
//                        query = paginationParams.SortDesc
//                            ? query.OrderByDescending(i => i.Id)
//                            : query.OrderBy(i => i.Id);
//                        break;
//                }

//                totalCount = await query.CountAsync();

//                var invoices = await query
//                    .Skip((paginationParams.PageNumber - 1) * paginationParams.PageSize)
//                    .Take(paginationParams.PageSize)
//                    .ToListAsync();

//                invoiceDtos = invoices.Select(MapToInvoiceDto).ToList();
//            }

//            return new PaginatedResponse<InvoiceDto>(invoiceDtos, totalCount, paginationParams);
//        }

//        public async Task<InvoiceDto> GetInvoiceByIdAsync(int id)
//        {
//            var invoice = await _context.Invoices
//                .Include(i => i.Customer)
//                .Include(i => i.LineItems)
//                .ThenInclude(li => li.Product)
//                .FirstOrDefaultAsync(i => i.Id == id);

//            if (invoice == null)
//                return null;

//            return MapToInvoiceDto(invoice);
//        }

//        public async Task<InvoiceDto> CreateInvoiceAsync(InvoiceDto invoiceDto, string realmId, string accessToken)
//        {
//            // Create in QuickBooks first
//            var quickbooksInvoice = await CreateInvoiceInQuickBooksAsync(invoiceDto, realmId, accessToken);

//            // Create in local database
//            var invoice = new Invoice
//            {
//                QuickBooksInvoiceId = quickbooksInvoice.Id,
//                CustomerId = invoiceDto.CustomerId,
//                InvoiceDate = invoiceDto.InvoiceDate,
//                DueDate = invoiceDto.DueDate,
//                Store = invoiceDto.Store,
//                BillingAddress = invoiceDto.BillingAddress,
//                Subtotal = invoiceDto.Subtotal,
//                Total = invoiceDto.Total,
//                SendLater = invoiceDto.SendLater,
//                CreatedAt = DateTime.UtcNow,
//                UpdatedAt = DateTime.UtcNow
//            };

//            _context.Invoices.Add(invoice);
//            await _context.SaveChangesAsync();

//            // Add line items
//            foreach (var itemDto in invoiceDto.LineItems)
//            {
//                var lineItem = new InvoiceLineItem
//                {
//                    InvoiceId = invoice.Id,
//                    ProductId = itemDto.ProductId,
//                    Description = itemDto.Description,
//                    Quantity = itemDto.Quantity,
//                    Rate = itemDto.Rate,
//                    Amount = itemDto.Amount
//                };

//                _context.InvoiceLineItems.Add(lineItem);
//            }

//            await _context.SaveChangesAsync();

//            return await GetInvoiceByIdAsync(invoice.Id);
//        }

//        public async Task<InvoiceDto> UpdateInvoiceAsync(int id, InvoiceDto invoiceDto, string realmId, string accessToken)
//        {
//            var invoice = await _context.Invoices
//                .Include(i => i.LineItems)
//                .FirstOrDefaultAsync(i => i.Id == id);

//            if (invoice == null)
//                return null;

//            // Update in QuickBooks first
//            await UpdateInvoiceInQuickBooksAsync(invoice.QuickBooksInvoiceId, invoiceDto, realmId, accessToken);

//            // Update local database
//            invoice.CustomerId = invoiceDto.CustomerId;
//            invoice.InvoiceDate = invoiceDto.InvoiceDate;
//            invoice.DueDate = invoiceDto.DueDate;
//            invoice.Store = invoiceDto.Store;
//            invoice.BillingAddress = invoiceDto.BillingAddress;
//            invoice.Subtotal = invoiceDto.Subtotal;
//            invoice.Total = invoiceDto.Total;
//            invoice.SendLater = invoiceDto.SendLater;
//            invoice.UpdatedAt = DateTime.UtcNow;

//            // Remove existing line items
//            _context.InvoiceLineItems.RemoveRange(invoice.LineItems);

//            // Add updated line items
//            foreach (var itemDto in invoiceDto.LineItems)
//            {
//                var lineItem = new InvoiceLineItem
//                {
//                    InvoiceId = invoice.Id,
//                    ProductId = itemDto.ProductId,
//                    Description = itemDto.Description,
//                    Quantity = itemDto.Quantity,
//                    Rate = itemDto.Rate,
//                    Amount = itemDto.Amount
//                };

//                _context.InvoiceLineItems.Add(lineItem);
//            }

//            await _context.SaveChangesAsync();

//            return await GetInvoiceByIdAsync(invoice.Id);
//        }

//        public async Task<bool> DeleteInvoiceAsync(int id, string realmId, string accessToken)
//        {
//            var invoice = await _context.Invoices.FindAsync(id);
//            if (invoice == null)
//                return false;

//            // Delete from QuickBooks first
//            await DeleteInvoiceFromQuickBooksAsync(invoice.QuickBooksInvoiceId, realmId, accessToken);

//            // Delete from local database
//            _context.Invoices.Remove(invoice);
//            await _context.SaveChangesAsync();

//            return true;
//        }

//        public async Task<byte[]> GetInvoicePdfAsync(int id, string realmId, string accessToken)
//        {
//            var invoice = await _context.Invoices.FindAsync(id);
//            if (invoice == null)
//                return null;

//            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice/{invoice.QuickBooksInvoiceId}/pdf?minorversion=75";

//            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

//            var response = await _httpClient.GetAsync(url);
//            if (!response.IsSuccessStatusCode)
//                return null;

//            return await response.Content.ReadAsByteArrayAsync();
//        }

//        public async Task<bool> SendInvoiceByEmailAsync(int id, string emailAddress, string realmId, string accessToken)
//        {
//            var invoice = await _context.Invoices.FindAsync(id);
//            if (invoice == null)
//                return false;

//            string url;
//            if (string.IsNullOrEmpty(emailAddress))
//            {
//                url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice/{invoice.QuickBooksInvoiceId}/send";
//            }
//            else
//            {
//                url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice/{invoice.QuickBooksInvoiceId}/send?sendTo={Uri.EscapeDataString(emailAddress)}&minorversion=75";
//            }

//            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

//            var response = await _httpClient.PostAsync(url, null);
//            return response.IsSuccessStatusCode;
//        }

//        // Helper methods for QuickBooks API operations
//        private async Task<dynamic> CreateInvoiceInQuickBooksAsync(InvoiceDto invoiceDto, string realmId, string accessToken)
//        {
//            var customer = await _context.Customers.FindAsync(invoiceDto.CustomerId);
//            if (customer == null)
//                throw new Exception("Customer not found");

//            var lineItems = new List<object>();

//            foreach (var item in invoiceDto.LineItems)
//            {
//                var product = await _context.Products.FindAsync(item.ProductId);
//                if (product == null)
//                    throw new Exception($"Product with ID {item.ProductId} not found");

//                lineItems.Add(new
//                {
//                    DetailType = "SalesItemLineDetail",
//                    Amount = item.Amount,
//                    Description = item.Description,
//                    SalesItemLineDetail = new
//                    {
//                        ItemRef = new
//                        {
//                            value = product.QuickBooksItemId,
//                            name = product.Name
//                        },
//                        Qty = item.Quantity,
//                        UnitPrice = item.Rate
//                    }
//                });
//            }

//            var payload = new
//            {
//                CustomerRef = new
//                {
//                    value = customer.QuickBooksCustomerId
//                },
//                TxnDate = invoiceDto.InvoiceDate.ToString("yyyy-MM-dd"),
//                DueDate = invoiceDto.DueDate.ToString("yyyy-MM-dd"),
//                Line = lineItems,
//                BillEmail = new
//                {
//                    Address = customer.Email
//                }
//            };

//            var url = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice?minorversion=75";

//            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
//            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//            var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
//            var response = await _httpClient.PostAsync(url, content);

//            if (!response.IsSuccessStatusCode)
//            {
//                var errorContent = await response.Content.ReadAsStringAsync();
//                throw new Exception($"Failed to create invoice in QuickBooks: {errorContent}");
//            }

//            var responseContent = await response.Content.ReadFromJsonAsync<dynamic>();
//            return responseContent.Invoice;
//        }

//        private async Task<dynamic> UpdateInvoiceInQuickBooksAsync(string quickbooksInvoiceId, InvoiceDto invoiceDto, string realmId, string accessToken)
//        {
//            // First get the current invoice from QuickBooks to get the SyncToken
//            var getUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice/{quickbooksInvoiceId}?minorversion=75";

//            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
//            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//            var getResponse = await _httpClient.GetAsync(getUrl);
//            if (!getResponse.IsSuccessStatusCode)
//            {
//                var errorContent = await getResponse.Content.ReadAsStringAsync();
//                throw new Exception($"Failed to get invoice from QuickBooks: {errorContent}");
//            }

//            var existingInvoice = await getResponse.Content.ReadFromJsonAsync<dynamic>();
//            var syncToken = existingInvoice.Invoice.SyncToken.ToString();

//            // Prepare the update payload
//            var customer = await _context.Customers.FindAsync(invoiceDto.CustomerId);
//            if (customer == null)
//                throw new Exception("Customer not found");

//            var lineItems = new List<object>();

//            foreach (var item in invoiceDto.LineItems)
//            {
//                var product = await _context.Products.FindAsync(item.ProductId);
//                if (product == null)
//                    throw new Exception($"Product with ID {item.ProductId} not found");

//                lineItems.Add(new
//                {
//                    DetailType = "SalesItemLineDetail",
//                    Amount = item.Amount,
//                    Description = item.Description,
//                    SalesItemLineDetail = new
//                    {
//                        ItemRef = new
//                        {
//                            value = product.QuickBooksItemId,
//                            name = product.Name
//                        },
//                        Qty = item.Quantity,
//                        UnitPrice = item.Rate
//                    }
//                });
//            }

//            var payload = new
//            {
//                Id = quickbooksInvoiceId,
//                SyncToken = syncToken,
//                CustomerRef = new
//                {
//                    value = customer.QuickBooksCustomerId
//                },
//                TxnDate = invoiceDto.InvoiceDate.ToString("yyyy-MM-dd"),
//                DueDate = invoiceDto.DueDate.ToString("yyyy-MM-dd"),
//                Line = lineItems,
//                BillEmail = new
//                {
//                    Address = customer.Email
//                }
//            };

//            var updateUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice?minorversion=75";
//            var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
//            var response = await _httpClient.PostAsync(updateUrl, content);

//            if (!response.IsSuccessStatusCode)
//            {
//                var errorContent = await response.Content.ReadAsStringAsync();
//                throw new Exception($"Failed to update invoice in QuickBooks: {errorContent}");
//            }

//            var responseContent = await response.Content.ReadFromJsonAsync<dynamic>();
//            return responseContent.Invoice;
//        }

//        private async Task DeleteInvoiceFromQuickBooksAsync(string quickbooksInvoiceId, string realmId, string accessToken)
//        {
//            // First get the current invoice from QuickBooks to get the SyncToken
//            var getUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice/{quickbooksInvoiceId}?minorversion=75";

//            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
//            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//            var getResponse = await _httpClient.GetAsync(getUrl);
//            if (!getResponse.IsSuccessStatusCode)
//            {
//                var errorContent = await getResponse.Content.ReadAsStringAsync();
//                throw new Exception($"Failed to get invoice from QuickBooks: {errorContent}");
//            }

//            var existingInvoice = await getResponse.Content.ReadFromJsonAsync<dynamic>();
//            var syncToken = existingInvoice.Invoice.SyncToken.ToString();

//            // Prepare the delete payload
//            var payload = new
//            {
//                Id = quickbooksInvoiceId,
//                SyncToken = syncToken
//            };

//            var deleteUrl = $"https://sandbox-quickbooks.api.intuit.com/v3/company/{realmId}/invoice?operation=delete&minorversion=75";
//            var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
//            var response = await _httpClient.PostAsync(deleteUrl, content);

//            if (!response.IsSuccessStatusCode)
//            {
//                var errorContent = await response.Content.ReadAsStringAsync();
//                throw new Exception($"Failed to delete invoice from QuickBooks: {errorContent}");
//            }
//        }

//        private InvoiceDto MapToInvoiceDto(Invoice invoice)
//        {
//            return new InvoiceDto
//            {
//                Id = invoice.Id,
//                QuickBooksInvoiceId = invoice.QuickBooksInvoiceId,
//                CustomerId = invoice.CustomerId,
//                CustomerName = invoice.Customer?.DisplayName ?? "",
//                CustomerEmail = invoice.Customer?.Email ?? "",
//                InvoiceDate = invoice.InvoiceDate,
//                DueDate = invoice.DueDate,
//                Store = invoice.Store,
//                BillingAddress = invoice.BillingAddress,
//                Subtotal = invoice.Subtotal,
//                Total = invoice.Total,
//                SendLater = invoice.SendLater,
//                LineItems = invoice.LineItems?.Select(li => new InvoiceLineItemDto
//                {
//                    Id = li.Id,
//                    ProductId = li.ProductId,
//                    ProductName = li.Product?.Name ?? "",
//                    Description = li.Description,
//                    Quantity = li.Quantity,
//                    Rate = li.Rate,
//                    Amount = li.Amount
//                }).ToList() ?? new List<InvoiceLineItemDto>()
//            };
//        }
//    }
//}