// Task5.2/Program.cs
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Task5._2.Middleware;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    // Note: Exception handling middleware should be registered before any other middleware that might throw exceptions
    app.UseExceptionHandling();
}
else
{
    app.UseExceptionHandling();
    // The default HSTS value is 30 days. You may want to change this for production scenarios.
    app.UseHsts();
}

// Register request logging middleware early in the pipeline
app.UseRequestLogging();

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();