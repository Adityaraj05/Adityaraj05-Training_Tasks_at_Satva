﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace Task5._2.Controllers
{
    public class TestController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Success()
        {
            return Content("This endpoint executed successfully!");
        }

        public IActionResult Error()
        {
            // This will trigger the exception handling middleware
            throw new Exception("This is a test exception to demonstrate the exception handling middleware.");
        }
    }
}