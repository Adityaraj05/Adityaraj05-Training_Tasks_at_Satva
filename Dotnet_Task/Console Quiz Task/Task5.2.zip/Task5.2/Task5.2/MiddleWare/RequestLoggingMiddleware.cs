﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Task5._2.Middleware
{
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestLoggingMiddleware> _logger;
        private readonly string _logFilePath;

        public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;

            // Create logs directory if it doesn't exist
            string logsDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Logs");
            if (!Directory.Exists(logsDirectory))
            {
                Directory.CreateDirectory(logsDirectory);
            }

            _logFilePath = Path.Combine(logsDirectory, "request_logs.txt");
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Log request details
            string logMessage = $"[{DateTime.Now}] {context.Request.Method} {context.Request.Path}{context.Request.QueryString}";

            // Log to console via ILogger
            _logger.LogInformation(logMessage);

            // Log to file
            await File.AppendAllTextAsync(_logFilePath, logMessage + Environment.NewLine);

            // Call the next delegate/middleware in the pipeline
            await _next(context);
        }
    }
}