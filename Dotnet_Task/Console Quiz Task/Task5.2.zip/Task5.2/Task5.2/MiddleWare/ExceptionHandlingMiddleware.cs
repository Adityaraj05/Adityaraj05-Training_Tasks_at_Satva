﻿using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Task5._2.Middleware
{
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;
        private readonly string _logFilePath;

        public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;

            // Create logs directory if it doesn't exist
            string logsDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Logs");
            if (!Directory.Exists(logsDirectory))
            {
                Directory.CreateDirectory(logsDirectory);
            }

            _logFilePath = Path.Combine(logsDirectory, "error_logs.txt");
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            // Log the error details
            string errorMessage = $"[{DateTime.Now}] Error: {exception.Message}{Environment.NewLine}StackTrace: {exception.StackTrace}";

            // Log to console via ILogger
            _logger.LogError(exception, "An unhandled exception has occurred");

            // Log to file
            await File.AppendAllTextAsync(_logFilePath, errorMessage + Environment.NewLine + Environment.NewLine);

            // Create a friendly response for the user
            var response = new
            {
                StatusCode = 500,
                Message = "An unexpected error occurred. Please try again later."
            };

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = 500;

            // Write the response to the client
            await context.Response.WriteAsync(JsonSerializer.Serialize(response));
        }
    }
}