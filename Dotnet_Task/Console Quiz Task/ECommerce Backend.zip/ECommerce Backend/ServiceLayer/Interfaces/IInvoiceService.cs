﻿using DataAccessLayer.Models;
using SharedResources.DTOS;


namespace ServiceLayer.Interfaces
{
    public interface IInvoiceService
    {
        Task<Invoice> GenerateInvoiceForSellerAsync(int orderId, int sellerId);
        Task<byte[]> ExportInvoicePdfAsync(int invoiceId);
        Task<List<InvoiceDto>> GetInvoiceBySellerIdAsync(int sellerId);
    }
}
