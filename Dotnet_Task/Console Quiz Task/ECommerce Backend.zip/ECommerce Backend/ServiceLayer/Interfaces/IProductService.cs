﻿using DataAccessLayer.Models;
using SharedResources.DTOS;


namespace ServiceLayer.Interfaces
{
    public interface IProductService
    {
        Task<ServiceResponse<ProductDto>> GetProductByIdAsync(int id);
        Task<IEnumerable<ProductDto>> GetAllProductsAsync();
        Task<IEnumerable<ProductDto>> GetProductsBySupplierAsync(int supplierId);
        Task<ServiceResponse<int>> AddProductAsync(AddProductDto dto, int supplierId);
        Task<ServiceResponse<int>> UpdateProductAsync(int productId, AddProductDto dto, int supplierId);
        Task<ServiceResponse<int>> SoftDeleteProductAsync(int productId, int userId, bool isAdmin);
        Task<ServiceResponse<int>> ReactivateProductAsync(int productId, int userId, bool isAdmin);
        Task<ServiceResponse<List<ProVarDto>>> GetProductVariantsByProductIdAsync(int productId);
    }

}
