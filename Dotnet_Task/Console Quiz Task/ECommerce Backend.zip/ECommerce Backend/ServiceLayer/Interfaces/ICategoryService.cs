﻿using SharedResources.DTOS;


namespace ServiceLayer.Interfaces
{
    public interface ICategoryService
    {
        Task<List<CategoryDto>> GetAllCategoriesAsync();

    }
}
