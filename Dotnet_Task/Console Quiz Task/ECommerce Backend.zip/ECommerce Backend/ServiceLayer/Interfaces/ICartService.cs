﻿using DataAccessLayer.Models;
using SharedResources.DTOS;


namespace ServiceLayer.Interfaces
{
    public interface ICartService
    {
        Task<ServiceResponse<int>> AddToCartAsync(int productId, int userId, int quantity);
        Task<ServiceResponse<CartDto?>> GetCartByUserIdAsync(int userId);
        Task<ServiceResponse<bool>> RemoveFromCartAsync(int cartItemId, int userId);
        Task<ServiceResponse<bool>> UpdateCartItemQuantityAsync(int productId, int userId, int quantity);
        Task<ServiceResponse<bool>> ClearCartAsync(int userId);
    }
}
