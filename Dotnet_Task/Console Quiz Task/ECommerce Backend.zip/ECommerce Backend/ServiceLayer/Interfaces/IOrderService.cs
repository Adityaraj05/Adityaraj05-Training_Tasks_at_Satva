﻿using DataAccessLayer.Models;
using SharedResources.DTOS;

namespace ServiceLayer.Interfaces
{
    public interface IOrderService
    {
        Task<ServiceResponse<List<OrderDto>>> GetAllOrdersAsync();
        Task<ServiceResponse<Order?>> PlaceOrderAsync(OrderDto orderDto);
        Task<ServiceResponse<int>> ApproveOrderItemAsync(int orderItemId, int supplierId);
        Task<ServiceResponse<int>> RejectOrderItemAsync(int orderItemId, int supplierId);
        Task<ServiceResponse<List<PendingOrderItemDto>>> GetOrderItemsBySupplierAsync(int supplierId, string status);
    }
}
