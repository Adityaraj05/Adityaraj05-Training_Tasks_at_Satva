﻿using SharedResources.DTOS;


namespace ServiceLayer.Interfaces
{
    public interface IUserService
    {
        Task<List<SupplierDTO>> GetPendingSuppliersAsync();
        Task<ServiceResponse<string>> ApproveSupplierAsync(int userId);
        Task<List<SupplierDTO>> GetActiveSuppliersAsync();
        Task<List<CustomerDTO>> GetAllCustomersAsync();
        Task<ServiceResponse<bool>> ToggleUserActivationAsync(int id);
        Task<ServiceResponse<List<AddressDto>>> GetAddressesByUserIdAsync(int userId);
    }

}
