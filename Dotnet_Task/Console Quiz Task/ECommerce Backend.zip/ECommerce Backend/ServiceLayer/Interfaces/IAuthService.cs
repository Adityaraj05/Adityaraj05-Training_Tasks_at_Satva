﻿
using SharedResources.DTOS;

namespace ServiceLayer.Interfaces
{
    public interface IAuthService
    {
        public Task<ServiceResponse<string>> RegisterUserAsync(RegisterDto registerDto);
        public  Task<ServiceResponse<TokenRequestDto>> LoginUserAsync(LoginDto loginDto);
        Task<ServiceResponse<TokenRequestDto>> RefreshTokenAsync(string refreshToken);
        Task<ServiceResponse<bool>> LogoutAsync(string refreshToken);
    }
}
