﻿using DataAccessLayer.Models;
using SharedResources.DTOS;

namespace ServiceLayer.Utils
{
    public static class OrderMappingHelper
    {
        public static Order MapToOrder(OrderDto orderDto)
        {
            return new Order
            {
                UserId = orderDto.UserId,
                TotalAmount = orderDto.TotalAmount,
                Status = "Pending",
                ShippingAddressId = orderDto.ShippingAddressId,
                BillingAddressId = orderDto.BillingAddressId,
                OrderNotes = orderDto.OrderNotes,
                TrackingNumber = orderDto.TrackingNumber,
                ShippingProvider = orderDto.ShippingProvider,
                OrderDate = DateTime.UtcNow,
                OrderItems = orderDto.OrderItems.Select(oi => new OrderItem
                {
                    ProductId = oi.ProductId,
                    ProductVariantId = oi.ProductVariantId,
                    Quantity = oi.Quantity,
                    Status = "Pending",
                    Price = oi.Price, 
                }).ToList()
            };
        }
    }

}
