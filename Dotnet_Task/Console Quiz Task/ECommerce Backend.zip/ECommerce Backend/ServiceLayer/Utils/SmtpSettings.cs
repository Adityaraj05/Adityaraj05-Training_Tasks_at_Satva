﻿namespace ServiceLayer.Utils
{
    public class SmtpSettings
    {
        public string? SmtpServer { get; set; }
        public int SmtpPort { get; set; }
        public string? SenderEmail { get; set; }
        public string? SenderPassword { get; set; }
        public string? AdminEmail { get; set; }
    }


}
