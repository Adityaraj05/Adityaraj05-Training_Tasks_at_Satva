﻿using DataAccessLayer.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using RepositoryLayer.Interfaces;
using SharedResources.DTOS;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace ServiceLayer.Utils
{
    public class HelperClass
    {
        private readonly IConfiguration _config;
        private readonly IAddressRepository _addressRepository;

        public HelperClass(IConfiguration config, IAddressRepository addressRepository)
        {
            _config = config;
            _addressRepository = addressRepository;
        }

        public string GenerateToken(User user)
        {
            var roles = user.UserRoles!.Select(ur => ur.Role!.Name).ToList();

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Email, user.Email!)
            };

            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role!));
            }

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        public string GenerateRefreshToken()
        {
            var randomBytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomBytes);
            return Convert.ToBase64String(randomBytes);
        }
        public async Task AddAddressAsync(RegisterDto dto, User user, string addressType)
        {
            string? line1, line2, city, state, postalCode, country;

            if (addressType == "ShippingAddress")
            {
                line1 = dto.Line1;
                line2 = dto.Line2;
                city = dto.City;
                state = dto.State;
                postalCode = dto.PostalCode;
                country = dto.Country;
            }
            else if (addressType == "BillingAddress")
            {
                line1 = dto.ShopLine1;
                line2 = dto.ShopLine2;
                city = dto.ShopCity;
                state = dto.ShopState;
                postalCode = dto.ShopPostalCode;
                country = dto.ShopCountry;
            }
            else
            {
                throw new ArgumentException("Invalid address type.");
            }

            if (!string.IsNullOrWhiteSpace(line1) ||
                !string.IsNullOrWhiteSpace(line2) ||
                !string.IsNullOrWhiteSpace(city) ||
                !string.IsNullOrWhiteSpace(state) ||
                !string.IsNullOrWhiteSpace(postalCode) ||
                !string.IsNullOrWhiteSpace(country))
            {
                var address = new Address
                {
                    Line1 = line1,
                    Line2 = line2,
                    City = city,
                    State = state,
                    PostalCode = postalCode,
                    Country = country,
                    AddressType = addressType, 
                    UserId = user.Id
                };

                await _addressRepository.AddAsync(address);
                await _addressRepository.SaveChangesAsync();
            }
        }

    }
}
