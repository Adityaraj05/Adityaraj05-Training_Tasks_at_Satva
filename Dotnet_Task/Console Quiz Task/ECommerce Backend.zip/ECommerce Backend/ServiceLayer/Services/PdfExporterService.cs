﻿using DataAccessLayer.Models;
using ServiceLayer.Interfaces;


namespace ServiceLayer.Services
{
    public class PdfExporterService : IPdfExporterService
    {
        private readonly InvoicePdfService _invoicePdfService;

        public PdfExporterService(InvoicePdfService invoicePdfService)
        {
            _invoicePdfService = invoicePdfService;
        }

        public byte[] GenerateInvoicePdf(Invoice invoice)
        {
            return _invoicePdfService.GenerateInvoicePdf(invoice);
        }
    }

}
