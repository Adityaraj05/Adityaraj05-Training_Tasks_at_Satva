﻿using DataAccessLayer.Models;
using RepositoryLayer.Interfaces;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;


namespace ServiceLayer.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<ServiceResponse<ProductDto>> GetProductByIdAsync(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);

            if (product == null)
                return ServiceResponse<ProductDto>.Fail("Product does not exist!");

            var firstImage = product.ProductImages?.FirstOrDefault();
            var firstVariant = product.ProductVariants?.FirstOrDefault();

            var productDto = new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                DiscountPrice = product.DiscountPrice,
                StockQuantity = product.StockQuantity,
                ImageUrl = firstImage?.ImageUrl,
                IsActive = product.IsActive,
                Category = product.Category == null ? null : new CategoryDto
                {
                    Id = product.Category.Id,
                    Name = product.Category.Name
                },
                Variant = firstVariant == null ? null : new ProductVariantDto
                {
                    Id = firstVariant.Id,
                    Size = firstVariant.Size,
                    Color = firstVariant.Color,
                    Material = firstVariant.Material,
                    PriceAdjustment = firstVariant.PriceAdjustment,
                    StockQuantity = firstVariant.StockQuantity,
                    SKU = firstVariant.SKU
                }
            };

            return ServiceResponse<ProductDto>.Ok(productDto, "Product fetched successfully.");
        }
        public async Task<IEnumerable<ProductDto>> GetAllProductsAsync()
        {
            var products = await _productRepository.GetAllAsync();
            var productDtos = products.Select(p => new ProductDto
            {
                Id = p.Id,
                Name = p.Name,
                Description = p.Description,
                Price = p.Price,
                DiscountPrice = p.DiscountPrice,
                StockQuantity = p.StockQuantity,
                IsActive = p.IsActive,
                ImageUrl = p.ProductImages?.FirstOrDefault()?.ImageUrl,
                Category = new CategoryDto
                {
                    Id = p.Category!.Id,
                    Name = p.Category.Name
                }
            }).ToList();

            return productDtos;
        }
        public async Task<IEnumerable<ProductDto>> GetProductsBySupplierAsync(int supplierId)
        {
            var products = await _productRepository.GetBySupplierIdAsync(supplierId);
            var productDtos = products.Select(p => new ProductDto
            {
                Id = p.Id,
                Name = p.Name,
                Description = p.Description,
                Price = p.Price,
                DiscountPrice = p.DiscountPrice,
                StockQuantity = p.StockQuantity,
                ImageUrl = p.ProductImages?.FirstOrDefault()?.ImageUrl,
                IsActive = p.IsActive,
                Category = new CategoryDto
                {
                    Id = p.Category!.Id,
                    Name = p.Category.Name
                }
            }).ToList();

            return productDtos;
        }
        public async Task<ServiceResponse<int>> AddProductAsync(AddProductDto dto, int supplierId)
        {
            try
            {
                var product = new Product
                {
                    Name = dto.Name,
                    Description = dto.Description,
                    Price = dto.Price,
                    DiscountPrice = dto.DiscountPrice,
                    StockQuantity = dto.StockQuantity,
                    CategoryId = dto.CategoryId,
                    UserId = supplierId,
                    ProductImages = dto.ImageUrls.Select((url, index) => new ProductImage
                    {
                        ImageUrl = url,
                        IsMain = index == 0,
                        DisplayOrder = index
                    }).ToList(),
                    ProductVariants = dto.Variants.Select(v => new ProductVariant
                    {
                        Size = v.Size,
                        Color = v.Color,
                        Material = v.Material,
                        PriceAdjustment = v.PriceAdjustment,
                        StockQuantity = v.StockQuantity,
                        SKU = v.SKU
                    }).ToList()
                };

                await _productRepository.AddProductAsync(product);
                return ServiceResponse<int>.Ok(product.Id, "Product added successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<int>.Fail("An error occurred while adding the product.", new List<string> { ex.Message });
            }
        }
        public async Task<ServiceResponse<int>> UpdateProductAsync(int productId, AddProductDto dto, int supplierId)
        {
            try
            {
                var existingProduct = await _productRepository.GetProductWithDetailsAsync(productId, supplierId);

                if (existingProduct == null)
                {
                    return ServiceResponse<int>.Fail("Product not found or you do not have permission.");
                }

                UpdateProductFromDto(existingProduct, dto);

                await _productRepository.UpdateProductAsync(existingProduct);

                return ServiceResponse<int>.Ok(existingProduct.Id, "Product updated successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<int>.Fail("An error occurred while updating the product.", new List<string> { ex.Message });
            }
        }
        public async Task<ServiceResponse<int>> SoftDeleteProductAsync(int productId, int userId, bool isAdmin)
        {
            try
            {
                if (isAdmin)
                {
                    var existingProduct = await _productRepository.GetProductWithDetailsAsync(productId);
                    if (existingProduct == null)
                    {
                        return ServiceResponse<int>.Fail("Product not found.");
                    }
                    await _productRepository.SoftDeleteProductAsync(productId);
                    return ServiceResponse<int>.Ok(productId, "Product soft deleted successfully by admin.");
                }
                var product = await _productRepository.GetProductWithDetailsAsync(productId, userId);
                if (product == null)
                {
                    return ServiceResponse<int>.Fail("Product not found or you do not have permission.");
                }
                await _productRepository.SoftDeleteProductAsync(productId, userId);
                return ServiceResponse<int>.Ok(productId, "Product soft deleted successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<int>.Fail("An error occurred while deleting the product.", new List<string> { ex.Message });
            }
        }
        public async Task<ServiceResponse<int>> ReactivateProductAsync(int productId, int userId, bool isAdmin)
        {
            try
            {
                if (isAdmin)
                {
                    var existingProduct = await _productRepository.GetProductWithDetailsAsync(productId);
                    if (existingProduct == null)
                    {
                        return ServiceResponse<int>.Fail("Product not found.");
                    }
                    await _productRepository.ReactivateProductAsync(productId);
                    return ServiceResponse<int>.Ok(productId, "Product reactivated successfully by admin.");
                }
                var product = await _productRepository.GetProductWithDetailsAsync(productId, userId);
                if (product == null)
                {
                    return ServiceResponse<int>.Fail("Product not found or you do not have permission.");
                }
                await _productRepository.ReactivateProductAsync(productId, userId);
                return ServiceResponse<int>.Ok(productId, "Product reactivated successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<int>.Fail("An error occurred while reactivating the product.", new List<string> { ex.Message });
            }
        }
        private void UpdateProductFromDto(Product product, AddProductDto dto)
        {
            product.Name = dto.Name;
            product.Description = dto.Description;
            product.Price = dto.Price;
            product.DiscountPrice = dto.DiscountPrice;
            product.StockQuantity = dto.StockQuantity;
            product.CategoryId = dto.CategoryId;
            product.ProductImages?.Clear();
            product.ProductImages = dto.ImageUrls.Select((url, index) => new ProductImage
            {
                ImageUrl = url,
                IsMain = index == 0,
                DisplayOrder = index
            }).ToList();
            var updatedVariants = new List<ProductVariant>();

            foreach (var variantDto in dto.Variants)
            {
                var existingVariant = product.ProductVariants!.FirstOrDefault(v => v.Id == variantDto.Id);

                if (existingVariant != null)
                {
                    existingVariant.Size = variantDto.Size;
                    existingVariant.Color = variantDto.Color;
                    existingVariant.Material = variantDto.Material;
                    existingVariant.PriceAdjustment = variantDto.PriceAdjustment;
                    existingVariant.StockQuantity = variantDto.StockQuantity;
                    existingVariant.SKU = variantDto.SKU;

                    updatedVariants.Add(existingVariant);
                }
                else
                {
                    updatedVariants.Add(new ProductVariant
                    {
                        Size = variantDto.Size,
                        Color = variantDto.Color,
                        Material = variantDto.Material,
                        PriceAdjustment = variantDto.PriceAdjustment,
                        StockQuantity = variantDto.StockQuantity,
                        SKU = variantDto.SKU
                    });
                }
            }
            var variantIdsInDto = dto.Variants.Select(v => v.Id).ToHashSet();
            var variantsToRemove = product.ProductVariants!.Where(v => !variantIdsInDto.Contains(v.Id)).ToList();
            foreach (var variant in variantsToRemove)
            {
                product.ProductVariants!.Remove(variant);
            }
        }
        public async Task<ServiceResponse<List<ProVarDto>>> GetProductVariantsByProductIdAsync(int productId)
        {
            var response = new ServiceResponse<List<ProVarDto>>();
            try
            {
                var variants = await _productRepository.GetProductVariantsByProductIdAsync(productId);

                var variantDtos = variants.Select(v => new ProVarDto
                {
                    Id = v.Id,
                    Size = v.Size!,
                    Material = v.Material!,
                    Color = v.Color!,
                    StockQuantity = v.StockQuantity,
                    Sku = v.SKU,
                }).ToList();

                response.Data = variantDtos;
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.Success = false;
                response.Message = $"Error retrieving product variants: {ex.Message}";
            }
            return response;
        }

    }

}
