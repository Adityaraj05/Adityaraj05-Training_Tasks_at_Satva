﻿using DataAccessLayer.Models;
using DinkToPdf.Contracts;
using DinkToPdf;
using System.Text;
using System.Text.RegularExpressions;

namespace ServiceLayer.Services
{
    public class InvoicePdfService
    {
        private readonly IConverter _converter;

        public InvoicePdfService(IConverter converter)
        {
            _converter = converter;
        }

        public byte[] GenerateInvoicePdf(Invoice invoice)
        {
            string html = BuildInvoiceHtml(invoice);

            var doc = new HtmlToPdfDocument()
            {
                GlobalSettings = new GlobalSettings
                {
                    PaperSize = PaperKind.A4,
                    Orientation = Orientation.Portrait,
                    Margins = new MarginSettings { Top = 10, Bottom = 10, Left = 10, Right = 10 }
                },
                Objects = {
                new ObjectSettings
                {
                    HtmlContent = html,
                    WebSettings = { DefaultEncoding = "utf-8" }
                }
            }
            };

            return _converter.Convert(doc);
        }

        private string BuildInvoiceHtml(Invoice invoice)
        {
            string templatePath = Path.Combine(AppContext.BaseDirectory, "Resources", "InvoiceFormat.html");

            if (!File.Exists(templatePath))
                throw new FileNotFoundException("Invoice template not found at path: " + templatePath);

            string htmlTemplate = File.ReadAllText(templatePath);

            var lineItemsHtml = new StringBuilder();
            foreach (var item in invoice.LineItems)
            {
                lineItemsHtml.Append($@"
                <tr>
                    <td>{item.ProductName}</td>
                    <td>{item.Quantity}</td>
                    <td>{item.UnitPrice:C}</td>
                    <td>{item.LineTotal:C}</td>
                </tr>");
            }

            htmlTemplate = htmlTemplate
                .Replace("@Model.InvoiceNumber", invoice.InvoiceNumber)
                .Replace("@Model.InvoiceDate.ToShortDateString()", invoice.InvoiceDate.ToShortDateString())
                .Replace("@Model.CustomerName", invoice.CustomerName)
                .Replace("@Model.Subtotal.ToString(\"C\")", invoice.Subtotal.ToString("C"))
                .Replace("@Model.TaxAmount.ToString(\"C\")", invoice.TaxAmount.ToString("C"))
                .Replace("@Model.TotalAmount.ToString(\"C\")", invoice.TotalAmount.ToString("C"));

            htmlTemplate = Regex.Replace(htmlTemplate,
                @"@foreach\(var item in Model\.LineItems\).*?{.*?}",
                lineItemsHtml.ToString(),
                RegexOptions.Singleline);

            return htmlTemplate;
        }
    }
}
