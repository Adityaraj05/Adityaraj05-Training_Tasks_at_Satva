﻿using RepositoryLayer.Interfaces;
using RepositoryLayer.Services;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;


namespace ServiceLayer.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<List<SupplierDTO>> GetPendingSuppliersAsync()
        {
            var users = await _userRepository.GetPendingSuppliersAsync();

            var supplierDTOs = users.Select(u => new SupplierDTO
            {
                Id = u.Id,
                ShopName = u.ShopName!,
                ShopDetails = u.ShopDetails!,
                City = u.Addresses?.FirstOrDefault()?.City!, 
                IsActive = u.IsActive
            }).ToList();

            return supplierDTOs;
        }


        public async Task<List<SupplierDTO>> GetActiveSuppliersAsync()
        {
            var users = await _userRepository.GetActiveSuppliersAsync();
            var supplierDTOs = users.Select(u => new SupplierDTO
            {
                Id = u.Id,
                ShopName = u.ShopName!,
                ShopDetails = u.ShopDetails!,
                City = u.Addresses?.FirstOrDefault()?.City!,
                IsActive = u.IsActive
            }).ToList();

            return supplierDTOs;
        }

        public async Task<ServiceResponse<List<AddressDto>>> GetAddressesByUserIdAsync(int userId)
        {
            try
            {
                var addresses = await _userRepository.GetAddressesByUserIdAsync(userId);

                if (addresses == null || !addresses.Any())
                {
                    return ServiceResponse<List<AddressDto>>.Fail("No addresses found for this user.");
                }

                var addressDtos = addresses.Select(a => new AddressDto
                {
                    Id = a.Id,
                    Line1 = a.Line1!,
                    Line2 = a.Line2!,
                    City = a.City!,
                    State = a.State!,
                    PostalCode = a.PostalCode!,
                    Country = a.Country!
                }).ToList();

                return ServiceResponse<List<AddressDto>>.Ok(addressDtos);
            }
            catch (Exception ex)
            {
                return ServiceResponse<List<AddressDto>>.Fail($"An error occurred: {ex.Message}");
            }
        }


        public async Task<ServiceResponse<string>> ApproveSupplierAsync(int userId)
        {
            var user = await _userRepository.GetByIdAsync(userId);

            if (user == null)
            {
                return ServiceResponse<string>.Fail("User not found.");
            }

            if (!user.IsSupplier)
            {
                return ServiceResponse<string>.Fail("This user is not a supplier.");
            }

            user.IsActive = true;

            await _userRepository.UpdateAsync(user);
            await _userRepository.SaveChangesAsync();

            return ServiceResponse<string>.Ok("Supplier approved successfully.");
        }

        public async Task<ServiceResponse<bool>> ToggleUserActivationAsync(int id)
        {
            try
            {
                var result = await _userRepository.ToggleUserActivation(id);

                if (result == null)
                {
                    return ServiceResponse<bool>.Fail("Supplier not found.");
                }

                var message = result.Value ? "Supplier activated successfully." : "Supplier deactivated successfully.";
                return ServiceResponse<bool>.Ok(result.Value, message);
            }
            catch (Exception ex)
            {
                return ServiceResponse<bool>.Fail($"An error occurred while toggling the supplier: {ex.Message}");
            }
        }

        public async Task<List<CustomerDTO>> GetAllCustomersAsync()
        {
            var users = await _userRepository.GetAllCustomersAsync();

            var customerDTOs = users.Select(u => new CustomerDTO
            {
                Id = u.Id,
                FirstName = u.FirstName!,
                LastName = u.LastName!,
                Email = u.Email!,
                Phone = u.Phone!,
                Address = u.Addresses?.FirstOrDefault()?.Line1, 
                IsActive = u.IsActive
            }).ToList();

            return customerDTOs!;
        }

    }
}
