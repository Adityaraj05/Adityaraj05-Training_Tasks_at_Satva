﻿using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryLayer.Interfaces;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;


namespace ServiceLayer.Services
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IInvoiceRepository _invoiceRepository;
        private readonly IPdfExporterService _pdfExporterService;
        private readonly IOrderRepository _orderRepository;

        public InvoiceService(IInvoiceRepository invoiceRepository, IPdfExporterService pdfExporterService, IOrderRepository orderRepository)
        {
            _invoiceRepository = invoiceRepository;
            _pdfExporterService = pdfExporterService;
            _orderRepository = orderRepository;
        }

        public async Task<Invoice> GenerateInvoiceForSellerAsync(int orderId, int sellerId)
        {
            var order = await _orderRepository.GetOrderWithItemsForSellerAsync(orderId, sellerId);

            if (order == null)
                throw new ArgumentException("Order not found");

            if (order.Status != "Approved" && order.Status != "Partially Approved")
                throw new InvalidOperationException("Invoice can only be generated for approved or partially approved orders.");

            var sellerItems = order.OrderItems?
                .Where(oi =>
                    oi.Product != null &&
                    oi.Product.UserId == sellerId &&
                    oi.Status == "Approved"
                )
                .ToList();

            if (sellerItems == null || !sellerItems.Any())
                throw new InvalidOperationException("No order items for this seller");

            var invoice = new Invoice
            {
                OrderId = order.Id,
                InvoiceNumber = GenerateInvoiceNumber(),
                InvoiceDate = DateTime.UtcNow,
                DueDate = DateTime.UtcNow.AddDays(30),
                SellerId = sellerId,
                CustomerId = order.UserId,
                CustomerName = $"{order.User?.FirstName} {order.User?.LastName}",
                CustomerEmail = order.User?.Email,
                Status = InvoiceStatus.Pending,
                Notes = order.OrderNotes,
                LineItems = sellerItems.Select(item => new InvoiceLineItem
                {
                    ProductId = item.ProductId,
                    ProductName = item.Product?.Name ?? "Unknown",
                    Quantity = item.Quantity,
                    UnitPrice = item.Price,
                    LineTotal = item.Quantity * item.Price
                }).ToList()
            };

            invoice.Subtotal = invoice.LineItems.Sum(li => li.LineTotal);
            invoice.TaxAmount = invoice.Subtotal * 0.1m;
            invoice.DiscountAmount = 0;
            invoice.TotalAmount = invoice.Subtotal + invoice.TaxAmount - invoice.DiscountAmount;

            await _invoiceRepository.AddInvoiceAsync(invoice);
            await _invoiceRepository.SaveChangesAsync();

            return invoice;
        }

        public async Task<byte[]> ExportInvoicePdfAsync(int invoiceId)
        {
            var invoice = await _invoiceRepository.GetInvoiceByIdAsync(invoiceId);
            if (invoice == null) throw new KeyNotFoundException("Invoice not found");

            var pdfBytes = _pdfExporterService.GenerateInvoicePdf(invoice);
            return pdfBytes;
        }

        private string GenerateInvoiceNumber()
        {
            var datePart = DateTime.UtcNow.ToString("yyyyMMdd");
            var randomPart = new Random().Next(1000, 9999);
            return $"INV-{datePart}-{randomPart}";
        }

        public async Task<List<InvoiceDto>> GetInvoiceBySellerIdAsync(int sellerId)
        {
            var invoices = await _invoiceRepository.GetInvoicesBySellerIdAsync(sellerId);

            if (invoices == null || !invoices.Any())
                return new List<InvoiceDto> { };

            return invoices.Select(invoice => new InvoiceDto
            {
                Id = invoice.InvoiceId,
                OrderId = invoice.OrderId,
                InvoiceNumber = invoice.InvoiceNumber,
                InvoiceDate = invoice.InvoiceDate,
                DueDate = invoice.DueDate,
                SellerId = invoice.SellerId,
                CustomerName = invoice.CustomerName,
                CustomerEmail = invoice.CustomerEmail,
                TotalAmount = invoice.TotalAmount
            }).ToList();
        }

    }
}
