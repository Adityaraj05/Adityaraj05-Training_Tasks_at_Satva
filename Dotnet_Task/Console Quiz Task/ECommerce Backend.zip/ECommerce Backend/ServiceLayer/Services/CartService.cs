﻿using DataAccessLayer.Models;
using RepositoryLayer.Interfaces;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;


namespace ServiceLayer.Services
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _cartRepository;
        private readonly ICartItemRepository _cartItemRepository;
        private readonly IProductRepository _productRepository;

        public CartService(ICartRepository cartRepository, ICartItemRepository cartItemRepository, IProductRepository productRepository)
        {
            _cartRepository = cartRepository;
            _cartItemRepository = cartItemRepository;
            _productRepository = productRepository;
        }

        public async Task<ServiceResponse<int>> AddToCartAsync(int productId, int userId, int quantity)
        {
            try
            {
                var cart = await _cartRepository.GetCartByUserIdAsync(userId);
                if (cart == null)
                {
                    cart = new Cart
                    {
                        UserId = userId,
                        CartItems = new List<CartItem>()
                    };
                    await _cartRepository.AddCartAsync(cart);
                }
                var existingCartItem = cart.CartItems!.FirstOrDefault(ci => ci.ProductId == productId);

                if (existingCartItem != null)
                {
                    existingCartItem.Quantity += quantity;
                    existingCartItem.UpdatedAt = DateTime.UtcNow;
                    await _cartItemRepository.UpdateCartItemAsync(existingCartItem);
                }
                else
                {
                    var product = await _productRepository.GetByIdAsync(productId);
                    if (product == null)
                    {
                        return ServiceResponse<int>.Fail("Product not found.");
                    }

                    var newCartItem = new CartItem
                    {
                        ProductId = productId,
                        UserId = userId,
                        Quantity = quantity,
                        Price = product.Price,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                    cart.CartItems!.Add(newCartItem);
                    await _cartItemRepository.AddCartItemAsync(newCartItem);
                }

                return ServiceResponse<int>.Ok(cart.Id, "Product added to cart successfully.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<int>.Fail("An error occurred while adding to the cart.", new List<string> { ex.Message });
            }
        }
        public async Task<ServiceResponse<CartDto?>> GetCartByUserIdAsync(int userId)
        {
            try
            {
                var cart = await _cartRepository.GetCartByUserIdAsync(userId);
                if (cart == null)
                {
                    return ServiceResponse<CartDto?>.Fail("Cart is empty.");
                }

                var cartDto = new CartDto
                {
                    Id = cart.Id,
                    UserId = cart.UserId,
                    CartItems = cart.CartItems?.Select(ci => new CartItemDto
                    {
                        Id = ci.Id,
                        ProductId = ci.ProductId,
                        Quantity = ci.Quantity,
                        Price = ci.Price,
                        ProductName = ci.Product!.Name,
                        ProductImageUrl = ci.Product.ProductImages?.FirstOrDefault()?.ImageUrl ?? string.Empty
                    }).ToList()
                };

                return ServiceResponse<CartDto?>.Ok(cartDto);
            }
            catch (Exception ex)
            {
                return ServiceResponse<CartDto?>.Fail($"An error occurred while retrieving the cart: {ex.Message}");
            }
        }
        public async Task<ServiceResponse<bool>> RemoveFromCartAsync(int cartItemId, int userId)
        {
            try
            {
                var cartItem = await _cartRepository.GetCartItemByIdAndUserIdAsync(cartItemId, userId);

                if (cartItem == null)
                {
                    return ServiceResponse<bool>.Fail("Cart item not found.");
                }
                var success = await _cartRepository.RemoveCartItemAsync(cartItem);

                if (success)
                {
                    return ServiceResponse<bool>.Ok(true, "Product removed from cart successfully.");
                }

                return ServiceResponse<bool>.Fail("An error occurred while removing the product from the cart.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<bool>.Fail($"An error occurred: {ex.Message}");
            }
        }
        public async Task<ServiceResponse<bool>> UpdateCartItemQuantityAsync(int cartItemId, int userId, int quantity)
        {
            try
            {
                var cartItem = await _cartRepository.GetCartItemByIdAndUserIdAsync(cartItemId, userId);

                if (cartItem == null)
                    return ServiceResponse<bool>.Fail("Cart item not found.");

                cartItem.Quantity = quantity;
                var success = await _cartRepository.UpdateCartItemAsync(cartItem);

                if (success)
                    return ServiceResponse<bool>.Ok(true, "Cart item quantity updated successfully.");

                return ServiceResponse<bool>.Fail("Failed to update cart item quantity.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<bool>.Fail($"An error occurred: {ex.Message}");
            }
        }
        public async Task<ServiceResponse<bool>> ClearCartAsync(int userId)
        {
            try
            {
                var success = await _cartRepository.ClearCartAsync(userId);

                if (success)
                {
                    return ServiceResponse<bool>.Ok(true, "Cart cleared successfully.");
                }

                return ServiceResponse<bool>.Fail("Cart not found for the user.");
            }
            catch (Exception ex)
            {
                return ServiceResponse<bool>.Fail($"An error occurred: {ex.Message}");
            }
        }
    }

}
