﻿using Microsoft.Extensions.Options;
using ServiceLayer.Interfaces;
using ServiceLayer.Utils;
using System.Net.Mail;
using System.Net;


namespace ServiceLayer.Services
{
    public class EmailService : IEmailService
    {
        private readonly SmtpSettings _smtpSettings;

        public EmailService(IOptions<SmtpSettings> smtpOptions)
        {
            _smtpSettings = smtpOptions.Value;
        }

        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            if (string.IsNullOrWhiteSpace(toEmail))
                throw new ArgumentException("Recipient email address is required", nameof(toEmail));

            var smtpClient = new SmtpClient(_smtpSettings.SmtpServer)
            {
                Port = _smtpSettings.SmtpPort,
                Credentials = new NetworkCredential(_smtpSettings.SenderEmail, _smtpSettings.SenderPassword),
                EnableSsl = true,
            };

            var mailMessage = new MailMessage
            {
                From = new MailAddress(_smtpSettings.SenderEmail!),
                Subject = subject,
                Body = body,
                IsBodyHtml = true
            };

            mailMessage.To.Add(toEmail); 

            await smtpClient.SendMailAsync(mailMessage);
        }

    }

}
