﻿using DataAccessLayer.Models;
using Microsoft.Extensions.Options;
using RepositoryLayer.Interfaces;
using ServiceLayer.Interfaces;
using ServiceLayer.Utils;
using SharedResources.DTOS;


namespace ServiceLayer.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IEmailService _emailService;
        private readonly HelperClass _helperClass;
        private readonly SmtpSettings _smtpSettings;

        public AuthService(IUserRepository userRepository, IRoleRepository roleRepository, HelperClass helperClass, IEmailService emailService, IOptions<SmtpSettings> smtpSettings)
        {
            _userRepository = userRepository;
            _roleRepository = roleRepository;
            _helperClass = helperClass;
            _emailService = emailService;
            _smtpSettings = smtpSettings.Value;
        }

        public async Task<ServiceResponse<string>> RegisterUserAsync(RegisterDto dto)
        {
            var existingUser = await _userRepository.GetByEmailAsync(dto.Email!);
            var role = await _roleRepository.GetByNameAsync(dto.Role!);

            if (role == null)
                return ServiceResponse<string>.Fail($"Role '{dto.Role}' is invalid.");

            if (existingUser != null)
            {
                var hasRole = existingUser.UserRoles?.Any(ur => ur.RoleId == role.Id) ?? false;
                if (hasRole)
                    return ServiceResponse<string>.Fail("User already has this role assigned.");

                existingUser.UserRoles ??= new List<UserRole>();
                existingUser.UserRoles.Add(new UserRole { RoleId = role.Id });
                existingUser.Balance = dto.Balance;

                if (dto.IsSupplier)
                {
                    bool isUnique = await _userRepository.IsShopNameUniqueInCityAsync(dto.ShopName!, dto.ShopCity!, existingUser.Id);

                    if (!isUnique)
                    {
                        return ServiceResponse<string>.Fail("A supplier with the same shop name already exists in this city. Please choose a different name.");
                    }
                    existingUser.IsSupplier = true;
                    existingUser.IsActive = false;
                    existingUser.ShopName = dto.ShopName;
                    existingUser.ShopDetails = dto.ShopDetails;

                    await _helperClass.AddAddressAsync(dto, existingUser, "ShippingAddress");
                    await _helperClass.AddAddressAsync(dto, existingUser, "BillingAddress");

                    var emailSubject = "Updated Supplier Registration: " + existingUser.ShopName;
                    var emailBody = await CreateSupplierEmailBodyAsync(existingUser);
                    await _emailService.SendEmailAsync(_smtpSettings.AdminEmail!, emailSubject, emailBody);
                }
                else
                {
                    await _helperClass.AddAddressAsync(dto, existingUser, "ShippingAddress");
                }

                await _userRepository.UpdateAsync(existingUser);
                await _userRepository.SaveChangesAsync();

                return ServiceResponse<string>.Ok("User updated with new role.");
            }

            var passwordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password);
            var user = CreateUserEntity(dto, passwordHash, role.Id);

            if (dto.IsSupplier)
            {
                bool isUnique = await _userRepository.IsShopNameUniqueInCityAsync(dto.ShopName!, dto.ShopCity!, user.Id);

                if (!isUnique)
                {
                    return ServiceResponse<string>.Fail("A supplier with the same shop name already exists in this city. Please choose a different name.");
                }
                user.IsActive = false;
            }

            await _userRepository.AddAsync(user);
            await _userRepository.SaveChangesAsync();

            await AddAddressesBasedOnRoleAsync(dto, user);

            if (dto.IsSupplier)
            {
                await _userRepository.UpdateAsync(user);
                await _userRepository.SaveChangesAsync();
                var emailSubject = "New Supplier Registration: " + user.ShopName;
                var emailBody = await CreateSupplierEmailBodyAsync(user);
                await _emailService.SendEmailAsync(_smtpSettings.AdminEmail!, emailSubject, emailBody);
            }

            return ServiceResponse<string>.Ok("User registered successfully.");
        }
        public async Task<ServiceResponse<TokenRequestDto>> LoginUserAsync(LoginDto dto)
        {
            var authResponse = await AuthenticateUserAsync(dto.Email!, dto.Password!);
            if (!authResponse.Success)
                return ServiceResponse<TokenRequestDto>.Fail(authResponse.Message!);

            var user = authResponse.Data;

            if (!user!.IsActive)
            {
                return ServiceResponse<TokenRequestDto>.Fail("Your account is not active. Please contact support.");
            }

            var accessToken = _helperClass.GenerateToken(user!);
            var refreshToken = _helperClass.GenerateRefreshToken();

            user!.RefreshToken = refreshToken;
            user.RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7);
            await _userRepository.UpdateAsync(user);

            var roles = user.UserRoles?.Select(ur => ur.Role?.Name!).ToList() ?? new List<string>();

            var tokenResponse = new TokenRequestDto
            {
                Id = user.Id,
                AccessToken = accessToken,
                RefreshToken = refreshToken,
                Roles = roles,
                Name = $"{user.FirstName} {user.LastName}",
            };

            return ServiceResponse<TokenRequestDto>.Ok(tokenResponse, "Login successful");
        }
        public async Task<ServiceResponse<User>> AuthenticateUserAsync(string email, string password)
        {
            var user = await _userRepository.GetByEmailWithRolesAsync(email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
                return ServiceResponse<User>.Fail("Invalid email or password.");

            return ServiceResponse<User>.Ok(user, "Authentication successful");
        }
        public async Task<ServiceResponse<TokenRequestDto>> RefreshTokenAsync(string refreshToken)
        {
            var user = await _userRepository.GetUserByRefreshTokenAsync(refreshToken);

            if (user == null || user.RefreshTokenExpiryTime < DateTime.UtcNow)
                return ServiceResponse<TokenRequestDto>.Fail("Invalid or expired refresh token.");

            var newAccessToken = _helperClass.GenerateToken(user);
            var newRefreshToken = _helperClass.GenerateRefreshToken();

            user.RefreshToken = newRefreshToken;
            user.RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7);
            await _userRepository.UpdateAsync(user);

            var tokenResponse = new TokenRequestDto
            {
                AccessToken = newAccessToken,
                RefreshToken = newRefreshToken
            };

            return ServiceResponse<TokenRequestDto>.Ok(tokenResponse, "Token refreshed successfully.");
        }
        public async Task<ServiceResponse<bool>> LogoutAsync(string refreshToken)
        {
            var user = await _userRepository.GetUserByRefreshTokenAsync(refreshToken);

            if (user == null || user.RefreshToken != refreshToken)
                return ServiceResponse<bool>.Fail("Invalid refresh token.");

            user.RefreshToken = null;
            user.RefreshTokenExpiryTime = null; 
            await _userRepository.UpdateAsync(user);

            return ServiceResponse<bool>.Ok(true, "Logout successful.");
        }
        private User CreateUserEntity(RegisterDto dto, string passwordHash, int roleId)
        {
            return new User
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                PasswordHash = passwordHash,
                Phone = dto.PhoneNumber,
                Balance = dto.Balance,
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                IsSupplier = dto.IsSupplier,
                ShopName = dto.ShopName,
                ShopDetails = dto.ShopDetails,
                UserRoles = new List<UserRole>
        {
            new UserRole { RoleId = roleId }
        }
            };
        }
        private async Task AddAddressesBasedOnRoleAsync(RegisterDto dto, User user)
        {
            if (dto.IsSupplier)
            {
                await _helperClass.AddAddressAsync(dto, user, "ShippingAddress");
                await _helperClass.AddAddressAsync(dto, user, "BillingAddress");
            }
            else
            {
                await _helperClass.AddAddressAsync(dto, user, "ShippingAddress");
            }
        }
        private async Task<string> CreateSupplierEmailBodyAsync(User user)
        {
            var templatePath = Path.Combine(AppContext.BaseDirectory, "Resources", "EmailFormat.html");
            Console.WriteLine(templatePath);

            if (!File.Exists(templatePath))
                throw new FileNotFoundException("Email template not found at: " + templatePath);

            var emailTemplate = await File.ReadAllTextAsync(templatePath);

            emailTemplate = emailTemplate
                .Replace("{{SupplierName}}", $"{user.FirstName} {user.LastName}")
                .Replace("{{ShopName}}", user.ShopName ?? "")
                .Replace("{{ShopDetails}}", user.ShopDetails ?? "");

            return emailTemplate;
        }

    }
}
