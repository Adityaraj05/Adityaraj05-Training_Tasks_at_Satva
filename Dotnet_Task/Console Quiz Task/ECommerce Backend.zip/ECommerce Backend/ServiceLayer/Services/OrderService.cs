﻿using DataAccessLayer.Models;
using RepositoryLayer.Interfaces;
using RepositoryLayer.Services;
using ServiceLayer.Interfaces;
using ServiceLayer.Utils;
using SharedResources.DTOS;

namespace ServiceLayer.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IUserRepository _userRepository;
        private readonly IOrderStatusHistoryRepository _orderStatusHistoryRepository;
        private readonly ICartRepository _cartRepository;
        private readonly ICartItemRepository _cartItemRepository;
        private readonly IProductRepository _productRepository;

        public OrderService(
            IOrderRepository orderRepository,
            IUserRepository userRepository,
            IOrderStatusHistoryRepository orderStatusHistoryRepository,
            ICartRepository cartRepository,
            ICartItemRepository cartItemRepository,
            IProductRepository productRepository)
        {
            _orderRepository = orderRepository;
            _userRepository = userRepository;
            _orderStatusHistoryRepository = orderStatusHistoryRepository;
            _cartRepository = cartRepository;
            _cartItemRepository = cartItemRepository;
            _productRepository = productRepository;
        }
        public async Task<ServiceResponse<List<OrderDto>>> GetAllOrdersAsync()
        {
            var orders = await _orderRepository.GetAllOrdersAsync();

            var orderDtos = orders.Select(o => new OrderDto
            {
                UserId = o.UserId,
                TotalAmount = o.TotalAmount,
                Status = o.Status!,
                ShippingAddressId = o.ShippingAddressId,
                BillingAddressId = o.BillingAddressId,
                OrderNotes = o.OrderNotes,
                TrackingNumber = o.TrackingNumber,
                ShippingProvider = o.ShippingProvider,
                OrderItems = o.OrderItems!.Select(oi => new OrderItemDto
                {
                    ProductId = oi.ProductId,
                    Quantity = oi.Quantity,
                    Price = oi.Price,
                }).ToList()
            }).ToList();

            return ServiceResponse<List<OrderDto>>.Ok(orderDtos);
        }
        public async Task<ServiceResponse<Order?>> PlaceOrderAsync(OrderDto orderDto)
        {
            try
            {
                var user = await _userRepository.GetByIdAsync(orderDto.UserId);
                if (user == null)
                {
                    return ServiceResponse<Order?>.Fail("User not found.");
                }

                foreach (var item in orderDto.OrderItems)
                {
                    var product = await _productRepository.GetByIdAsync(item.ProductId);
                    if (product == null)
                    {
                        return ServiceResponse<Order?>.Fail($"Product with ID {item.ProductId} not found.");
                    }

                    if (product.StockQuantity < item.Quantity)
                    {
                        return ServiceResponse<Order?>.Fail($"Insufficient stock for product: {product.Name}");
                    }
                }


                if (user.Balance < orderDto.TotalAmount)
                {
                    return ServiceResponse<Order?>.Fail("Insufficient balance.");
                }

                var order = OrderMappingHelper.MapToOrder(orderDto);

                user.Balance -= orderDto.TotalAmount;
                await _userRepository.UpdateAsync(user);

                await _orderRepository.AddAsync(order);
                var orderStatusHistory = new OrderStatusHistory
                {
                    OrderId = order.Id,
                    Status = "Pending",
                    StatusDate = DateTime.UtcNow
                };

                await _orderStatusHistoryRepository.AddAsync(orderStatusHistory);
                await _cartRepository.ClearCartAsync(orderDto.UserId);
                await _cartItemRepository.ClearCartByUserIdAsync(orderDto.UserId);

                return ServiceResponse<Order?>.Ok(order);
            }
            catch (Exception ex)
            {
                return ServiceResponse<Order?>.Fail($"Error while placing the order: {ex.Message}");
            }
        }
        public async Task<ServiceResponse<int>> ApproveOrderItemAsync(int orderItemId, int supplierId)
        {
            var orderItem = await _orderRepository.GetOrderItemWithProductAsync(orderItemId);

            if (orderItem == null || orderItem.Product == null)
                return ServiceResponse<int>.Fail("Order item not found.");

            if (orderItem.Product.UserId != supplierId)
                return ServiceResponse<int>.Fail("You are not authorized to approve this order item.");

            if (orderItem.Status == "Approved")
                return ServiceResponse<int>.Fail("Order item is already approved.");

            if (orderItem.Product.StockQuantity < orderItem.Quantity)
                return ServiceResponse<int>.Fail("Insufficient stock to approve this order item.");

            await _orderRepository.DecreaseStockAsync(orderItem.ProductId, orderItem.Quantity);

            orderItem.Status = "Approved";

            await _orderRepository.UpdateOrderItemAsync(orderItem);
            await _orderRepository.AddOrderItemStatusHistoryAsync(orderItem.OrderId, "Approved");
            await _orderRepository.UpdateOrderStatusBasedOnItemsAsync(orderItem.OrderId);

            return ServiceResponse<int>.Ok(orderItem.Id, "Order item approved and stock reduced.");
        }
        public async Task<ServiceResponse<int>> RejectOrderItemAsync(int orderItemId, int supplierId)
        {
            var orderItem = await _orderRepository.GetOrderItemWithProductAsync(orderItemId);

            if (orderItem == null || orderItem.Product == null)
                return ServiceResponse<int>.Fail("Order item not found.");

            if (orderItem.Product.UserId != supplierId)
                return ServiceResponse<int>.Fail("You are not authorized to reject this order item.");

            if (orderItem.Status == "Rejected")
                return ServiceResponse<int>.Fail("Order item is already rejected.");

            orderItem.Status = "Rejected";

            await _orderRepository.UpdateOrderItemAsync(orderItem);
            await _orderRepository.AddOrderItemStatusHistoryAsync(orderItem.OrderId, "Rejected");

            await _orderRepository.UpdateOrderStatusBasedOnItemsAsync(orderItem.OrderId);

            var order = await _orderRepository.GetOrderByIdAsync(orderItem.OrderId);
            if (order != null)
            {
                var customer = await _userRepository.GetByIdAsync(order.UserId);
                if (customer != null)
                {
                    decimal refundAmount = orderItem.Price * orderItem.Quantity;
                    customer.Balance += refundAmount;
                    await _userRepository.UpdateAsync(customer);
                }
            }

            return ServiceResponse<int>.Ok(orderItem.Id, "Order item rejected and amount refunded.");
        }
        public async Task<ServiceResponse<List<PendingOrderItemDto>>> GetOrderItemsBySupplierAsync(int supplierId, string status)
        {
            IEnumerable<OrderItem> orderItems;

            switch (status.ToLower())
            {
                case "pending":
                    orderItems = await _orderRepository.GetOrderItemsBySupplierAsync(supplierId,status);
                    break;
                case "approved":
                    orderItems = await _orderRepository.GetOrderItemsBySupplierAsync(supplierId, status);
                    break;
                case "rejected":
                    orderItems = await _orderRepository.GetOrderItemsBySupplierAsync(supplierId, status);
                    break;
                default:
                    orderItems = Enumerable.Empty<OrderItem>();
                    break;
            }

            var result = orderItems.Select(oi => new PendingOrderItemDto
            {
                OrderItemId = oi.Id,
                ProductId = oi.ProductId,
                ProductName = oi.Product?.Name,
                Quantity = oi.Quantity,
                Price = oi.Price,
                OrderId = oi.OrderId,
                CustomerId = oi.Order?.UserId,
                CustomerName = $"{oi.Order?.User?.FirstName ?? ""} {oi.Order?.User?.LastName ?? ""}".Trim(),
                CreatedAt = oi.CreatedAt
            }).ToList();

            return ServiceResponse<List<PendingOrderItemDto>>.Ok(result);
        }

    }

}
