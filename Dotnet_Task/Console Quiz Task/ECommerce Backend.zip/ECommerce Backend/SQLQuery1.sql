create database ShopNexDb

use ShopNexDb


select @@SERVERNAME




select * from Users;

UPDATE Users
SET ApprovalStatus = 2
WHERE Id = 9; 
select * from Products;
select * from Wallets;

UPDATE Wallets 
SET IsActive = 1
WHERE Id = 4;

select * from RefreshTokens;