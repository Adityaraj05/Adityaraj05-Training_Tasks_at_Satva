﻿using DataAccessLayer.Models;

namespace RepositoryLayer.Interfaces
{
    public interface IInvoiceRepository
    {
        Task<Invoice> GetInvoiceByIdAsync(int invoiceId);
        Task AddInvoiceAsync(Invoice invoice);
        Task SaveChangesAsync();
        Task<List<Invoice>> GetInvoicesBySellerIdAsync(int sellerId);
    }
}
