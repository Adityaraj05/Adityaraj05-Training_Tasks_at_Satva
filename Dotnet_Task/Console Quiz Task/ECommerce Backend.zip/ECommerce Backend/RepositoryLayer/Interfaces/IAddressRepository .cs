﻿using DataAccessLayer.Models;


namespace RepositoryLayer.Interfaces
{
    public interface IAddressRepository
    {
        Task AddAsync(Address address);
        Task SaveChangesAsync();
    }
}
