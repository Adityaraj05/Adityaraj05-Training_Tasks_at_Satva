﻿using DataAccessLayer.Models;


namespace RepositoryLayer.Interfaces
{
    public interface IOrderItemRepository
    {
        Task AddAsync(OrderItem orderItem);
        Task<IEnumerable<OrderItem>> GetOrderItemsByOrderIdAsync(int orderId);
        Task RemoveAsync(OrderItem orderItem);
    }

}
