﻿using DataAccessLayer.Models;

namespace RepositoryLayer.Interfaces
{
    public interface IProductRepository
    {
        Task<Product?> GetByIdAsync(int id);
        Task<IEnumerable<Product>> GetAllAsync();
        Task<IEnumerable<Product>> GetBySupplierIdAsync(int supplierId);
        Task<Product?> GetProductWithDetailsAsync(int productId, int? supplierId = null);
        Task AddProductAsync(Product product);
        Task UpdateProductAsync(Product product);
        Task SoftDeleteProductAsync(int productId, int? supplierId = null);
        Task ReactivateProductAsync(int productId, int? supplierId = null);
        Task<List<ProductVariant>> GetProductVariantsByProductIdAsync(int productId);
    }

}
