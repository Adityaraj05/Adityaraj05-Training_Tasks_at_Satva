﻿

using DataAccessLayer.Models;

namespace RepositoryLayer.Interfaces
{
    public interface ICartRepository
    {
        Task<Cart?> GetCartByUserIdAsync(int userId);
        Task<CartItem?> GetCartItemByIdAndUserIdAsync(int cartItemId, int userId);
        Task AddCartAsync(Cart cart);
        Task<bool> RemoveCartItemAsync(CartItem cartItem);
        Task<bool> UpdateCartItemQuantityAsync(CartItem cartItem);
        Task<bool> ClearCartAsync(int userId);
        Task<bool> UpdateCartItemAsync(CartItem cartItem);
    }
}
