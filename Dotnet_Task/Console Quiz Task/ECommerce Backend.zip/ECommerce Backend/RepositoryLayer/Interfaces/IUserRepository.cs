﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer.Interfaces
{
    public interface IUserRepository
    {
        Task<User?> GetByEmailAsync(string email);
        Task<User?> GetByEmailWithRolesAsync(string email);
        Task<User?> GetUserByRefreshTokenAsync(string refreshToken);
        Task<bool> IsShopNameUniqueInCityAsync(string shopName, string city, int? excludeUserId = null);
        Task<List<User>> GetPendingSuppliersAsync();
        Task<List<User>> GetActiveSuppliersAsync();
        Task<List<User>> GetAllCustomersAsync();
        Task AddAsync(User user);
        Task SaveChangesAsync();
        Task UpdateAsync(User user);
        Task<User?> GetByIdAsync(int userId);
        Task<bool?> ToggleUserActivation(int id);
        Task<List<Address>> GetAddressesByUserIdAsync(int userId);
    }
}
