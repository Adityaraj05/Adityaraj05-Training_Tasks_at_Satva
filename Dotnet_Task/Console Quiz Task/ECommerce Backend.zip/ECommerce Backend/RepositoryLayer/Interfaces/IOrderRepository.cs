﻿using DataAccessLayer.Models;


namespace RepositoryLayer.Interfaces
{
    public interface IOrderRepository
    {
        Task<Order?> GetOrderByIdAsync(int id);
        Task<List<Order>> GetAllOrdersAsync();
        Task<IEnumerable<Order>> GetOrdersByUserIdAsync(int userId);
        Task AddAsync(Order order);
        Task UpdateAsync(Order order);
        Task<bool> ApproveOrderAsync(int orderId);
        Task<bool> RejectOrderAsync(int orderId);
        Task<OrderItem?> GetOrderItemWithProductAsync(int orderItemId);
        Task UpdateOrderItemAsync(OrderItem orderItem);
        Task AddOrderItemStatusHistoryAsync(int orderId, string status);
        Task UpdateOrderStatusBasedOnItemsAsync(int orderId);
        Task<List<OrderItem>> GetOrderItemsBySupplierAsync(int supplierId, string status);
        Task DecreaseStockAsync(int productId, int quantity);
        Task<Order?> GetOrderWithItemsForSellerAsync(int orderId, int sellerId);
    }

}
