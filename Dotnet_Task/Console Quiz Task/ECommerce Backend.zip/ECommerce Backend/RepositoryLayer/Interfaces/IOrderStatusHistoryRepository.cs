﻿using DataAccessLayer.Models;


namespace RepositoryLayer.Interfaces
{
    public interface IOrderStatusHistoryRepository
    {
        Task AddAsync(OrderStatusHistory orderStatusHistory);
        Task<IEnumerable<OrderStatusHistory>> GetStatusHistoryByOrderIdAsync(int orderId);
    }

}
