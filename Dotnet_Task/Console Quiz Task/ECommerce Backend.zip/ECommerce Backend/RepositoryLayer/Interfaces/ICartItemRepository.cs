﻿

using DataAccessLayer.Models;

namespace RepositoryLayer.Interfaces
{
    public interface ICartItemRepository
    {
        Task AddCartItemAsync(CartItem cartItem);
        Task UpdateCartItemAsync(CartItem cartItem);
        Task RemoveCartItemAsync(int cartItemId);
        Task<bool> ClearCartByUserIdAsync(int userId);
    }
}
