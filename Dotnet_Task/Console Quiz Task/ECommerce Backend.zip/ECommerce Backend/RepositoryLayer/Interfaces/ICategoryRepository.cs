﻿using DataAccessLayer.Models;
using SharedResources.DTOS;


namespace RepositoryLayer.Interfaces
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllCategoriesAsync();
    }
   
}
