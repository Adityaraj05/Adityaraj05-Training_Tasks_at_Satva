﻿using DataAccessLayer.Models;
using DataAccessLayer;
using RepositoryLayer.Interfaces;
using Microsoft.EntityFrameworkCore;


namespace RepositoryLayer.Services
{
    public class OrderStatusHistoryRepository : IOrderStatusHistoryRepository
    {
        private readonly ApplicationDbContext _context;

        public OrderStatusHistoryRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task AddAsync(OrderStatusHistory orderStatusHistory)
        {
            await _context.OrderStatusHistories.AddAsync(orderStatusHistory);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<OrderStatusHistory>> GetStatusHistoryByOrderIdAsync(int orderId)
        {
            return await _context.OrderStatusHistories
                .Where(osh => osh.OrderId == orderId)
                .OrderBy(osh => osh.StatusDate)
                .ToListAsync();
        }
    }

}
