﻿using DataAccessLayer;
using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryLayer.Interfaces;

namespace RepositoryLayer.Services
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _context;

        public ProductRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Product?> GetByIdAsync(int id)
        {
            return await _context.Products
                .Include(p => p.Category)
                .Include(p => p.ProductImages)
                .Include(p=> p.ProductVariants)
                .Include(p => p.User)
                .FirstOrDefaultAsync(p => p.Id == id);
        }
        public async Task<IEnumerable<Product>> GetAllAsync()
        {
            return await _context.Products
                .Include(p => p.Category)
                .Include(p => p.User)
                .Include(p => p.ProductImages)
                .ToListAsync();
        }
        public async Task<IEnumerable<Product>> GetBySupplierIdAsync(int supplierId)
        {
            return await _context.Products
                .Where(p => p.UserId == supplierId)
                .Include(p => p.Category)         
                .Include(p => p.User)              
                .Include(p => p.ProductImages)     
                .ToListAsync();
        }
        public async Task<Product?> GetProductWithDetailsAsync(int productId, int? supplierId = null)
        {
            var query = _context.Products
                .Include(p => p.ProductImages)
                .Include(p => p.ProductVariants)
                .AsQueryable();
            if (supplierId.HasValue)
            {
                query = query.Where(p => p.Id == productId && p.UserId == supplierId.Value);
            }
            else
            {
                query = query.Where(p => p.Id == productId);
            }

            return await query.FirstOrDefaultAsync();
        }
        public async Task AddProductAsync(Product product)
        {
            _context.Products.Add(product);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateProductAsync(Product product)
        {
            _context.Products.Update(product);
            await _context.SaveChangesAsync();
        }
        public async Task SoftDeleteProductAsync(int productId, int? supplierId = null)
        {
            var query = _context.Products.AsQueryable();

            if (supplierId.HasValue)
            {
                query = query.Where(p => p.Id == productId && p.UserId == supplierId.Value);
            }
            else
            {
                query = query.Where(p => p.Id == productId);
            }

            var product = await query.FirstOrDefaultAsync();

            if (product != null)
            {
                product.IsActive = false;
                _context.Products.Update(product);
                await _context.SaveChangesAsync();
            }
        }
        public async Task ReactivateProductAsync(int productId, int? supplierId = null)
        {
            var query = _context.Products.AsQueryable();

            if (supplierId.HasValue)
            {
                query = query.Where(p => p.Id == productId && p.UserId == supplierId.Value);
            }
            else
            {
                query = query.Where(p => p.Id == productId);
            }

            var product = await query.FirstOrDefaultAsync();

            if (product != null)
            {
                product.IsActive = true;
                _context.Products.Update(product);
                await _context.SaveChangesAsync();
            }
        }
        public async Task<List<ProductVariant>> GetProductVariantsByProductIdAsync(int productId)
        {
            return await _context.ProductVariants
                                 .Where(pv => pv.ProductId == productId)
                                 .ToListAsync();
        }

    }

}
