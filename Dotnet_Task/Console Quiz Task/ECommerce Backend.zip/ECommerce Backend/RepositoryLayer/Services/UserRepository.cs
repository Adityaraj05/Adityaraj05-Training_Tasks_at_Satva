﻿using DataAccessLayer;
using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryLayer.Interfaces;


namespace RepositoryLayer.Services
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext _context;

        public UserRepository(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<User?> GetByEmailAsync(string email)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Email == email);
        }
        public async Task<User?> GetByEmailWithRolesAsync(string email)
        {
            return await _context.Users
                .Include(u => u.UserRoles)!
                .ThenInclude(ur => ur.Role)
                .FirstOrDefaultAsync(u => u.Email == email);
        }
        public async Task<User?> GetUserByRefreshTokenAsync(string refreshToken)
        {
            return await _context.Users
                .Include(u => u.UserRoles)!
                .ThenInclude(ur => ur.Role)
                .FirstOrDefaultAsync(u => u.RefreshToken == refreshToken);
        }
        public async Task<bool> IsShopNameUniqueInCityAsync(string shopName, string city, int? excludeUserId = null)
        {
            var query = _context.Users
                .Where(u => u.IsSupplier && u.ShopName == shopName)
                .SelectMany(u => u.Addresses!)
                .Where(a => a.City == city);

            if (excludeUserId.HasValue)
            {
                query = query.Where(a => a.UserId != excludeUserId.Value);
            }

            return !await query.AnyAsync();
        }
        public async Task<List<User>> GetPendingSuppliersAsync()
        {
            return await _context.Users
                .Include(u => u.Addresses)
                .Where(u => u.IsSupplier && !u.IsActive)
                .ToListAsync();
        }
        public async Task<List<User>> GetActiveSuppliersAsync()
        {
            return await _context.Users
                .Where(u => u.IsSupplier && u.IsActive)
                .Include(u => u.Addresses)
                .ToListAsync();
        }
        public async Task<List<User>> GetAllCustomersAsync()
        {
            return await _context.Users
                .Where(u => u.UserRoles!.Any(ur => ur.RoleId == 1)) 
                .Include(u => u.Addresses)
                .ToListAsync();
        }
        public async Task<bool?> ToggleUserActivation(int id)
        {
            var user = await _context.Users.FirstOrDefaultAsync(s => s.Id == id);
            if (user == null)
                return null;

            user.IsActive = !user.IsActive;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            return user.IsActive; 
        }
        public async Task<List<Address>> GetAddressesByUserIdAsync(int userId)
        {
            return await _context.Addresses
                .Where(a => a.UserId == userId)
                .ToListAsync();
        }
        public async Task AddAsync(User user)
        {
            await _context.Users.AddAsync(user);
        }
        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(User user)
        {
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }
        public async Task<User?> GetByIdAsync(int userId)
        {
            return await _context.Users
                .Include(u => u.UserRoles) 
                .FirstOrDefaultAsync(u => u.Id == userId);
        }

    }
}
