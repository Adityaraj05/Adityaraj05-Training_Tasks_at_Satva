﻿using DataAccessLayer.Models;
using DataAccessLayer;
using RepositoryLayer.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace RepositoryLayer.Services
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _context;

        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Order?> GetOrderByIdAsync(int id)
        {
            return await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)!
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == id);
        }


        public async Task<List<Order>> GetAllOrdersAsync()
        {
            return await _context.Orders
                .Include(o => o.OrderItems)!        
                .ThenInclude(oi => oi.Product)
                .Include(o => o.User)          
                .ToListAsync();
        }


        public async Task<Order?> GetOrderWithItemsForSellerAsync(int orderId, int sellerId)
        {
            return await _context.Orders
                .Include(o => o.User) 
                .Include(o => o.OrderItems!.Where(oi => oi.Product!.UserId == sellerId))
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == orderId);
        }




        public async Task<IEnumerable<Order>> GetOrdersByUserIdAsync(int userId)
        {
            return await _context.Orders
                .Where(o => o.UserId == userId)
                .Include(o => o.OrderItems)!
                .ThenInclude(oi => oi.Product)
                .ToListAsync();
        }

        public async Task AddAsync(Order order)
        {
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Order order)
        {
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();
        }


        public async Task<bool> ApproveOrderAsync(int orderId)
        {
            var order = await _context.Orders.FirstOrDefaultAsync(o => o.Id == orderId);
            if (order == null)
            {
                return false; 
            }

            order.Status = "Approved";
            _context.Orders.Update(order);

            var statusHistory = new OrderStatusHistory
            {
                OrderId = order.Id,
                Status = "Approved",
                StatusDate = DateTime.UtcNow
            };
            _context.OrderStatusHistories.Add(statusHistory);

            await _context.SaveChangesAsync();
            return true;
        }


        public async Task<bool> RejectOrderAsync(int orderId)
        {
            var order = await _context.Orders.FirstOrDefaultAsync(o => o.Id == orderId);
            if (order == null)
            {
                return false;
            }

            order.Status = "Rejected";
            _context.Orders.Update(order);

            var statusHistory = new OrderStatusHistory
            {
                OrderId = order.Id,
                Status = "Rejected",
                StatusDate = DateTime.UtcNow
            };
            _context.OrderStatusHistories.Add(statusHistory);

            await _context.SaveChangesAsync();
            return true;
        }




        public async Task<List<OrderItem>> GetOrderItemsBySupplierAsync(int supplierId, string status)
        {
            return await _context.OrderItems
                .Include(oi => oi.Product)
                .Include(oi => oi.Order)
                    .ThenInclude(o => o!.User)
                .Where(oi => oi.Status == status && oi.Product != null && oi.Product.UserId == supplierId)
                .ToListAsync();
        }

        public async Task UpdateOrderStatusBasedOnItemsAsync(int orderId)
        {
            var orderItems = await _context.OrderItems
                .Where(oi => oi.OrderId == orderId)
                .ToListAsync();

            var order = await _context.Orders.FirstOrDefaultAsync(o => o.Id == orderId);
            if (order == null || !orderItems.Any()) return;

            bool allApproved = orderItems.All(oi => oi.Status == "Approved");
            bool anyApproved = orderItems.Any(oi => oi.Status == "Approved");
            bool anyRejected = orderItems.Any(oi => oi.Status == "Rejected");

            string newStatus;

            if (allApproved)
                newStatus = "Approved";
            else if (anyApproved || anyRejected)
                newStatus = "Partially Approved";
            else
                newStatus = "Pending"; 

            if (order.Status != newStatus)
            {
                order.Status = newStatus;
                _context.Orders.Update(order);

                var history = new OrderStatusHistory
                {
                    OrderId = orderId,
                    Status = newStatus,
                    StatusDate = DateTime.UtcNow
                };
                await _context.OrderStatusHistories.AddAsync(history);

                await _context.SaveChangesAsync();
            }
        }

        public async Task DecreaseStockAsync(int productId, int quantity)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null)
                throw new InvalidOperationException("Product not found.");

            if (product.StockQuantity < quantity)
                throw new InvalidOperationException("Insufficient stock.");

            product.StockQuantity -= quantity;

            _context.Products.Update(product);
            await _context.SaveChangesAsync();
        }



        public async Task<OrderItem?> GetOrderItemWithProductAsync(int orderItemId)
        {
            return await _context.OrderItems
                .Include(oi => oi.Product)
                .FirstOrDefaultAsync(oi => oi.Id == orderItemId);
        }

        public async Task UpdateOrderItemAsync(OrderItem orderItem)
        {
            _context.OrderItems.Update(orderItem);
            await _context.SaveChangesAsync();
        }

        public async Task AddOrderItemStatusHistoryAsync(int orderId, string status)
        {
            var history = new OrderStatusHistory
            {
                OrderId = orderId,
                Status = status,
                StatusDate = DateTime.UtcNow
            };
            await _context.OrderStatusHistories.AddAsync(history);
            await _context.SaveChangesAsync();
        }


    }

}
