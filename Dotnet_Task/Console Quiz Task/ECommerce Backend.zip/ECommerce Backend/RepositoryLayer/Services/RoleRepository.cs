﻿using DataAccessLayer.Models;
using DataAccessLayer;
using RepositoryLayer.Interfaces;
using Microsoft.EntityFrameworkCore;
using BCrypt.Net;

namespace RepositoryLayer.Services
{
    public class RoleRepository : IRoleRepository
    {
        private readonly ApplicationDbContext _context;

        public RoleRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Role?> GetByNameAsync(string roleName)
        {
            return await _context.Roles
                .FirstOrDefaultAsync(r => r.Name == roleName);
        }
        public async Task AddAsync(Role role)
        {
            await _context.Roles.AddAsync(role);
        }
        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
        public async Task SeedRolesAndAdminAsync()
        {
            await DeleteIncompleteUsersAsync();
            var roles = new[] { "Customer", "Supplier", "Admin" };
            foreach (var roleName in roles)
            {
                if (await GetByNameAsync(roleName) == null)
                {
                    await AddAsync(new Role
                    {
                        Name = roleName,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    });
                }
            }

            await SaveChangesAsync();

            var adminUser = await _context.Users
                .Include(u => u.UserRoles)!
                .ThenInclude(ur => ur.Role)
                .FirstOrDefaultAsync(u => u.UserRoles!.Any(ur => ur.Role!.Name == "Admin"));

            if (adminUser == null)
            {
                var adminEmail = "adityarajavi05@gmail.com";
                var passwordHash = BCrypt.Net.BCrypt.HashPassword("aditya123");

                var admin = new User
                {
                    FirstName = "Super",
                    LastName = "Admin",
                    Email = adminEmail,
                    PasswordHash = passwordHash,
                    Phone = "8210483019",
                    Balance = 10000000,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow,
                    UserRoles = new List<UserRole>
                    {
                        new UserRole
                        {
                            RoleId = (await GetByNameAsync("Admin"))!.Id
                        }
                    }
                };

                await _context.Users.AddAsync(admin);
                await SaveChangesAsync();
            }
        }
        public async Task DeleteIncompleteUsersAsync()
        {
            var usersToDelete = await _context.Users
                .Where(u => u.Email == null || u.PasswordHash == null)
                .ToListAsync();

            if (usersToDelete.Any())
            {
                _context.Users.RemoveRange(usersToDelete);
                await _context.SaveChangesAsync();
            }
        }

    }
}
