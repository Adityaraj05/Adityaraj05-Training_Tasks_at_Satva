﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;

namespace ECommerceTask.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register(RegisterDto dto)
        {
            var result = await _authService.RegisterUserAsync(dto);
            if (!result.Success)
                return BadRequest(result.Message);
            return Ok(result);
        }


        [AllowAnonymous]
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            var tokenResponse = await _authService.LoginUserAsync(dto);

            if (!tokenResponse.Success)
            {
                return Unauthorized(new { message = tokenResponse.Message });
            }

            Response.Cookies.Append("refreshToken", tokenResponse.Data!.RefreshToken!, new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict,
                Expires = DateTime.UtcNow.AddDays(7)
            });

            return Ok(new { tokenResponse.Data.Id, tokenResponse.Data.AccessToken, tokenResponse.Data.Roles , tokenResponse.Data.Name });
        }




        [HttpPost]
        [Route("refreshToken")]
        public async Task<IActionResult> RefreshToken([FromBody] TokenRequestDto request)
        {
            var response = await _authService.RefreshTokenAsync(request.RefreshToken!);

            if (!response.Success)
                return Unauthorized(response.Message);

            Response.Cookies.Append("refreshToken", response.Data!.RefreshToken!, new CookieOptions
            {
                HttpOnly = true,  
                Secure = true,    
                SameSite = SameSiteMode.Strict,  
                Expires = DateTime.UtcNow.AddDays(7)  
            });
            return Ok(new { response.Data.AccessToken });
        }





        [HttpPost]
        [Route("logout")]
        public async Task<IActionResult> Logout([FromBody] TokenRequestDto request)
        {
            var response = await _authService.LogoutAsync(request.RefreshToken!);

            if (!response.Success)
                return Unauthorized(response.Message);

            return Ok(response);
        }

    }
}
