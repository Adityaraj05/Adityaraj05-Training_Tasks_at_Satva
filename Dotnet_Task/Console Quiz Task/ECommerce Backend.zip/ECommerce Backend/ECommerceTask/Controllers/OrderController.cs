﻿using DataAccessLayer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;
using System.Security.Claims;

namespace ECommerceTask.Controllers
{
    [Route("api/order")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }




        [HttpGet]
        [Route("allOrders")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllOrders()
        {
            var response = await _orderService.GetAllOrdersAsync();
            if (!response.Success)
                return BadRequest(response.Message);

            return Ok(response.Data);
        }



        [HttpPost]
        [Route("placeOrder")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> PlaceOrder([FromBody] OrderDto orderDto)
        {
            var response = await _orderService.PlaceOrderAsync(orderDto);
            if (response.Success)
            {
                return Ok(new
                {
                    success = true,
                    data = response.Data,
                });
            }
            return BadRequest(new
            {
                success = false,
                message = response.Message,
            });
        }


        [HttpGet]
        [Route("orderItems")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> GetOrderItemsByStatus([FromQuery] string status)
        {
            var supplierId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value!);
            if (string.IsNullOrEmpty(status) || !(new[] { "Pending", "Approved", "Rejected" }).Contains(status))
            {
                return BadRequest("Invalid status parameter. Allowed values are: Pending, Approved, Rejected.");
            }
            var response = await _orderService.GetOrderItemsBySupplierAsync(supplierId, status);
            if (response.Success)
                return Ok(response.Data);
            return BadRequest(response.Message);
        }




        [HttpPost]
        [Route("approveOrder/{id}")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> ApproveOrderItem(int id)
        {
            var supplierId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value!);

            var response = await _orderService.ApproveOrderItemAsync(id, supplierId);

            if (response.Success)
                return Ok(response.Data);

            return BadRequest(response.Message);
        }


        [HttpPost]
        [Route("rejectOrder/{id}")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> RejectOrderItem(int id)
        {
            var supplierId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value!);

            var response = await _orderService.RejectOrderItemAsync(id, supplierId);

            if (response.Success)
                return Ok(response.Data);

            return BadRequest(response.Message);
        }

    }
}
