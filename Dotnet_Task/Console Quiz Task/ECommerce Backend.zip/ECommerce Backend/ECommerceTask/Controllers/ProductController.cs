﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;
using System.Security.Claims;

namespace ECommerceTask.Controllers
{
    [Route("api/product")]
    [ApiController]
    public class ProductController : ControllerBase
    {

        private readonly IProductService _productService;
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }



        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            var response = await _productService.GetProductByIdAsync(id);
            if (response.Success)
                return Ok(new { success = true, data = response.Data });

            return NotFound(new { success = false, message = response.Message });
        }


        [HttpGet]
        [Route("getAllProducts")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _productService.GetAllProductsAsync();
            return Ok(products);
        }



        [HttpGet]
        [Route("getAllForSupplier")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> GetAllForSupplier()
        {
            var supplierId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var products = await _productService.GetProductsBySupplierAsync(supplierId);
            return Ok(products);
        }



        [HttpPost]
        [Route("addProduct")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> AddProduct([FromBody] AddProductDto dto)
        {
            var supplierId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var result = await _productService.AddProductAsync(dto, supplierId);
            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }

        [HttpPost]
        [Route("updateProduct/{id}")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] AddProductDto dto)
        {
            var supplierId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var result = await _productService.UpdateProductAsync(id, dto, supplierId);
            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }

        [HttpGet("variants/{productId}")]
        [Authorize(Roles = "Admin,Customer,Supplier")]
        public async Task<IActionResult> GetProductVariants(int productId)
        {
            var result = await _productService.GetProductVariantsByProductIdAsync(productId);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }


        [HttpPost]
        [Route("softDeleteProduct/{id}")]
        [Authorize(Roles = "Admin,Supplier")]
        public async Task<IActionResult> SoftDeleteProduct(int id)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var isAdmin = User.IsInRole("Admin");
            var result = await _productService.SoftDeleteProductAsync(id, userId, isAdmin);
            if (!result.Success)
                return BadRequest(result);
            return Ok(result);
        }



        [HttpPost]
        [Route("reactivateProduct/{id}")]
        [Authorize(Roles = "Admin,Supplier")]
        public async Task<IActionResult> ReactivateProduct(int id)
        {
            var supplierId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var isAdmin = User.IsInRole("Admin");
            var result = await _productService.ReactivateProductAsync(id, supplierId, isAdmin);
            if (!result.Success)
                return BadRequest(result);
            return Ok(result);
        }


    }
}
