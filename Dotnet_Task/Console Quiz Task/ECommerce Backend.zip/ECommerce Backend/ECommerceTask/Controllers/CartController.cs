﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Interfaces;
using SharedResources.DTOS;
using System.Security.Claims;

namespace ECommerceTask.Controllers
{
    [ApiController]
    [Route("api/cart")]
    [Authorize(Roles = "Customer")]
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;

        public CartController(ICartService cartService)
        {
            _cartService = cartService;
        }

        [HttpGet]
        [Route("get")]
        public async Task<IActionResult> GetCart()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var cart = await _cartService.GetCartByUserIdAsync(userId);

            if (cart == null)
                return NotFound("Cart is empty.");

            return Ok(cart);
        }

        
        
        
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddToCart([FromBody] AddToCartDto dto)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var result = await _cartService.AddToCartAsync(dto.ProductId, userId, dto.Quantity);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }





        [HttpDelete]
        [Route("remove/{cartItemId}")]
        public async Task<IActionResult> RemoveFromCart(int cartItemId)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var result = await _cartService.RemoveFromCartAsync(cartItemId, userId);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }






        [HttpPut]
        [Route("update/{cartItemId}")]
        public async Task<IActionResult> UpdateCartItemQuantity(int cartItemId, [FromBody] UpdateCartItemDto dto)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var result = await _cartService.UpdateCartItemQuantityAsync(cartItemId, userId, dto.Quantity);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }






        [HttpDelete]
        [Route("clear")]
        public async Task<IActionResult> ClearCart()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var result = await _cartService.ClearCartAsync(userId);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }
    }

}
