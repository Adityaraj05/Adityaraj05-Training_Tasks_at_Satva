﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Interfaces;

namespace ECommerceTask.Controllers
{
    [Route("api/invoice")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly IInvoiceService _invoiceService;
        public InvoiceController(IInvoiceService invoiceService)
        {
            _invoiceService = invoiceService;
        }


        [HttpGet("generate/{orderId}/{sellerId}")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> GenerateInvoiceForSeller(int orderId, int sellerId)
        {
            try
            {
                var invoice = await _invoiceService.GenerateInvoiceForSellerAsync(orderId, sellerId);
                return Ok(invoice);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        [HttpGet("export/{invoiceId}")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> ExportInvoicePdf(int invoiceId)
        {
            try
            {
                var pdfBytes = await _invoiceService.ExportInvoicePdfAsync(invoiceId);
                return File(pdfBytes, "application/pdf", $"Invoice_{invoiceId}.pdf");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet]
        [Route("getInvoicesBySellerId/{sellerId}")]
        [Authorize(Roles = "Supplier")]
        public async Task<IActionResult> GetInvoiceBySellerId(int sellerId)
        {
            try
            {
                var invoices = await _invoiceService.GetInvoiceBySellerIdAsync(sellerId);
                if (invoices == null)
                {
                    return NotFound("No invoice found for the given seller ID.");
                }
                return Ok(invoices);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
