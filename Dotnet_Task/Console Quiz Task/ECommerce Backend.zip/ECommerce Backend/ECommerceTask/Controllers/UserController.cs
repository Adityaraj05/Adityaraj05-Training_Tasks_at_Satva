﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Interfaces;
using System.Security.Claims;

namespace ECommerceTask.Controllers
{
    [Route("api/user")]
    [ApiController]
    
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        [Route("pendingSuppliers")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetPendingSuppliers()
        {
            var pendingSuppliers = await _userService.GetPendingSuppliersAsync();
            return Ok(pendingSuppliers);
        }



        [HttpGet]
        [Route("activeSuppliers")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetActiveSuppliers()
        {
            var suppliers = await _userService.GetActiveSuppliersAsync();
            return Ok(suppliers); 
        }



        [HttpPost]
        [Route("approveSupplier/{userId:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ApproveSupplier(int userId)
        {
            var response = await _userService.ApproveSupplierAsync(userId);
            if (!response.Success)
                return BadRequest(response.Message);
            return Ok(response);
        }


        [HttpPost]
        [Route("toggleUserActivation/{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ToggleSupplierActivation(int id)
        {
            var response = await _userService.ToggleUserActivationAsync(id);

            if (!response.Success)
                return BadRequest(response.Message);

            return Ok(response);
        }

        [HttpGet]
        [Route("addresses")]
        [Authorize(Roles = "Customer")] 
        public async Task<IActionResult> GetUserAddresses()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var result = await _userService.GetAddressesByUserIdAsync(userId);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }



        [HttpGet]
        [Route("getAllCustomers")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllCustomers()
        {
            var customers = await _userService.GetAllCustomersAsync();
            return Ok(customers); 
        }
       
    }
}
