﻿

namespace SharedResources.DTOS
{
    public class TokenRequestDto
    {
        public int Id { get; set; }
        public string? AccessToken { get; set; }
        public string? RefreshToken { get; set; }
        public List<string> Roles { get; set; } = new();
        public string? Name { get; set; }

    }

}
