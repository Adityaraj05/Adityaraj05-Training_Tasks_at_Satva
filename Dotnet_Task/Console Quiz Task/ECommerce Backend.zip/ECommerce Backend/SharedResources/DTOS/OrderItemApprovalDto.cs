﻿

namespace SharedResources.DTOS
{
    public class OrderItemApprovalDto
    {
        public int OrderItemId { get; set; }
        public bool IsApproved { get; set; }
    }

}
