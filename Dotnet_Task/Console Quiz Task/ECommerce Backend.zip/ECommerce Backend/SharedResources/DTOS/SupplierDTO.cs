﻿

namespace SharedResources.DTOS
{
    public class SupplierDTO
    {
        public int Id { get; set; }
        public string? ShopName { get; set; }
        public string? ShopDetails { get; set; }
        public string? City { get; set; }
        public bool IsActive { get; set; }
    }

}
