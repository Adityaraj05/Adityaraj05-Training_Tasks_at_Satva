﻿
namespace SharedResources.DTOS
{
    public class ServiceResponse<T>
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public T? Data { get; set; }
        public List<string>? Errors { get; set; }

        public static ServiceResponse<T> Ok(T data, string? message = null) =>
            new() { Success = true, Data = data, Message = message };

        public static ServiceResponse<T> Fail(string message, List<string>? errors = null) =>
            new() { Success = false, Message = message, Errors = errors };

        public static ServiceResponse<T> Fail(List<string> errors) =>
            new() { Success = false, Message = "Validation failed", Errors = errors };
    }
}
