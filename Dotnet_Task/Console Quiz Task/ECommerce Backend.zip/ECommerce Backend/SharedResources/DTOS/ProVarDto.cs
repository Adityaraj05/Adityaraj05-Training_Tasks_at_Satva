﻿

namespace SharedResources.DTOS
{
    public class ProVarDto
    {
        public int Id { get; set; }
        public string Size { get; set; } = string.Empty;
        public string Material { get; set; } = string.Empty;
        public string Color { get; set; } = string.Empty;
        public int StockQuantity { get; set; }
        public string? Sku { get; set; }
    }

}
