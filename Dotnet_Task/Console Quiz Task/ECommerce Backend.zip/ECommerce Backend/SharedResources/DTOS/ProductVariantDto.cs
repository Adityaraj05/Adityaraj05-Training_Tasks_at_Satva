﻿

namespace SharedResources.DTOS
{
    public class ProductVariantDto
    {
        public int Id { get; set; }
        public string? Size { get; set; }
        public string? Color { get; set; }
        public string? Material { get; set; }
        public decimal? PriceAdjustment { get; set; }
        public int StockQuantity { get; set; }
        public string? SKU { get; set; }
    }

}
