﻿
namespace SharedResources.DTOS
{
    public class OrderDto
    {
        public int UserId { get; set; }
        public decimal TotalAmount { get; set; }
        public string Status { get; set; } = "Pending"; 

        public int? ShippingAddressId { get; set; }
        public int? BillingAddressId { get; set; }

        public string? OrderNotes { get; set; }
        public string? TrackingNumber { get; set; }
        public string? ShippingProvider { get; set; }

        public List<OrderItemDto> OrderItems { get; set; } = new List<OrderItemDto>();
    }
}
