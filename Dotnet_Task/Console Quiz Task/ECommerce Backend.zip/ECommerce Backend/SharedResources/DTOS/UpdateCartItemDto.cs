﻿

namespace SharedResources.DTOS
{
    public class UpdateCartItemDto
    {
        public int Quantity { get; set; }
    }
}
