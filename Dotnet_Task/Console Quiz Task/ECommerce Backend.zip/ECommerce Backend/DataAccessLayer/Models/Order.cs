﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace DataAccessLayer.Models
{
    public class Order
    {
        public int Id { get; set; }
        [Required]
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        [JsonIgnore]
        public User? User { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.UtcNow;
        public decimal TotalAmount { get; set; }
        public string? Status { get; set; }
        public int? ShippingAddressId { get; set; }
        public int? BillingAddressId { get; set; }
        [ForeignKey("ShippingAddressId")]
        public Address? ShippingAddress { get; set; }
        [ForeignKey("BillingAddressId")]
        public Address? BillingAddress { get; set; }
        public string? OrderNotes { get; set; }
        public string? TrackingNumber { get; set; }
        public string? ShippingProvider { get; set; }
        [InverseProperty("Order")]
        public ICollection<OrderItem>? OrderItems { get; set; }
        [InverseProperty("Order")]
        public ICollection<OrderStatusHistory>? StatusHistory { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}
