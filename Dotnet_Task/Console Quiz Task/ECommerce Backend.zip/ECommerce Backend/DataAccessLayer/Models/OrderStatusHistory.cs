﻿

using System.Text.Json.Serialization;

namespace DataAccessLayer.Models
{
    public class OrderStatusHistory
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        [JsonIgnore]
        public Order? Order { get; set; }
        public string? Status { get; set; }
        public string? Notes { get; set; }
        public DateTime StatusDate { get; set; } = DateTime.UtcNow;
        public int? UpdatedByUserId { get; set; }
    }
}
