﻿

using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccessLayer.Models
{
    public class User
    {
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? PasswordHash { get; set; }
        public string? Phone { get; set; }
        public decimal? Balance { get; set; }
        public bool IsActive { get; set; } = true;
        public string? RefreshToken { get; set; }
        public DateTime? RefreshTokenExpiryTime { get; set; }

        public string? ShopName { get; set; }
        public string? ShopDetails { get; set; }


        public bool IsSupplier { get; set; } = false;

        public ICollection<Product>? Products { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? LastLoginAt { get; set; }

        public ICollection<UserRole>? UserRoles { get; set; }

        public ICollection<Address>? Addresses { get; set; }

        public ICollection<Order>? Orders { get; set; }

        public ICollection<CartItem>? CartItems { get; set; }

        public ICollection<WishlistItem>? WishlistItems { get; set; }
    }
}
