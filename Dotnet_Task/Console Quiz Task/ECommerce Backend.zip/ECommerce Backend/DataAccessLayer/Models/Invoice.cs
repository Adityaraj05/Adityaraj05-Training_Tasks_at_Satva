﻿
namespace DataAccessLayer.Models
{
    public class Invoice
    {
        public int InvoiceId { get; set; }              
        public int OrderId { get; set; }
        public int SellerId { get; set; }
        public string? InvoiceNumber { get; set; }      
        public DateTime InvoiceDate { get; set; }     
        public DateTime DueDate { get; set; }         
        public int CustomerId { get; set; }             
        public string? CustomerName { get; set; }
        public string? CustomerEmail { get; set; }
        public decimal Subtotal { get; set; }           
        public decimal TaxAmount { get; set; }          
        public decimal DiscountAmount { get; set; }     
        public decimal TotalAmount { get; set; }       
        public string? Notes { get; set; }               
        public InvoiceStatus Status { get; set; }       
        public List<InvoiceLineItem> LineItems { get; set; } = new List<InvoiceLineItem>();
    }




    public enum InvoiceStatus
    {
        Pending,
        Paid,
        Overdue,
        Cancelled
    }
}
