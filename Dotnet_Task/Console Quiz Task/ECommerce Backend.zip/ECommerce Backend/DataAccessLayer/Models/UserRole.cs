﻿
using System.Text.Json.Serialization;

namespace DataAccessLayer.Models
{
    public class UserRole
    {
        public int UserId { get; set; }
        [JsonIgnore]
        public User? User { get; set; }
        public int RoleId { get; set; }
        [JsonIgnore]
        public Role? Role { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
