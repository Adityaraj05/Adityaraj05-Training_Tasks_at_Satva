﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace DataAccessLayer.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public decimal? DiscountPrice { get; set; }
        public int StockQuantity { get; set; }
        public bool IsActive { get; set; } = true;

        [Required]
        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public Category? Category { get; set; }

        [Required]
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        [JsonIgnore]
        public User? User { get; set; }

        [InverseProperty("Product")]
        public ICollection<ProductImage>? ProductImages { get; set; }

        [InverseProperty("Product")]
        public ICollection<ProductVariant>? ProductVariants { get; set; }

        [InverseProperty("Product")]
        public ICollection<OrderItem>? OrderItems { get; set; }

        [InverseProperty("Product")]
        public ICollection<CartItem>? CartItems { get; set; }

        [InverseProperty("Product")]
        public ICollection<WishlistItem>? WishlistItems { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}
