using Microsoft.AspNetCore.Mvc;
using Task5_1.Models;

namespace Task5_1.Controllers
{
    public class HomeController : Controller
    {
        private readonly IGuidService _transientGuidService1;
        private readonly IGuidService _transientGuidService2;
        private readonly IGuidService _scopedGuidService1;
        private readonly IGuidService _scopedGuidService2;
        private readonly IGuidService _singletonGuidService1;
        private readonly IGuidService _singletonGuidService2;

        public HomeController(
            [FromKeyedServices("Transient")] IGuidService transientGuidService1,
            [FromKeyedServices("Transient")] IGuidService transientGuidService2,
            [FromKeyedServices("Scoped")] IGuidService scopedGuidService1,
            [FromKeyedServices("Scoped")] IGuidService scopedGuidService2,
            [FromKeyedServices("Singleton")] IGuidService singletonGuidService1,
            [FromKeyedServices("Singleton")] IGuidService singletonGuidService2)
        {
            _transientGuidService1 = transientGuidService1;
            _transientGuidService2 = transientGuidService2;
            _scopedGuidService1 = scopedGuidService1;
            _scopedGuidService2 = scopedGuidService2;
            _singletonGuidService1 = singletonGuidService1;
            _singletonGuidService2 = singletonGuidService2;
        }

        public IActionResult Index()
        {
            var viewModel = new GuidViewModel
            {
                TransientGuid1 = _transientGuidService1.GetGuid(),
                TransientGuid2 = _transientGuidService2.GetGuid(),
                ScopedGuid1 = _scopedGuidService1.GetGuid(),
                ScopedGuid2 = _scopedGuidService2.GetGuid(),
                SingletonGuid1 = _singletonGuidService1.GetGuid(),
                SingletonGuid2 = _singletonGuidService2.GetGuid()
            };

            return View(viewModel);
        }
    }
}