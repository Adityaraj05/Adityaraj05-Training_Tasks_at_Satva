﻿namespace Task5_1.Services
{
    public interface IGuidService
    {
        Guid GetGuid();
    }
}
