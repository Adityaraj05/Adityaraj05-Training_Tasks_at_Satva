﻿namespace Task5_1.Models
{
    public interface IGuidService
    {
        Guid GetGuid();
    }

    public class TransientGuidService : IGuidService
    {
        private readonly Guid _guid;

        public TransientGuidService()
        {
            _guid = Guid.NewGuid();
        }

        public Guid GetGuid() => _guid;
    }

    public class ScopedGuidService : IGuidService
    {
        private readonly Guid _guid;

        public ScopedGuidService()
        {
            _guid = Guid.NewGuid();
        }

        public Guid GetGuid() => _guid;
    }

    public class SingletonGuidService : IGuidService
    {
        private readonly Guid _guid;

        public SingletonGuidService()
        {
            _guid = Guid.NewGuid();
        }

        public Guid GetGuid() => _guid;
    }
}