import React, { useEffect, useState } from 'react';
import {
    Layout,
    Tabs,
    Input,
    Button,
    Space,
    Typography,
    Dropdown,
    Menu,
    Avatar,
    message
} from 'antd';
import {
    SearchOutlined,
    FilterOutlined,
    PlusOutlined,
    ArrowLeftOutlined,
    UserOutlined,
    LogoutOutlined
} from '@ant-design/icons';
import styles from './Home.module.css';
import apiService from '../../services/apiService';
import { AddGroupForm } from '../components/AddGroupForm';
import { GroupTable } from '../components/GroupTable';
import { GroupClassTable } from '../components/GroupClassTable';
import { useNavigate } from 'react-router-dom';

const { Header, Content } = Layout;
const { TabPane } = Tabs;
const { Text } = Typography;

const Home: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'group' | 'groupClass'>('group');
    const [groupData, setGroupData] = useState<any[]>([]);
    const [classData, setClassData] = useState<any[]>([]);
    const [isDrawerVisible, setIsDrawerVisible] = useState<boolean>(false);
    const [editGroupData, setEditGroupData] = useState<any | null>(null);
    const [visible, setVisible] = useState<boolean>(false);
    const [searchText, setSearchText] = useState<string>('');
    const handleTabChange = (key: string) => {
        setActiveTab(key as 'group' | 'groupClass');
    };
    const navigate=useNavigate();
    const handleMenuClick = (e: any) => {
        if (e.key === "profile") {
            message.info("Navigating to profile...");
        } else if (e.key === "logout") {
            localStorage.clear();
            navigate("/");
            message.success("Logged out successfully.");
            // Implement logout logic
        }
    };

    const getGroupRecords = async () => {
        try {
            const response = await apiService.get("/api/Group/GetGroups");
            console.log(response)
            setGroupData(response?.result?.records || []);
        } catch (error) {
            message.error(error.message)
            console.error("Error fetching groups:", error);
        }
    };

    const getGroupClassData = async () => {
        try {
            const response = await apiService.get("/api/GRC/GetGRCRecords");
            setClassData(response.result.records || []);
        } catch (error) {
            console.error("Error fetching group classes:", error);
        }
    };
    const showDrawer = () => {
        setIsDrawerVisible(true);
    };
    useEffect(() => {
        getGroupRecords();
        getGroupClassData();
    }, []);

    return (
        <Layout className={styles.layout}>
            <Header className={styles.header}>
                <div className={styles.logoContainer}>
                    <span className={styles.logoText}>
                        <span className={styles.gatherText}>GATHER</span>
                        <span className={styles.nexusText}>.nexus</span>
                    </span>
                </div>
                <div className={styles.profileContainer}>
                    <Avatar className={styles.avatar}>R</Avatar>
                    <Dropdown overlay={
                        <Menu onClick={handleMenuClick}>
                            <Menu.Item key="profile" icon={<UserOutlined />}>My Profile</Menu.Item>
                            <Menu.Item key="logout" icon={<LogoutOutlined />}>Log Out</Menu.Item>
                        </Menu>
                    } trigger={["click"]} onOpenChange={setVisible} open={visible}>
                        <div className={styles.profileContainer} onClick={(e) => e.stopPropagation()}>
                            <div className={styles.profileInfo}>
                                <Text strong>Sujal</Text>
                                <Text>My Profile</Text>
                            </div>
                        </div>
                    </Dropdown>
                </div>
            </Header>

            <Content className={styles.content}>
                <div className={styles.pageHeader}>
                    <Button type="text" icon={<ArrowLeftOutlined />} className={styles.backButton}>
                        <span className={styles.pageTitle}>Multi-Entity & Display</span>
                    </Button>
                    <Button type="link" className={styles.addCompanyLink}>
                        How to Add {activeTab}?
                    </Button>
                </div>

                <div className={styles.searchActions}>
                    <Tabs activeKey={activeTab} onChange={handleTabChange} className={styles.tabs}>
                        <TabPane tab="Group" key="group" />
                        <TabPane tab="Group Class" key="groupClass" />
                    </Tabs>

                    <div className={styles.filterBox}>
                        <Input
                            placeholder="Search here..."
                            prefix={<SearchOutlined />}
                            className={styles.searchInput}
                            value={searchText}
                            onChange={(e) => setSearchText(e.target.value)}
                        />
                        <div className={styles.tableActions}>
                            <Space>
                                <Button icon={<FilterOutlined />}>Filter</Button>
                                <Button
                                    type="primary"
                                    icon={<PlusOutlined />}
                                    onClick={showDrawer}
                                    className={styles.addButton}
                                >
                                    Add {activeTab === "group" ? " Group" : " Class"}
                                </Button>
                            </Space>
                        </div>
                    </div>
                </div>

        
                <AddGroupForm
                    isDrawerVisible={isDrawerVisible}
                    setIsDrawerVisible={setIsDrawerVisible}
                    editGroupData={editGroupData}
                    setEditGroupData={setEditGroupData}
                    getGroupRecords={getGroupRecords}
                />
                {activeTab === "group" ? (
                    <GroupTable
                        groupData={groupData}
                        setEditGroupData={setEditGroupData}
                        setIsDrawerVisible={setIsDrawerVisible}
                    />
                ) : (
                    <GroupClassTable classData={classData} />
                )}
            </Content>
        </Layout>
    );
};

export default Home;
