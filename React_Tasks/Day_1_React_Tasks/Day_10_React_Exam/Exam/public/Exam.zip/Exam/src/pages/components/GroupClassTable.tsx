import { Button, Space, Table } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';

interface ClassData {
    groupclassId: string;
    groupName: string;
    className: string;
    mappedAccountsCount: number;
}

export const GroupClassTable = ({ classData }: { classData: ClassData[] }) => {

    const handleEdit = (record: ClassData) => {
        console.log("Edit clicked", record);
    };

    const handleDelete = (record: ClassData) => {
        console.log("Delete clicked", record);
    };
    const columns = [
        {
            title: "Group Name",
            dataIndex: "groupName",
            key: "groupName",
        },
        {
            title: "Class Name",
            dataIndex: "className",
            key: "className",
        },
        {
            title: "Setup or Mapping Action",
            key: "setupOrMapping",
            render: (record: ClassData) =>
                record.mappedAccountsCount > 0 ? (
                    <Button type="primary">View Mapping</Button>
                ) : (
                    <Button type="dashed">Setup</Button>
                ),
        },
        {
            title: "Actions",
            key: "actions",
            render: (record: ClassData) => (
                <Space>
                    <Button type="text" icon={<EditOutlined />} onClick={() => handleEdit(record)} />
                    <Button type="text" icon={<DeleteOutlined />} danger onClick={() => handleDelete(record)} />
                </Space>
            ),
        },
    ];

    return (
        <Table dataSource={classData} columns={columns} rowKey="groupclassId" />
    )
}
