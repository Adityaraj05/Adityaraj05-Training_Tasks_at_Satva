import { Button, Dropdown, Menu, Table } from 'antd';
import DownOutlined from '@ant-design/icons/DownOutlined';
import React from 'react'
import { CopyOutlined, EditOutlined } from '@ant-design/icons';

interface GroupData {
    id: string;
    groupName: string;
    erpCompanyData: { erpCompanyId: string; erpCompanyName: string }[];
    groupClass: string;
    financialYear: string;
    currencyName: string;
    groupTranferStatus: boolean;
}

interface GroupTableProps {
    groupData: GroupData[];
}

export const GroupTable: React.FC<GroupTableProps> = ({ groupData, setEditGroupData, setIsDrawerVisible }) => {
    const getCompanyMenu = (companies: { erpCompanyId: string; erpCompanyName: string }[]) => (
        <Menu>
            {companies.map((company) => (
                <Menu.Item key={company.erpCompanyId}>{company.erpCompanyName}</Menu.Item>
            ))}
        </Menu>
    );
    const Groupcolumns = [
        {
            title: "Group Name",
            dataIndex: "groupName",
            key: "groupName",
        },
        {
            title: "Companies",
            key: "companies",
            render: (record: GroupData) => (
                <Dropdown overlay={getCompanyMenu(record.erpCompanyData)} trigger={["click"]}>
                    <Button type="link">
                        {record.erpCompanyData.length} Companies <DownOutlined />
                    </Button>
                </Dropdown>
            ),
        },
        {
            title: "Group Class",
            dataIndex: "groupClass",
            key: "groupClass",
            render: () => "Group Class",
        },
        {
            title: "Financial Year",
            dataIndex: "financialYear",
            key: "financialYear",
        },
        {
            title: "Currency",
            dataIndex: "currencyName",
            key: "currencyName",
        },
        {
            title: "Transfer Ownership",
            key: "transferOwnership",
            render: (record: GroupData) => ("-"),
        },
        {
            title: "Action",
            key: "action",
            render: (record: GroupData) => (
                <>
                    <Button type="link" onClick={() => {
                        setIsDrawerVisible(true);
                        setEditGroupData(record)
                    }}><EditOutlined /></Button>
                    <Button type="link"><CopyOutlined /></Button>
                </>
            ),
        },
    ];
    return (
        <Table dataSource={groupData} columns={Groupcolumns} rowKey="id" />
    )
}
